﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualBasic;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                bool flag = true;
                while (flag)
                {
                    App.ShowMenu();
                    switch (Console.ReadKey().Key)
                    {
                        case ConsoleKey.Q:
                            App.Task1();
                            break;
                        case ConsoleKey.W:
                            App.Task2();
                            break;
                        case ConsoleKey.Escape:
                            flag = false;
                            break;
                    }
                }
            }
            catch (MyException ex)
            {
                Interaction.MsgBox($"{ex.Message}", MsgBoxStyle.Critical);
            }
        }
    }
}
