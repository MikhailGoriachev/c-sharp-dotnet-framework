﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{


    //В массиве треугольников (не менее 10 элементов) выполнить сортировку:
    //-по убыванию периметров
    //-по возрастанию площадей

    class App
    {
        static Random rand = new Random();
        private static double RandomDbl(double lo, double hi) 
            => lo + (hi - lo) * rand.NextDouble();

        static public void Task1()
        {
            Triangle[] triangles = {
                new Triangle(RandomDbl(1,7),RandomDbl(1,7),RandomDbl(1,7)),
                new Triangle(RandomDbl(1,7),RandomDbl(1,7),RandomDbl(1,7)),
                new Triangle(RandomDbl(1,7),RandomDbl(1,7),RandomDbl(1,7)),
                new Triangle(RandomDbl(1,7),RandomDbl(1,7),RandomDbl(1,7)),
                new Triangle(RandomDbl(1,7),RandomDbl(1,7),RandomDbl(1,7)),
                new Triangle(RandomDbl(1,7),RandomDbl(1,7),RandomDbl(1,7)),
                new Triangle(RandomDbl(1,7),RandomDbl(1,7),RandomDbl(1,7)),
                new Triangle(RandomDbl(1,7),RandomDbl(1,7),RandomDbl(1,7)),
                new Triangle(RandomDbl(1,7),RandomDbl(1,7),RandomDbl(1,7)),
                new Triangle(RandomDbl(1,7),RandomDbl(1,7),RandomDbl(1,7)),
            };

            Console.Clear();

            Console.SetCursorPosition(30, 1);
            Console.WriteLine("Ваш массив треугольников");
            Console.ForegroundColor = ConsoleColor.Blue;
            Array.ForEach(triangles, Console.WriteLine);
            Console.ForegroundColor = ConsoleColor.White;


            Console.SetCursorPosition(27, 14);
            Array.Sort(triangles, (Triangle a, Triangle b) => b.GetP().CompareTo(a.GetP()));
            Console.WriteLine("Сортировка по убыванию периметров");
            Console.ForegroundColor = ConsoleColor.Blue;
            Array.ForEach(triangles, Console.WriteLine);
            Console.ForegroundColor = ConsoleColor.White;

            Console.SetCursorPosition(27, 27);
            Array.Sort(triangles, (Triangle a, Triangle b) => a.GetS().CompareTo(b.GetS()));
            Console.WriteLine("Сортировка по возрастанию площадей");
            Console.ForegroundColor = ConsoleColor.Blue;
            Array.ForEach(triangles, Console.WriteLine);
            Console.ForegroundColor = ConsoleColor.White;

            Console.ReadKey();
            Console.Clear();
        }
        static public void Task2()
        {
            Console.Clear();

            Room[] rooms =
            {
                new Room(RandomDbl(5,15),RandomDbl(2.7,4d),rand.Next(1,3)),
                new Room(RandomDbl(5,15),RandomDbl(2.7,4d),rand.Next(1,3)),
                new Room(RandomDbl(5,15),RandomDbl(2.7,4d),rand.Next(1,3)),
                new Room(RandomDbl(5,15),RandomDbl(2.7,4d),rand.Next(1,3)),
                new Room(RandomDbl(5,15),RandomDbl(2.7,4d),rand.Next(1,3)),
                new Room(RandomDbl(5,15),RandomDbl(2.7,4d),rand.Next(1,3)),
                new Room(RandomDbl(5,15),RandomDbl(2.7,4d),rand.Next(1,3)),
                new Room(RandomDbl(5,15),RandomDbl(2.7,4d),rand.Next(1,3)),
                new Room(RandomDbl(5,15),RandomDbl(2.7,4d),rand.Next(1,3)),
                new Room(RandomDbl(5,15),RandomDbl(2.7,4d),rand.Next(1,3))

            };


            Console.SetCursorPosition(30, 1);
            Console.WriteLine("Ваш массив комнат");
            Console.ForegroundColor = ConsoleColor.Blue;
            Array.ForEach(rooms, Console.WriteLine);
            Console.ForegroundColor = ConsoleColor.White;


            Console.SetCursorPosition(27, 14);
            Array.Sort(rooms, (Room a, Room b) => b.Square.CompareTo(a.Square));
            Console.WriteLine("Сортировка по убыванию площади");
            Console.ForegroundColor = ConsoleColor.Blue;
            Array.ForEach(rooms, Console.WriteLine);
            Console.ForegroundColor = ConsoleColor.White;

            Console.SetCursorPosition(27, 27);
            Array.Sort(rooms, (Room a, Room b) => a.Windows.CompareTo(b.Windows));
            Console.WriteLine("Сортировка по возрастанию количества окон");
            Console.ForegroundColor = ConsoleColor.Blue;
            Array.ForEach(rooms, Console.WriteLine);
            Console.ForegroundColor = ConsoleColor.White;

            Console.ReadKey();
            Console.Clear();
        }
        static public void ShowMenu()
        {
            Console.CursorVisible = false;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.SetCursorPosition(5, 5);
            Console.Write("Task 1 - Q");
            Console.SetCursorPosition(5, 6);
            Console.Write("Task 2 - W");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
