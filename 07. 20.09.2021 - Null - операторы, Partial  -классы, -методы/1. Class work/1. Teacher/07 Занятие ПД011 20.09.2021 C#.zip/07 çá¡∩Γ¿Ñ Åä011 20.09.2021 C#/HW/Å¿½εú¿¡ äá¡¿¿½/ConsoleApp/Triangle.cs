﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Triangle
    {
        private double _a;
        private double _b;
        private double _c;

        public Triangle() { _a = 1d; _b = 1d; _c = 1d; }
        public Triangle(double a, double b, double c)
        {
            A = a;
            B = b;
            C = c;
        }

        //свойство типа кортеж для задания трех сторон
        public (double, double, double) ABC
        {
            get { return (_a, _b, _c); }
            set { A = value.Item1; B = value.Item2; C = value.Item2; }
        }
        //cвойства полей класса
        public double A
        {
            get { return _a; }
            set { _a = (value > 0) ? value 
                    : throw new MyException($"A: недопустимо отрицательное значение {value}!");; ; }
        }
        public double B
        {
            get { return _b; }
            set
            {
                _b = (value > 0) ? value
                  : throw new MyException($"B: недопустимо отрицательное значение {value}!");
            }
        }
        public double C
        {
            get { return _c; }
            set
            {
                _c = (value > 0) ? value
                  : throw new MyException($"C: недопустимо отрицательное значение {value}!");
            }
        }
        //площадь треугольника
        public double GetS()
        {
            double p = GetP() / 2;
            return Math.Sqrt(p * (p - _a) * (p - _b) * (p - _c));
        }
        //периметр треугольника
        public double GetP() => _a + _b + _c;
        //медиана треугольника
        public double GetMedian() => Math.Sqrt((2 * _a * _a + 2* _b * _b - _c *_c)/4);

        public override string ToString() => 
            $"\tСторона А {_a,5:f2}, сторона В {_b,5:f2}, сторона С {_c,5:f2}, периметр {GetP(),5:f2}, площадь {GetS(),5:f2}";
    }
}
