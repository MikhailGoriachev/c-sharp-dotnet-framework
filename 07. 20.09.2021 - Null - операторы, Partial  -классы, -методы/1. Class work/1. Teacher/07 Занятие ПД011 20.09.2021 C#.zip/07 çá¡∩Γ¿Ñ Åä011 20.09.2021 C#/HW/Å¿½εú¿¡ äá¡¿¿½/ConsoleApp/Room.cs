﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Room
    {
        private double _square;
        private double _height;
        private int _windows;

        public Room(double square, double height, int windows)
        {
            Windows = windows;
            Height = height;
            Square = square;
        }

        public int Windows
        {
            get { return _windows; }
            set { _windows = (value > 0) ? value :
                    throw new MyException($"Неверное значение количества окон команты {value}!");
            }
        }
        public double Height
        {
            get { return _height; }
            set { _height = (value > 0) ? value :
                    throw new MyException($"Неверное значение высоты потолков команты {value}!");}
        }
        public double Square
        {
            get { return _square; }
            set { _square = (value > 0) ? value :
                    throw new MyException($"Неверное значение площади команты {value}!"); }
        }

        public double GetV() => _square * _height;

        public override string ToString()
        {
            return $"\tПлощадь {_square, 5:f2}, объем {GetV(),4:f2}, высота потолков {_height,4:f2}, количество окон {_windows}";
        }
    }
}
