﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* 
 * Разработайте консольное приложение для решения следующих задач. Используйте 
 * простое меню для выбора заданий по обработке. При ошибках в выполняемых 
 * заданиях обрабатывайте исключения.
 * 
 * Задача 1. 
 * Описать класс, представляющий треугольник. Предусмотреть методы для создания
 * объектов (конструкторы), вычисления площади, периметра и длин медиан, 
 * проверки возможности создания треугольника.
 * Описать свойство типа кортеж для задания трех сторон. При невозможности 
 * построения треугольника выбрасывается исключение. Описать свойства для 
 * получения сторон треугольника.
 * Разработайте собственный класс исключения, унаследованный от класса 
 * Exception. Передавать в исключение: сообщении об ошибке, значения для 
 * сторон. 
 * В массиве треугольников (не менее 10 элементов) выполнить сортировку: 
 *     • по убыванию периметров
 *     • по возрастанию площадей
 * 
 * Задача 2. 
 * Описать класс, содержащий сведения о площади комнаты, высоте потолков и 
 * количестве окон. Описать методы вычисления объема комнаты и свойства для 
 * задания и получения состояния объекта. В случае недопустимых значений 
 * свойств выбрасывается исключение – класс, унаследованный от Exception. 
 * Исключению передавать сообщение об ошибке и значение, приведшее к выбросу
 * исключения.
 * В массиве комнат (не менее 10и элементов) выполнить сортировку:
 *     • по убыванию площади
 *     • по возрастанию количества окон
 *
 */
namespace ExceptionIntro
{
    class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 20.09.2021 - введение в обработку исключений";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Демонстрация исключений для модели треугольника" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Формирование массива треугольников для обработки по заданию" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Вывод массива треугольников" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Упорядочить массив треугольников по убыванию периметров" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Упорядочить массив треугольников по возрастанию площадей" },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Демонстрация исключений для модели комнаты хостела" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Формирование данных хостела" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Вывод данных о комнатах хостела" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Упорядочить комнаты хостела по убыванию площадей" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Упорядочить комнаты хостела по возрастанию количества окон" },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - исключения, классы, свойства, массивы объектов");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1
                        // Демонстрация исключений для модели треугольника
                        case ConsoleKey.Q:
                            app.TriangleDemoExceptions();
                            break;

                        // Формирование массива треугольников для обработки по заданию
                        case ConsoleKey.W:
                            app.TrianglesInitialize();
                            break;


                        // Вывод массива треугольников
                        case ConsoleKey.E:
                            app.TrianglesShow();
                            break;

                        // Упорядочить массив треугольников по убыванию периметров
                        case ConsoleKey.R:
                            app.TrianglesOrderByPerimeterDesc();
                            break;

                        // Упорядочить массив треугольников по возрастанию площадей
                        case ConsoleKey.T:
                            app.TrianglesOrderByArea();
                            break;

                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 2

                        // Демонстрация исключений для модели комнаты хостела
                        case ConsoleKey.A:
                            app.HostelDemoException();
                            break;

                        // Формирование данных хостела
                        case ConsoleKey.S:
                            app.HostelInitialize();
                            break;

                        // Вывод данных о комнатах хостела
                        case ConsoleKey.D:
                            app.HostelShow();
                            break;

                        // Упорядочить комнаты хостела по убыванию площадей
                        case ConsoleKey.F:
                            app.HostelOrderByAreaDesc();
                            break;

                        // Упорядочить комнаты хостела по возрастанию количества окон
                        case ConsoleKey.G:
                            app.HostelOrderByWindowsAmount();
                            break;


                        // Выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try
                
                catch (TriangleException ex) {
                    string msg = $"{ex.Message}\n{ex.Sides.A:f2};{ex.Sides.B:f2};{ex.Sides.C:f2}";
                    MessageBox.Show(msg, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                catch (InvalidRoomParameterException ex) {
                    string msg = $"{ex.Message}\nПараметры: {ex.Area:f2};{ex.CeilingHeight:f2};{ex.WindowsNumber}";
                    MessageBox.Show(msg, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                catch (Exception ex) {
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                } // try-catch


            } // while
        } // Main
    }
}
