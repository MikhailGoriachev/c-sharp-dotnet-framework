﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionIntro
{
    /*
     * Класс исключения, унаследованный от класса Exception. Передавать 
     * в исключение: сообщении об ошибке, значения для сторон. 
     *
     */

    [Serializable]
    public class TriangleException : Exception
    {
        // параметры, вызвавшие ошибку
        public (double A, double B, double C) Sides { get; private set; }

        public TriangleException() { }
        
        public TriangleException(string message) : base(message) { }

        // конструктор по заданию
        public TriangleException(string message, (double A, double B, double C) sides) : base(message) { 
            Sides = sides;
        } // TriangleException

        public TriangleException(string message, Exception inner) : base(message, inner) { }
        
        protected TriangleException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
