﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionIntro
{
    /* 
     * Класс, представляющий треугольник. Предусмотреть методы для создания
     * объектов (конструкторы), вычисления площади, периметра и длин медиан, 
     * проверки возможности создания треугольника.
     * Описать свойство типа кортеж для задания трех сторон. При невозможности 
     * построения треугольника выбрасывается исключение. Описать свойства для 
     * получения сторон треугольника.
     *
     */
    public class Triangle
    {
        // стороны треугольника
        private double _a;
        private double _b;
        private double _c;

        // свойство для задания длин треугольника
        public (double A, double B, double C) Sides {
            get => (_a, _b, _c);
            set {
                if (!IsTriangle(value.A, value.B, value.C))
                    throw new TriangleException(
                        "Некорректные параметры для сторон треугольника",
                        value);

                _a = value.A; _b = value.B; _c = value.C;
            }
        } // Sides


        // проверка возможности создания треугольника
        public static bool IsTriangle(double a, double b, double c) =>
            a + b > c && a + c > b && b + c > a;

        // Свойства для доступа к сторонам

        // конструкторы
        public Triangle() : this(1d) { }

        // равносторонние
        public Triangle(double a) : this(a, a, a) { }

        // равнобедренные треугольники
        public Triangle(double a, double b) : this(a, b, b) { }

        // разносторонние треугольники
        public Triangle(double a, double b, double c) {
            if (!IsTriangle(a, b, c))
                throw new TriangleException("Невозможно создать треугольник со сторонами", (a, b, c));

            Sides = (a, b, c);
        } // Triangle

        // вычисление периметра
        public double Perimeter() => _a * _b + _c;

        // вычисление площади
        public double Area() {
            double p = Perimeter() / 2;  // полупериметр
            double area = Math.Sqrt(p * (p - _a) * (p - _b) * (p - _c));
            return area;
        } // Area

        public (double MedianA, double MedianB, double MedianC) Medians() {
            double CalcMedian(double a, double b, double c) =>
                0.5 * Math.Sqrt(2 * (b * b + c * c) - a * a);

            return (CalcMedian(_a, _b, _c), CalcMedian(_b, _a, _c), CalcMedian(_c, _a, _b));
        } // Medians

        // Вывод строкового представления объекта
        public override string ToString() => $"a: {_a:f3}; b: {_b:f3}; c: {_c:f3}";

        // формирование строки таблицы для представления объекта 
        public string ToTableRow(int rowNumber) {
            var medians = Medians();
            return $"│ {rowNumber,3} │ {_a, 10:f3} │ {_b, 10:f3} │ {_c, 10:f3} " +
            $"│ {medians.MedianA,10:f3} │ {medians.MedianB,10:f3} │ {medians.MedianC,10:f3} " +
            $"│ {Perimeter(), 12:f3} │ {Area(), 12:f3} │";
        } // ToTableRow

        // статический метод для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬────────────┬────────────┬────────────┬────────────┬────────────┬────────────┬──────────────┬──────────────┐\n" +
                $"{spaces}│  №  │   Сторона  │   Сторона  │   Сторона  │  Медиана   │  Медиана   │  Медиана   │   Периметр   │    Площадь   │\n" +
                $"{spaces}│ п/п │      A     │      B     │      C     │  стороны A │  стороны B │  стороны C │ треугольника │ треугольника │\n" +
                $"{spaces}├─────┼────────────┼────────────┼────────────┼────────────┼────────────┼────────────┼──────────────┼──────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴────────────┴────────────┴────────────┴────────────┴────────────┴────────────┴──────────────┴──────────────┘";

        // компаратор для сортировки по убыванию периметров
        public static int PerimeterDescComparator(Triangle t1, Triangle t2) =>
            t2.Perimeter().CompareTo(t1.Perimeter());

        // компаратор для сортировки по возрастанию площадей
        public static int AreaComparator(Triangle t1, Triangle t2) =>
            t1.Area().CompareTo(t2.Area());


        // Фабрика создания треугольника со случайными сторонами
        public static Triangle Generate() {
            // генерация сторон треугольника
            double a, b, c;
            
            do {
                a = Utils.GetRandom(1d, 20d);
                b = Utils.GetRandom(1d, 20d);
                c = Utils.GetRandom(1d, 20);
            } while (!Triangle.IsTriangle(a, b, c));

            return new Triangle { Sides = (a, b, c) };
        } // Generate
    } // class Triangle
}
