﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionIntro
{
    /* 
     * В случае недопустимых значений свойств комнаты (класс Room) 
     * выбрасывается исключение – класс, унаследованный от Exception. 
     * Исключению передавать сообщение об ошибке и значение, приведшее 
     * к выбросу исключения. 
     */
    [System.Serializable]
    public class InvalidRoomParameterException : Exception
    {
        // параметры комнаты, вызвававшие ошибку
        public double Area { get; private set; }
        public double CeilingHeight { get; private set; }
        public int WindowsNumber { get; private set; }

        public InvalidRoomParameterException() { }
        
        public InvalidRoomParameterException(string message) : base(message) { }
        
        // конструктор по заданию
        public InvalidRoomParameterException(string message, 
            (double Area, double CeilingHeight, int WindowsNumber) data) : base(message) {
            Area = data.Area;
            CeilingHeight = data.CeilingHeight;
            WindowsNumber = data.WindowsNumber;
        }

        public InvalidRoomParameterException(string message, Exception inner) : base(message, inner) { }
        protected InvalidRoomParameterException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    } // class InvalidRoomParameterException
}
