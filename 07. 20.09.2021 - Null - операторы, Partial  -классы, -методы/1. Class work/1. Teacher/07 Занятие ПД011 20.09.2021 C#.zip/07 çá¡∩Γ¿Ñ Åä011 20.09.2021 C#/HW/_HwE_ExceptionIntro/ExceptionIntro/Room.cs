﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionIntro
{
    /* 
     * Класс,  содержащий  сведения  о  площади  комнаты, высоте потолков и 
     * количестве окон. Описать методы вычисления объема комнаты и свойства
     * для задания и получения состояния объекта. 
     * В случае недопустимых значений свойств выбрасывается исключение – класс,
     * унаследованный от Exception. 
     * Исключению передавать сообщение об ошибке и значение, приведшее к выбросу
     * исключения.
     *
     */
    public class Room
    {
        // площадь комнаты, м2
        private double _area;

        public double Area {
            get => _area; 
            set {
                if (value < 6.3)
                    throw new InvalidRoomParameterException("Недопустимая площадь комнаты", (value, _ceilingHeight, _windowsNumber));

                _area = value; 
            } // set
        } // Area

        // высота потолка, в см
        private double _ceilingHeight;

        public double CeilingHeight {
            get { return _ceilingHeight; }
            set {
                if (value < 250)
                    throw new InvalidRoomParameterException("Недопустимая высота потолка", (_area, value, _windowsNumber));

                _ceilingHeight = value;
            }
        } // CeilingHeight

        // количество окон
        private int _windowsNumber;

        public int WindowsNumber {
            get { return _windowsNumber; }
            set {
                if (value < 0)
                    throw new InvalidRoomParameterException("Недопустимое количество окон", (_area, _ceilingHeight, value));

                _windowsNumber = value;
            }
        } // WindowsNumber

        // методы класса
        // Вычисление объема комнаты, учтем, что высота потолка в см - переведем высоту в метры
        public double CalcVolume() => _area * (_ceilingHeight / 100);

        public override string ToString() => $"Площадь комнаты {_area} м2, высота потолка {_ceilingHeight} см, " +
            $"окон в комнате: {_windowsNumber}";

        // формирование строки таблицы для представления объекта 
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_area, 11:f2} │ {_ceilingHeight, 11:f2} │ {_windowsNumber, 10} │";

        // статический метод для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬─────────────┬─────────────┬────────────┐\n" +
                $"{spaces}│  №  │   Площадь   │   Высота    │ Количество │\n" +
                $"{spaces}│ п/п │ комнаты, м2 │ потолка, см │    окон    │\n" +
                $"{spaces}├─────┼─────────────┼─────────────┼────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴─────────────┴─────────────┴────────────┘";


        // компаратор для сортировки по убыванию площади
        public static int AreaDescComparator(Room r1, Room r2) =>
            r2._area.CompareTo(r1._area);

        // компаратор для сортировки по возрастанию количества окон
        public static int WindowsNumberComparator(Room r1, Room r2) =>
            r1._windowsNumber.CompareTo(r2._windowsNumber);    

    } // class Room
}
