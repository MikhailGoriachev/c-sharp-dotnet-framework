﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionIntro
{
    // Класс, хранящий массив комнат - модель хостела :)
    public class Hostel
    {
        public string Name { get; set; }   // название хостела 
        private Room[] _rooms;              // коллекция комнат хостела

        public Hostel():this("Отдых у моря", new Room[10]) {
            Initializer();
        } //Hostel

        public Hostel(string name, Room[] rooms) {
            Name = name;
            _rooms = rooms; 
        } // Hostel

        // проверка массива на пустоту
        public bool Empty => _rooms.Length == 0;


        // формирование массива комнат
        public void Initializer() {
            int n = _rooms.Length;
            for (int i = 0; i < n; i++) {
                double area = Utils.GetRandom(50d, 120d);
                double ceilingHeight = Utils.GetRandom(250d, 340d);
                int windowsNumber = Utils.Random.Next(1, 5);

                _rooms[i] = new Room { Area = area, CeilingHeight = ceilingHeight, WindowsNumber = windowsNumber};
            } // for i
        } // Initializer


        // сортировка массива комнат по убыванию площади
        public void OrderByAreaDesc() => Array.Sort(_rooms, Room.AreaDescComparator);

        // сортировка массива комнат по возрастанию количества окон
        public void OrderByWindowsNumber() => Array.Sort(_rooms, Room.WindowsNumberComparator);


        // Вывести данные хостела в консоль
        public void Show(string caption, int indent) {
            // вывод заголовка таблицы данных хостела
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Name}\n" +
                              $"{Room.Header(indent)}");

            // вывод всех элементов массива комнат
            int row = 1;
            void OutItem(Room r) => Console.WriteLine($"{space}{r.ToTableRow(row++)}");
            Array.ForEach(_rooms, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Room.Footer(indent));
        } // Show
    } // class Hostel
}
