﻿using System;

namespace ExceptionIntro
{

    // Объекты и методы для обработки по заданию
    public class App {
        // объекты для обработки
        private Tiles  _tiles;
        private Hostel _hostel;

        public App():this(new Tiles(), new Hostel()) { }
        public App(Tiles tiles, Hostel hostel) {
            _tiles = tiles;
            _hostel = hostel;
        } // App

        // --------------------------------------------------

        // Демонстрация исключений для модели треугольника
        public void TriangleDemoExceptions() {
            Utils.ShowNavBarTask("   Демонстрация исключений для модели треугольника");

            Triangle t = new Triangle { Sides = 
                (Utils.GetRandom(-10d, 10d), Utils.GetRandom(-10d, 10d), Utils.GetRandom(-10d, 10d))
            };

            Console.WriteLine($"\n\n\n\n\t    {t}\n\n\n");
        } // TriangleDemoExceptions


        // Формирование массива треугольников для обработки по заданию
        public void TrianglesInitialize() {
            Utils.ShowNavBarTask("   Формирование массива треугольников для обработки по заданию");

            _tiles.Initializer();
            _tiles.Show("Данные по треугольникам сформированы", 12);
        } // TrianglesInitialize


        // Вывод массива треугольников
        public void TrianglesShow() {
            Utils.ShowNavBarTask("   Вывод массива треугольников");

            if (_tiles.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _tiles.Show("Данные для обработки по заданию на 20.09.2021", 12);
        } // TrianglesShow


        // Упорядочить массив треугольников по убыванию периметров
        public void TrianglesOrderByPerimeterDesc() {
            Utils.ShowNavBarTask("   Упорядочить массив треугольников по убыванию периметров");

            if (_tiles.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _tiles.OrderByPerimeterDesc();
            _tiles.Show("Массиы треугольников упорядочен по убыванию периметров", 12);
        } // TrianglesOrderByPerimeterDesc       


        // Упорядочить массив треугольников по возрастанию площадей
        public void TrianglesOrderByArea() {
            Utils.ShowNavBarTask("   Упорядочить массив треугольников по возрастанию площадей");

            if (_tiles.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _tiles.OrderByArea();
            _tiles.Show("Массиы треугольников упорядочен по возрастанию площадей", 12);
        } // TrianglesOrderByArea

        // --------------------------------------------------

        // Демонстрация исключений для модели комнаты хостела
        public void HostelDemoException() {
            Utils.ShowNavBarTask("   Демонстрация исключений для модели комнаты хостела");

            Room r = new Room {
                Area = Utils.GetRandom(-10d, 10d), 
                CeilingHeight = Utils.GetRandom(-10d, 10d), 
                WindowsNumber = Utils.Random.Next(-10, 10)
            };

            Console.WriteLine($"\n\n\n\n\t    {r}\n\n\n");
        } // HostelDemoException


        // Формирование данных хостела
        public void HostelInitialize() {
            Utils.ShowNavBarTask("   Формирование данных хостела");

            _hostel.Initializer();
            _hostel.Show("Данные о хостеле сформированы", 12);
        } // HostelInitialize


        // Вывод данных о комнатах хостела
        public void HostelShow() {
            Utils.ShowNavBarTask("   Вывод данных о комнатах хостела");

            if (_hostel.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _hostel.Show("Данные о хостеле для обработки", 12);
        } // HostelShow


        // Упорядочить комнаты хостела по убыванию площадей
        public void HostelOrderByAreaDesc() {
            Utils.ShowNavBarTask("   Упорядочить комнаты хостела по убыванию площадей");

            if (_hostel.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _hostel.OrderByAreaDesc();
            _hostel.Show("Комнаты хостела упорядоченные по убыванию площадей", 12);
        } // HostelOrderByAreaDesc


        // Упорядочить комнаты хостела по возрастанию количества окон
        public void HostelOrderByWindowsAmount() {
            Utils.ShowNavBarTask("   Упорядочить комнаты хостела по возрастанию количества окон");

            if (_hostel.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _hostel.OrderByWindowsNumber();
            _hostel.Show("Комнаты хостела упорядоченные по возрастанию количества окон", 12);
        } // HostelOrderByWindowsAmount

    } // class App
}