﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionIntro
{
    /* 
      * В массиве треугольников (не менее 10 элементов) выполнить сортировку: 
      *     • по убыванию периметров
      *     • по возрастанию площадей
     */
    public class Tiles
    {
        public string Name { get; set; }  // название набора заготовок
        private Triangle[] _triangles;    // массив заготовок

        public Tiles() : this("Заготовки для изделий", new Triangle[10])
        {
            Initializer();
        } //Tiles

        public Tiles(string name, Triangle[] triangles)
        {
            Name = name;
            _triangles = triangles;
        } // Tiles

        // проверка массива на пустоту
        public bool Empty => _triangles.Length == 0;

        // формирование массива треугольников
        public void Initializer()
        {
            int n = _triangles.Length;
            for (int i = 0; i < n; i++) {
                _triangles[i] = Triangle.Generate();
            } // for i
        } // Initializer


        // сортировка массива треугольников по убыванию периметров
        public void OrderByPerimeterDesc() => Array.Sort(_triangles, Triangle.PerimeterDescComparator);

        // сортировка массива треугольников по возрастанию площадей
        public void OrderByArea() => Array.Sort(_triangles, Triangle.AreaComparator);


        // Вывести данные треугольников/заготовок в консоль
        public void Show(string caption, int indent) {
            // вывод заголовка таблицы данных заготовок
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Name}\n" +
                              $"{Triangle.Header(indent)}");

            // вывод всех элементов массива треугольников
            int row = 1;
            void OutItem(Triangle t) => Console.WriteLine($"{space}{t.ToTableRow(row++)}");
            Array.ForEach(_triangles, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Triangle.Footer(indent));
        } // Show
    } // class Tiles
}
