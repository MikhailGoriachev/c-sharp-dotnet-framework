﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HWOOP
{
    public class RoomArray
    {
        private RoomInfo[] _rooms;
        public RoomInfo[] Room { get=>_rooms; set=>_rooms = value; }


        public RoomArray():this(new RoomInfo[10]) { }
        public RoomArray(RoomInfo[] rooms)
        {
            _rooms = rooms; 
        }

        //инцилизация
        public void Init()
        {
            _rooms = new []
            {
                new RoomInfo{square = 12.4,height = 2.10,windowcount = 1},
                new RoomInfo{square = 5d,height= 1.9,windowcount  = 0 },
                new RoomInfo{square = 10d,height = 2d,windowcount = 2},
                new RoomInfo{square = 15.3,height = 2.6,windowcount = 1},
                new RoomInfo{square = 7.5,height = 1.86,windowcount = 0},
                new RoomInfo{square = 11.13,height = 2d,windowcount =3},
                new RoomInfo{square = 20.1,height = 3d,windowcount =4},
                new RoomInfo{square = 9.2,height = 2d,windowcount = 1},
                new RoomInfo{square = 6.4,height = 1.87,windowcount = 0},
                new RoomInfo{square = 16.2,height = 2.76,windowcount = 5}
            };
        }

        public void Show(string caption, int indent)
        {
            // вывод заголовка таблицы 
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}\n" +
                              $"{RoomInfo.Header(indent)}");

            // вывод всех элементов массива 
            int row = 1;
            void OutItem(RoomInfo r) => Console.WriteLine($"{space}{r.ToTableRow(row++)}");
            Array.ForEach(_rooms, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(RoomInfo.Footers(indent));
        } // Show

        // сортировка массива  по убыванию площади
        public void OrderBySquare() => Array.Sort(_rooms,RoomInfo.SquareComp);

        // cортировка массива по возрастанию кол-ва окон

        public void OrderByWindow() => Array.Sort(_rooms, RoomInfo.WindowComp);

    }

    
}
