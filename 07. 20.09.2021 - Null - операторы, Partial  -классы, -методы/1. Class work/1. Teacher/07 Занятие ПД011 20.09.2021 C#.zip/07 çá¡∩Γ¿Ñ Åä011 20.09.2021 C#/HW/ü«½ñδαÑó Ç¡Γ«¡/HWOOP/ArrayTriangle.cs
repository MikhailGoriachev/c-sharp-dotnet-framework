﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HWOOP
{
    public class ArrayTriangle
    {
        private Triangle[] _triangles;
        public Triangle[] triangle
        {
            get => _triangles;
            set => _triangles = value;
        }
        

        //конструкторы
        public ArrayTriangle() : this(new Triangle[10]) {
             Init();
        }
        public ArrayTriangle(Triangle[] triangles)
        {
            _triangles = triangles;
        }


        //инициилизация массива
      public void Init()
      {
           _triangles = new[]
           {
              new Triangle{Sides = (2.4,3.45,4.25)},
              new Triangle{Sides = (3.23,5.45,6.25)},
              new Triangle{Sides = (1.10,1.25,3.10)},
              new Triangle{Sides = (4d,4d,3d)},
              new Triangle{Sides = (2.45,3d,5d)},
              new Triangle{Sides = (4.5,4.67,5.04)},
              new Triangle{Sides = (10d,11d,14d)},
              new Triangle{Sides = (1d,1.23,2d)},
              new Triangle{Sides = (2.05,2.37,3.15)},
              new Triangle{Sides = (1.5,1.67,3.05)}
   
          };
      }

      
        public void Show(string caption, int indent)
        {
            // вывод заголовка таблицы 
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}\n" +
                              $"{Triangle.Header(indent)}");

            // вывод всех элементов массива 
            int row = 1;
            void OutItem(Triangle p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(_triangles, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Triangle.Footer(indent));
        } // Show

        // сортировка массива  по убыванию периметра
         public void OrderByPerimeter() => Array.Sort(_triangles, Triangle.PerimeterComp);

        // cортировка массива по возрастанию площади

        public void OrderBySquare() => Array.Sort(_triangles, Triangle.SquareComp);

    }
}
