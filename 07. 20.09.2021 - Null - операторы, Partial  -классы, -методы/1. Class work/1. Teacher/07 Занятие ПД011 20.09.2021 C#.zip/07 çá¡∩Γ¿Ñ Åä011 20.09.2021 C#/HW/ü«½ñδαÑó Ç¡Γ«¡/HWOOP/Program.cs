﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HWOOP
{
    class Program
    {
        static void Main(string[] args)
        {
            //меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Инициилизация и вывод массива треугольников" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Сортировка массива треугольников по убыванию периметра" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Сортировка массива треугольников по возрастанию площади" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Инициилизация и вывод массива комнат" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Сортировка массива комнат по убыванию площади" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Сортировка массива комнат по возрастанию кол-ва оконо" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };
            App app = new App();

            // главный цикл приложения
            while (true)
            {
                // настройка цветового оформления
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.Clear();
                Console.CursorVisible = false;

                ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);
                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                Console.Clear();

                switch (key)
                {
                    // ------------------------------------------------------------
                    // пункты меню, относящиеся к задаче 1
                    // Инициилизация и вывод массива треугольников
                    case ConsoleKey.Q:
                        app.Initialize();
                        break;

                    // Сортировка массива треугольников по убыванию периметра
                    case ConsoleKey.W:
                        app.PerimeterSort();
                        break;


                    // Сортировка массива треугольников по возрастанию площади
                    case ConsoleKey.A:
                        app.SquareSort();
                        break;

                    // Инициилизация и вывод массива комнат
                    case ConsoleKey.S:
                        app.Init();
                        break;

                    //Вывод самолетов с максимальным количеством пассажиров
                    case ConsoleKey.D:
                        app.SquareComp();
                        break;

                    //Сортировка массива комнат по убыванию площади
                    case ConsoleKey.F:
                        app.WindowsComp();
                        break;
                    // выход из приложения назначен на клавишу F10 или кавишу Z
                    case ConsoleKey.F10:
                    case ConsoleKey.Z:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                       
                        Console.CursorVisible = true;
                        return;

                    default:
                        continue;
                } // switch

                // Ожидать нажатия любой клавиши по окончании работы пункта меню
                Console.CursorVisible = true;
                Console.ReadKey(true);
            } // while

        }
        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // Вывод меню приложения
        public static void ShowMenu(int x, int y, string title, MenuItem[] menu)
        {
            WriteXY(x, y, title, ConsoleColor.Gray);
            int offsetY = 2;

            foreach (var menuItem in menu)
            {
                WriteXY(x, y + offsetY, menuItem.HotKey.ToString(), ConsoleColor.Cyan);
                WriteXY(x + 2, y + offsetY++, menuItem.Text, ConsoleColor.Gray);
            } // foreach menuItem
        } // ShowMenu
    }
}
