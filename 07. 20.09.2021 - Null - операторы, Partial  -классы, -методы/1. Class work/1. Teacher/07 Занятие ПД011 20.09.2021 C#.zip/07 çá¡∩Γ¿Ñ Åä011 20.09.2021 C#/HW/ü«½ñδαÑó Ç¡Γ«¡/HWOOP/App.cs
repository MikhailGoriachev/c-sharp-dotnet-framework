﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HWOOP
{
    class App
    {
        private ArrayTriangle triangles; //обьект для треугольников
        private RoomArray rooms; //обьект для комнат

        public App(): this(new ArrayTriangle(),new RoomArray())
        {

            triangles.Init();
            rooms.Init();

        }

        public App(ArrayTriangle tr,RoomArray r)
        {
            triangles = tr;
            rooms = r;
        }


        //инициилазция и вывод массива треугольника
        public void Initialize()
        {


            triangles.Init();
            triangles.Show("Данные сформированы", 10);
        }


        //сортировка по периметру
        public void PerimeterSort()
        {
            triangles.OrderByPerimeter();
            triangles.Show("Отсортированый массив по периметру(по убыванию)", 10);
        }

        //сортировка по площади
        public void SquareSort()
        {
            triangles.OrderBySquare();
            triangles.Show("Остортированный массив по площади(по возрастанию)", 10);
        }
           

        //Инициилизация и вывод массива комнат
        public void Init()
        {
            rooms.Init();
            rooms.Show("Данные сформированы",10);
        }

        //сортировка по убыванию площади в массиве комнат
        public void SquareComp()
        {
            rooms.OrderBySquare();
            rooms.Show("Данне после сортировки по убыванию площади сформированны", 10);
        }

        public void WindowsComp() {

            rooms.OrderByWindow();
            rooms.Show("Данные после сортировки по возрастанию кол-ва оконо сформированны", 10);

        
        }
    }
}
