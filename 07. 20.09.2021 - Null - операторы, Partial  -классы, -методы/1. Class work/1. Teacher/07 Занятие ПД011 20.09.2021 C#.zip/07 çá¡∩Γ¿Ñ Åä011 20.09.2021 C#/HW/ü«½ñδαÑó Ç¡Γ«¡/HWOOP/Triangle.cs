﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HWOOP
{
    public class Triangle
    {
        private double _a;
        public double SideA
        {
            get => _a;

        }
        private double _b;

        public double SideB
        {
            get => _b;

        }

        private double _c;

        public double SideC
        {
            get => _c;

        }

        //Свойство для установки сторон треугольника
        public (double a, double b, double c) Sides { get => (_a, _b, _c); set {


                if (value.a <= 0 || value.b <= 0 || value.c <= 0)
                    throw new MyException("Неправильные данные для треугольника!");
                else
                {
                    _a = value.a;
                    _b = value.b;
                    _c = value.c;

                }

                
               

            }
        }

        //конструктор
        public Triangle():this((1, 1, 1)) { }
      public Triangle((double a, double b, double c) tuple)
     {
            //_a = tuple.a;
            //_b = tuple.b;
            //_c = tuple.c;
            Sides = tuple; 
      }
     
        public override string ToString() =>
            $"Side A: {_a}, Side B: {_b},Side C {_c},P {Perimeter():n2},S {Square():n2},M {Median():n2}";


        //метотд вычисления периметра треугольника
        public double Perimeter()
        {
            return _a + _b + _c;
        }


        //Площадь треугольника по формуле герона https://www.fxyz.ru/формулы_по_геометрии/формулы_площади/площадь_треугольника_формула_герона/
        public double Square()
        {
            double p = Perimeter() / 2; //полупериметр

            return Math.Sqrt(Math.Abs(p * (p - _a) * (p - _b) * (p - _c)));
        }
        

        //Медиана https://www.fxyz.ru/формулы_по_геометрии/плоские_фигуры/треугольник/медиана_треугольника/
        public double Median() => 0.5 * Math.Sqrt(2 * _b*_b + 2 * _c*_c - _a*_a); 
        
  

        //для сортировки периметра по убыванию
        public static int PerimeterComp(Triangle p1, Triangle p2) =>
            p2.Perimeter().CompareTo(p1.Perimeter());

        //для сортировки площадей по возрастанию
        public static int SquareComp(Triangle p1, Triangle p2) =>
            p1.Square().CompareTo(p2.Square());

        
        // формирование строки таблицы для представления объекта 
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {Square(),-18:n2} │ {Perimeter(),8}    " +
            $"│ {Median(),6:n2}     │ {_a,13:n2} │ {_b,13:n2} │ {_c,13:n2} │";

        // статический метод для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬────────────────────┬─────────────┬────────────┬───────────────┬───────────────┬───────────────┐\n" +
                $"{spaces}│  №  │ Площадь ,S         │ Периметр    │ Медиана    │ Сторона a     │ Сторона b     │ Cторона с     │\n" +
                $"{spaces}│ п/п │                    │ P           │ M          │               │               │               │\n" +
                $"{spaces}├─────┼────────────────────┼─────────────┼────────────┼───────────────┼───────────────┼───────────────┤\n";
            return str;
        } // Header


        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴────────────────────┴─────────────┴────────────┴───────────────┴───────────────┴───────────────┘";
    }
}
