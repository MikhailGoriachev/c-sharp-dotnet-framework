﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HWOOP
{
    public class RoomInfo
    {
        //площадь комнаты
        private double _square;
        public double square { get => _square; 
            set => _square = value <= 0 
                ? throw new MyException("Недопустимое значение для площади") 
                : value; }

        //высота потолков
        private double _height;
        public double height
        {
            get => _height;
            set => _height = value <= 1
                ? throw new MyException("Недопустимое значение для высоты потолков")
                : value;
        }

        //количество окон
        private int _windowcount;
        public int windowcount { get => _windowcount; set => _windowcount = value < 0 ? 
                throw new MyException("Недопустимое значение для кол-ва окон")
                : value;
        }

        //расчет обьема комнаты https://www.tproekt.com/obem-komnaty-kak-rasscitat-obem-komnaty/#i-6
        public double Volume()
        {

            return _height * _square;
        }


        //для сортировки по убыванию площади
        public static int SquareComp(RoomInfo r1, RoomInfo r2) =>
            r2._square.CompareTo(r1._square);

        //для сортировки по возрастанию кол-ва окон
        public static int WindowComp(RoomInfo r1, RoomInfo r2) =>
            r1._windowcount.CompareTo(r2._windowcount); 
        
        public override string ToString() =>
            $"Площадь: {_square:n2} ㎡, Обьем: {Volume():n2} ㎥,Высота {_height} м,Кол-во окон {_windowcount}";

        // формирование строки таблицы для представления объекта 
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_square,-17:n2} │ {Volume(),10}  " +
            $"│ {_height,6:n2}     │ {_windowcount,13:n2} │";

        // статический метод для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬───────────────────┬─────────────┬────────────┬───────────────┬\n" +
                $"{spaces}│  №  │ Площадь ,S        │ Обьем       │ Высота     │ Кол-во окон   │\n" +
                $"{spaces}│ п/п │                   │ V           │ потолков   │               │\n" +
                $"{spaces}├─────┼───────────────────┼─────────────┼────────────┼───────────────┼\n";
            return str;
        } // Header
        // статический метод для вывода подвала таблицы
        public static string Footers(int indent) =>
            $"{" ".PadRight(indent)}└─────┴───────────────────┴─────────────┴────────────┴───────────────┴";

    }
}
