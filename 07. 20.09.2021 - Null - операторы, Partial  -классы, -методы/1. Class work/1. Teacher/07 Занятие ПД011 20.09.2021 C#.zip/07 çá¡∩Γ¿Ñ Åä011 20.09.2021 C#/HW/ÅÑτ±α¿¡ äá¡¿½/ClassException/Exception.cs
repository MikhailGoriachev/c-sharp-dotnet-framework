﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace ClassExceptions
{
    [Serializable]
    class MyException : Exception
    {
        // дополнительные данные для обработки исключения
        private (double a, double b, double c) _value;

        public MyException() { }
        public MyException(string message) : base(message) { }

        public MyException(string message, (double a, double b, double c) value) : base(message)
        {
            _value= value;
            
        }
        public (double a, double b, double c) GetValue() => _value;
        public MyException(string message, Exception inner) : base(
            message, inner)
        {
        }
        protected MyException(
            SerializationInfo info,
            StreamingContext context) : base(info
            , context)
        
        { }

    }
}
