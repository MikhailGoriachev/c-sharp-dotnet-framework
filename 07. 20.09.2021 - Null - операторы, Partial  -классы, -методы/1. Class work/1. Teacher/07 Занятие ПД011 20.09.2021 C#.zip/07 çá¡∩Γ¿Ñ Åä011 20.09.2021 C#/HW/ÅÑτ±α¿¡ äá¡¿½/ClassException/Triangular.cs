﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExceptions
{
    public class Triangular
    {
        // кортеж сторон треугольников 
        private (double a, double b, double c) _sides;

        public double SideA => _sides.a;
        public double SideB => _sides.b;
        public double SideC => _sides.c;

        public (double a, double b, double c) Sides
        {
            get => _sides;
            set
            {
                var(a,b,c) = value;
                if (a < 0 || b <0 || c<0) 
                    throw new MyException("Значение не может быть меньше нуля", value);
                if (!(a + b > c && b + c > a && a + c > b))
                    throw new MyException("Треугольник не может быть создан", value);

                _sides = value;
                
            }// set
             
        }// Sides

        // периметр
        public double Perimetr() => _sides.a + _sides.b + _sides.c;

        // площадь
        public double Area()
        {
         double hP = Perimetr() / 2; // полупериметр

            return Math.Sqrt(hP*((hP - _sides.a)*(hP - _sides.b)*(hP - _sides.c)));

        }

        public double MedianA() => Math.Sqrt((2 * Math.Pow(_sides.b, 2)) + (2 * Math.Pow(_sides.c, 2)) - Math.Pow(_sides.a, 2)) / 2; 
        public double MedianB() => Math.Sqrt((2 * Math.Pow(_sides.a, 2)) + (2 * Math.Pow(_sides.c, 2)) - Math.Pow(_sides.b, 2)) / 2; 
        public double MedianC() => Math.Sqrt((2 * Math.Pow(_sides.a, 2)) + (2 * Math.Pow(_sides.b, 2)) - Math.Pow(_sides.c, 2)) / 2;

        // компаратор по убыванию периметров 
        public static int ComparatorPerimetr(Triangular x, Triangular y) => y.Perimetr().CompareTo(x.Perimetr());

        // компаратор по возрастанию площадей
        public static int CompatorArea(Triangular x, Triangular y) => x.Area().CompareTo(y.Area());
       
        public string ToTableRow() => $"| {SideA, 11:f2} | {SideB, 11:f} | {SideC, 14:f} | {Perimetr(), 11:f} | {Area(), 13:f} | {MedianA(), 10:f} |  {MedianB(), 9:f} | {MedianC(), 10:f} |"; 

    }
}
