﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 Задача 1. Описать класс, представляющий треугольник. 
Предусмотреть методы для создания объектов (конструкторы), 
вычисления площади, периметра и длин медиан, проверки 
возможности создания треугольника. Описать свойство типа кортеж для задания трех сторон. 
При невозможности построения треугольника выбрасывается исключение. 
Описать свойства для получения сторон треугольника.

Разработайте собственный класс исключения, унаследованный от класса Exception. Передавать в исключение: сообщении об ошибке, значения для сторон. 
В массиве треугольников (не менее 10 элементов) выполнить сортировку: 

*по убыванию периметров
*по возрастанию площадей

Задача 2. Описать класс, содержащий сведения о площади комнаты, 
высоте потолков и количестве окон. Описать методы вычисления объема 
комнаты и свойства для задания и получения состояния объекта. 
В случае недопустимых значений свойств выбрасывается исключение – 
класс, унаследованный от Exception. Исключению передавать сообщение 
об ошибке и значение, приведшее к выбросу исключения.
В массиве комнат (не менее 10и элементов) выполнить сортировку:
•	по убыванию площади
•	по возрастанию количества окон
 */



namespace ClassExceptions
{
    class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 20.09.2021 - введение в ООП на C#: Работа с исключениями";
            
            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Создание массива треугольников" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Сортировать треугольникипо убыванию периметров" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1. Сортировать треугольники по возрастанию площадей" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 2. Создание массива комнат" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 2. Сортировать по убыванию площадей" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Сортировать по возрастанию количеству окон" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };
            
            // Создание экземпляра класса приложения
            App app = new App();
            
            // главный цикл приложения
            while (true) {
                try
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Введение в ООП C# - работа с кортежами");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с кортежами", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // Создание массива треугольников
                        case ConsoleKey.Q:
                            app.TriangualrArray();
                            break;

                        // Сортировать треугольникипо убыванию периметров
                        case ConsoleKey.W:
                            app.SortPerimetr();
                            break;

                        // Сортировать треугольники по возрастанию площадей
                        case ConsoleKey.E:
                            app.SortArea();
                            break;

                        // Создание массива комнат
                        case ConsoleKey.R:
                            app.RoomsArray();
                            break;

                        // Сортировать по убыванию площадей
                        case ConsoleKey.T:
                            app.SortRoomsByArea();
                            break;


                        // Сортировать по возрастанию количеству окон
                        case ConsoleKey.A:
                            app.SortRoomsByWindows();
                            break;



                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }// try
                catch(MyException ex) {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"\n {ex.Message}, значение вызвавшение ошибку : {ex.GetValue()}");
                }
                finally
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("\nКод финализации");
                    Console.ForegroundColor = ConsoleColor.Gray;
                }
            } // while
        } // Main
    } // class Program
}
