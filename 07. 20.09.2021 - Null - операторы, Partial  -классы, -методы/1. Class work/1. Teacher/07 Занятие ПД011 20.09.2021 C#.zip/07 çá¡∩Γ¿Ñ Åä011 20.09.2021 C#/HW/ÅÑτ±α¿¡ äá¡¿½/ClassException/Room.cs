﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
Задача 2. Описать класс, содержащий сведения о площади комнаты, 
высоте потолков и количестве окон. Описать методы вычисления объема 
комнаты и свойства для задания и получения состояния объекта. 
В случае недопустимых значений свойств выбрасывается исключение – класс, 
унаследованный от Exception. Исключению передавать сообщение об ошибке 
и значение, приведшее к выбросу исключения.

В массиве комнат (не менее 10и элементов) выполнить сортировку:
•	по убыванию площади
•	по возрастанию количества окон
 */

namespace ClassExceptions
{
    public class Room

    {
        private double _roomArea;
        private double _ceilingHeight;
        private int _windowsNumber;


        public double RoomArea
        {
            get => _roomArea;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException($"Площадь не может быть отрицательнымv  {value} ");
                _roomArea = value;
            }
        }

        public double CeilingHeight
        {
            get => _ceilingHeight;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException($"Высота потолка не допустима {value} ");
                _ceilingHeight = value;
            }
        }

        public int WindowsNumber
        {
            get => _windowsNumber;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException($"Недопустимое значение для комнаты {value}");
                _windowsNumber = value;
            }
        }

        //объем комнаты. (предполагается, что комната  - куб)
        public double RoomVolume() => Math.Pow(_ceilingHeight, 3);

        //компаратор по убыванию площади
        public static int ComparatorArea(Room a, Room b) => b.RoomArea.CompareTo(a.RoomArea);

        public string ToTableRow() => $"| {RoomArea,11:f} | {CeilingHeight,16:f} | {WindowsNumber,16} | ";

        // компаратор по возрастранию количества окон
        public static int ComparatorWindows(Room m, Room c) => m.WindowsNumber.CompareTo(c.WindowsNumber);

        
    }
}
