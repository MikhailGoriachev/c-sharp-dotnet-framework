﻿using System;

namespace ClassExceptions {

    // Объекты и методы для обработки по заданию
    public class App {

        Random rand = new Random();
        Triangular[] triangulars = new Triangular[10];
        Room[] rooms = new Room[10];



        // Методы для обработок по заданию


        // Создание  массива треугольников
        public void TriangualrArray(double low = 1, double high = 10) {
            Utils.ShowNavBarTask("  Задача 1. Создание  массива треугольников");

            ShowTask1();

            triangulars = new[] { GenerateTriangular(), GenerateTriangular(), 
                GenerateTriangular(), GenerateTriangular(), GenerateTriangular(), GenerateTriangular(), 
                GenerateTriangular(), GenerateTriangular(), GenerateTriangular(), GenerateTriangular() };

            ShowTable();

            Console.ReadKey();






        } // TriangualrArray

        // Сортировать треугольникипо убыванию периметров
        public void SortPerimetr() {
            Utils.ShowNavBarTask(" Задача 1. Сортировать треугольники по убыванию периметров");

            Array.Sort(triangulars, Triangular.ComparatorPerimetr);

            ShowTable();

            Console.ReadKey();

            


        } // SortPerimetr

        // Сортировать треугольники по возрастанию площадей
        public void SortArea() {
            Utils.ShowNavBarTask("  Сортировать треугольники по возрастанию площадей");

            Array.Sort(triangulars, Triangular.CompatorArea);

            ShowTable();

            Console.ReadKey();
            




        } // SortArea

        // 
        public void RoomsArray() {
            Utils.ShowNavBarTask("  Создание массива комнат");

            ShowTask2();
            rooms = new[] { GenerateRoom(), GenerateRoom(), GenerateRoom(), GenerateRoom(),
                GenerateRoom(),GenerateRoom(),GenerateRoom(),GenerateRoom(),GenerateRoom(),GenerateRoom(), };
            ShowRoom();
            Console.ReadKey();




        } // Создание массива комнат

        // Сортировать по убыванию площадей
        public void SortRoomsByArea() {
            Utils.ShowNavBarTask("  Сортировать по убыванию площадей");

            Array.Sort(rooms, Room.ComparatorArea);

            ShowRoom();
            Console.ReadKey();

        } // SortRoomsByArea



        // Сортировать по возрастанию количеству окон
        public void SortRoomsByWindows() {
            Utils.ShowNavBarTask("  Сортировать по возрастанию количеству окон");

            Array.Sort(rooms, Room.ComparatorWindows);

            ShowRoom();
            Console.ReadKey();


        } // SortRoomsByWindows





        private static void ShowTask1()
        {
            string text = @" Задача 1. Описать класс, представляющий треугольник. 
            Предусмотреть методы для создания объектов (конструкторы), 
            вычисления площади, периметра и длин медиан, проверки 
            возможности создания треугольника. Описать свойство типа кортеж для задания трех сторон. 
            При невозможности построения треугольника выбрасывается исключение. 
            Описать свойства для получения сторон треугольника.";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        }

        private static void ShowTask2()
        {
            string text = @" Задача 2. Описать класс, содержащий сведения о площади комнаты, 
            высоте потолков и количестве окон. Описать методы вычисления объема 
            комнаты и свойства для задания и получения состояния объекта. 
            В случае недопустимых значений свойств выбрасывается исключение – 
            класс, унаследованный от Exception. Исключению передавать сообщение 
            об ошибке и значение, приведшее к выбросу исключения.

           В массиве комнат (не менее 10и элементов) выполнить сортировку:
           •	по убыванию площади
           •	по возрастанию количества окон";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        }

        private void ShowTable()
        {
            Console.WriteLine("\n\n");

            Console.WriteLine("┌─────────────┬─────────────┬────────────────┬─────────────┬───────────────┬────────────┬────────────┬────────────┐");
            Console.WriteLine("│  Сторона А  │  Сторона В  │  Сторона С     │   Периметр  │    Площадь    │  Медиана А │ Медиана  В │ Медиана С  │");
            Console.WriteLine("├─────────────┼─────────────┼────────────────┼─────────────┼───────────────┼────────────┼────────────┼────────────┤");
            foreach(var item in triangulars)
            {
                Console.WriteLine(item.ToTableRow());
            }

            Console.WriteLine("└─────────────┴─────────────┴────────────────┴─────────────┴───────────────┴────────────┴────────────┴────────────┘");
        }

        private void ShowRoom()
        {
            Console.WriteLine("\n\n");

            Console.WriteLine("┌─────────────┬──────────────────┬──────────────────┐");
            Console.WriteLine("│  Площадь    │  Высота пололков │  Количество окон │");
            Console.WriteLine("├─────────────┼──────────────────┼──────────────────┤");

            foreach(var item in rooms)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine("└─────────────┴──────────────────┴──────────────────┘");

        }

        // фабрика треугольников
        public Triangular GenerateTriangular (double low = 1, double high = 10)
        {
         return new Triangular() { Sides = (a: Utils.GetRandom(low+4, high), 

             b: Utils.GetRandom(low+4, high), c: Utils.GetRandom(low+4, high-6))};
        }

        // фабрика комннат
        public Room GenerateRoom(double low = 1, double high = 10, int low1 = 1, int low2 = 10)
        {
            return new Room()
            {
                WindowsNumber = Utils.GetRandomInt(low1, low2),
                CeilingHeight = Utils.GetRandom(low, high),
                RoomArea = Utils.GetRandom(low, high)
            };
        }










    } // class App
}