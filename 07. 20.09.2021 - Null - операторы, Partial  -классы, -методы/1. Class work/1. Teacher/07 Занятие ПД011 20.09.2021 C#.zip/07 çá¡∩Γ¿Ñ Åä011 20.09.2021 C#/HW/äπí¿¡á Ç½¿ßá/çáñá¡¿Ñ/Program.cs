﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 16.09.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Формирование коллекции треугольников" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Сортировка коллекции треугольников по убыванию периметров" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1. Сортировка коллекции треугольников по возрастанию площадей" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 1. Демонстрация работы класса TriangleException" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Формирование коллекции комнат" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Сортировка коллекции комнат по убыванию площади" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2. Сортировка коллекции комнат по возрастанию количества окон" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2. Демонстрация работы класса RoomException" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 16.09.2021 - исключения  в C#");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Формирование коллекции треугольников
                        case ConsoleKey.Q:
                            app.TrianglesInitialize();
                            break;

                        // Сортировка коллекции треугольников по убыванию периметров
                        case ConsoleKey.W:
                            app.DemoOrderByPerimeter();
                            break;


                        // Сортировка коллекции треугольников по возрастанию площадей
                        case ConsoleKey.E:
                            app.DemoOrderByTriangleArea();
                            break;

                        // Демонстрация работы класса TriangleException
                        case ConsoleKey.R:
                            new Triangle(0d, 5d, -7d);
                            break;

                        // ------------------------------------------------------------

                        // Формирование коллекции комнат
                        case ConsoleKey.A:
                            app.RoomsInitialize();
                            break;

                        // Сортировка коллекции комнат по убыванию площади
                        case ConsoleKey.S:
                            app.DemoOrderByRoomArea();
                            break;


                        //  Сортировка коллекции комнат по возрастанию количества окон
                        case ConsoleKey.D:
                            app.DemoOrderByWindows();
                            break;

                        // Демонстрация работы класса RoomException
                        case ConsoleKey.F:
                            new Room { Area = -1d};
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            continue;
                    } // switch

                }
                catch (TriangleException ex) {
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.GetMessage(), -79}  *  \n", ConsoleColor.White);                                   
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                catch (RoomException ex) {
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.GetMessage(),-79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                catch (Exception ex) {
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }

            } // while
        } // Main
    }
}
