﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{

    [Serializable]
    public class RoomException : Exception
    {
        private double _value;
        public RoomException() { }
        public RoomException(string message) : base(message) { }

        public RoomException(string message, double value) : base(message) {
            _value = value;
        } // RoomException
        public RoomException(string message, Exception inner) : base(message, inner) { }
        protected RoomException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }

        // собственный геттер
        public string GetMessage() => $"{this.Message} ({_value})";
    }
}
