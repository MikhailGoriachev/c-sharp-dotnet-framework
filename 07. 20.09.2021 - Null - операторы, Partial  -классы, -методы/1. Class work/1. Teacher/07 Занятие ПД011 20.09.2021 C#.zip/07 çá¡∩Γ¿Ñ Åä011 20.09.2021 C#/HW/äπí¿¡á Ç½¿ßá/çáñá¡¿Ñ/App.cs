﻿using System;

namespace Задание
{
    
    // Объекты и методы для обработки по заданию
    public class App {

        private ArrayTriangle _triangles;
        private ArrayRoom _rooms;

        // в конструкторе по умолчанию будем заполнять коллекции
        public App() : this(new ArrayTriangle(), new ArrayRoom()) {
            _triangles.Initialize();
            _rooms.Initialize();
        } // App

        // конструктор с внедрением зависимостей/ dependency injection
        public App(ArrayTriangle triangles, ArrayRoom rooms) {
            _triangles = triangles;
            _rooms = rooms;
        } // App


        // ---------------------------------------------------------------

        // Формирование коллекции треугольников
        public void TrianglesInitialize() {
            Utils.ShowNavBarTask("    Формирование коллекции треугольников");

            _triangles.Initialize();
            _triangles.Show("Данные сформированы", 8);
        } // TrianglesInitialize



        // Сортировка коллекции треугольников по убыванию периметров
        public void DemoOrderByPerimeter(){
            Utils.ShowNavBarTask("    Сортировка коллекции треугольников по убыванию периметров");

            _triangles.OrderByPerimeter();
            _triangles.Show("Сортировка коллекции треугольников по убыванию периметров", 8);
        } // DemoOrderByPerimeter


        // Сортировка коллекции треугольников по возрастанию площадей
        public void DemoOrderByTriangleArea()
        {
            Utils.ShowNavBarTask("  Сортировка коллекции треугольников по возрастанию площадей");

            _triangles.OrderByArea();
            _triangles.Show("Сортировка коллекции треугольников по возрастанию площадей", 8);
        } // DemoOrderByTriangleArea

        // ---------------------------------------------------------------

        // Формирование коллекции комнат
        public void RoomsInitialize(){
            Utils.ShowNavBarTask("  Формирование коллекции комнат");

            _rooms.Initialize();
            _rooms.Show("Данные сформированы", 8);
        } // RoomsInitialize

        // Сортировка коллекции комнат по убыванию площади
        public void DemoOrderByRoomArea()
        {
            Utils.ShowNavBarTask("  Сортировка коллекции комнат по убыванию площади");

            _rooms.OrderByArea();
            _rooms.Show("Сортировка коллекции комнат по убыванию площади", 8);
        } // DemoOrderByRoomArea

        // Сортировка коллекции комнат по возрастанию количества окон
        public void DemoOrderByWindows()
        {
            Utils.ShowNavBarTask("  Сортировка коллекции комнат по возрастанию количества окон");

            _rooms.OrderByWindows();
            _rooms.Show("Сортировка коллекции комнат по возрастанию количества окон", 8);
        } // DemoOrderByWindows

    } // class App
}