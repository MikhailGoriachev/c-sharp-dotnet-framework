﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{

    [Serializable]
    public class TriangleException : Exception
    {
        private (double a, double b, double c) _value;
        public TriangleException() { }
        public TriangleException(string message) : base(message) { }

        public TriangleException(string message, (double a, double b, double c) value) : base(message) {
            _value = value;
        }
        public TriangleException(string message, Exception inner) : base(message, inner) { }
        protected TriangleException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }

        // собственный геттер
        public string GetMessage() => $"{this.Message} {_value}";
    } // TriangleException
}
