﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    public class Triangle {

        private double _a;
        private double _b;
        private double _c;

        // свойство типа кортеж для задания трех сторон
        public (double a, double b, double c) Sides {
            set {
                if (!IsCorrectTriangle(value.a, value.b, value.c)) throw new TriangleException("Triangle: Некорректные значения сторон! ", (value.a, value.b, value.c));
                (_a, _b, _c) = value;
            }
        } // Sides

        // свойства для получения сторон треугольника
        public double A { get => _a; }
        public double B { get => _b; }
        public double C { get => _c; }


        public Triangle(double a, double b, double c) {
            this.Sides = (a, b, c);
        }

        // проверка возможности создания треугольника
        public static bool IsCorrectTriangle(double a, double b, double c) {
            bool res = true;
            if (a <= 0d || c <= 0d || b <= 0d || a >= c + b || c >= a + b || b >= c + a) res = false;
            return res;
        } // IsCorrectTriangle

        // метод вычисления площади
        public double Area() {
            double p = (_a + _b + _c) / 2d;
            return Math.Sqrt(p * (p - _a) * (p - _b) * (p - _c));
        } // Area

        // метод вычисления периметра 
        public double Perimeter() => _a + _b + _c;

        // метод вычисления длин медиан
        public (double mA, double mB, double mC) Medians() =>
            (mA: Math.Sqrt(2d * (_a * _a + _b * _b) - _c * _c) / 2d,
             mB: Math.Sqrt(2d * (_a * _a + _c * _c) - _b * _b) / 2d,
             mC: Math.Sqrt(2d * (_b * _b + _c * _c) - _a * _a) / 2d);


        // представление объекта в виде строки таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_a,8:f2}  │ {_b,8:f2}  │ {_c, 8:f2}  " +
            $"│ {Perimeter(), 8:f2} │ {Area(), 9:f2} │";

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬───────────┬───────────┬───────────┬──────────┬───────────┐\n" +
                $"{spaces}│  №  │ Сторона А │ Сторона B │ Сторона C │ Периметр │  Площадь  │\n" +
                $"{spaces}├─────┼───────────┼───────────┼───────────┼──────────┼───────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴───────────┴───────────┴───────────┴──────────┴───────────┘";


        // Компаратор для сортировки по убыванию периметров
        public static int PerimeterComparer(Triangle t1, Triangle t2) =>
            t2.Perimeter().CompareTo(t1.Perimeter());

        // Компаратор для сортировки по возрастанию площадей
        public static int AreaComparer(Triangle t1, Triangle t2) =>
            t1.Area().CompareTo(t2.Area());
        // 
    } // Triangle
}
