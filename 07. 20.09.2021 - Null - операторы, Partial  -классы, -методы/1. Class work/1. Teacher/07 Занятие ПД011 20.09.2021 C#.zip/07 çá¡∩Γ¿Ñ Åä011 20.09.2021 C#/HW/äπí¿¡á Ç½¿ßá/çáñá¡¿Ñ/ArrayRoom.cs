﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    public class ArrayRoom {

        private Room[] _rooms;
        public Room[] Rooms {
            get => _rooms;
            private set => _rooms = value;
        } // Rooms

        public ArrayRoom(Room[] rooms) {
            _rooms = rooms;
        } // ArrayRoom
        public ArrayRoom() : this(new Room[10]) {
            Initialize();
        } // ArrayRoom


        // заполнение массива комнат начальными значениями
        public void Initialize() {
            for (int i = 0; i < _rooms.Length; i++) {
                double area, ceilingHeight;
                int windows;
                (area, ceilingHeight, windows) = (Utils.GetRandom(10d, 20d), Utils.GetRandom(2d, 5d), Utils.Random.Next(0, 5));

                _rooms[i] = new Room {Area = area, CeilingHeight = ceilingHeight, Windows = windows };
            } // for i
        } // Initialize

        // Вывести массив комнат в консоль
        public void Show(string caption, int indent) {
            // вывод заголовка таблицы комнат
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n" +
                              $"{Room.Header(indent)}");

            // вывод всех элементов массива комнат
            int row = 1;
            void OutItem(Room p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(Rooms, OutItem);

            // вывод подвала таблицы комнат
            Console.WriteLine(Room.Footer(indent));
        } // Show

        // сортировка массива комнат по убыванию площади
        public void OrderByArea() => Array.Sort(_rooms, Room.AreaComparer);
        // сортировка массива комнат по возрастанию количества окон
        public void OrderByWindows() => Array.Sort(_rooms, Room.WindowsComparer);
    }
}
