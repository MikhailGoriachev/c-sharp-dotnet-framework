﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    public class ArrayTriangle {

        private Triangle[] _triangles;
        public Triangle[] Triangles
        {
            get => _triangles;
            private set => _triangles = value;
        } // Triangles

        public ArrayTriangle(Triangle[] triangles) {
            _triangles = triangles;
        } // ArrayTriangle
        public ArrayTriangle() : this(new Triangle[10]) {
            Initialize();
        } // ArrayTriangle


        // заполнение массива треугольников начальными значениями
        public void Initialize() {
            for (int i = 0; i < _triangles.Length; i++) {
                double a, b, c;
                do (a, b, c) = (Utils.GetRandom(1d, 10d), Utils.GetRandom(1d, 10d), Utils.GetRandom(1d, 10d));
                while (!Triangle.IsCorrectTriangle(a, b, c));
                
                _triangles[i] = new Triangle(a, b, c);
            } // for i
        } // Initialize

        // Вывести массив треугольников в консоль
        public void Show(string caption, int indent)
        {
            // вывод заголовка таблицы треугольников
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n" +
                              $"{Triangle.Header(indent)}");

            // вывод всех элементов массива треугольников
            int row = 1;
            void OutItem(Triangle p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(Triangles, OutItem);

            // вывод подвала таблицы треугольников
            Console.WriteLine(Triangle.Footer(indent));
        } // Show

        // сортировка массива треугольников по убыванию периметров
        public void OrderByPerimeter() => Array.Sort(_triangles, Triangle.PerimeterComparer);

        // сортировка массива треугольников по возрастанию площадей
        public void OrderByArea() => Array.Sort(_triangles, Triangle.AreaComparer);
    } // ArrayTriangle
}
