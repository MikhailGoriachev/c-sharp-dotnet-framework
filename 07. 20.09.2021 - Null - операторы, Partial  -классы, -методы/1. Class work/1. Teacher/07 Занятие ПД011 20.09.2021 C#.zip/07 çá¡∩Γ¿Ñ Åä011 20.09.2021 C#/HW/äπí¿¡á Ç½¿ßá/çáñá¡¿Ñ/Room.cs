﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    public class Room {


        private double _area;                 // площадь комнаты
        private double _ceilingHeight;        // высота потолков
        private int _windows;                 // количество окон


        public double Area {
            get => _area; 
            set { if (value <= 0) throw new RoomException("Room: Некорректное значение площади комнаты!", value); _area = value; }
        } // Area

        public double CeilingHeight {
            get => _ceilingHeight;
            set { if (value <= 0) throw new RoomException("Room: Некорректное значение высоты потолков!", value); _ceilingHeight = value; }
        } // CeilingHeight

        public int Windows {
            get => _windows;
            set { if (value < 0) throw new RoomException("Room: Некорректное значение кол-ва окон!", value); _windows = value; }
        } // Windows

        // метод вычисления объема комнаты
        public double Volume() => _area * _ceilingHeight;

        // представление объекта в виде строки таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_area,11:f2} м^2 │ {_ceilingHeight,12:f2} м. │ {_windows, 10}  " +
            $"│ {Volume(),9:f2} м^3 │";

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬─────────────────┬─────────────────┬─────────────┬───────────────┐\n" +
                $"{spaces}│  №  │ Площадь комнаты │ Bысота потолков │ Кол-во окон │ Объем комнаты │\n" +
                $"{spaces}├─────┼─────────────────┼─────────────────┼─────────────┼───────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴─────────────────┴─────────────────┴─────────────┴───────────────┘";

        // Компаратор для сортировки по убыванию площади 
        public static int AreaComparer(Room r1, Room r2) =>
            r2.Area.CompareTo(r1.Area);

        // Компаратор для сортировки по возрастанию количества окон
        public static int WindowsComparer(Room r1, Room r2) =>
             r1.Windows.CompareTo(r2.Windows);
    } // Room
}
