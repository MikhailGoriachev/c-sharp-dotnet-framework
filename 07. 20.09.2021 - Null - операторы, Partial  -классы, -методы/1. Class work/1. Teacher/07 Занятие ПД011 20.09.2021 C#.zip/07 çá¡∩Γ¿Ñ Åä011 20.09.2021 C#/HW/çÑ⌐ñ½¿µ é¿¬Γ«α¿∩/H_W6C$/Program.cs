﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6C_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Домашнее задание № 6.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.F5, Text = "Задача 1.Формирование коллекции треугольников." },
                new MenuItem { HotKey = ConsoleKey.F6, Text = "Вывод кортежа треугольников." },
                new MenuItem { HotKey = ConsoleKey.F7, Text = "Пример обработки исключения по сторонам треугольника." },
                new MenuItem { HotKey = ConsoleKey.F8, Text = "Упорядочить треугольники по убыванию периметров." },
                new MenuItem { HotKey = ConsoleKey.F9, Text = "Упорядочить треугольники по возрастанию площадей." },
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 2.Формирование коллекции комнат." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Упорядочить комнаты по убыванию площади." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Упорядочить комнаты по возрастанию количества окон." },
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true)
            {
                // настройка цветового оформления
                Console.ForegroundColor = ConsoleColor.White;
                Console.BackgroundColor = ConsoleColor.DarkCyan;
                Console.Clear();
                Console.CursorVisible = false;

                Utils.ShowMenu(12, 5, "Меню приложения : ", menu);

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                Console.Clear();

                switch (key)
                {
                        // Формирование коллекции треугольников
                        case ConsoleKey.F5:
                            app.ShowInizialize();
                            break;

                         // Вывод Вывод кортежа треугольников
                        case ConsoleKey.F6: 
                            app.ShowTriangleCorteg();
                            break;

                        // Пример обработки исключения по сторонам треугольника
                        case ConsoleKey.F7:
                            app.ExceptionHandling();
                            break;

                        //  Сортировка коллекции треугольников по убыванию периметров
                        case ConsoleKey.F8:
                            app.SortPerimeter();
                            break;

                        // Сортировка коллекции треугольников по возрастанию площадей
                        case ConsoleKey.F9:
                         app.SortArea();
                            break;

                    // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 2

                        // Формирование коллекции комнат
                        case ConsoleKey.Q:
                         app.ShowInizRoom();
                            break;

                        // Сортировка коллекции комнат по убыванию площади
                        case ConsoleKey.W:
                         app.SortSquare();
                            break;

                        // Сортировка коллекции комнат по возрастанию количества окон
                        case ConsoleKey.E:
                          app.SortWindows();
                            break;
                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                        Console.CursorVisible = true;
                        return;
                    default:
                        continue;
                } // switch

                // Ожидать нажатия любой клавиши по окончании работы пункта меню
                Console.CursorVisible = true;
                Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                Console.ReadKey(true);
            } // while

            }
            catch (ProcesAssigmentException ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}, значение вызвавшее ошибку: {ex.GetValueA()}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;
        }// Main
    }
}
