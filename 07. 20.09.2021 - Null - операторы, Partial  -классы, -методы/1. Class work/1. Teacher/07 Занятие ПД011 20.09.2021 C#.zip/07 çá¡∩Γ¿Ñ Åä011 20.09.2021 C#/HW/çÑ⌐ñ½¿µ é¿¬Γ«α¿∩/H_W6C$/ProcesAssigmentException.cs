﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6C_
{
   
    [Serializable]

    public class ProcesAssigmentException : Exception
    {
        // дополнительные данные для обработки исключения
        private double _valueA;
        //private double _valueB;
        //private double _valueC;

        public ProcesAssigmentException() { }
        public ProcesAssigmentException(string message) : base(message) { }
        public ProcesAssigmentException(string message, Exception inner) : base(message, inner) { }

        public ProcesAssigmentException(string message, double valueA) : base(message)
        {
            _valueA = valueA;
        }

        /*
        public ProcesAssigmentException(string message, double valueA, double valueB, double valueC) : base(message)
        {
            _valueA = valueA;
            _valueB = valueB;
            _valueC = valueC;
        }
        */
        protected ProcesAssigmentException(
        System.Runtime.Serialization.SerializationInfo info,
        System.Runtime.Serialization.StreamingContext context) : base(info, context) { }

        // собственный геттер
        public double GetValueA() => _valueA;
        //public double GetValueB() => _valueB;
        //public double GetValueC() => _valueC;
    }// class TriangleException

}
