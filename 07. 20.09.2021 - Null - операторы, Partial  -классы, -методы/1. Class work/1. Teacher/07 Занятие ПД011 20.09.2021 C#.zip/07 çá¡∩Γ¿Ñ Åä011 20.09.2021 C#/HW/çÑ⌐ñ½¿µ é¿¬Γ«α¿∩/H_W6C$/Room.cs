﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/// <summary>
/// Описать класс, содержащий сведения о площади комнаты,
/// высоте потолков и количестве окон.
/// Описать методы вычисления объема комнаты и 
/// свойства для задания и получения состояния объекта. 
/// В случае недопустимых значений свойств выбрасывается исключение – класс,
/// унаследованный от Exception. 
/// Исключению передавать сообщение об ошибке и значение, приведшее к выбросу исключения.
/// В массиве комнат (не менее 10и элементов) выполнить сортировку:
/// •	по убыванию площади
/// •	по возрастанию количества окон
/// </summary>
namespace H_W6C_
{
    class Room
    {
        // длина комнаты
        private double _length;      
        public double Length
        {
            get => _length;
            set
            {
                if (value <= 0) throw new ProcesAssigmentException($"Room: некорректное значение для длины комнаты {value:f2}", value);
                _length = value;
            }
        }// Length
        // ширина комнаты
        private double _width;  
        public double Width
        {
            get => _width;
            set
            {
                if (value <= 0) throw new ProcesAssigmentException($"Room: некорректное значение для ширины комнаты {value:f2}", value);
                _width = value;
            }
        }// Width

        // высота комнаты
        private double _hight;
        public double Hight
        {
            get => _hight;
            set
            {
                if (value <= 0) throw new ProcesAssigmentException($"Room: некорректное значение для высоты комнаты {value:f2}", value);
                _hight = value;
            }
        }// Hight

        // количество окон в комнате 
        private int _windows;        
        public int Windows
        {
            get => _windows;
            set
            {
                if (value < 0) throw new ProcesAssigmentException($"Room: некорректное значение окон в комнате {value:f2}", value);
                _windows = value;
            }
        }// Windows

        // метод вычисления площади комнаты
        public double Square() => _length * _width;

        public double Volume() => _length * _width * _hight;

        // строковое представление комнаты 
        public override string ToString() =>
            $"Длина комнаты: {_length,9:f2}; Высота комнаты: {_hight,9:f2}; Ширина комнаты : {_width,9:f2}; Количество окон : {_windows,9}";

        public string ToTableRow() =>
        $"\t│ {_length,7:n2} | {_hight,7:n2} | {_width,7:n2} | {_windows,10} │ {Square(),8:f2} │ {Volume(),7:f2} │";


        // статическое свойство для вывода шапки таблицы
        public static string Header()
        {

            string str =
            $"\n\n\t┌─────────┬─────────┬─────────┬────────────┬──────────┬─────────┐\n" +
            $"\t│  Длина  │  Высота │  Ширина │ Количество │ Площадь  │  Объём  │\n" +
            $"\t│ комнаты │ комнаты │ комнаты │    окон    │ комнаты  │ комнаты │\n" +
            $"\t├─────────┼─────────┼─────────┼────────────┼──────────┼─────────┤";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"\t└─────────┴─────────┴─────────┴────────────┴──────────┴─────────┘";

        // Компараторы для сортировки по заданию
        // компаратор для сортировки по убыванию убыванию площади
        public static int ComparerBySquare(Room r1, Room r2) =>
           r2.Square().CompareTo(r1.Square());

        // компаратор для сортировки по возрастанию количества окон
        public static int ComparerByWindows(Room r1, Room r2) =>
           r1._windows.CompareTo(r2._windows);

    }// class Room
}
