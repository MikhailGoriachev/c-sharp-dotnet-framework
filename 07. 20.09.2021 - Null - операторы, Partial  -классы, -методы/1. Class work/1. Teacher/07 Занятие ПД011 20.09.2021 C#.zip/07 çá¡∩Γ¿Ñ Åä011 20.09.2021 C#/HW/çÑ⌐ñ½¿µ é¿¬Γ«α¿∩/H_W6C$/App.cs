﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6C_
{
    public class App
    {
        Triangle[] triangles;
        Room[] rooms;


        #region Решение Задачи 1 Класс Triangle
        // кортеж для задания трех сторон
        public void ShowTriangleCorteg()
        {
            Utils.ShowNavBarTask(" Кортеж для трех сторон треугольника");
            (double a, double b, double c)[] triagle = new (double a, double b, double c)[10];
            for (int i = 0; i < triagle.Length; i++)
            {
                triagle[i].a = Utils.GetRandom(2d, 10d);
                triagle[i].b = Utils.GetRandom(2d, 10d);
                triagle[i].c = Utils.GetRandom(2d, 10d);

            }// for i
            
            Console.WriteLine($" {Triangle.Header()}");
            for (int i = 0; i < triagle.Length; i ++)
            {
                (double p, double a, double m) rect1 = Triangle.Side(triagle[i].a, triagle[i].b, triagle[i].c);
                Console.WriteLine($"\t| {triagle[i].a,9:n2} | {triagle[i].b,9:n2} | {triagle[i].c,9:n2} | {rect1.p,9:n2} | {rect1.a,8:n2} | {rect1.m,8:n2} |");
            }// for i
            Console.WriteLine($" {Triangle.Footer()}");

        }// ShowTriangleCorteg

        // пример обработки исключения по сторонам треугольника
        public void ExceptionHandling()
        {
            Utils.ShowNavBarTask(" Пример обработки исключения по стороной треугольника");
            Console.WriteLine($" {Triangle.Header()}");
            triangles = new Triangle[]
            {
                new Triangle{ A = Utils.GetRandom(2d, 10d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 10d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 3d), B = Utils.GetRandom(-10d, -2d), C =Utils.GetRandom(2d, 10d)  },
            };

            foreach (var item in triangles)
                Console.WriteLine($"{item.ToTableRow()}");
            Console.WriteLine($" {Triangle.Footer()}");
        }// ExceptionHandling

        // сортировка по убыванию периметров треугольника
        public void SortPerimeter()
        {
            Utils.ShowNavBarTask("  Упорядочить по убыванию периметров треугольника");

            Array.Sort(triangles, Triangle.ComparerByPerimeter);

            Console.WriteLine($" {Triangle.Header()}");
            foreach (var item in triangles)
                Console.WriteLine($"{item.ToTableRow()}");
            Console.WriteLine($" {Triangle.Footer()}");

        } // SortPerimeter

        // сортировка по возрастанию площадей треугольника
        public void SortArea()
        {
            Utils.ShowNavBarTask("  Упорядочить по возрастанию площадей треугольника");

            Array.Sort(triangles, Triangle.ComparerByArea);

            Console.WriteLine($" {Triangle.Header()}");
            foreach (var item in triangles)
                Console.WriteLine($"{item.ToTableRow()}");
            Console.WriteLine($" {Triangle.Footer()}");

        } // SortArea

        public void ShowInizialize()
        {
            Utils.ShowNavBarTask(" Создание массива треугольников");
            Console.WriteLine($" {Triangle.Header()}");
            triangles = new Triangle[]
            {
                new Triangle{ A = Utils.GetRandom(2d, 10d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 10d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 3d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 3d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 3d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 3d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 3d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 3d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 3d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
                new Triangle{ A = Utils.GetRandom(2d, 3d), B = Utils.GetRandom(2d, 10d), C =Utils.GetRandom(2d, 10d)  },
            };

            foreach (var item in triangles)
                Console.WriteLine($"{item.ToTableRow()}");
            Console.WriteLine($" {Triangle.Footer()}");
        }// ShowInizialize
        #endregion

        #region Решение Задачи 2 Класс Room

        public void ShowInizRoom()
        {
            Utils.ShowNavBarTask(" Создание массива комнат");
            Console.WriteLine($" {Room.Header()}");

            rooms = new Room[]
            {
                new Room{Length = 5d, Width = 3d, Hight = 2.7, Windows = 2},
                new Room{Length = 7d, Width = 4d, Hight = 3.5, Windows = 3},
                new Room{Length = 5d, Width = 3d, Hight = 2.8, Windows = 1},
                new Room{Length = 6d, Width = 3d, Hight = 2.7, Windows = 2},
                new Room{Length = 5d, Width = 5d, Hight = 3d, Windows = 3},
                new Room{Length = 5d, Width = 3d, Hight = 2.7, Windows = 2},
                new Room{Length = 4d, Width = 3d, Hight = 2.5, Windows = 1},
                new Room{Length = 5d, Width = 3d, Hight = 2.7, Windows = 2},
                new Room{Length = 8d, Width = 4d, Hight = 3.5, Windows = 4},
                new Room{Length = 6d, Width = 2d, Hight = 3d, Windows = 1},
            };
            foreach (var item in rooms)
                Console.WriteLine($"{item.ToTableRow()}");
            Console.WriteLine($" {Room.Footer()}");

        }// ShowInizRoom

        // сортировка по убыванию площади комнаты
        public void SortSquare()
        {
            Utils.ShowNavBarTask("  Упорядочить по убыванию площади комнаты");

            Array.Sort(rooms, Room.ComparerBySquare);

            Console.WriteLine($" {Room.Header()}");
            foreach (var item in rooms)
                Console.WriteLine($"{item.ToTableRow()}");
            Console.WriteLine($" {Room.Footer()}");

        } // SortSquare

        // сортировка по возрастанию количества окон
        public void SortWindows()
        {
            Utils.ShowNavBarTask("  Упорядочить по возрастанию количества окон комнаты");

            Array.Sort(rooms, Room.ComparerByWindows);
            
            Console.WriteLine($" {Room.Header()}");
            foreach (var item in rooms)
                Console.WriteLine($"{item.ToTableRow()}");
            Console.WriteLine($" {Room.Footer()}");

        } //SortWindows

        #endregion
    }// class App
}
