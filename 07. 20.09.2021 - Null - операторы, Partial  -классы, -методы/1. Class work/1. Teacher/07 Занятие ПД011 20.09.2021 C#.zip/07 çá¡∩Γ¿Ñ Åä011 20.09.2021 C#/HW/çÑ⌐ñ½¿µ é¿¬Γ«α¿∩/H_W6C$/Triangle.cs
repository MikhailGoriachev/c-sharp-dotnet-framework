﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Описать класс, представляющий треугольник. 
/// Предусмотреть методы для создания объектов (конструкторы),
/// вычисления площади,
/// периметра и длин медиан, проверки возможности создания треугольника.
/// Описать свойство типа кортеж для задания трех сторон. 
/// При невозможности построения треугольника выбрасывается исключение. 
/// Описать свойства для получения сторон треугольника.
/// Разработайте собственный класс исключения, унаследованный от класса Exception.
/// Передавать в исключение: сообщении об ошибке, значения для сторон. 
/// В массиве треугольников (не менее 10 элементов) выполнить сортировку: 
///•	по убыванию периметров
///•	по возрастанию площадей
/// </summary>
namespace H_W6C_
{
    class Triangle
    {
        // сторона треугольника a
        private double _a;
        public double A
        {
            get => _a;
            set
            {
                if (value < 0)  throw new ProcesAssigmentException($"Triangle: некорректное значение стороны 'a' треугольника {value:f2}", value);    
                    _a = value;
            }
        }// A

        // сторона треугольника b
        private double _b;
        public double B
        {
            get => _b;
            set
            {
                 if (value < 0) throw new ProcesAssigmentException($"Triangle: некорректное значение стороны 'b' треугольника {value:f2}", value);
                _b = value;
            }
        }// B

        // сторона треугольника с
        private double _c;
        public double C
        {
            get => _c;
            set
            {
                if (value < 0) throw new ProcesAssigmentException($"Triangle: некорректное значение стороны 'c' треугольника {value:f2}", value);
                _c = value;
            }
        }// C

        public Triangle() { }//:this(1d, 1d, 1d) { }

        // конструктор с внедрением зависимостей
        public Triangle(double a, double b, double c)
        {
            // if (a < 0) { throw new ProcesAssigmentException("Triangle: некорректное значение стороны 'a' треугольника"); }
            _a = a;
            //if (b < 0) { throw new ProcesAssigmentException("Triangle: некорректное значение стороны 'b' треугольника"); }
            _b = b;
            // if (c < 0) throw new ProcesAssigmentException("Triangle: некорректное значение стороны 'c' треугольника");
            _c = c;
        }// Triangle

        // кортеж для задания трех сторон
        public static (double p, double a, double m) Side(double a1, double b1, double c1)
            => (p: a1 + b1 + c1, 
            a: 2d * (a1 * b1)* Math.Sin(c1), 
            m: 2d * Math.Sqrt(2d * (a1 * a1 + b1 * b1) - c1 * c1) / 2d);

        // метод нахождения периметра треугольника
        // https://www-formula.ru/2011-09-19-02-39-24/2011-09-10-00-03-56
        public double Perimeter() => _a + _b + _c;
        
        // метод нахождения площади треугольника
        // в этом методе срабатывает значение NaN
        public double Area()
	    {
		    double p = Perimeter() / 2d;
            double s = Math.Sqrt(p * (p - _a) * (p - _b) * (p - _c));
            //if (double.IsNaN(s)) Console.WriteLine("Вычисление Sqrt(0)");
            return s;
        }// Area

        // метод нахождения медианы треугольника
        public double Mediana() => 2d* Math.Sqrt(2d * (_a * _a + _b * _b) - _c *_c) / 2d;

        // строковое представление треугольника (метод ToString(), выводить только
        // стороны треугольника)
        public override string ToString() =>
            $"сторона А: {_a, 9:f2}; сторона В: {_b, 9:f2}; сторона C : {_c, 9:f2}";

        public string ToTableRow() =>
           $"\t│ {_a,9:n2} | {_b,9:n2} | {_c,9:n2} | {Perimeter(),9:f2} │ {Area(),8:f2} │ {Mediana(),8:f2} │";

        // статическое свойство для вывода шапки таблицы
        public static string Header()
        {
            
            string str =
            $"\n\n\t┌───────────┬───────────┬───────────┬───────────┬──────────┬──────────┐\n" +
            $"\t│ Сторона А │ Сторона В │ Сторона С │ Периметер │ Площадь  │ Медиана  │\n" +
            $"\t├───────────┼───────────┼───────────┼───────────┼──────────┼──────────┤";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"\t└───────────┴───────────┴───────────┴───────────┴──────────┴──────────┘";

        // Компараторы для сортировки по заданию
        // компаратор для сортировки по убыванию периметров
        public static int ComparerByPerimeter(Triangle t1, Triangle t2) =>
           t2.Perimeter().CompareTo(t1.Perimeter());

        // компаратор для сортировки по возрастанию площадей
        public static int ComparerByArea(Triangle t1, Triangle t2) =>
           t1.Area().CompareTo(t2.Area());

    }// class Triangle
}
