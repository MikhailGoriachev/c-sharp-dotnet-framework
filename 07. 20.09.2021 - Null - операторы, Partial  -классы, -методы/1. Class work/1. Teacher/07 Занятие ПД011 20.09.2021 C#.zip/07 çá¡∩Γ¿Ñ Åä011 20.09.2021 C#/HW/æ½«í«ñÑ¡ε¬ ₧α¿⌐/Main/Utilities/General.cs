﻿using System;


namespace Main.Utilities
{


internal static class General
{
	public static Random Rand { get; } = new Random();


	public static void Pause()
	{
		Console.Write("Нажмите любую клавишу для продолжения...");
		Console.ReadKey(true);
	}


	public static void CursorToBottomAndPause()
	{
		CursorToBottom();
		Pause();
	}


	public static void CursorToBottom() => Console.SetCursorPosition(0, Console.WindowHeight - 1);


	public static void CursorAndPause(int left, int top)
	{
		Console.SetCursorPosition(left, top);
		Pause();
	}
}


}
