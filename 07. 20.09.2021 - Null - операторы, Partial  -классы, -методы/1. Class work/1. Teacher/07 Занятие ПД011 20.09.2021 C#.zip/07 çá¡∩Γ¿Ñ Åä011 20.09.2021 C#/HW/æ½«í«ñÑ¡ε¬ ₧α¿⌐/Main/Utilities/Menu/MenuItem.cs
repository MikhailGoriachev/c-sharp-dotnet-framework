﻿using System;


namespace Main.Utilities.Menu
{


public sealed class MenuItem
{
	public MenuItem(string text, Action callback)
	{
		Text = text.ReturnIfNotNullEmptyOrWhitespaceOrThrow();

		Callback = callback.ReturnIfNotNullOrThrow();
	}


	public  string Text           { get; }
	private Action Callback       { get; }
	public  bool   IsDivide       { get; set; } = false;
	public  bool   IsSimpleInvoke { get; set; } = false;


	public void InvokeItem()
	{
		if (IsSimpleInvoke)
		{
			Callback.Invoke();
			return;
		}

		Console.Clear();
		Console.SetCursorPosition(0, 0);

		ShowTitleOfItem();
		Callback.Invoke();

		ProperlyMakeIndentsAfterInvoke();
		Console.Clear();
	}


	private static void ProperlyMakeIndentsAfterInvoke()
	{
		if (Console.CursorTop >= Console.WindowHeight)
			General.CursorAndPause(0, Console.CursorTop + 5);
		else
			General.CursorToBottomAndPause();
	}


	private void ShowTitleOfItem()
	{
		object space = ' ';
		
		$"{space,10} {Text} {space,10}".ColoredLine(Palette.Navbar);
		
		Console.WriteLine("\n\n");
	}
}


}
