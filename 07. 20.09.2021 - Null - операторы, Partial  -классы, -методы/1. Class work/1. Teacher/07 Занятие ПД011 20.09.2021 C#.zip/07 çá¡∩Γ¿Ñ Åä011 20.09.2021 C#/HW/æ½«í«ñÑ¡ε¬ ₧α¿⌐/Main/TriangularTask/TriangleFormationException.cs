﻿using System;
using System.Runtime.Serialization;


namespace Main.TriangularTask
{


[Serializable]
public class TriangleFormationException : Exception
{
	public TriangleFormationException() { }


	public TriangleFormationException((double a, double b, double c) sides) : base(
		$"\n\tТреугольник не может быть сформирован\n\tСтороны приведшие к ошибке {sides}") {}


	public TriangleFormationException(string message, Exception inner) : base(message, inner) { }


	protected TriangleFormationException(
		SerializationInfo info,
		StreamingContext  context) : base(info, context)
	{ }
}


}
