﻿using Main.Utilities.Menu;


namespace Main.RoomTask
{


public class RoomProcessor : MenuWrapper
{
	public RoomProcessor() => Menu = new Menu("Главное меню приложения", new[]
	{
		new MenuItem("Вывести массив комнат", Show),
		new MenuItem("Упорядочить по убыванию площади", OrderByAreaDescending),
		new MenuItem("Упорядочить по возрастанию количества окон", OrderByWindowsCountAscending),
		new MenuItem("Работа исключения", ShowException)
	});


	private RoomArray Rooms { get; } = new RoomArray((8, 17), (10, 20));


	private void Show() => Rooms.ShowAsTable();


	private void ShowException() => Room.Generate(-5, 3);


	private void OrderByAreaDescending()
	{
		Rooms.OrderByAreaDescending();
		Show();
	}


	private void OrderByWindowsCountAscending()
	{
		Rooms.OrderByWindowsCountAscending();
		Show();
	}
}


}
