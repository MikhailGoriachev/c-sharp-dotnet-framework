﻿using System;
using Main.Utilities;


namespace Main.TriangularTask
{


public class TriangleArray
{
	private Triangle[] _triangles;


	public TriangleArray((int min, int max) sizeRange, (double min, double max) triangleSidesRange)
	{
		_triangles = new Triangle[General.Rand.Next(sizeRange.min, sizeRange.max)];

		for (int i = 0; i < _triangles.Length; i++)
			_triangles[i] = Triangle.Generate(triangleSidesRange.min, triangleSidesRange.max);
	}


	public Triangle[] Triangles { private get => _triangles; set => _triangles = value.ReturnIfNotNullOrThrow(); }


	public void ShowAsTable()
	{
		Triangle.ShowTableHeader();

		foreach (var triangle in Triangles)
			Console.WriteLine(triangle.ToTableRow());

		Triangle.ShowTableFooter();
	}


	public void OrderByPerimeterDescending() => Array.Sort(Triangles, Triangle.CompareByPerimeterDescending);

	public void OrderByAreaAscending() => Array.Sort(Triangles, Triangle.CompareByAreaAscending);
}


}
