﻿using System;
using Main.Utilities;
using Main.Utilities.Menu;


namespace Main.TriangularTask
{


public class TriangleProcessor : MenuWrapper
{
	public TriangleProcessor() => Menu = new Menu("Главное меню приложения", new[]
	{
		new MenuItem("Вывести массив треугольников", Show),
		new MenuItem("Упорядочить по убыванию периметров", OrderByPerimeterDescending),
		new MenuItem("Упорядочить по возрастанию площадей", OrderByAreaAscending),
		new MenuItem("Работа исключения", ShowException)
	});


	private TriangleArray Triangles { get; } = new TriangleArray((8, 17), (10, 40));


	private void Show() => Triangles.ShowAsTable();


	private void ShowException()
	{
		new Triangle(
			General.Rand.RealNextDouble(),
			Math.Pow(General.Rand.RealNextDouble(), 4),
			General.Rand.RealNextDouble());
	}


	private void OrderByPerimeterDescending()
	{
		Triangles.OrderByPerimeterDescending();
		Show();
	}


	private void OrderByAreaAscending()
	{
		Triangles.OrderByAreaAscending();
		Show();
	}
}


}
