﻿using System;
using Main.Utilities;


namespace Main.RoomTask
{


public class Room
{
	public static readonly double PlafondMinHeight = 2.4;

	private double _area;
	private double _plafondHeight;
	private int    _windowsCount;

	public double Area
	{
		get => _area;
		set
		{
			if (value <= 0)
				throw new ArgumentOutOfRangeException(
					nameof(value),
					$"Площадь комнаты не может быть отрицательной, текущее значение: {value}");

			_area = value;
		}
	}

	public double PlafondHeight
	{
		get => _plafondHeight;
		set
		{
			if (value < PlafondMinHeight)
				throw new ArgumentOutOfRangeException(
					nameof(value),
					$"Высота потолков должна быть не меньше {PlafondMinHeight}, текущее значение: {value}");

			_plafondHeight = value;
		}
	}

	public int WindowsCount
	{
		get => _windowsCount;
		set
		{
			if (value < 0)
				throw new ArgumentOutOfRangeException(
					nameof(value),
					$"Количество окон не может быть отрицательным, текущее значение: {value}");

			_windowsCount = value;
		}
	}


	public double Volume() => Area * PlafondHeight;


	public static Room Generate(double min = 1, double max = 30) => new Room
	{
		Area          = General.Rand.RealNextDouble(min, max),
		PlafondHeight = General.Rand.RealNextDouble(min, max),
		WindowsCount  = General.Rand.Next((int)min, (int)max)
	};


#region Таблица


	public static void ShowTableHeader()
	{
		Console.WriteLine("┌───────────────┬──────────────┬──────────────┬─────────────┐");
		Console.WriteLine("│    Площадь    │    Высота    │    Кол-во    │    Объем    │");
		Console.WriteLine("│               │   потолков   │     окон     │             │");
		Console.WriteLine("├───────────────┼──────────────┼──────────────┼─────────────┤");
	}


	public string ToTableRow() => $"│ {Area, -13:F} │ {PlafondHeight, -12:F} │ {WindowsCount, -12:N0} │ {Volume(), -11:F} │";


	public static void ShowTableFooter() => Console.WriteLine(
		"└───────────────┴──────────────┴──────────────┴─────────────┘");


#endregion


#region Компараторы


	public static int CompareByAreaDescending(Room lhs, Room rhs) => rhs?.Area.CompareTo(lhs?.Area ?? 0) ?? 0;


	public static int CompareByWindowsCountAscending(Room lhs, Room rhs) =>
		lhs?.WindowsCount.CompareTo(rhs?.WindowsCount ?? 0) ?? 0;


#endregion
}


}
