﻿using System;
using Main.Utilities;


namespace Main.TriangularTask
{


public class Triangle
{
	public Triangle() { }

	public Triangle(double a, double b, double c) => Sides = (a, b, c);

	public double A { get; private set; }
	public double B { get; private set; }
	public double C { get; private set; }

	public (double a, double b, double c) Sides
	{
		get => (A, B, C);
		set
		{
			var (a, b, c) = value;

			if (value.CompareTo((0d, 0d, 0d)) != 1 || !IsTriangleCanBeFormed(a, b, c))
				throw new TriangleFormationException(value);

			(A, B, C) = value;
		}
	}

	
	private static bool IsTriangleCanBeFormed(double a, double b, double c) => (a + b > c) & (b + c > a) & (a + c > b);


	public double Area()
	{
		// https://www.calc.ru/ploshchad-treugolnika.html —> Формула Герона
		double p = (A + B + C) / 2;

		return Math.Sqrt(p * (p - A) * (p - B) * (p - C));
	}


	public double Perimeter() => A + B + C;


	public double MedianA() => FindMedian(B, C, A);
	public double MedianB() => FindMedian(A, C, B);
	public double MedianC() => FindMedian(A, B, C);


	private static double FindMedian(double fromA, double fromB, double to) =>
		1d / 2d * Math.Sqrt(2 * Math.Pow(fromA, 2) + 2 * Math.Pow(fromB, 2) - Math.Pow(to, 2));


	public override string ToString() => $"A: {A,-16:F} B: {B,-16:F} C: {C,-16:F}";

	
	public static Triangle Generate(double min = 1, double max = 30)
	{
		if (max < min)
			throw new ArgumentOutOfRangeException(
				$"{nameof(max)} должен быть больше {nameof(min)}");

		// Сгенерируем две стороны
		double a = General.Rand.RealNextDouble(min, max);
		double b = General.Rand.RealNextDouble(min, max);

		// Выясним разницу между ними, возведем в модуль
		double diff = Math.Abs(a - b);
		// Сгенерируем оставшуюся сторону таким образом,
		// чтобы она сбалансировала наш треугольник
		double c = General.Rand.RealNextDouble(diff, Math.Max(a, b));

		return new Triangle(a, b, c);
	}
	

#region Таблица


	public static void ShowTableHeader()
	{
		Console.WriteLine(
			"┌─────────┬─────────┬─────────┬────────────────┬─────────────┬─────────────┬─────────────┬─────────────┐");
		Console.WriteLine(
			"│    A    │    B    │    B    │    Периметр    │   Площадь   │   Медиана   │   Медиана   │   Медиана   │");
		Console.WriteLine(
			"│         │         │         │                │             │      A      │      B      │      C      │");
		Console.WriteLine(
			"├─────────┼─────────┼─────────┼────────────────┼─────────────┼─────────────┼─────────────┼─────────────┤");
	}


	public string ToTableRow() =>
		$"│ {A,-7:F} │ {B,-7:F} │ {C,-7:F} │ {Perimeter(),-14:F} │ {Area(),-11:F} │ {MedianA(),-11:F} │ {MedianB(),-11:F} │ {MedianC(),-11:F} │";


	public static void ShowTableFooter() => Console.WriteLine(
		"└─────────┴─────────┴─────────┴────────────────┴─────────────┴─────────────┴─────────────┴─────────────┘");


#endregion


#region Компараторы


	public static int CompareByPerimeterDescending(Triangle lhs, Triangle rhs) =>
		rhs?.Perimeter().CompareTo(lhs?.Perimeter() ?? 0) ?? 0;


	public static int CompareByAreaAscending(Triangle lhs, Triangle rhs) =>
		lhs?.Area().CompareTo(rhs?.Area() ?? 0) ?? 0;


#endregion
}


}
