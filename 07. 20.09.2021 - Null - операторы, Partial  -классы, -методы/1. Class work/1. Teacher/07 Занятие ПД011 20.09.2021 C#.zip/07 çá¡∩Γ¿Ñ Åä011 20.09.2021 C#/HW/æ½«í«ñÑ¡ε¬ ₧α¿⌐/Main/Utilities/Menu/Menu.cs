﻿using System;
using System.Drawing;
using System.Linq;


namespace Main.Utilities.Menu
{


public sealed class Menu
{
	public Menu(string title, MenuItem[] items)
	{
		Title = title.ReturnIfNotNullEmptyOrWhitespaceOrThrow();
		Items = items.ReturnIfNotNullOrThrow();
		
		CurrentItem    = 0;
		CursorLength   = Items.Max(item => item.Text.Length);
		CursorPosition = new Point(Console.WindowWidth / CursorLength + 10, 8);
	}


	private string     Title          { get; }
	public  string     DivideLine     { get; set; } = null;
	public  Point      CursorPosition { get; set; }
	private MenuItem[] Items          { get; }
	private int        CurrentItem    { get; set; }
	private int        CursorLength   { get; }


	private void Show()
	{
		Console.CursorVisible = false;

		Console.SetCursorPosition(CursorPosition.X, CursorPosition.Y);
		Title.ColoredLine(Palette.Title);
		Console.WriteLine();

		for (int i = 0; i < Items.Length; i++)
		{
			Console.SetCursorPosition(CursorPosition.X, Console.CursorTop + 1);

			string.Intern($"      {Items[i].Text.PadRight(CursorLength)}     ")
				  .Colored(i == CurrentItem ? Palette.Current : Palette.Normal);

			if (!Items[i].IsDivide)
				continue;

			Console.SetCursorPosition(CursorPosition.X, Console.CursorTop + 1);
			Console.WriteLine(DivideLine);
		}
	}


	private bool Navigate()
	{
		switch (Console.ReadKey(true).Key)
		{
			case ConsoleKey.UpArrow:
				CurrentItem--;
				if (CurrentItem < 0)
					CurrentItem = Items.Length - 1;
				break;
			case ConsoleKey.DownArrow:
				CurrentItem++;
				if (CurrentItem >= Items.Length)
					CurrentItem = 0;
				break;
			case ConsoleKey.Enter:
				Items[CurrentItem].InvokeItem();
				break;
			case ConsoleKey.Escape:
				return true;
		}

		return false;
	}


	public void Run()
	{
		Palette.Normal.AsCurrent();
		Console.Clear();

		while (true)
		{
			Show();

			try
			{
				if (Navigate())
				{
					Console.Clear();
					return;
				}
			}
			catch (Exception e)
			{
				e.Output();
			}
		}
	}
}


public abstract class MenuWrapper
{
	protected Menu Menu { get; set; }


	public void Run() => Menu?.Run();
}


}
