﻿using System;
using Main.TriangularTask;
using Main.Utilities;


namespace Main.RoomTask
{


public class RoomArray
{
	private Room[] _rooms;


	public RoomArray((int min, int max) sizeRange, (double min, double max) randomRange)
	{
		_rooms = new Room[General.Rand.Next(sizeRange.min, sizeRange.max)];

		for (int i = 0; i < _rooms.Length; i++)
			_rooms[i] = Room.Generate(randomRange.min, randomRange.max);
	}


	public Room[] Rooms { private get => _rooms; set => _rooms = value.ReturnIfNotNullOrThrow(); }


	public void ShowAsTable()
	{
		Room.ShowTableHeader();

		foreach (var room in Rooms)
			Console.WriteLine(room.ToTableRow());

		Room.ShowTableFooter();
	}


	public void OrderByAreaDescending() => Array.Sort(Rooms, Room.CompareByAreaDescending);

	public void OrderByWindowsCountAscending() => Array.Sort(Rooms, Room.CompareByWindowsCountAscending);
}


}
