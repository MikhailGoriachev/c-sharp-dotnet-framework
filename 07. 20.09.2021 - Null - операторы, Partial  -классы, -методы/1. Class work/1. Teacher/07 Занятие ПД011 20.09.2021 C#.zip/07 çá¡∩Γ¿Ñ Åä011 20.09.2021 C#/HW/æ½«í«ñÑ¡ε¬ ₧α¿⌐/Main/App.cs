﻿using System.Drawing;
using Main.RoomTask;
using Main.TriangularTask;
using Main.Utilities.Menu;


namespace Main
{


public class App : MenuWrapper
{
	private TriangleProcessor Triangles { get; } = new TriangleProcessor();
	private RoomProcessor     Rooms     { get; } = new RoomProcessor();


	public App() => Menu = new Menu("Главное меню приложения", new[]
	{
		new MenuItem("Задача 1. Треугольники", Triangles.Run)
			{ IsSimpleInvoke = true },
		new MenuItem("Задача 2. Комнаты", Rooms.Run)
			{ IsSimpleInvoke = true }
	});
}


}
