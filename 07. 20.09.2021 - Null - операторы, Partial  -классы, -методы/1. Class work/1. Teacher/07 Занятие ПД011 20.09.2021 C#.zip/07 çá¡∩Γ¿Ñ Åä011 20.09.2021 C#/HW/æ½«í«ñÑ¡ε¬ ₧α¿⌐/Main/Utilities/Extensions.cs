﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Main.Utilities
{


internal static class Extensions
{
	public static void ColoredLine(this string message, Color color)
	{
		message.Colored(color);
		Console.WriteLine();
	}


	public static void Colored(this string message, Color color)
	{
		Color old = Color.Instantiate();

		color.AsCurrent();

		Console.Write(message);

		old.AsCurrent();
	}


	public static int Center(this string message, int towardMessageLength) =>
		(towardMessageLength - (message?.Length ?? 0)) / 2;


	public static string ReturnIfNotNullEmptyOrWhitespaceOrThrow(this string message)
	{
		if (string.IsNullOrWhiteSpace(message))
			throw new ArgumentException(
				"Параметр не может быть null, empty, whitespace",
				nameof(message));

		return message;
	}


	public static T ReturnIfNotNullOrThrow<T>(this T obj)
		where T : class
	{
		if (obj is null)
			throw new ArgumentNullException(nameof(obj));

		return obj;
	}


	public static IEnumerable<T> ReturnIfNotNullOrThrow<T>(this IEnumerable<T> collection)
		where T : class
	{
		if (collection?.Any(triangle => triangle is null) ?? true)
			throw new ArgumentNullException(nameof(collection));

		return collection;
	}


	public static void Output(this Exception e)
	{
		if (e == null)
			return;

		Palette.Error.AsCurrent();
		Console.Clear();

		Console.SetCursorPosition(0, Console.WindowHeight / 5);
		Console.WriteLine(e);
		Console.ReadKey(true);

		Palette.Default.AsCurrent();
		Console.Clear();
	}


	public static double RealNextDouble(this Random rand, double min = 1, double max = 10) =>
		rand.ReturnIfNotNullOrThrow().NextDouble() * (max - min) + min;
}


}
