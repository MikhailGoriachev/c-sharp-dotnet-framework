﻿using System;


namespace Main.Utilities
{


/// Обертка для цветов консоли
public struct Color
{
	public ConsoleColor Foreground { get; set; }
	public ConsoleColor Background { get; set; }


	public void AsCurrent()
	{
		Console.ForegroundColor = Foreground;
		Console.BackgroundColor = Background;
	}


	public static Color Instantiate() => new Color
		{ Foreground = Console.ForegroundColor, Background = Console.BackgroundColor };
}


}
