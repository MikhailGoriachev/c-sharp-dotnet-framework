﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;   // для MessageBox() 
using Microsoft.VisualBasic;  // для Interaction



namespace HW_APP
{
    class Program
    {
        static void Main(string[] args)
        {

           
            while (true)
            {
                string inp = Interaction.InputBox("Выберете задание: \nЗадача 1 \nЗадача 2 \nЗадача 3", "Выбор Задания");
                int.TryParse(inp, out int choice);
                switch (choice)
                {
                    case 1:
                        Task1Demo();
                        break;
                    case 2:
                        Task2Demo();
                        break;
                    case 3:
                        Task3Demo();
                        break;
                    case 0:
                        Environment.Exit(0);
                        break;


                }
            }
        }


        

        /*Задача 1. Выполнить ввод и вывод при помощи методов класса Interaction. Реализовать решение задачи в бесконечном цикле, выход из цикла – после ввода 0. 
         * Вводить трехзначное положительное число (100, …, 999). При помощи операций деления и взятия остатка выделить цифры числа (единицы = число % 10, сотни = число / 100, 
         * десятки = число % 100 / 10). Определить:
         * входят ли в число цифры 4 или 7
            входят ли в него цифры 3, 6, или 9

         */
        static void Task1Demo()
        {
            Console.WindowWidth = 80;
            Console.WindowHeight = 35;
            //ввод данных
            while (true) {

                string input = Interaction.InputBox("Введите трехзначное положительное число(100,999):", "Ввод данных");

                Console.BackgroundColor = ConsoleColor.Gray;
                int.TryParse(input, out int a);
                int one;
                int hundreds;
                int dozens;
                //Создание строк для записи вариантов 
                string a1 = "a)входят цифры 4 или 7";
                string b = "b)входят цифры 3,6 или 9";

                //Проверка на правильность ввода
                if (a < 100 && a!=0 || a > 999)
                {
                    Interaction.MsgBox($"Ошибка ввода!Диапозон ввода (100,999),а пользователь ввел {a}",MsgBoxStyle.Information,"Ошибка ввода");
                }
                else if (a == 0)
                {
                    Interaction.MsgBox("Выход из программы!",MsgBoxStyle.Information,"Выход");
                    Environment.Exit(0);
                }
                else
                {

                    Interaction.MsgBox($"Вы ввели число {a}", MsgBoxStyle.Information, "Результат");
                    one = a % 10;
                    hundreds = a / 100;
                    dozens = (a % 100) / 10;

                    //проверка на соответсвие вариантам
                    //входят ли в число цифры 4 или 7
                    //входят ли в него цифры 3, 6, или 9
                    if (hundreds == 4 || hundreds == 7 || dozens == 4 || dozens == 7 || one == 4 || one == 7)
                    {
                        Interaction.MsgBox($"\tCотни : {hundreds} \n\tДесятки : {dozens} \n\tЕдиницы : {one} \n\t{a1}", MsgBoxStyle.Information, "Результат первой задачи");
                    }
                    else if(hundreds == 3 || hundreds == 6 || hundreds == 9 || dozens == 3 || dozens == 6 || dozens == 9 || one == 3 || one == 6 || one == 9)
                    {
                        Interaction.MsgBox($"\tCотни : {hundreds} \n\tДесятки : {dozens} \n\tЕдиницы : {one} \n\t{b}", MsgBoxStyle.Information, "Результат первой задачи"); ;
                    }
                    else
                    {
                        Interaction.MsgBox($"\tCотни : {hundreds} \n\tДесятки : {dozens} \n\tЕдиницы : {one} \n\tНет соответсвий!", MsgBoxStyle.Information, "Результат первой задачи");
                    }
                    
                    Console.ReadKey();
                   
                   
                }
                
            }
        }//Task1Demo

         //*Задача 2. Выполнить ввод и вывод при помощи методов класса Interaction. Решение задачи должно содержать цикл, повторяющийся трижды. 
         //* Ввести вещественное число. Если число отрицательное, то возвести его в квадрат, иначе поменять знак числа на противоположный.
        static void Task2Demo()
        {
            string msg;
            for (int i = 0; i < 3; i++)
            {
                msg = Interaction.InputBox("Введите вещественное число: ", "Ввод");
                int.TryParse(msg, out int res);
                int result = res < 0 ? res * res : res * -1;
                Interaction.MsgBox($"Вы ввели {res}\nРезультат: {result}", MsgBoxStyle.Information, "Результат");
            }
        }//Task2Demo

        static private Random rand = new Random();


        /*Задача 3. Вывод задачи организовать в консоль, в табличном виде.
        Игральным картам условно присвоены следующие порядковые номера в зависимости от их достоинства: «валет» – 11, «дама» -–12, «король» – 13, «туз» – 14. 
        Порядковые номера остальных карт соответствуют их названиям («шестерка», «семерка», …). 
        В цикле формировать 10 случайных чисел в диапазоне от 6 до 14, т.е. номер карты. По этому номеру определить достоинство карты*/
        static void Task3Demo()
        {
            string J = "Валет";
            string Q = "Дама";
            string K = "Король";
            string A = "Туз";

            Console.WindowWidth = 80;
            Console.WindowHeight = 35;

            //Вывод таблицы карты
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;

          
            Console.WriteLine("Таблица Карт:              ");
            Console.WriteLine("___________________________");

            Console.WriteLine($"Карта   {"|",8} Значение  ");
            Console.WriteLine("___________________________");

            for (int i = 0; i < 10; i++)
            {
                int x = rand.Next(6, 15);
                if(x == 11)
                {
                   
                    Console.WriteLine($"{J} {"|",10} {x}        ");
                    Console.WriteLine("___________________________");
                }
                else if(x == 12)
                {
                   
                    Console.WriteLine($"{Q}  {"|",10} {x}        ");
                    Console.WriteLine("___________________________");
                }
                else if(x == 13)
                {
                  
                    Console.WriteLine($"{K}{"|",10} {x}        ");
                    Console.WriteLine("___________________________");
                }
                else if(x == 14)
                {
                    
                    Console.WriteLine($"{A}   {"|",10} {x}        ");
                    Console.WriteLine("___________________________");
                }
                else if(x == 10)
                {
                   
                    Console.WriteLine($"Карта {x} {"|",7} {x}        ");
                    Console.WriteLine("___________________________");
                }
                else
                {
                    
                    Console.WriteLine($"Карта {x} {"|",8} {x}         ");
                    Console.WriteLine("___________________________");
                }
            }
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;

            Console.ReadKey();
            Console.Clear();

        }//Task3Demo


       
    }
}
