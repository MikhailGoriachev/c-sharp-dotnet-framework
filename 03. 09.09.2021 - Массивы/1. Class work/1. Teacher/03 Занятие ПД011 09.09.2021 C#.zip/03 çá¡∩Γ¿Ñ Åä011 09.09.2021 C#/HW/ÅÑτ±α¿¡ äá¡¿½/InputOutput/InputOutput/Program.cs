﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;



namespace InputOutput
{
    class Program
    {
        static void Task1() 
        {
            Console.Title = "InputOutput";

            while (true)
            {

                string response = Interaction.InputBox("Введите число от 100 до 999", "Задача 1");
                int d = int.Parse(response);
                if (d == 0) break;
                if (d < 100 || d > 999)
                {
                    Interaction.MsgBox("Число должно быть от 100 до 999", MsgBoxStyle.Exclamation, "Warning");
                }

                int units = d % 10;        // разряд единиц
                int tens = d / 100;        // разряд десятков
                int hundreds = d % 100 / 10; // разряд сотен

                if (units == 4 || tens == 4 || hundreds == 4)
                {
                    Interaction.MsgBox("Число содержить 4", MsgBoxStyle.Information, "Результат проверки");
                }

                if (units == 7 || tens == 7 || hundreds == 7)
                {
                    Interaction.MsgBox("Число содержить 7", MsgBoxStyle.Information, "Результат проверки");
                }

                if (units == 3 || tens == 3 || hundreds == 3)
                {
                    Interaction.MsgBox("Число содержить 3", MsgBoxStyle.Information, "Результат проверки");
                }

                if (units == 6 || tens == 6 || hundreds == 6)
                {
                    Interaction.MsgBox("Число содержить 6", MsgBoxStyle.Information, "Результат проверки");
                }
                if (units == 9 || tens == 9 || hundreds == 9)
                {
                    Interaction.MsgBox("Число содержить 9", MsgBoxStyle.Information, "Результат проверки");
                }

                Console.WriteLine("\nПрограмма закончена");
                Console.ReadKey();

            }
        }

        static void Task2()
        {

            for (int i = 0; i < 3; ++i)
            {
                string response = Interaction.InputBox("Введите вещественное число", "Задача 2");
                double d = double.Parse(response);
                if (d < 0)
                {
                    Interaction.MsgBox(d = d * d, MsgBoxStyle.Information, "Ответ");
                }
                else Interaction.MsgBox(d = -d, MsgBoxStyle.Information, "Ответ");
            }

        }

        static void Task3()
        {


            Console.WriteLine("|----------------------------|");
            Console.WriteLine("| Наименование карты | Цифра |");
            Console.WriteLine("|--------------------|-------|");
            Random rand = new Random();
            for (int i = 0; i < 10; ++i)
            {
                int a = rand.Next(6, 14);

                string desc;

                switch (a)
                {
                    case 6: desc = "шестерка"; break;
                    case 7: desc = "семерка"; break;
                    case 8: desc = "восьмерка"; break;
                    case 9: desc = "девятка"; break;
                    case 10: desc = "десятка"; break;
                    case 11: desc = "валет"; break;
                    case 12: desc = "дама"; break;
                    case 13: desc = "король"; break;
                    case 14: desc = "туз"; break;
                    default: desc = "нет такого значения"; break;

                }// switch

                Console.WriteLine($"| {desc,17}, | {a,3}   |");


            }// for
            Console.WriteLine("|--------------------|-------|");
        }
        static void Main(string[] args)
        {
            Task1();
            Task2();
            Task3();
        }
    }
}
