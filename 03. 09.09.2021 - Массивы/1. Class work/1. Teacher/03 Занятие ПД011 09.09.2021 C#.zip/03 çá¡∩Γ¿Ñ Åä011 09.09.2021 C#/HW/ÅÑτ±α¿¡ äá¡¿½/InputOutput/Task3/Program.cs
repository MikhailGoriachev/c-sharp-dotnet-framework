﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("|----------------------------|");
            Console.WriteLine("| Наименование карты | Цифра |");
            Console.WriteLine("|--------------------|-------|");
            Random rand = new Random();
            for (int i = 0; i < 10; ++i)
            {
                int a = rand.Next(6, 14);
                
                string desc;

                switch (a)
                {
                    case 6: desc = "шестерка"; break;
                    case 7: desc = "семерка"; break;
                    case 8: desc = "восьмерка"; break;
                    case 9: desc = "девятка"; break;
                    case 10: desc = "десятка"; break;
                    case 11: desc = "валет"; break;
                    case 12: desc = "дама"; break;
                    case 13: desc = "король"; break;
                    case 14: desc = "туз"; break;
                    default: desc = "нет такого значения"; break;

                }// switch

                Console.WriteLine($"| {desc,17}, | {a,3}   |");
                

            }// for
            Console.WriteLine("|--------------------|-------|");
        }
    }
}
