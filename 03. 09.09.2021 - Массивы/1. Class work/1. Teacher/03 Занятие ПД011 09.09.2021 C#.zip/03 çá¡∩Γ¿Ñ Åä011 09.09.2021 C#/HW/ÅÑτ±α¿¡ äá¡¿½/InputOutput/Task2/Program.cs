﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i =0; i<3; ++i)
            {
                string response = Interaction.InputBox("Введите вещественное число", "Задача 2");
                double d = double.Parse(response);
                if (d < 0)
                {
                    Interaction.MsgBox(d = d * d, MsgBoxStyle.Information, "Ответ");
                }
                else Interaction.MsgBox(d = -d, MsgBoxStyle.Information, "Ответ");
            }
        }
    }
}
