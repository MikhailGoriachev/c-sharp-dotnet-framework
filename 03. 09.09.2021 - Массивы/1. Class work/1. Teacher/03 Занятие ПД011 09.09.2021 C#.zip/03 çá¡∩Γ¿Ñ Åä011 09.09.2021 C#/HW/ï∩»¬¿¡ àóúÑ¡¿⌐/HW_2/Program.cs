﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

namespace HW_2
{
    class Program
    {
        //метод, находящий цифры в числе для варианта А
        //static void FindNumberA(int units, int dozens, int hundreds, int a)
        //{
        //    if ((units == 4) || (dozens == 4) || (hundreds == 4))
        //        Interaction.MsgBox($"В числе {a} найдена цифра 4", MsgBoxStyle.Information, "Вариант a");
        //    else if ((units == 7) || (dozens == 7) || (hundreds == 7))
        //        Interaction.MsgBox($"В числе {a} найдена цифра 7", MsgBoxStyle.Information, "Вариант a");
        //    else
        //        Interaction.MsgBox($"В числе {a} не найдено цифр 4 или 7", MsgBoxStyle.Information, "Вариант a");
        //}//FindNumberA

        //метод, находящий цифры в числе для варианта B
        //static void FindNumberB(int units, int dozens, int hundreds, int a)
        //{
        //    if ((units == 3) || (dozens == 3) || (hundreds == 3))
        //        Interaction.MsgBox($"В числе {a} найдена цифра 3", MsgBoxStyle.Information, "Вариант b");
        //    else if ((units == 6) || (dozens == 6) || (hundreds == 6))
        //        Interaction.MsgBox($"В числе {a} найдена цифра 6", MsgBoxStyle.Information, "Вариант b");
        //    else if ((units == 9) || (dozens == 9) || (hundreds == 9))
        //        Interaction.MsgBox($"В числе {a} найдена цифра 9", MsgBoxStyle.Information, "Вариант b");
        //    else
        //        Interaction.MsgBox($"В числе {a} не найдено цифр 3,6 или 9", MsgBoxStyle.Information, "Вариант b");
        //}//FindNumberB
        static bool FindNumber(int units, int dozens, int hundreds, int number) 
        {
            return units == number || dozens == number || hundreds == number;
        }//FindNumberr

        static private Random rand = new Random();

        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;

            Task1();
            Task2();
            Task3();

        }//main

        static void Task1() 
        {
            while (true)
            {
                //вводим целое число
                string resp = Interaction.InputBox("Введите трехзначное положительное число(100, ..., 999 | 0 - выход из программы):",
                   "Ввод данных");
                //парсинг числа из строки
                int a;
                int.TryParse(resp, out a);

                if (a == 0)
                {
                    Interaction.MsgBox("Выход из приложения", MsgBoxStyle.Information, "Введен 0");
                    break;
                } else if(a < 0) 
                {
                    Interaction.MsgBox("Выполните ввод повторно", MsgBoxStyle.Information,
                        "Введены некорректные данные");
                    continue;
                }//if else if

                int units = a % 10;
                int dozens = a % 100 / 10;
                int hundreds = a / 100;

                //вариант проверки а
                //FindNumberA(units, dozens, hundreds, a);
                //вариант проверки b
                //FindNumberB(units, dozens, hundreds, a);

                //вариант проверки а
                bool aRes = FindNumber(units, dozens, hundreds, 4) ||
                            FindNumber(units, dozens, hundreds, 7);
                ////вариант проверки b
                bool bRes = FindNumber(units, dozens, hundreds, 3) ||
                            FindNumber(units, dozens, hundreds, 6) ||
                            FindNumber(units, dozens, hundreds, 9);
                Interaction.MsgBox($"Результаты:\n Вариант a(4 или 7): {aRes}.\n Вариант b:(3,6,9): {bRes}",
                    MsgBoxStyle.Information, "Results");

            }//while
        }//Task1
        static void Task2() 
        {
            for (int i = 0; i < 3; i++)
            {
                //вводим вещественное число
                string resp = Interaction.InputBox("Введите вещественное число(знак разделитель \",\"):",
                   "Ввод данных");
                //парсинг числа из строки
                double a;
                double.TryParse(resp, out a);

                if (a < 0)
                    a *= a;
                else
                    a = -a;

                Interaction.MsgBox($"Число после обработки: {a}", MsgBoxStyle.Information);

            }//for

        }//Task2
        static void Task3() 
        {
            Console.WriteLine("+-----+-------+---------------+");
            Console.WriteLine("|  №  | Число |  Достоинство  |");
            Console.WriteLine("+-----+-------+---------------+");

            //строка для Достоинства карты
            string str = "";

            for(int i = 0; i < 10; i++) 
            {
                int card  = rand.Next(6, 15);

                switch (card) 
                {
                    case 6:
                        str = "\"Шестерка\"";
                        break;
                    case 7:
                        str = "\"Семерка\"";
                        break;
                    case 8:
                        str = "\"Восьмерка\"";
                        break;
                    case 9:
                        str = "\"Девятка\"";
                        break;
                    case 10:
                        str = "\"Десятка\"";
                        break;
                    case 11:
                        str = "\"Валет\"";
                        break;
                    case 12:
                        str = "\"Дама\"";
                        break;
                    case 13:
                        str = "\"Король\"";
                        break;
                    case 14:
                        str = "\"Туз\"";
                        break;

                }//switch      
                
                Console.WriteLine($"| {i + 1,3} | {card,5} | {str,-13} |");
            }//for
            Console.WriteLine("+-----+-------+---------------+");
        }//Task3

    }
}
