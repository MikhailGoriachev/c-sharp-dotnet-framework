﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction
/*
 * Разработайте консольное приложение для решения следующих задач. Каждую
 * задачу размещайте в отдельном статическом методе класса Program. 
 *
 * Задача 1.
 * Выполнить ввод и вывод при помощи методов класса Interaction. Реализовать
 * решение задачи в бесконечном цикле, выход из цикла – после ввода 0.
 * Вводить трехзначное положительное число (100, …, 999). При помощи операций
 * деления и взятия остатка выделить цифры числа (единицы = число % 10,
 * сотни = число / 100, десятки = число % 100 / 10).
 * Определить:
 *     a) входят ли в число цифры 4 или 7
 *     b) входят ли в него цифры 3, 6, или 9
 *
 * Задача 2.
 * Выполнить ввод и вывод при помощи методов класса Interaction. Решение задачи
 * должно содержать цикл, повторяющийся трижды. Ввести вещественное число. Если
 * число отрицательное, то возвести его в квадрат, иначе поменять знак числа на
 * противоположный.
 *
 * Задача 3.
 * Вывод задачи организовать в консоль, в табличном виде.
 * Игральным картам условно присвоены следующие порядковые номера в зависимости
 * от их достоинства: «валет» – 11, «дама» - 12, «король» – 13, «туз» – 14.
 * Порядковые номера остальных карт соответствуют их названиям («шестерка»,
 * «семерка», …). 
 * В цикле формировать 10 случайных чисел в диапазоне от 6 до 14, т.е. номер
 * карты. По этому номеру определить достоинство карты.     
 *
 */
namespace ControlOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 09.09.2021 - ввод и вывод, управляющие операторы";
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.CursorVisible = false;

            // главный цикл работы приложения 
            while (true) {
                ShowNavBar();
                ShowText();

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                switch (key) {
                    // решение задачи 1 назначено на клавишу F5
                    case ConsoleKey.F5:
                        Task1();
                        break;

                    // решение задачи 1 назначено на клавишу F6
                    case ConsoleKey.F6:
                        Task2();
                        break;

                    // решение задачи 1 назначено на клавишу F7
                    case ConsoleKey.F7:
                        Task3();
                        break;

                    // выход из приложения назначен на клавишу F10
                    case ConsoleKey.F10:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Console.SetCursorPosition(0, Console.WindowHeight - 1);
                        Console.CursorVisible = true;
                        return;
                } // switch
            } // while
        } // Main


        // выводим верхнюю строку
        private static void ShowNavBar() {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст с функциональными клавишами в верхнюю строку
            WriteXY(2, 0, "F5", ConsoleColor.Red);
            WriteXY(5, 0, "Задача 1", ConsoleColor.Black);

            WriteXY(16, 0, "F6", ConsoleColor.Red);
            WriteXY(19, 0, "Задача 2", ConsoleColor.Black);

            WriteXY(30, 0, "F7", ConsoleColor.Red);
            WriteXY(33, 0, "Задача 3", ConsoleColor.Black);

            WriteXY(45, 0, "F10", ConsoleColor.Red);
            WriteXY(49, 0, "Выход", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBar


        // вывод текста задания в консоль
        private static void ShowText() {
            string text = @"
             Задача 1.
             Выполнить ввод и вывод при помощи методов класса Interaction. Реализовать
             решение задачи в бесконечном цикле, выход из цикла – после ввода 0.
             Вводить трехзначное положительное число (100, …, 999). При помощи операций
             деления и взятия остатка выделить цифры числа (единицы = число % 10,
             сотни = число / 100, десятки = число % 100 / 10).
             Определить:
                 a) входят ли в число цифры 4 или 7
                 b) входят ли в него цифры 3, 6, или 9
             
             Задача 2.
             Выполнить ввод и вывод при помощи методов класса Interaction. Решение задачи
             должно содержать цикл, повторяющийся трижды. Ввести вещественное число. Если
             число отрицательное, то возвести его в квадрат, иначе поменять знак числа на
             противоположный.
             
             Задача 3.
             Вывод задачи организовать в консоль, в табличном виде.
             Игральным картам условно присвоены следующие порядковые номера в зависимости
             от их достоинства: ""валет"" – 11, ""дама"" - 12, ""король"" – 13, ""туз"" – 14.
             Порядковые номера остальных карт соответствуют их названиям (""шестерка"",
              ""семерка"",...). 
             В цикле формировать 10 случайных чисел в диапазоне от 6 до 14, т.е. номер
             карты. По этому номеру определить достоинство карты.     
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowText


        // Решение задачи 1 --------------------------------------------------------
        // Вывод текста задания в консоль
        private static void ShowTextTask1()
        {
            string text = @"
             Задача 1.
             Выполнить ввод и вывод при помощи методов класса Interaction. Реализовать
             решение задачи в бесконечном цикле, выход из цикла – после ввода 0.
             Вводить трехзначное положительное число (100, …, 999). При помощи операций
             деления и взятия остатка выделить цифры числа (единицы = число % 10,
             сотни = число / 100, десятки = число % 100 / 10).
             Определить:
                 a) входят ли в число цифры 4 или 7
                 b) входят ли в него цифры 3, 6, или 9
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask1

        // Вывод информационного сообщения в верхнюю строку экрана
        private static void ShowNavBarTask1() {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY( 2, 0, "Задача 1", ConsoleColor.Red);
            WriteXY(11, 0, "Определить наличие цифр в трехзначном положительном числе, 0 - для выхода", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask1

        // возвращает true, если трехзначное число
        // number содержит цифру digit, не проверяем,
        // что число трехзначное, доверяем :) 
        private static bool HasDigit(int number, int digit)
        {
            // получаем цифры числа
            int d1 = number % 10;
            int d10 = number / 10 % 10;
            int d100 = number / 100;

            // проверяем цифры числа на совпадение с заданной цифрой digit
            return d1 == digit || d10 == digit || d100 == digit;
        } // HasDigit


        /*
         * Задача 1.
         * Выполнить ввод и вывод при помощи методов класса Interaction. Реализовать
         * решение задачи в бесконечном цикле, выход из цикла – после ввода 0.
         * Вводить трехзначное положительное число (100, …, 999). При помощи операций
         * деления и взятия остатка выделить цифры числа (единицы = число % 10,
         * сотни = число / 100, десятки = число % 100 / 10).
         * Определить:
         *     a) входят ли в число цифры 4 или 7
         *     b) входят ли в него цифры 3, 6, или 9
         */
        private static void Task1() {

            string response = "345";// переменная для получения ввода пользователя

            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask1();
            ShowTextTask1();

            while (true) {
                // ввод и парсинг числа
                response = Interaction.InputBox(
                    "Введите трехзначное положительное число или 0 для выхода",
                    "Задача 1. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                bool succcess = int.TryParse(response, out int number);
                if (!succcess) {
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

                // проверка условия выхода из цикла
                if (number == 0) break;

                // прооверка допусимого диапазона значений
                if (number < 100 || number > 999) {
                    Interaction.MsgBox(
                    "Вы ввели не трехзначное положительное число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

                // обработка по заданию
                // разбивку на цифры можно провести только один раз,
                // но тогда код проверки будет сложнее, но можно
                // вынести (делегировать) разбивку и проверку в 
                // отдельный метод
                // int d1 = number % 10;
                // int d10 = number % 100 / 10;
                // int d100 = number / 100;

                // a) входят ли в число цифры 4 или 7
                // bool result1 = d1 == 4 || d1 == 7 || 
                //                d10 == 4 || d10 == 7 || 
                //                d100 == 4 || d100 == 7;
                // альтернатива - через методы класса string
                // bool result1 = response.Contains("4") || response.Contains("7");
                bool result1 = HasDigit(number, 4) || HasDigit(number, 7);

                // входят ли в него цифры 3, 6, или 9 
                // bool result2 = d1 == 3 || d1 == 6 || d1 == 9 ||
                //                d10 == 3 || d10 == 6 || d10 == 9 ||
                //                d100 == 3 || d100 == 6 || d100 == 9;
                // альтернатива - через методы класса string
                // bool result2 = response.Contains("3") || response.Contains("6") || response.Contains("9");
                bool result2 = HasDigit(number, 3) || HasDigit(number, 6) || HasDigit(number, 9);

                // формирование и вывод строки результата
                string result = $"Задача 1.\nа) В числе {number} есть цифры 4 или 7: {(result1 ? "Да" : "Нет")}\n" +
                                $"б) В числе {number} есть цифры 3, 6 или 9: {(result2 ? "Да" : "Нет")}\n";
                Interaction.MsgBox(result, 
                    MsgBoxStyle.Information | MsgBoxStyle.OkOnly, 
                    "Задача 1. Вывод результатов");
            } // while
        } // Task1
        // Решение задачи 1 --------------------------------------------------------
        

        // Решение задачи 2 --------------------------------------------------------
        // Вывод текста задания в консоль
        private static void ShowTextTask2()
        {
            string text = @"
             Задача 2.
             Выполнить ввод и вывод при помощи методов класса Interaction. Решение задачи
             должно содержать цикл, повторяющийся трижды. Ввести вещественное число. Если
             число отрицательное, то возвести его в квадрат, иначе поменять знак числа на
             противоположный.
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask2

        // Вывод информационного сообщения в верхнюю строку экрана
        private static void ShowNavBarTask2() {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 2", ConsoleColor.Red);
            WriteXY(11, 0, "Три цикла: ввод и обработка вещественного числа", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask2

        /*
         * Задача 2.
         * Выполнить ввод и вывод при помощи методов класса Interaction. Решение задачи
         * должно содержать цикл, повторяющийся трижды. Ввести вещественное число. Если
         * число отрицательное, то возвести его в квадрат, иначе поменять знак числа на
         * противоположный.
         */
        private static void Task2() {
            string response = "";   // переменная для получения ввода пользователя

            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask2();
            ShowTextTask2();

            const int n = 3;
            for (int i = 1; i <= n; ++i) {
                // ввод и парсинг числа
                response = Interaction.InputBox(
                    "Введите вещественное число (используйте ',' для разделения " +
                    "целой и дробной частей) или 0 для выхода",
                    $"Задача 2. Ввод, цикл {i} из {n}", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                bool succcess = double.TryParse(response, out double number);
                if (!succcess) {
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

                // проверка условия выхода из цикла
                if (number == 0) break;

                // обработка по заданию

                // Начинаем формирование строки результата
                string result = $"Задача 2.\nВведено число для обработки: {number:n3}\n";

                // Если число отрицательное, то возвести его в квадрат,
                // иначе поменять знак числа на противоположный
                number = number < 0 ? number * number : -number;

                // Завершение формирования и вывод строки результата
                result += $"Число после обработки: {number:n3}\n";
                Interaction.MsgBox(result,
                    MsgBoxStyle.Information | MsgBoxStyle.OkOnly,
                    "Задача 2. Вывод результатов");
            } // for i
        } // Task2


        // Решение задачи 3 --------------------------------------------------------
        // Вывод текста задания в консоль
        private static void ShowTextTask3() {
            string text = @"
             Задача 3.
             Вывод задачи организовать в консоль, в табличном виде.
             Игральным картам условно присвоены следующие порядковые номера в зависимости
             от их достоинства: ""валет"" – 11, ""дама"" – 12, ""король"" – 13, ""туз"" – 14.
             Порядковые номера остальных карт соответствуют их названиям (""шестерка"",
             ""семерка"", ...). 
             В цикле формировать 10 случайных чисел в диапазоне от 6 до 14, т.е. номер
             карты. По этому номеру определить достоинство карты. 
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask3

        // Вывод информационного сообщения в верхнюю строку экрана
        private static void ShowNavBarTask3() {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 3", ConsoleColor.Red);
            WriteXY(11, 0, "Формирование и вывод в табличном формате описаний 10 карт", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask2


        // Создание статического объекта для формирования случайных чисел
        private static Random random = new Random();

        /*
         * Задача 3.
         * Вывод задачи организовать в консоль, в табличном виде.
         * Игральным картам условно присвоены следующие порядковые номера в зависимости
         * от их достоинства: «валет» – 11, «дама» – 12, «король» – 13, «туз» – 14.
         * Порядковые номера остальных карт соответствуют их названиям («шестерка»,
         * «семерка», …). 
         * В цикле формировать 10 случайных чисел в диапазоне от 6 до 14, т.е. номер
         * карты. По этому номеру определить достоинство карты. 
         */
        private static void Task3() {
            // оформление экрана вывода, в т.ч. выключение курсора
            Console.Clear();
            ShowNavBarTask3();
            ShowTextTask3();
            Console.CursorVisible = true;

            // Выводим шапку таблицы
            Console.WriteLine(
                "\n" +
                "\t    ┌────┬─────────────┬────────────────┐\n" +
                "\t    │  N │ Номер карты │ Описание карты │\n" +
                "\t    ├────┼─────────────┼────────────────┤"
            );

            // формирование и вывод описаний 10 игральных карт
            const int n  = 10;  // количество циклов по заданию
            const int lo =  6;  // минимальный номер карты
            const int hi = 14;  // максимальный номер карты
            for (int i = 0; i < n; i++) {
                // получить номер карты
                int number = random.Next(lo, hi);

                // сформировать описание карты
                string cardDescription = "";
                switch (number) {
                    case 6:
                        cardDescription = "шестерка";
                        break;
                    case 7:
                        cardDescription = "семерка";
                        break;              
                    case 8:
                        cardDescription = "восьмерка";
                        break;
                    case 9:
                        cardDescription = "девятка";
                        break;          
                    case 10:
                        cardDescription = "десятка";
                        break;
                    case 11:
                        cardDescription = "валет";
                        break;              
                    case 12:
                        cardDescription = "дама";
                        break;
                    case 13:
                        cardDescription = "король";
                        break;  
                    case 14:
                        cardDescription = "туз";
                        break;
                } // switch

                // вывести строку таблицы
                Console.WriteLine($"\t    │ {i+1, 2} │ {number, 11} │ {cardDescription, -14} │");
            } // for i

            Console.WriteLine("\t    └────┴─────────────┴────────────────┘");

            // выводим финишное сообщение задачи, ждем нажатия любой клавиши
            // и чистим экран перед выходом и выключаем курсор
            WriteXY(12, Console.WindowHeight-1, 
                "Нажмите любую клавишу для продолжения...", 
                ConsoleColor.Gray
            );
            Console.ReadKey(true);  // ожидать код клавиши, не отображать символ клавиши
            Console.Clear();
            Console.CursorVisible = false;
        } // Task3
        // Решение задачи 3 --------------------------------------------------------


        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        static void WriteXY(int x, int y, string s, ConsoleColor color) {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);
            
            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY
    } // class Program
}
