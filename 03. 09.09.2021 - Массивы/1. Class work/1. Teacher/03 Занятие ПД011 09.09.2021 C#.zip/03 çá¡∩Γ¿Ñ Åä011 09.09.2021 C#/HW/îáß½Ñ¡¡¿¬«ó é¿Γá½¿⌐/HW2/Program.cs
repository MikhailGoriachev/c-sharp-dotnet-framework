﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace HW2
{
	class Program
	{
		static void Main(string[] args)
		{
			// Начальная настройка
			Console.Title = "Домашнее задание";
			Console.ForegroundColor = ConsoleColor.Green;
			Console.BackgroundColor = ConsoleColor.Black;
			Console.CursorVisible = false;
			
			ConsoleKeyInfo cmd;
			// Меню выбора задачи
			do
			{
				Console.Clear();
				Console.SetCursorPosition(0,3);
				Console.WriteLine("    Выберите пункт меню:\n");
				Console.WriteLine("    1. Задача 1");
				Console.WriteLine("    2. Задача 2");
				Console.WriteLine("    3. Задача 3");
				Console.WriteLine("    Esc. Выход");
				
				// Чтение кода клавиши
				cmd = Console.ReadKey(false);

				switch (cmd.Key)
				{
					case ConsoleKey.D1 or ConsoleKey.NumPad1: Task1(); break;
					case ConsoleKey.D2 or ConsoleKey.NumPad2: Task2(); break;
					case ConsoleKey.D3 or ConsoleKey.NumPad3: Task3(); break;
				}
			} while (cmd.Key != ConsoleKey.Escape);
		}

		/// <summary>
		/// Реализация решения задачи 1
		/// </summary>
		private static void Task1()
		{
			while (true)
			{
				// Ввод числа 
				string response = Interaction.InputBox("Введите трёхзначное положительное число:",
					"Ввод данных"
				);

				// Случай, если в InputBox нажата отмена (нажатие ОК с пустой строкой ввода возвращает
				// тоже самое, не получается обработать по-разному)
				if (response == "") break;

				// Парсинг целого числа из строки
				int inputNum;
				if (!int.TryParse(response, out inputNum))
				{
					Interaction.MsgBox(
						"Неверный ввод",
						MsgBoxStyle.Critical,
						"Ошибка");
					continue;
				}

				// Выход из цикла, если введен 0
				if (inputNum == 0) 
					break;
				
				// Введено число не по условию
				if (inputNum is < 100 or > 999)
				{
					Interaction.MsgBox(
						"Введено не трёхзначное положительное число",
						MsgBoxStyle.Critical,
						"Ошибка");
					continue;
				}


				// Разбор на цифры
				int units = inputNum % 10;
				int tens = inputNum % 100 / 10;
				int hundreds = inputNum / 100;

				string msg = "Цифры 4 или 7 не входят в число";

				// a)входят ли в число цифры 4 или 7
				if (units == 4 || tens == 4 || hundreds == 4)
				{
					msg = "В число входит: цифра 4";
					if (units == 7 || tens == 7 || hundreds == 7)
						msg += " и цифра 7";
				}
				else if (units == 7 || tens == 7 || hundreds == 7)
					msg = "В число входит: цифра 7";


				Interaction.MsgBox(
					msg,
					MsgBoxStyle.Information,
					"Вхождение цифры 4 или 7");


				msg = "В число входит:";

				// b)входят ли в него цифры 3, 6, или 9
				switch (units, tens, hundreds)
				{
					case var (u, t, h) when u == 3 || t == 3 || h == 3:
						msg += " 3";
						break;
					case var (u, t, h) when u == 6 || t == 6 || h == 6:
						msg += " 6";
						break;
					case var (u, t, h) when u == 9 || t == 9 || h == 9:
						msg += " 9";
						break;
					default:
						msg = "Ни одна из цифр не входит в число";
						break;
				}

				Interaction.MsgBox(
					msg,
					MsgBoxStyle.Information,
					"Вхождение цифр 3, 6, 9");
			}
		}

		/// <summary>
		/// Реализация решения задачи 2
		/// </summary>
		private static void Task2()
		{
			for (int i = 0; i < 3; i++)
			{
				// Ввод числа 
				string response = Interaction.InputBox("Введите вещественное число:",
					"Ввод данных"
				);

				// Случай, если в InputBox нажата отмена (нажатие ОК с пустой строкой ввода возвращает
				// тоже самое, не получается обработать по-разному)
				if (response == "") break;

				// Парсинг вещественного числа из строки
				double inputNum;
				if (!double.TryParse(response, out inputNum))
				{
					Interaction.MsgBox(
						"Неверный ввод",
						MsgBoxStyle.Critical,
						"Ошибка");
					return;
				}

				// Если число отрицательное, то возвести его в квадрат,
				// иначе поменять знак числа на противоположный.
				if (inputNum < 0)
					inputNum *= inputNum;
				else inputNum = -inputNum;

				Interaction.MsgBox(
					$"Измененное число: {inputNum}",
					MsgBoxStyle.Information,
					"Задача 2");
			}
		}

		/// <summary>
		/// Реализация решения задачи 3
		/// </summary>
		static void Task3()
		{
			Console.Clear();
			Console.SetCursorPosition(0,4);

			Random rand = new Random();
			Console.WriteLine("    Задача 3. Определить достоинство карты по номеру:\n");
			Console.WriteLine("    +———————+———————————+");
			Console.WriteLine("    | Число |   Карта   |");
			Console.WriteLine("    +———————+———————————+");

			for (int i = 0; i < 10; i++)
			{
				int n = rand.Next(6, 15);
				// Определить достоинство карты по номеру
				switch (n)
				{
					case 6:  Console.WriteLine($"    | {n,5} | Шестерка  |"); break;
					case 7:  Console.WriteLine($"    | {n,5} | Семерка   |"); break;
					case 8:  Console.WriteLine($"    | {n,5} | Восьмерка |"); break;
					case 9:  Console.WriteLine($"    | {n,5} | Девятка   |"); break;
					case 10: Console.WriteLine($"    | {n,5} | Десятка   |"); break;
					case 11: Console.WriteLine($"    | {n,5} | Валет     |"); break;
					case 12: Console.WriteLine($"    | {n,5} | Дама      |"); break;
					case 13: Console.WriteLine($"    | {n,5} | Король    |"); break;
					case 14: Console.WriteLine($"    | {n,5} | Туз       |"); break;
				}
			}
			Console.WriteLine("    +———————+———————————+");
			Console.WriteLine("    Нажмите любую клавишу для продолжения.");
			Console.ReadKey(false);
		}
	}
}
