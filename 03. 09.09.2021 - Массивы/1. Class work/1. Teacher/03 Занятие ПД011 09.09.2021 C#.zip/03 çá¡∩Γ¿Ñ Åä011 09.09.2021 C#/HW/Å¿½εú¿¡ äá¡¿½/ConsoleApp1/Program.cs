﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;  // для Interaction


namespace ConsoleApp1
{
    class Program
    {
        static private Random rand = new Random();

        static void Main(string[] args)
        {
            //Task1();
            //Task2();
            Task3();

        }

        static void Task1()
        {
            while (true)
            {
                string str = Interaction.InputBox("Введите трехзначное положительное число:");
                int number;

                int.TryParse(str, out number);


                if (number > 100 && number < 999)
                {
                    int units = number % 10;
                    int hundreds = number / 100;
                    int decades = number % 100 / 10;


                    Interaction.MsgBox($"Еденицы: {units}, десятки: {decades}, сотни {hundreds}");


                    if (units == 7 || hundreds == 7 || decades == 7)
                        Interaction.MsgBox("Найдена цифра 7!");
                    if (units == 4 || hundreds == 4 || decades == 4)
                        Interaction.MsgBox("Найдена цифра 4!");
                    if (units == 3 || hundreds == 3 || decades == 3)
                        Interaction.MsgBox("Найдена цифра 3!");
                    if (units == 6 || hundreds == 6 || decades == 6)
                        Interaction.MsgBox("Найдена цифра 6!");
                    if (units == 9 || hundreds == 9 || decades == 9)
                        Interaction.MsgBox("Найдена цифра 9!");
                    else
                        Interaction.MsgBox("Число не содержит цифр: 7, 4, 3, 6, 9!");


                }
                else
                {
                    Interaction.MsgBox("Неверный ввод!", MsgBoxStyle.Information);
                    break;
                }
            }
        }

        static void Task2()
        {
            for (int i = 0; i < 3; i++)
            {
                string str = Interaction.InputBox("Введите вещественное число(со знаком запятой):");

                double number;
                double.TryParse(str, out number);

                if (number == 0)
                {
                    Interaction.MsgBox("Неверный ввод!", MsgBoxStyle.Information);
                    break;
                }

                if (number > 0)
                    number *= -1;
                else number *= number;

                Interaction.MsgBox($"Ваше число после преобразования: {number}", MsgBoxStyle.Information);
            }
        }

        static void Task3()
        {
            Console.BackgroundColor = ConsoleColor.Green;
            Console.ForegroundColor = ConsoleColor.Black;

            int h=35, w=0;

            w++;
            Console.SetCursorPosition(h, w);
            Console.Write(" _____________________________ \n");
            w++;
            Console.SetCursorPosition(h, w);
            Console.Write("|   Номер   |   Достоинство   |\n");
            w++;
            Console.SetCursorPosition(h, w);
            Console.Write("|___________|_________________|\n");

            for (int i = 0; i < 10; i++)
            {
                int n = rand.Next(6, 15);

                w++;

                Console.SetCursorPosition(h, w);

                switch (n)
                {
                    case 6:
                        Console.Write("|     6     |     Шестерка    |\n");
                        goto default;
                    case 7:
                        Console.Write("|     7     |     Семерка     |\n");
                        goto default;
                    case 8:
                        Console.Write("|     8     |    Восьмерка    |\n");
                        goto default;
                    case 9:
                        Console.Write("|     9     |     Девятка     |\n");
                        goto default;
                    case 10:
                        Console.Write("|    10     |     Десятка     |\n");
                        goto default;
                    case 11:
                        Console.Write("|    11     |      Валет      |\n");
                        goto default;
                    case 12:
                        Console.Write("|    12     |       Дама      |\n");
                        goto default;
                    case 13:
                        Console.Write("|    13     |      Король     |\n");
                        goto default;
                    case 14:
                        Console.Write("|    14     |       Туз       |\n");
                        goto default;
                    default:
                        w++;
                        Console.SetCursorPosition(h, w);
                        Console.Write("|___________|_________________|\n");
                        break;

                }
            }

            Console.ReadKey();
        }
    }
}
