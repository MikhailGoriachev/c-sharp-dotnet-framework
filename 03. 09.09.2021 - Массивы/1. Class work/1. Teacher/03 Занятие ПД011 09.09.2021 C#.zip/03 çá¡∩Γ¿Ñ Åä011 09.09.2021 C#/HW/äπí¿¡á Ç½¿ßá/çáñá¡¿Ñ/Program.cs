﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;  // для Interaction

namespace Задание
{
    class Program
    {
        static private Random rand = new Random(); // для задачи 3

        const int HEIGHT = 35, WIDTH = 120;        // размер окна консоли 
        static void Main(string[] args) {
            Console.Title = "Задание на 09.09.2021";
            Console.SetWindowSize(WIDTH, HEIGHT);

            // Задача 1
            Task1();

            // Задача 2
            Task2();

            // Задача 3
            Task3();

        } // Main

        /// <summary>
        /// Задача 1. Выполнить ввод и вывод при помощи методов класса Interaction.
        ///           Реализовать решение задачи в бесконечном цикле, выход из цикла – после ввода 0. 
        ///           Вводить трехзначное положительное число (100, …, 999). При помощи операций 
        ///           деления и взятия остатка выделить цифры числа. Определить:
        ///           a)	входят ли в число цифры 4 или 7
        ///           b)	входят ли в него цифры 3, 6, или 9
        /// </summary>
        static void Task1() {

            while (true) {
                Console.Clear();
                showNavBarMessage("Задача 1.");

                int x = -1;

                do {
                    string str = Interaction.InputBox(
                    "Введите трехзначное положительное число (100, …, 999)\n0 - выход:",
                    "Задача 1");

                    // парсинг целого числа из строки
                    if(!(int.TryParse(str, out x))) x = -1;
                } while (x != 0 && (x < 100 || x > 999));

                if (x == 0) break;

                // сотни 
                int handreds = x / 100;

                // десятки
                int dozens = x % 100 / 10;

                // единицы
                int units = x % 10;


                // a == true, если в число входят цифры 4 или 7
                bool a = handreds == 7 || handreds == 4 ||
                           dozens == 7 ||   dozens == 4 ||
                            units == 7 ||    units == 4;


                // b == true, если в число входят цифры 3, 6, или 9
                //bool b = handreds == 3 || handreds == 6 || handreds == 9 ||
                //           dozens == 3 ||   dozens == 6 ||   dozens == 9 ||
                //           units  == 3 ||    units == 6 ||    units == 9;

                // b == true, если в число входят цифры 3, 6, или 9
                // В диапазоне (0, ..., 9) нацело делятся на 3 цифры: 0, 3, 6, 9.
                bool b = handreds % 3 == 0 && handreds != 0 ||
                           dozens % 3 == 0 &&  dozens  != 0 ||
                            units % 3 == 0 &&    units != 0;

                string strA = a ? "Да" : "Нет";
                string strB = b ? "Да" : "Нет";

                Interaction.MsgBox(
                $"\nВы ввели число: {x}\n\nA)   Входят ли в число цифры 4 или 7?\nОтвет: {strA}\n\nB)   Входят ли в число цифры 3, 6, или 9?\nОтвет: {strB}",
                MsgBoxStyle.Question, "Задача 1");
            } // while
        } // Task1

        /// <summary>
        /// Задача 2. Выполнить ввод и вывод при помощи методов класса Interaction
        ///           Решение задачи должно содержать цикл, повторяющийся трижды. 
        ///           Ввести вещественное число. Если число отрицательное, то 
        ///           возвести его в квадрат, иначе поменять знак числа на противоположный.
        /// </summary>
        static void Task2() {
            Console.Clear();
            showNavBarMessage("Задача 2.");

            const int N = 3;

            for(int i = 0; i < N; i++){
                double x;
                string str;
                do {
                    str = Interaction.InputBox(
                    "Введите вещественное число:",
                    "Задача 2");

                } while (!(double.TryParse(str, out x)));

                // Если число отрицательное, то возвести его в квадрат, иначе поменять знак числа на противоположный
                double res = x < 0 ? x * x : -x; 

                Interaction.MsgBox(
                $"\nВы ввели число: {x}\n\nЕсли число отрицательное, то возвести его в квадрат, иначе поменять знак числа на противоположный\n\nРезультат: {res}",
                MsgBoxStyle.Question, "Задача 2");

                x = res; 
            } // for i
        } // Task2

        /// <summary>
        /// Задача 3. Вывод задачи организовать в консоль, в табличном виде.
        /// 
        ///           Игральным картам условно присвоены следующие порядковые номера в 
        ///           зависимости от их достоинства: «валет» – 11, «дама» -–12,
        ///           «король» – 13, «туз» – 14. Порядковые номера остальных карт 
        ///           соответствуют их названиям(«шестерка», «семерка», …). 
        ///           
        ///           В цикле формировать 10 случайных чисел в диапазоне от 6 до 14, 
        ///           т.е.номер карты.По этому номеру определить достоинство карты.
        /// </summary>
        static void Task3() {
            const int N = 10;  // кол-во карт

            while (true){

                Console.Clear();
                showNavBarMessage("Задача 3. По номеру карты определить достоинство карты");

                int[] arr = new int[N];

                for (int i = 0; i < N; i++) arr[i] = rand.Next(6, 15);   // заполнение массива случайными числами 

                string str = "    +-----+------------------+------------+";

                Console.WriteLine("\n             Сформированные карты:");
                Console.WriteLine(str);
                Console.WriteLine("    |  №  | Порядковый номер |  Название  |");
                Console.WriteLine(str);

                int num = 1;
                foreach (var item in arr){
                    string name = "";
                    switch (item){
                        case 6: name = "шестерка";  break;
                        case 7: name = "семерка";   break;
                        case 8: name = "восьмерка"; break;
                        case 9: name = "девятка";   break;
                        case 10: name = "десятка";  break;
                        case 11: name = "валет";    break;
                        case 12: name = "дама";     break;
                        case 13: name = "король";   break;
                        case 14: name = "туз";      break;
                    } // switch
                    Console.WriteLine($"    | {num,3} | {item,16} | {name,10} |");
                    num++;
                } // foreach
                Console.WriteLine(str);

                ConsoleColor oldForegroundColor = Console.ForegroundColor;
                int a;

                Console.ForegroundColor = ConsoleColor.Green;

                do{
                    Console.SetCursorPosition(0, 18);
                    Console.Write("\n    1 - Повтор\n    0 - Выход\nВыберете пункт > _____\b\b\b\b\b");
                } while (!(int.TryParse(Console.ReadLine(), out a)) || a != 1 && a!=0);
                Console.ForegroundColor = oldForegroundColor;


                if (a == 0) break;

            } // while

        } // Task3

        // вывод сообщения в верхнюю строку окна
        static void showNavBarMessage(string msg){
            ConsoleColor oldForegroundColor = Console.ForegroundColor;
            ConsoleColor oldBackgroundColor = Console.BackgroundColor;

            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.SetCursorPosition(0, 0);

            Console.WriteLine($"    {msg}{"",WIDTH}");

            Console.ForegroundColor = oldForegroundColor;
            Console.BackgroundColor = oldBackgroundColor;
            Console.SetCursorPosition(0, 1);
            Console.WriteLine($"{"",WIDTH}");

        } // showNavBarMessage
    } // class Program
}
