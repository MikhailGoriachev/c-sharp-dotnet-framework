﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;   // для MessageBox() 
using Microsoft.VisualBasic;  // для Interaction


namespace HomeWork08._09._21
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Домашние задание на 09.09.21";
            Console.SetWindowSize(110, 35);
          

            Task1();
            Task2();
            Task3();



        }

        /*         
         Задача 1.  Выполнить ввод и вывод при помощи методов класса Interaction. 
                    Реализовать решение задачи в бесконечном цикле, выход из цикла – после ввода 0. 
                    Вводить трехзначное положительное число (100, …, 999). 
                    При помощи операций деления и взятия остатка выделить цифры числа 
                    (единицы = число % 10, сотни = число / 100, десятки = число % 100 / 10). 
                    Определить:
                    a)	входят ли в число цифры 4 или 7
                    b)	входят ли в него цифры 3, 6, или 9         
         */
        static void Task1() 
        {
            while (true)
            {

                // флаг для цикла do while
                bool flag = false;
                int a; // значение

                // цикл для ввода числа с помощью класса Interaction
                do
                {
                    flag = false;

                    // диалоговое окно для ввода числа
                    string res = Interaction.InputBox(
                    "Введите трехзначное положительное число (100, …, 999) ",
                    "Ввод"
                    );

                    // парсинг целого числа
                    flag = int.TryParse(res, out a);


                    // проверка числа на знак выхода
                    if (a == 0 && flag) return;

                    // проверка числа на корректность
                    if (!flag || (a < 100 || a > 999))
                    {
                        // выводить при неккоректном значении
                        Interaction.MsgBox(
                        "Пожалуйста, вводите данные в заданом диапазоне",
                        MsgBoxStyle.Information,
                        "Ошибка, повторите ввод");
                        flag = false;
                    }


                } while (!flag);

                int r1; // еденици 
                int r2; // десятки 
                int r3; // тысячи

                r1 = a % 10;
                r2 = a % 100 / 10;
                r3 = a / 100;

                string result = $"\t Еденици - {r1}\n\t Десятки - {r2}\n\t Сотни - {r3}\n\t";

                result += Comparison(r1);
                result += Comparison(r2);
                result += Comparison(r3);


                // вывод сообщения с результатами
                Interaction.MsgBox(result,
                        MsgBoxStyle.Information,
                        "Результат");


            }// while()true)
        }// Task1

        // метод для проверки наличия искомых цифр в числе
        static string Comparison(int a) {

            string result = "";

            // обработка команды
            switch (a)
            {  
                case 3:
                    result = $"\nb) В число входят цифры 3, 6, или 9\n";
                    break;

                case 4:                    
                    goto case 7;

                case 6:

                    goto case 3;

                case 7:
                    result = $"\na) В число входят цифры 4 или 7\n";
                    break;

                case 9:
                    result = $"b) В число входят цифры 3, 6, или 9";
                    break;

                default:
                    result = $"";   // В числе нет цифр 3,4,6,7 или 9
                    break;
                
            } // switch
            return result;
        }// Comparison(int a)


        /*Задача 2. Выполнить ввод и вывод при помощи методов класса Interaction. 
         *          Решение задачи должно содержать цикл, повторяющийся трижды. 
         *          Ввести вещественное число. Если число отрицательное, то возвести его в квадрат, 
         *          иначе поменять знак числа на противоположный.*/
        static void Task2() 
        {
            for (int i = 0; i < 3; i++)
            {


                bool flag = false;
                double a; // значение


                do
                {

                    // диалоговое окно для ввода числа
                    string res = Interaction.InputBox(
                    "Введите любое вещественное число ",
                    "Ввод"
                    );


                    // парсинг целого числа
                    flag = double.TryParse(res, out a);


                    // проверка числа на знак выхода
                    if (a == 0 && flag) return;

                    // проверка числа на корректность
                    if (!flag)
                    {
                        // выводить при неккоректном значении
                        Interaction.MsgBox(
                        "Пожалуйста, вводите только вещественные числа",
                        MsgBoxStyle.Information,
                        "Ошибка, повторите ввод");
                        flag = false;
                    }

                } while (!flag);

                double aCopy = a;

                if (a < 0)
                {
                    a = a * a;
                    // вывод сообщения с результатами
                    Interaction.MsgBox($" Число {aCopy} отрицательное, \n возводим его в квадрат\n Результат : {a} ",
                            MsgBoxStyle.Information,
                            "Результат");
                }
                else
                {
                    a = a * -1;
                    // вывод сообщения с результатами
                    Interaction.MsgBox($" Число {aCopy} положительное, \n Меняем знак на противоположный\n Результат : {a} ",
                            MsgBoxStyle.Information,
                            "Результат");


                }



            }// for


        }// Task2() 

        /*        
        Задача 3. Вывод задачи организовать в консоль, в табличном виде.
                  Игральным картам условно присвоены следующие порядковые номера в зависимости от их достоинства:
                  «валет» – 11, «дама» -–12, «король» – 13, «туз» – 14. Порядковые номера остальных карт соответствуют их названиям 
                  («шестерка», «семерка», …). 
                  В цикле формировать 10 случайных чисел в диапазоне от 6 до 14, т.е. номер карты. 
                  По этому номеру определить достоинство карты.              
         */
        static void Task3()
        {

            Console.Write($"Задача 3. Вывод задачи организовать в консоль, в табличном виде.\n");
            Console.Write($"          Игральным картам условно присвоены следующие порядковые номера в зависимости от их достоинства:\n");
            Console.Write($"          «валет» – 11, «дама» -–12, «король» – 13, «туз» – 14.\n");
            Console.Write($"          Порядковые номера остальных карт соответствуют их названиям\n");
            Console.Write($"          («шестерка», «семерка», …). \n");
            Console.Write($"          В цикле формировать 10 случайных чисел в диапазоне от 6 до 14, т.е. номер карты. \n");
            Console.Write($"          По этому номеру определить достоинство карты. \n");


            ShowHeader();

            for (int i = 0; i < 10; i++)
            {
                int temp = rand.Next(6, 15);


                // обработка команды
                switch (temp)
                {
                    case 6:
                        Console.Write($"\t|{temp, 12}| \"Шестерка\" |\n");
                        break; 

                    case 7:
                        Console.Write($"\t|{temp,12}|  \"Семерка\" |\n");
                        break;                     

                    case 8:
                        Console.Write($"\t|{temp,12}|\"Восьмерка\" |\n");
                        break;

                    case 9:
                        Console.Write($"\t|{temp,12}|  \"Девятка\" |\n");
                        break;

                    case 10:
                        Console.Write($"\t|{temp,12}|  \"Десятка\" |\n");
                        break;

                    case 11:
                        Console.Write($"\t|{temp,12}|   \"Валет\"  |\n");
                        break;

                    case 12:
                        Console.Write($"\t|{temp,12}|   \"Дама\"   |\n");
                        break;

                    case 13:
                        Console.Write($"\t|{temp,12}|  \"Король\"  |\n");
                        break;

                    case 14:
                        Console.Write($"\t|{temp,12}|    \"Туз\"   |\n");
                        break;

                    default:
                        
                        break;

                } // switch

                ShowFooter();




            }// for
            


        }

        // Класс имяОбъекта = new Класс(параметры);
        static private Random rand = new Random();

        static void ShowHeader() { 
            Console.Write($"\t+────────────+────────────+\n");
            Console.Write($"\t|  Код карты |  Название  |\n");
            Console.Write($"\t+────────────+────────────+\n");
        }

        static void ShowFooter()
        {
            Console.Write($"\t+────────────+────────────+\n");
           
        }


    }// class Program

}// namespace HomeWork08._09._21
