﻿using System;
using Microsoft.VisualBasic;


namespace Task_1
{
	internal class Program
	{
		public static void Main(string[] args)
		{
			FirstTask();

			SecondTask();

			ThirdTask();

			Console.WriteLine("Нажмите любую клавишу...");
			Console.ReadKey();
		}


#region Первая задача


		private static void FirstTask()
		{
			while (true)
			{
				string input = Interaction.InputBox
					("Введите трехзначное число (100 - 999), 0 для выхода",
					 DefaultResponse: "283");

				if (string.IsNullOrEmpty(input))
					break;
				
				int number = int.Parse(input);

				if (number == 0)
					break;

				if (number < 100 || number > 999)
				{
					Interaction.MsgBox
						("Введено неверное число!",
						 MsgBoxStyle.Critical);
					continue;
				}

				int units    = number % 10;
				int tens     = number % 100 / 10;
				int hundreds = number / 100;

				bool firstResult =
					IsDigitExists(units, tens, hundreds, 4) ||
					IsDigitExists(units, tens, hundreds, 7);

				bool secondResult =
					IsDigitExists(units, tens, hundreds, 3) ||
					IsDigitExists(units, tens, hundreds, 6) ||
					IsDigitExists(units, tens, hundreds, 9);

				string result = $@"
Исходное число: {number}

Результаты:
	 a(4 ИЛИ 7) 	  —>    {(firstResult ? "Правда" : "Ложь")}
	 b(3 ИЛИ 6 ИЛИ 9) 	  —>    {(secondResult ? "Правда" : "Ложь")}";

				Interaction.MsgBox(result, Title: "Результат операции");
			}
		}

		private static bool IsDigitExists(int units, int tens, int hundreds, int digit)
		{
			return units == digit || tens == digit || hundreds == digit;
		}


#endregion


#region Вторая задача


		private static void SecondTask()
		{
			for (int i = 0; i < 3; i++)
			{
				string input = Interaction.InputBox
					("Введите вещественное число",
					 DefaultResponse: "2,83");
				
				if (string.IsNullOrEmpty(input))
					break;
				
				double number = double.Parse(input);

				Interaction.MsgBox($"{(number < 0 ? number * number : -number)}");
			}
		}


#endregion


#region Третья задача


		private static void ThirdTask()
		{
			var rand = new Random();

			const string line = "+———————————————————————+——————————————————————+";
			const string body = "| Сгенерированное число |       Название       |";
			Console.Write($"{line}\n{body}\n{line}\n");

			for (int i = 0; i < 10; i++)
			{
				int number = rand.Next(5, 16);
				
				// C# < 8
				/*string result;
				switch (number)
				{
					case 6:
						result = "Шестерка";
						break;
					case 7:
						result = "Семерка";
						break;
					case 8:
						result = "Восьмерка";
						break;
					case 9:
						result = "Девятка";
						break;
					case 10:
						result = "Десятка";
						break;
					case 11:
						result = "Валет";
						break;
					case 12:
						result = "Дама";
						break;
					case 13:
						result = "Король";
						break;
					case 14:
						result = "Туз";
						break;
					default:
						result = "Нет карты";
						break;
				}*/

				// C# 8
				string result = number switch
				{
					6  => "Шестерка",
					7  => "Семерка",
					8  => "Восьмерка",
					9  => "Девятка",
					10 => "Десятка",
					11 => "Валет",
					12 => "Дама",
					13 => "Король",
					14 => "Туз",
					_  => "Нет карты",
				};

				Console.WriteLine($"| {number, -21} | {result, 20} |");
			}

			Console.WriteLine(line);
		}


#endregion
	}
}
