﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace HomeWork15._09._21
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            App app = new App { };

            while (true)
            {
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.Clear();
                ConsoleColor foreColor = Console.ForegroundColor;
                ConsoleColor backColor = Console.BackgroundColor;


                Console.SetWindowSize(100, 35);

                WriteXY(0, 0, $"▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓\n");
                Console.BackgroundColor = ConsoleColor.Red;

                WriteXY(46, 0, $"0 - ВЫХОД\n");

                Console.Title = "Домашние задание на 15.09.21";
                Console.BackgroundColor = ConsoleColor.DarkCyan;

                WriteXY(30, 2, $"░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\n");
                WriteXY(35, 2, "Домашние задание на 15.09.21\n");

                Console.ForegroundColor = ConsoleColor.Black;

                WriteXY(5, 6, $"1 - Задача 1. Класс Conoid.\n");

                WriteXY(5, 8, $"2 - Задача 2. Класс Person.\n");
                

                WriteXY(4, 14, $"Сделайте Ваш выбор: \n");

                // ввод выбора меню
                string res = Console.ReadLine();
                bool flag = int.TryParse(res, out int a);

                if (!flag) continue;

                // обработка команды
                switch (a)
                {
                    case 1:
                        Console.Clear();
                        app.DemoConoid();
                        Console.ReadKey(false);

                        break;

                    case 2:
                        Console.Clear();
                        app.Task2();
                        Console.ReadKey(false);
                        break;
                                          

                    case 0:
                        return;

                    default:
                        //Console.Clear();
                        Console.BackgroundColor = ConsoleColor.Red;
                        Console.ForegroundColor = ConsoleColor.Black;
                        WriteXY(38, 17, $"Такого пункта меню нет!\n");
                        Thread.Sleep(1_000);
                        break;


                } // switch


                Console.ForegroundColor = foreColor;
                Console.BackgroundColor = backColor;
            }


        }

        #region Дополнительные методы
        // заполнение массива случайными числами
        private static void Fill(int[] arr, int lo, int hi)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rand.Next(lo, hi);
            } // for i
        } // Fill
        private static void Fill(int[,] matr, int lo, int hi)
        {
            // matr.GetLength(0) - количество строк
            // matr.GetLength(1) - количество столбцов
            int rows = matr.GetLength(0); // строки
            int cols = matr.GetLength(1); // столбцы

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    matr[i, j] = rand.Next(lo, hi + 1);
        } // Fill

        private static void Show(string title, int[] arr)
        {
            Console.Write(title);

            int count = 0;

            void LocalShowItem(int item)
            {
                Console.Write($"  {item,3}  ");
                count++;
                if (count % 6 == 0) Console.WriteLine();
            } // LocalShowItem

            Array.ForEach(arr, LocalShowItem);

            Console.WriteLine();
        } // Show
        // вывод прямоугольного массива
        private static void Show(string title, int[,] matr)
        {
            // Вывод заголовка
            Console.Write(title);

            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                    Console.Write("{0, 10}", matr[i, j]);
                Console.WriteLine();
            } // for i
        } // Show

        // Класс имяОбъекта = new Класс(параметры);
        static private Random rand = new Random();

        // Вспомогательный метод для вывода в заданных координатах окна консоли 
        static void WriteXY(int x, int y, string s)
        {
            Console.SetCursorPosition(x, y);
            Console.Write(s);
        } // WriteXY



        #endregion


    }
}
