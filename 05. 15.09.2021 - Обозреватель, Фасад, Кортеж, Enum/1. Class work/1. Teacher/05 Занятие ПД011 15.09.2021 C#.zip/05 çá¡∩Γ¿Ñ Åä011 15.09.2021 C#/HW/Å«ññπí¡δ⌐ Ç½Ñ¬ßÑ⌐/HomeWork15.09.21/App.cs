﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork15._09._21
{
    class App
    {
        // полное свойство - propfull, использование "классического" синтаксиса
        private ArrayConoid _arrCon;
        public ArrayConoid ArrCon
        {
            get { return _arrCon; }
            private set
            {                 
               _arrCon = value;
            } // value  - контекстное ключевое слово
        }

        public void DemoConoid()
        {
            ArrayConoid _arrCon = new ArrayConoid { Name = "Массив из 12 коноидов" };

            _arrCon.FillArray();
            _arrCon.Show();
            _arrCon.ShowTable();
            _arrCon.SortToH();
            _arrCon.SortToVolume();
        }

        public void Task2() {


            // инициализация массива персон из 12 элеметов
            Person[] people = {

                new Person{ Name = "Мартынов А.П.",   FullAge = 30, Нeight = 190, Weight = 100, City = "Донецк"},
                new Person{ Name = "Гордеев Г.Ф.",    FullAge = 26, Нeight = 165, Weight = 65, City = "Макеевка"},
                new Person{ Name = "Николаев Р.П.",   FullAge = 41, Нeight = 172, Weight = 70, City = "Горловка"},
                new Person{ Name = "Миронов И.Б.",    FullAge = 35, Нeight = 183, Weight = 90, City = "Шахтерск"},
                new Person{ Name = "Овчинников Г.И.", FullAge = 53, Нeight = 192, Weight = 95, City = "Снежное"},
                new Person{ Name = "Фомичёв Р.С.",    FullAge = 60, Нeight = 176, Weight = 70, City = "Торез"},
                new Person{ Name = "Цветков П.С.",    FullAge = 40, Нeight = 180, Weight = 85, City = "Угледар"},
                new Person{ Name = "Гущин И.В.",      FullAge = 32, Нeight = 169, Weight = 70, City = "Зугрес"},
                new Person{ Name = "Андреев Д.И.",    FullAge = 18, Нeight = 178, Weight = 75, City = "Донецк"},
                new Person{ Name = "Шарапов Ю.А.",    FullAge = 65, Нeight = 189, Weight = 92, City = "Макеевка"},
                new Person{ Name = "Галкин З.А.",     FullAge = 29, Нeight = 175, Weight = 80, City = "Горолвка"},
                new Person{ Name = "Гордеев Г.Р.",    FullAge = 30, Нeight = 181, Weight = 96, City = "Донецк"}
            };



            Console.WriteLine($"\n\tТаблица персон:");
            Console.WriteLine(Person.Header());
            foreach (Person item in people)
            {
                Console.WriteLine(item.ToRows());  
            }
            Console.WriteLine(Person.Footer());



            // Вывести в консоль персону/персон с максимальным ростом.
            Console.WriteLine($"\n\tВывод в консоль персону/персон с максимальным ростом:");
            int maxH = people[0].Нeight;

            // поиск максимального роста
            foreach (Person item in people)
            {
                if (item.Нeight > maxH)
                    maxH = item.Нeight;
            }

            
            Predicate<Person> maxНeight = delegate (Person x) { return x.Нeight == maxH; };
            Console.WriteLine(Person.Header());

            Person[] maxНeightArray = Array.FindAll(people, maxНeight);

            foreach (Person item in maxНeightArray)
            {
                Console.WriteLine(item.ToRows());
            }
            Console.WriteLine(Person.Footer());



            // Вывести в консоль персону/персон с минимальным возрастом
            Console.WriteLine($"\n\tВывод в консоль персону/персон с минимальным возрастом:");
            int minA = people[0].FullAge;

            // поиск максимального роста
            foreach (Person item in people)
            {
                if (item.FullAge < minA)
                    minA = item.FullAge;
            }


            Predicate<Person> minFullAge = delegate (Person x) { return x.FullAge == minA; };
            Console.WriteLine(Person.Header());

            Person[] minFullAgeArray = Array.FindAll(people, minFullAge);

            foreach (Person item in minFullAgeArray)
            {
                Console.WriteLine(item.ToRows());
            }
            Console.WriteLine(Person.Footer());




            // Сортировка
            //    по городу проживания

            Console.WriteLine($"\nCортировка массива персон по городу проживания.");
            Array.Sort(people, Person.CompareByCity);
            Console.WriteLine(Person.Header());
            foreach (Person item in people)
            {
                Console.WriteLine(item.ToRows());
            }
            Console.WriteLine(Person.Footer());


            //    по убыванию веса

            Console.WriteLine($"\nCортировка массива персон по убыванию веса.");
            Array.Sort(people, Person.CompareByWeight);
            Console.WriteLine(Person.Header());
            foreach (Person item in people)
            {
                Console.WriteLine(item.ToRows());
            }
            Console.WriteLine(Person.Footer());

            //    по возрастанию роста

            Console.WriteLine($"\nCортировка массива персон по возрастанию роста.");
            Array.Sort(people, Person.CompareByНeight);
            Console.WriteLine(Person.Header());
            foreach (Person item in people)
            {
                Console.WriteLine(item.ToRows());
            }
            Console.WriteLine(Person.Footer());


        }


    }
}
