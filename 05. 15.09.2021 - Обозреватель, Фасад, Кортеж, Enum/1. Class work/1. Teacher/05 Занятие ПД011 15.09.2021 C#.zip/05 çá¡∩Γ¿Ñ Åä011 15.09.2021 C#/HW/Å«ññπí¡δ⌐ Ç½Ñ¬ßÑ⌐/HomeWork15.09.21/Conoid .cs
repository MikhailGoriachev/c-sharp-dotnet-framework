﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork15._09._21
{
    class Conoid
    {
        // Полное свойства для высоты
        private double _h;
        public double H
        {
            get { return _h; }
            set { if(value>0)_h = value; }
        }

        // Полное свойства для нижнего радиуса
        private double _r2;
        public double R2
        {
            get { return _r2; }
            set { if(value>0)_r2 = value; }
        }

        // Полное свойство для верхнего радиуса
        private double _r1;
        public double R1
        {
            get { return _r1; }
            set { if(value>0)_r1 = value; }
        }


        // 
        public double Area {

           get { return Math.PI * (_r1 * _r1 + (_r1 + _r2) * Math.Sqrt(_h * _h + Math.Pow((_r2 - _r1), 2)) + _r2 * _r2); }

        }

        public double Volume {

            get { return (Math.PI * _h * (_r1 * _r1 + _r1 * _r2 + _r2 * _r2)) / 3d ; }
            
        }


        // строковое представление объекта класса
        public override string ToString() =>
           $"Радиус нижнего основания: {R2, 10:f2}, Радиус верхнего основания: {R1,10:f2}, Высота: {H,10:f2}";


        // метод формирующий строку таблицы со сведениями о конусе
        public string ToRows() =>
            $"│ {R1,10:f2} │ {R2,10:f2} │ {H,10:f2} │ {Area,10:f2} │ {Volume,10:f2} │";

        public static string Header() {

            return  $"┌────────────┬────────────┬────────────┬────────────┬────────────┐\n" +
                    $"│   Радиус   │   Радиус   │            │   Площадь  │            │\n" +
                    $"│   нижнего  │  верхнего  │   Высота   │   полной   │   Объем    │\n" +
                    $"│  основания │  основания │            │ поверхности│            │\n" +
                    $"├────────────┼────────────┼────────────┼────────────┼────────────┤";

        }

        public static string Footer()
        {
            return $"└────────────┴────────────┴────────────┴────────────┴────────────┘";
        }

        // компаратор для сортировки по возрастанию объемов
        public static int CompareByVolume(Conoid x, Conoid y) =>
            x.Volume.CompareTo(y.Volume);
        // компаратор для сортировки по убыванию высот
        public static int CompareByH(Conoid x, Conoid y) =>
            y.H.CompareTo(x.H);

    }
}
