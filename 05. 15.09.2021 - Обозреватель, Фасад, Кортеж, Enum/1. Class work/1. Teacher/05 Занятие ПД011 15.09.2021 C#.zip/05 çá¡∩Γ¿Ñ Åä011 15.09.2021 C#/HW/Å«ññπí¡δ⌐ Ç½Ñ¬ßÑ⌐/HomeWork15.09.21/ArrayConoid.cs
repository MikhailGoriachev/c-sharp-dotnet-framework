﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork15._09._21
{
    class ArrayConoid
    {
        // массив коноидов
        private Conoid[] _arrayCon;
        public Conoid[] ArrayCon
        {
            get { return _arrayCon; }
            private set { _arrayCon = value; }
        }

        // имя коллекции коноидов 
        private string _name;
        public string Name
        {
            get { return _name; }
            set {
                if (!string.IsNullOrWhiteSpace(value))
                    _name = value;
            }
        }


        // заполнение массива данными конусов 
        public void FillArray() {

            Array.Resize(ref _arrayCon, 12);

            for (int i = 0; i < _arrayCon.Length; i++)
            {
                _arrayCon[i] = new Conoid { R2 =  20 * rand.NextDouble()+10, R1 = 5 * rand.NextDouble()+5, H = 10 *rand.NextDouble()+5 };
            }
        }

        // вычисления суммарного объема конусов
        public double SArea()
        {
            double sum = 0;

            foreach (Conoid item in _arrayCon)
            {
                sum += item.Area;
            }

            return sum;
        }

        // вычисления суммарной площади поверхности конусов
        public double SVolume() {

            double sum = 0;

            foreach (Conoid item in _arrayCon)
            {
                sum += item.Volume;
            }

            return sum;
        }

        // вывод названия коллекции и массива конусов в консоль, в табличном виде
        public void Show() {

            Console.WriteLine($"Название коллекции: {_name} ");
            //Console.WriteLine(Conoid.Header());
            foreach (Conoid item in _arrayCon)
            {
                Console.WriteLine(item.ToString());                
            }
            //Console.WriteLine(Conoid.Footer());

        }

        public void ShowTable()
        {
            double maxArea= _arrayCon[0].Area;
            foreach (Conoid item in _arrayCon)
            {
                if (item.Area > maxArea)
                    maxArea = item.Area;
            }

            ConsoleColor foreColor = Console.ForegroundColor;
            ConsoleColor backColor = Console.BackgroundColor;

            
            Console.WriteLine($"\nНазвание коллекции: {_name} ");
            Console.WriteLine($"Цветом выделенны коноиды с максимальной площадью.");
            Console.WriteLine(Conoid.Header());
            foreach (Conoid item in _arrayCon)
            {
                if (item.Area == maxArea)
                {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.DarkMagenta;
                }
                Console.WriteLine(item.ToRows());

                Console.BackgroundColor = backColor;
                Console.ForegroundColor = foreColor;
            }
            Console.WriteLine(Conoid.Footer());


            Console.WriteLine($"Cуммарный объем конусов: {SVolume(),25:f2} ");
            Console.WriteLine($"Cуммарныя площадь поверхности конусов: {SArea(),10:f2} ");

        }

        // сортировка массива конусов по возрастанию объемов
        public void SortToVolume() 
        {
            Console.WriteLine($"\nCортировка массива конусов по возрастанию объемов.");
            Array.Sort(_arrayCon, Conoid.CompareByVolume);
            Console.WriteLine(Conoid.Header());
            foreach (Conoid item in _arrayCon)
            {               
                Console.WriteLine(item.ToRows());
            }
            Console.WriteLine(Conoid.Footer());
        }

        // сортировка массива конусов по убыванию высот
        public void SortToH()
        {
            Console.WriteLine($"\nCортировка массива конусов по убыванию высот.");
            Array.Sort(_arrayCon, Conoid.CompareByH);
            Console.WriteLine(Conoid.Header());
            foreach (Conoid item in _arrayCon)
            {
                Console.WriteLine(item.ToRows());
            }
            Console.WriteLine(Conoid.Footer());
        }

        private static Random rand = new Random();
    }
}
