﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork15._09._21
{
    class Person
    {
        // фамилия и инициалы имени и отчества
        private string _name;
        public string  Name
        {
            get { return _name; }
            set {
                if (!string.IsNullOrWhiteSpace(value))
                    _name = value;
            }
        }

        // возраст в полных годах 
        private int _fullage;
        public int FullAge
        {
            get { return _fullage; }
            set { if(value>0)_fullage = value; }
        }

        //	рост в сантиметрах 
        private int _height;
        public int Нeight
        {
            get { return _height; }
            set { if (value > 0) _height = value; }
        }

        // вес в кг 
        private double _weight;
        public double Weight
        {
            get { return _weight; }
            set { if (value > 0) _weight = value; }
        }


        // название города проживания 
        private string _city;
        public string City
        {
            get { return _city; }
            set {
                if (!string.IsNullOrWhiteSpace(value)) 
                    _city = value; 
            }
        }


        // метод формирующий строку таблицы со сведениями о конусе
        public string ToRows() =>
            $"│ {Name,23:f2} │ {FullAge,10:f2} │ {Нeight,10:f2} │ {Weight,10:f2} │ {City,10:f2} │";

        public static string Header()
        {
            // 23

            return  $"┌─────────────────────────┬────────────┬────────────┬────────────┬────────────┐\n" +
                    $"│   Фамилия и инициалы    │   Возраст  │    Рост    │     Вес    │   Город    │\n" +                   
                    $"├─────────────────────────┼────────────┼────────────┼────────────┼────────────┤";

        }

        public static string Footer()
        {
            return $"└─────────────────────────┴────────────┴────────────┴────────────┴────────────┘";
        }

        // компаратор для сортировки по городу проживания
        public static int CompareByCity(Person x, Person y) =>
            x.City.CompareTo(y.City);
        // компаратор для сортировки по убыванию веса
        public static int CompareByWeight(Person x, Person y) =>
            y.Weight.CompareTo(x.Weight);

        // компаратор для сортировки по возрастанию роста
        public static int CompareByНeight(Person x, Person y) =>
            x.Нeight.CompareTo(y.Нeight);
    }
}
