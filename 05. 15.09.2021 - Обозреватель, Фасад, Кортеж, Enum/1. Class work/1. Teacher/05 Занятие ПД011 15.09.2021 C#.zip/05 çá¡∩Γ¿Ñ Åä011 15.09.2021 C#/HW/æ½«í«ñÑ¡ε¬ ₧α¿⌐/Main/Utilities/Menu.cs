﻿using System;
using System.Linq;


namespace Main
{
	internal class Menu
	{
		public Menu(string title, MenuItem[] items)
		{
			if (items == null)
				throw new ArgumentNullException(nameof(items));
			if (items.Length < 1)
				throw new ArgumentOutOfRangeException(nameof(items), "Размер должен быть >= 1");

			Title        = title ?? throw new ArgumentNullException(nameof(title));
			Items        = items;
			CurrentItem  = 0;
			CursorLength = Items.Max(item => item.Text.Length);
		}


		private string         Title          { get; }
		public  string         DivideLine     { get; set; } = null;
		public  (int x, int y) CursorPosition { get; set; } = (x: Console.WindowWidth / 2 - 40, y: 6);
		private MenuItem[]     Items          { get; }
		private int            CurrentItem    { get; set; }
		private int            CursorLength   { get; }


		private void Show()
		{
			Console.CursorVisible = false;

			Console.SetCursorPosition(CursorPosition.x, CursorPosition.y);
			Title.ColoredLine(Palette.Title);
			Console.WriteLine();

			for (int i = 0; i < Items.Length; i++)
			{
				Console.SetCursorPosition(CursorPosition.x, Console.CursorTop + 1);

				string.Intern($"      {Items[i].Text.PadRight(CursorLength)}     ")
					  .Colored(i == CurrentItem ? Palette.Current : Palette.Normal);

				if (!Items[i].IsDivide)
					continue;

				Console.SetCursorPosition(CursorPosition.x, Console.CursorTop + 1);
				Console.WriteLine(DivideLine);
			}
		}


		private bool Navigate()
		{
			switch (Console.ReadKey(true).Key)
			{
				case ConsoleKey.UpArrow:
					CurrentItem--;
					if (CurrentItem < 0)
						CurrentItem = Items.Length - 1;
					break;
				case ConsoleKey.DownArrow:
					CurrentItem++;
					if (CurrentItem >= Items.Length)
						CurrentItem = 0;
					break;
				case ConsoleKey.Enter:
					Items[CurrentItem].InvokeItem();
					break;
				case ConsoleKey.Escape:
					return true;
			}

			return false;
		}


		public void Run()
		{
			Palette.Normal.AsCurrent();
			Console.Clear();

			while (true)
			{
				Show();

				try
				{
					if (Navigate())
					{
						Console.Clear();
						return;
					}
				}
				catch (Exception e)
				{
					e.Output();
				}
			}
		}


		internal class MenuItem
		{
			public MenuItem(string text, Action callback)
			{
				Text     = text ?? throw new ArgumentNullException(nameof(text));
				Callback = callback ?? throw new ArgumentNullException(nameof(callback));
			}


			public string Text           { get; set; }
			public Action Callback       { private get; set; }
			public bool   IsDivide       { get; set; } = false;
			public bool   IsSimpleInvoke { get; set; } = false;


			public void InvokeItem()
			{
				if (IsSimpleInvoke)
				{
					Callback.Invoke();
					return;
				}

				Console.Clear();
				Console.SetCursorPosition(0, 0);

				object space = ' ';
				$"{space,10} {Text} {space,10}".ColoredLine(Palette.Navbar);
				Console.WriteLine("\n\n");

				Callback.Invoke();

				if (Console.CursorTop >= Console.WindowHeight)
					Utilities.CursorAndPause(0, Console.CursorTop + 5);
				else
					Utilities.CursorToBottomAndPause();
				Console.Clear();
			}
		}


		private static class Palette
		{
			public static Color Title => Main.Palette.Info;

			public static Color Normal => Main.Palette.Default;

			public static Color Current => Main.Palette.AccentDedicated;

			public static Color Navbar => Main.Palette.TertiaryDedicated;
		}
	}


	internal class MenuWrapper
	{
		protected Menu Menu { get; set; }


		public void Run()
		{
			try
			{
				Menu?.Run();
			}
			catch (Exception e)
			{
				e.Output();
			}
		}
	}
}
