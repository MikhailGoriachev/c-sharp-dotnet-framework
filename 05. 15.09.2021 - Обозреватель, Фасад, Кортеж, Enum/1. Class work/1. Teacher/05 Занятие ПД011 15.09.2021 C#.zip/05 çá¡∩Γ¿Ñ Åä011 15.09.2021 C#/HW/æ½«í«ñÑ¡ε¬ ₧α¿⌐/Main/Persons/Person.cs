﻿using System;


namespace Main
{
	internal class Person
	{
		private string _fullName;
		private int    _age;
		private int    _height;
		private double _weight;
		private string _city;

		public string FullName { get => _fullName; set => _fullName = value; }
		public int    Age      { get => _age;      set => _age = value >= 150 ? 0 : value; }
		public int    Height   { get => _height;   set => _height = value >= 300 ? 0 : value; }
		public double Weight   { get => _weight;   set => _weight = value >= 700d ? 0 : value; }
		public string City     { get => _city;     set => _city = value; }


#region Компараторы


		public static int CompareByCity(Person lhs, Person rhs) => lhs.City.CompareTo(rhs.City);


		public static int CompareByWeightDescending(Person lhs, Person rhs) =>
			Math.Abs(lhs.Weight - rhs.Weight) <= 0.5 ? 0 : (int)(rhs.Weight - lhs.Weight);


		public static int CompareByHeightAscending(Person lhs, Person rhs) => lhs.Height.CompareTo(rhs.Height);


#endregion


		public override string ToString() =>
			$"Имя: {FullName,-30} Город: {City,-20} Возраст: {Age, -7} Вес: {Weight,-7} Рост: {Height,-7}";
	}
}
