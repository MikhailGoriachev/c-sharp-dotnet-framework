﻿using System;


namespace Main
{
	internal class ArrayConoid
	{
		private Conoid[] _conoids;
		private string   _title;

		public string Title { get => _title; set => _title = value; }


		public ArrayConoid(int size)
		{
			_conoids = new Conoid[size];

			for (int i = 0; i < size; i++)
				_conoids[i] = new Conoid();
		}


		public void Fill(double min, double max)
		{
			var rand = new Random();

			foreach (var conoid in _conoids)
			{
				conoid.Height      = rand.NextDouble() * (max - min) + min;
				conoid.LowerRadius = rand.NextDouble() * (max - min) + min;
				conoid.UpperRadius = rand.NextDouble() * (max - min) + min;
			}
		}


		public double TotalVolume()
		{
			double returned = 0;

			foreach (var conoid in _conoids)
				returned += conoid.Volume;

			return returned;
		}


		public double TotalArea()
		{
			double returned = 0;

			foreach (var conoid in _conoids)
				returned += conoid.Area;

			return returned;
		}


		public void ShowTable()
		{
			ShowTitle();
			Conoid.ShowHeader();

			foreach (var conoid in _conoids)
				Console.WriteLine(conoid.AsTableRow());

			Conoid.ShowFooter();
		}


		private void ShowTitle()
		{
			Console.SetCursorPosition(Title.Center(Conoid.TableRowLength()), Console.CursorTop);
			Console.WriteLine(Title ?? string.Empty);
		}


		private int MaxVolume()
		{
			int    returned = 0;
			double volume   = double.MinValue;

			for (int i = 0; i < _conoids.Length; i++)
			{
				double currentVolume = _conoids[i].Volume;

				if (currentVolume > volume)
				{
					volume   = currentVolume;
					returned = i;
				}
			}

			return returned;
		}


		private int MaxArea()
		{
			int    returned = 0;
			double area     = double.MinValue;

			for (int i = 0; i < _conoids.Length; i++)
			{
				double currentArea = _conoids[i].Area;

				if (currentArea > area)
				{
					area     = currentArea;
					returned = i;
				}
			}

			return returned;
		}


		public void ShowColoredTable()
		{
			ShowTitle();
			Conoid.ShowHeader();

			int maxVolume = MaxVolume();
			int maxArea   = MaxArea();

			for (int i = 0; i < _conoids.Length; i++)
			{
				Color color = i switch
				{
					_ when i == maxVolume && i == maxArea => Palette.AccentDedicated,
					_ when i == maxVolume                 => Palette.SecondaryDedicated,
					_ when i == maxArea                   => Palette.TertiaryDedicated,
					_                                     => Palette.Default
				};

				color.AsCurrent();
				Console.WriteLine(_conoids[i].AsTableRow());
				Palette.Default.AsCurrent();
			}

			Conoid.ShowFooter();
		}


		public void OrderByVolumeAscending() => Array.Sort(_conoids, Conoid.CompareByVolumeAscending);

		public void OrderByHeightDescending() => Array.Sort(_conoids, Conoid.CompareByHeightDescending);
	}
}
