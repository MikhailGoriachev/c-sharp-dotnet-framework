﻿using System;


namespace Main
{
	internal class ConoidProcessor : MenuWrapper
	{
		public ConoidProcessor() => Menu = new Menu("Задача 1. Обработка усеченных конусов", new[]
		{
			new Menu.MenuItem("Создание нового массива конусов", Fill),
			new Menu.MenuItem("Вычисление суммарного обьема конусов", TotalVolume),
			new Menu.MenuItem("Вычисление суммарной площади конусов", TotalArea),
			new Menu.MenuItem("Вывод названия коллекции и массива конусов в консоль, в табличном виде", ShowTable),
			new Menu.MenuItem("Вывод таблицы с выделением цветом", ShowColoredTable),
			new Menu.MenuItem("Сортировка массива конусов по возрастанию объемов", OrderByVolume),
			new Menu.MenuItem("Cортировка массива конусов по убыванию высот", OrderByHeight)
		});


		// Диапазоны для Random
		private static (double min, double max) ConoidValues => (4d, 15d);
		private static (int min, int max)       Size         => (15, 24);

		public ArrayConoid Conoids { get; set; }


		/// Создание нового массива конусов
		private void Fill()
		{
			Random rand = new Random();
			int    size = rand.Next(Size.min, Size.max);

			Conoids = new ArrayConoid(size) { Title = "Название коллекции" };
			Conoids.Fill(ConoidValues.min, ConoidValues.max);

			Console.WriteLine($"Размер массива конусов: {size}");
			ShowTable();
		}


		/// Вычисление суммарного обьема конусов
		private void TotalVolume()
		{
			ShowTable();

			Console.WriteLine($"Суммарный обьем конусов: {Conoids?.TotalVolume() ?? 0d:N4}");
		}


		/// Вычисление суммарной площади конусов
		private void TotalArea()
		{
			ShowTable();

			Console.WriteLine($"Суммарная площадь конусов: {Conoids?.TotalArea() ?? 0d:N4}");
		}


		/// Вывод названия коллекции и массива конусов в консоль, в табличном виде
		private void ShowTable() => Conoids?.ShowTable();


		/// Вывод названия коллекции и массива в консоль в табличном виде: радиусы и высота
		/// усеченного конуса, площадь и объем с выделением цветом конуса/конусов с максимальной
		/// площадью, также выводить итоговую информацию – суммарный объем конусов, суммарную
		/// площадь поверхности конусов
		private void ShowColoredTable()
		{
			Conoids?.ShowColoredTable();

			Console.WriteLine($"Суммарный обьем конусов —> {Conoids?.TotalVolume() ?? 0d:N4}");
			Console.WriteLine($"Суммарная площадь конусов —> {Conoids?.TotalArea() ?? 0d:N4}");
		}


		/// Сортировка массива конусов по возрастанию объемов
		private void OrderByVolume()
		{
			Conoids?.OrderByVolumeAscending();

			Conoids?.ShowColoredTable();
		}


		/// Cортировка массива конусов по убыванию высот
		private void OrderByHeight()
		{
			Conoids?.OrderByHeightDescending();

			Conoids?.ShowColoredTable();
		}
	}
}
