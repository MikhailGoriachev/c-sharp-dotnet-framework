﻿namespace Main
{
	internal class App : MenuWrapper
	{
		/// Задача 1. Обработка усеченных конусов
		private readonly ConoidProcessor _conoidProcessor = new ConoidProcessor();
		/// Задача 2. Обработка класса "Персона"
		private readonly PersonProcessor _personProcessor = new PersonProcessor();


		public App() => Menu = new Menu("Главное меню приложения", new[]
		{
			new Menu.MenuItem("Задача 1. Обработка усеченных конусов", _conoidProcessor.Run)
				{ IsSimpleInvoke = true },
			new Menu.MenuItem(@"Задача 2. Обработка класса ""Персона""", _personProcessor.Run)
				{ IsSimpleInvoke = true }
		});
	}
}
