﻿using System;


namespace Main
{
	internal class PersonProcessor : MenuWrapper
	{
		public PersonProcessor() => Menu = new Menu(@"Задача 2. Обработка класса ""Персона""", new[]
		{
			new Menu.MenuItem("Вывести массив персон в консоль", Show),
			new Menu.MenuItem("Вывести в консоль персону/персон с максимальным ростом", ShowMaxHeightPersons),
			new Menu.MenuItem("Вывести в консоль персону/персон с минимальным возрастом", ShowMinAgePersons),
			new Menu.MenuItem("Сортировка по городу проживания ", OrderByCity),
			new Menu.MenuItem("Сортировка по убыванию веса", OrderByWeightDescending),
			new Menu.MenuItem("Сортировка по возрастанию роста", OrderByHeightAscending),
		});


		private Person[] Persons { get; } =
		{
			new Person
			{
				FullName = "Craig Langworth Gibson", City = "North Oswaldobury",
				Age      = 24, Height                     = 163, Weight = 90
			},
			new Person
			{
				FullName = "Domenica Stroman Romaguera", City = "East Wilbermouth",
				Age      = 34, Height                         = 164, Weight = 80
			},
			new Person
			{
				FullName = "Mae Jenkins Windler I", City = "Port Keturah",
				Age      = 78, Height                    = 179, Weight = 70
			},
			new Person
			{
				FullName = "Tawana Streich Blick", City = "Haywoodhaven",
				Age      = 14, Height                   = 150, Weight = 50
			},
			new Person
			{
				FullName = "Raymon Parker Mayert", City = "Lake Vince",
				Age      = 68, Height                   = 169, Weight = 100
			},
			new Person
			{
				FullName = "Oretha Hodkiewicz Goldner", City = "McCulloughview",
				Age      = 45, Height                        = 163, Weight = 70
			},
			new Person
			{
				FullName = "Marilyn VonRueden Boyle", City = "Haleyfurt",
				Age      = 14, Height                      = 157, Weight = 64
			},
			new Person
			{
				FullName = "Dianne Cartwright Prohaska", City = "Carterport",
				Age      = 46, Height                         = 180, Weight = 73
			},
			new Person
			{
				FullName = "Dr. Edwin Kovacek", City = "West Edwardoberg",
				Age      = 24, Height                = 180, Weight = 76
			},
			new Person
			{
				FullName = "Madlyn Krajcik Rippin", City = "Murphyport",
				Age      = 81, Height                    = 176, Weight = 81
			},
			new Person
			{
				FullName = "Christel Doyle Effertz", City = "Mohrfort",
				Age      = 97, Height                     = 180, Weight = 86
			},
			new Person
			{
				FullName = "Mr. Mary Bergstrom Boyle", City = "East Ardelia",
				Age      = 39, Height                       = 156, Weight = 84
			},
			new Person
			{
				FullName = "Collette DuBuque Gerhold", City = "Eulafurt",
				Age      = 53, Height                       = 160, Weight = 140
			}
		};


		/// Вывести массив персон в консоль
		public void Show()
		{
			foreach (Person person in Persons)
				Console.WriteLine(person);
		}


		private int MaxHeight()
		{
			int returned = int.MinValue;

			foreach (Person person in Persons)
				if (person.Height > returned)
					returned = person.Height;

			return returned;
		}


		/// Вывести в консоль персону/персон с максимальным ростом
		public void ShowMaxHeightPersons()
		{
			int maxHeight = MaxHeight();

			foreach (Person person in Persons)
				if (person.Height == maxHeight)
					Console.WriteLine(person);
		}


		private int MinAge()
		{
			int returned = int.MaxValue;

			foreach (Person person in Persons)
				if (person.Age < returned)
					returned = person.Age;

			return returned;
		}


		/// Вывести в консоль персону/персон с минимальным возрастом
		public void ShowMinAgePersons()
		{
			int minAge = MinAge();

			foreach (Person person in Persons)
				if (person.Age == minAge)
					Console.WriteLine(person);
		}


		/// Сортировка по городу проживания 
		public void OrderByCity()
		{
			Array.Sort(Persons, Person.CompareByCity);

			Show();
		}


		/// Сортировка по убыванию веса 
		public void OrderByWeightDescending()
		{
			Array.Sort(Persons, Person.CompareByWeightDescending);

			Show();
		}


		/// Сортировка по возрастанию роста 
		public void OrderByHeightAscending()
		{
			Array.Sort(Persons, Person.CompareByHeightAscending);

			Show();
		}
	}
}
