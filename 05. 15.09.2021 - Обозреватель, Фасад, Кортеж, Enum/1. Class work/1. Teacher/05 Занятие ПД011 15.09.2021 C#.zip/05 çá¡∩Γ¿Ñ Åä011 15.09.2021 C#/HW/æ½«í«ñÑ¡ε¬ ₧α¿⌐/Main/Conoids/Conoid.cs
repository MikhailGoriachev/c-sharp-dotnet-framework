﻿using System;


namespace Main
{
	internal class Conoid
	{
		private double _height;
		private double _lowerRadius;
		private double _upperRadius;

		public double UpperRadius { get => _upperRadius; set => SetOnlyPositive(out _upperRadius, value); }
		public double LowerRadius { get => _lowerRadius; set => SetOnlyPositive(out _lowerRadius, value); }
		public double Height      { get => _height;      set => SetOnlyPositive(out _height, value); }

		public double Area
		{
			get
			{
				double l = Math.Sqrt(Math.Pow(Height, 2) + Math.Pow(LowerRadius - UpperRadius, 2));

				return Math.PI * l * (LowerRadius + UpperRadius);
			}
		}

		public double Volume
		{
			get => 1d / 3d * Math.PI * Height *
				   (Math.Pow(LowerRadius, 2) + LowerRadius *
					UpperRadius + Math.Pow(UpperRadius, 2));
		}

		private static void SetOnlyPositive(out double set, double value) => set = value <= 0 ? 0 : value;


		public override string ToString() =>
			$"Нижний радиус: {LowerRadius:N4}, Верхний радиус: {UpperRadius:N4}, Высота: {Height:N4}";


#region Таблица


		public static void ShowHeader()
		{
			Console.WriteLine("┌─────────────┬─────────────┬─────────────┬─────────────────┬─────────────────┐");
			Console.WriteLine("│      R      │      r      │   Высота    │     Площадь     │      Обьем      │");
			Console.WriteLine("├─────────────┼─────────────┼─────────────┼─────────────────┼─────────────────┤");
		}


		public string AsTableRow() =>
			$"│ {LowerRadius,-11:N3} │ {UpperRadius,-11:N3} │ {Height,-11:N3} │ {Area,-15:N3} │ {Volume,-15:N3} │";


		public static int TableRowLength() => new Conoid().AsTableRow().Length;


		public static void ShowFooter()
		{
			Console.WriteLine("└─────────────┴─────────────┴─────────────┴─────────────────┴─────────────────┘");
		}


#endregion


#region Компараторы


		public static int CompareByVolumeAscending(Conoid lhs, Conoid rhs) => lhs.Volume.CompareTo(rhs.Volume);

		public static int CompareByHeightDescending(Conoid lhs, Conoid rhs) => rhs.Height.CompareTo(lhs.Height);


#endregion
	}
}
