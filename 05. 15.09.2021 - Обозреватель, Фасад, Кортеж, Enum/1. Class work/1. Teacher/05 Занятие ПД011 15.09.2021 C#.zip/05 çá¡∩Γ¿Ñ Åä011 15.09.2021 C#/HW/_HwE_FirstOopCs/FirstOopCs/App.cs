﻿using System;

namespace FirstOopCs {
    
    // Объекты и методы для обработки по заданию
    public class App {
        private ArrayConoid _conoids;  // объект для конусов
        private ArrayPerson _persons;  // объект для персон

        // в конструкторе по умолчанию будем заполнять коллекции
        public App() : this(new ArrayConoid(), new ArrayPerson()) {
            _conoids.Initialize();
            _persons.Initialize();
        } // App

        // конструктор с внедрением зависимостей/ dependency injection
        public App(ArrayConoid conoids, ArrayPerson persons) {
            _conoids = conoids;
            _persons = persons;
        } // App
        
        // Методы для обработок по заданию
        // ---------------------------------------------------------------
        
        // Формирование коллекции конусов
        public void ConoidsInitialize() {
            Utils.ShowNavBarTask("  Формирование коллекции конусов");
            
            _conoids.Initialize();
            _conoids.ShowTable("");
        } // ConoidsInitialize
        
        // Вывод коллекции конусов в табличном формате
        public void ShowConoids() {
            Utils.ShowNavBarTask("  Вывод коллекции конусов в табличном формате");

            _conoids.ShowTable("");
        } // ShowConoids
        
        // Вывод коллекции конусов с итогами и цветовым выделением
        public void ShowConoidsTotal() {
            Utils.ShowNavBarTask("  Вывод коллекции конусов с итогами и цветовым выделением");

            _conoids.ShowTableColored("Итогаи и цветовое выделение");
        } // ShowConoidsTotal
        
        // Сортировка коллекции по возрастанию объемов
        public void DemoOrderConoidsByVolume() {
            Utils.ShowNavBarTask("  Сортировка коллекции по возрастанию объемов");
            
            _conoids.OrderByVolumeAscend();
            _conoids.ShowTable("Сортировка коллекции по возрастанию объемов");
        } // DemoOrderByConoidsByVolume
        
        // Сортировка коллекции по убыванию высоты
        public void DemoOrderConoidsByHeightDesc() {
            Utils.ShowNavBarTask("  Сортировка коллекции по убыванию высоты");
            
            _conoids.OrderByHeightDescend();
            _conoids.ShowTable("Сортировка коллекции по убыванию высоты");
        } // DemoOrderByConoidsByHeightDesc

        // ---------------------------------------------------------------
        
        // Формирование коллекции персон
        public void PersonsInitialize() {
            Utils.ShowNavBarTask("  Формирование коллекции персон");
            
            _persons.Initialize();
            _persons.Show("Данные сформированы", 12);
        } // PersonsInitialize
        
        // Вывод в таблицу самых высоких персон
        public void ShowHighests() {
            Utils.ShowNavBarTask("  Вывод в таблицу самых высоких персон");
            
            Person[] highestPersons = _persons.FindMaxHeight();
            _persons.Show("Отобраны самые высокие персоны", 12, highestPersons);
        } // ShowHighests
        
        // Вывод в таблицу самых молодых персон
        public void ShowYoungests() {
            Utils.ShowNavBarTask("  Вывод в таблицу самых молодых персон");
            
            Person[] youngestPersons = _persons.FindMinAge();
            _persons.Show("Отобраны самые молодые персоны", 12, youngestPersons);
        } // ShowYoungests
        
        // Сортировка персон по городу проживания
        public void DemoOrderByCity() {
            Utils.ShowNavBarTask("  Сортировка персон по городу проживания");
            
            _persons.OrderByCity();
            _persons.Show("Коллекция персон, упорядоченная по городу проживания", 12);
        } // DemoOrderByCity
        
        // Сортировка персон по убыванию веса
        public void DemoOrderByWeightDesc() {
            Utils.ShowNavBarTask("  Сортировка персон по убыванию веса");
            
            _persons.OrderByWeightDesc();
            _persons.Show("Коллекция персон, упорядоченная по убыванию веса", 12);
        } // DemoOrderByWeightDesc
        
        // Сортировка персон по росту
        public void DemoOrderByHeight() {
            Utils.ShowNavBarTask("  Сортировка персон по увеличению роста");
            
            _persons.OrderByHeight();
            _persons.Show("Коллекция персон, упорядоченная по увеличению роста", 12);
        } // DemoOrderByHeight
        
    } // class App
}