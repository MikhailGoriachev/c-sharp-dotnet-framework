﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstOopCs
{
    /* 
     * Класс ArrayConoid, хранящий массив из усеченных конусов – объектов
     * класса Conoid и название коллекции конусов. 
     * Реализуйте методы класса ArrayConoid:
     *     • заполнение массива данными конусов (не менее 12 элементов, 
     *       используйте генератор случайных чисел, вводить с клавиатуры 
     *       ничего не надо)
     *     • вычисления суммарного объема конусов 
     *     • вычисления суммарной площади поверхности конусов
     *     • вывод названия коллекции и массива конусов в консоль, в табличном 
     *       виде: радиусы и высота усеченного конуса, площадь и объем, без 
     *       выделения цветом отдельных строк таблицы
     *     • вывод названия коллекции и массива в консоль в табличном виде: 
     *       радиусы и высота усеченного конуса, площадь и объем с выделением 
     *       цветом конуса/конусов с максимальной площадью, также выводить 
     *       итоговую информацию – суммарный объем конусов, суммарную площадь 
     *       поверхности конусов
     *     • сортировка массива конусов по возрастанию объемов
     *     • сортировка массива конусов по убыванию высот
     */
    public class ArrayConoid
    {
        // название коллекции конусов
        public string Title { get; set; }

        // коллекция конусов
        public Conoid[] Conoids { get; set; }

        // проверка на пустую коллекции
        public bool Empty => Conoids.Length == 0;
        
        // Методы обработки по заданию
        
        // заполнение массива данными конусов (при помощи генератора случайных чисел)
        // формируется от 12 до 16 объектов
        public void Initialize() {
            int n = Utils.Random.Next(12, 16);
            Conoids = new Conoid[n];
            
            Title = $"Коллекция усеченных конусов, создана {DateTime.Now:G}";

            for (int i = 0; i < Conoids.Length; i++) {
                double u = Utils.GetRandom(1d, 100d);      // верхний радиус
                double d = u + Utils.GetRandom(1d, 20d);   // нижний радиус - зависит от верхнего
                double h = Utils.GetRandom(1d, 30d);       // высота
                Conoids[i] = new Conoid { RadiusDown = d,  RadiusUp = u, Height = h };
            } // for i 
        } // Initialize
        
        // вычисление суммарного объема конусов
        public double TotalVolume() {
            double total = 0;
            foreach (var conoid in Conoids) {
                total += conoid.Volume;
            } // foreach conoid

            return total;
        } // TotalVolume
        
        // вычисление суммарной площади поверхности конусов
        public double TotalArea() {
            double total = 0;
            foreach (var conoid in Conoids) {
                total += conoid.Area;
            } // foreach conoid

            return total;
        } // TotalArea
        
        
        // Возвращает индекс цилиндра с максимальной высотой
        public int MaxHeightIndex() {
            int imax = 0;

            for (int i = 1; i < Conoids.Length; i++) {
                if (Conoids[i].Height > Conoids[imax].Height)
                    imax = i;
            } // for i 
            
            return imax;
        } // MaxHeightIndex
        
        
        // вывод названия коллекции и массива конусов в консоль, в табличном 
        // виде: радиусы и высота усеченного конуса, площадь и объем, без 
        // выделения цветом отдельных строк таблицы
        public void ShowTable(string caption) {
            // количество отступов перед выводом шапки таблицы, строк таблицы и подвала таблицы 
            int indent = 12;
            string space = " ".PadRight(indent);
            
            // вывод заголовка и шапки таблицы
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n{Conoid.Header(indent)}");

            // вывод строк таблицы
            int row = 1;

            void OutLine(Conoid c) =>
                Console.WriteLine($"{space}{c.ToTableRow(row++)}");
            Array.ForEach(Conoids, OutLine);

            // вывод подвала таблицы
            Console.WriteLine(Conoid.Footer(indent));
        } // ShowTable
        
        // вывод названия коллекции и массива в консоль в табличном виде: 
        // радиусы и высота усеченного конуса, площадь и объем с выделением 
        // цветом конуса/конусов с максимальной площадью, также выводить 
        // итоговую информацию – суммарный объем конусов, суммарную площадь 
        // поверхности конусов
        public void ShowTableColored(string caption) {
            // количество отступов перед выводом шапки таблицы, строк таблицы и подвала таблицы 
            int indent = 12;
            string space = " ".PadRight(indent);
            
            // индекс элемента с максимальной высотой и собственно максимальная высота
            int imax = MaxHeightIndex();
            double maxHeight = Conoids[imax].Height;
            
            // вывод заголовка и шапки таблицы
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n{Conoid.Header(indent)}");

            // вывод строк таблицы
            int row = 1;
            foreach (var conoid in Conoids) {
                Console.Write(" ".PadRight(indent));
                
                // выделение цветом строки таблицы с конусом с максимальной высотой
                if (Math.Abs(maxHeight - conoid.Height) <= 1e-6) {
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.BackgroundColor = ConsoleColor.Gray;
                } // if

                // вывод строки таблицы 
                Console.WriteLine(conoid.ToTableRow(row++));
                
                // восстановление цвета консоли
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.DarkGray;
            } // foreach

            // вывод подвала таблицы - итоги по площади и объему
            double totalArea = TotalArea();
            double totalVolume = TotalVolume();

            string spaces = " ".PadRight(indent); 
            Console.WriteLine(
                $"{spaces}├─────┼───────────┼───────────┼───────────┼───────────┼───────────┤\n"+
                $"{spaces}│     │           │           │           │ {totalArea, 9:f2} │ {totalVolume, 9:f2} │\n" +
                $"{spaces}└─────┴───────────┴───────────┴───────────┴───────────┴───────────┘"
            );
        } // ShowTableColored
        
        // сортировка массива конусов по возрастанию объемов
        public void OrderByVolumeAscend() => Array.Sort(Conoids, Conoid.VolumeComparer);
        
        // сортировка массива конусов по убыванию высот
        public void OrderByHeightDescend() => Array.Sort(Conoids, Conoid.HeightComparerDesc);
    } // class ArrayConoid
}
