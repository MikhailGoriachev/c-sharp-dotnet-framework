﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstOopCs
{
    /* 
     * Класс Conoid, представляющий усеченный конус (радиус верхнего
     * основания, радиус нижнего основания, высота – тип полей double). 
     * Реализуйте полные свойства, вычисляемые свойства для площади и 
     * объема усеченного конуса, метод формирующий строковое представление
     * конуса (метод ToString(), выводить только радиус и высоту), метод  
     * формирующий строку таблицы со сведениями о конусе (радиус, высота,  
     * площадь поверхности, объем).
     * Разработайте компараторы для сортировки по возрастанию объемов, для
     * сортировки по убыванию высот. 
     */
    public class Conoid
    {
        // Радиус верхнего основания
        private double _radiusUp;
        public double RadiusUp {
            get => _radiusUp; 
            set => _radiusUp = value >=0?value:0; 
        } // RadiusUp

        // Радиус нижнего основания
        private double _radiusDown;
        public double RadiusDown
        {
            get => _radiusDown;
            set => _radiusDown = value >= 0 ? value : 0;
        } // RadiusDown

        // Высота
        private double _height;
        public double Height
        {
            get => _height;
            set => _height = value >= 0 ? value : 0;
        } // Height

        // вычисляемые свойства для площади и объема усеченного конуса
        // площадь поверхности усеченного конуса
        // https://www-formula.ru/2011-09-21-04-35-14
        public double Area { get {
                double delta = _radiusDown - _radiusUp; 
                double l = Math.Sqrt(_height*_height + delta*delta);
                double area = Math.PI * (l * _radiusUp + l * _radiusDown +
                    _radiusDown * _radiusDown + _radiusUp * _radiusUp);
                return area;
            } 
        } // Area

        // объем усеченного конуса
        // https://www-formula.ru/2011-09-21-10-55-40
        public double Volume => Math.PI * (_radiusDown*_radiusDown + 
            _radiusDown*_radiusUp + _radiusUp*_radiusUp) / 3d;

        // строковое представление конуса (метод ToString(), выводить только
        // радиусы и высоту)
        public override string ToString() => 
            $"радиус основания: {_radiusDown:f2}; верхний радиус: {_radiusUp:f2}; высота: {_height}";

        // вывод данных в строку таблицы, row - номер строки таблицы,
        // indent - количество отступов перед строкой 
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber, 3} │ {_radiusDown, 9:f2} │ {_radiusUp, 9:f2} " +
            $"│ {_height, 9:f2} │ {Area, 9:f2} │ {Volume, 9:f2} │";

        // компаратор для сортировки по возрастанию объемов
        public static int VolumeComparer(Conoid c1, Conoid c2) =>
            c1.Volume.CompareTo(c2.Volume);

        // компаратор для сортировки по убыванию высот
        public static int HeightComparerDesc(Conoid c1, Conoid c2) =>
            c2.Height.CompareTo(c1.Height);
        
        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent); 
            string str = 
            $"{spaces}┌─────┬───────────┬───────────┬───────────┬───────────┬───────────┐\n" +
            $"{spaces}│  №  │ Нижний    │ Верхний   │ Высота    │ Площадь   │ Объем     │\n" +
            $"{spaces}│ п/п │    радиус │    радиус │    конуса │    конуса │    конуса │\n" +
            $"{spaces}├─────┼───────────┼───────────┼───────────┼───────────┼───────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) => 
            $"{" ".PadRight(indent)}└─────┴───────────┴───────────┴───────────┴───────────┴───────────┘";
    } // class Conoid
}
