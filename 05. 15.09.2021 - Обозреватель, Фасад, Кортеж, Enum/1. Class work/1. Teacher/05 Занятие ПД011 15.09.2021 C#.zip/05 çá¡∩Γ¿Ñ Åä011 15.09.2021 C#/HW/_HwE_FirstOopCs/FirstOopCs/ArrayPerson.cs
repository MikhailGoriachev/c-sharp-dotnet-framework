﻿using System;

namespace FirstOopCs {
    /*
     *
     * Класс для работы с массивом объектов класса Person
     * Хранит название коллекции персон и собственно массив объектов класса Person
     * Заполнить массив персон данными для не менее чем 12 персон. Рекомендую для
     * наработки навыков кодирования не генерировать объекты массива, а создавать
     * с использованием свойств. Для массива персон выполнить следующие обработки:
     *     • Вывести массив персон в консоль.
     *     • Вывести в консоль персону/персон с максимальным ростом.
     *     • Вывести в консоль персону/персон с минимальным возрастом. 
     *     • Разработайте методы-компараторы для упорядочивания массива.
     *       Упорядочить массив и вывести его в консоль. Упорядочивать по:
     *         o по городу проживания
     *         o по убыванию веса
     *         o по возрастанию роста
     */
    public class ArrayPerson {
        public string Title { get; set; }
        public Person[] Persons { get; set; }
        
        public bool Empty => Persons.Length == 0;
        
        // обработки по заданию
        
        // Заполнить массив персон данными для не менее чем 12 персон.
        // Для наработки навыков кодирования не генерируем объекты массива,
        // а создаем их с использованием свойств
        public void Initialize() {
            Title = $"Персональные данные пользователей нашего сервиса на {DateTime.Now:d}";
            Persons = new[] {
                new Person {FullName = "Пожар И.П.",     Age = 23, Height = 176, Weight =  87.8, City = "Амвросиевка"},
                new Person {FullName = "Кленцарь Т.А.",  Age = 45, Height = 156, Weight =  69.8, City = "Макеевка"},
                new Person {FullName = "Саламаха А.В.",  Age = 22, Height = 186, Weight =  92.1, City = "Горловка"},
                new Person {FullName = "Биленко В.В.",   Age = 19, Height = 156, Weight =  45.3, City = "Горловка"},
                new Person {FullName = "Корнецкий А.Т.", Age = 33, Height = 196, Weight = 145.3, City = "Ясиноватая"},
                new Person {FullName = "Зеликов И.М.",   Age = 46, Height = 201, Weight = 134.1, City = "Шахтинск"},
                new Person {FullName = "Михайлов Р.О.",  Age = 33, Height = 188, Weight = 112.4, City = "Харцызск"},
                new Person {FullName = "Бурделя П.А.",   Age = 31, Height = 168, Weight =  78.2, City = "Белояровка"},
                new Person {FullName = "Паладич В.Р.",   Age = 47, Height = 155, Weight =  67.2, City = "Амвросиевка"},
                new Person {FullName = "Тесленко А.И.",  Age = 32, Height = 177, Weight =  97.9, City = "Снежное"},
                new Person {FullName = "Годовась А.У.",  Age = 21, Height = 187, Weight = 145.3, City = "Горловка"},
                new Person {FullName = "Запорожец А.В.", Age = 24, Height = 173, Weight =  95.7, City = "Макеевка"},
                new Person {FullName = "Коссе А.В.",     Age = 47, Height = 201, Weight = 189.7, City = "Белояровка"},
                new Person {FullName = "Годунов Р.В.",   Age = 19, Height = 167, Weight =  77.7, City = "Моспино"}
            };
        } // Initialize
        
        // Возвращает максимальный рост в массиве персон
        int MaxHeight() {
            int maxHeight = Persons[0].Height;
            for (int i = 1; i < Persons.Length; i++) {
                int height = Persons[i].Height;
                if (height > maxHeight)
                    maxHeight = height;
            } // for i

            return maxHeight;
        } // MaxHeight
        
        // Возвращает минимальный возраст в массиве персон
        int MinAge() {
            int minAge = Persons[0].Age;
            for (int i = 1; i < Persons.Length; i++) {
                int age = Persons[i].Age;
                if (age < minAge)
                    minAge = age;
            } // for i

            return minAge;
        } // MinAge
        
        // Отбор персон с максимальным ростом
        public Person[] FindMaxHeight() {
            // найти максимальный рост в массиве персон
            int maxHeight = MaxHeight();
            
            // предикат для отбора персон с максимальным ростом
            bool MaxHeightPredicate(Person p) => p.Height == maxHeight;
            
            // отбор персон с максимальным ростом
            Person[] selected = Array.FindAll(Persons, MaxHeightPredicate);
            
            return selected;
        } // FindMaxHeight
        
        // Отбор персон с минимальным возрастом
        public Person[] FindMinAge() {
            // найти минимальный возраст в массиве персон
            int minAge = MinAge();
            
            // предикат для отбора персон с минимальным возрастом
            bool MinAgePredicate(Person p) => p.Age == minAge;
            
            // отбор персон с минимальным возрастом
            Person[] selected = Array.FindAll(Persons, MinAgePredicate);
            
            return selected;
        } // FindMinAge
        
        // Вывести массив персон в консоль
        public void Show(string caption, int indent) {
            // вывод заголовка таблицы персон
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Person.Header(indent)}");
            
            // вывод всех элементов массива персон
            int row = 1;
            void OutItem(Person p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(Persons, OutItem);
            
            // вывод подвала таблицы
            Console.WriteLine(Person.Footer(indent));
        } // Show
        
        // Вывести массив отобранных персон в консоль.
        public void Show(string caption, int indent, Person[] persons) {
            // вывод заголовка таблицы персон
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Person.Header(indent)}");
            
            // вывод всех элементов массива персон
            int row = 1;
            void OutItem(Person p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(persons, OutItem);
            
            // вывод подвала таблицы
            Console.WriteLine(Person.Footer(indent));
        } // Show
        
        // Упорядочить массив персон по городу проживания
        public void OrderByCity() => Array.Sort(Persons, Person.CityComparer);
        
        // Упорядочить массив персон по убыванию веса
        public void OrderByWeightDesc() => Array.Sort(Persons, Person.WeightDescComparer);
        
        // Упорядочить массив персон по увеличению роста
        public void OrderByHeight() => Array.Sort(Persons, Person.HeightComparer);
    } // ArrayPerson
}