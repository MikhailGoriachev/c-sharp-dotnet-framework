﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstOopCs
{
    // Разработайте класс Персона со следующими полными свойствами: 
    // фамилия и инициалы имени и отчества (например, Семенов Р.О.) 
    // возраст в полных годах (целое число)
    // рост в сантиметрах (целое число)
    // вес в кг (вещественное число)
    // название города проживания (строка)
    public class Person
    {
        // фамилия и инициалы имени и отчества (например, Семенов Р.О.)
        private string _fullName = "";
        public string FullName { 
		    get => _fullName; 
			set => _fullName = string.IsNullOrWhiteSpace(value)?_fullName:value; 
		} // FullName

        // возраст в полных годах (целое число)
        private int _age;
        public int Age {
            get => _age;
            set =>  _age = value >=0 ? value:_age;
        } // Age
        
        // рост в сантиметрах (целое число)
        private int _height;
        public int Height {
            get => _height;
            set =>  _height = value >=0 ? value:_height;
        } // Height

        // вес в кг (вещественное число)
        private double _weight;
        public double Weight {
            get => _weight;
            set => _weight = value > 0?value:0; 
        } // Weight

        // название города проживания (строка)
        private string _city;
        public string City {
            get => _city;
            set => _city = string.IsNullOrWhiteSpace(value)?_city:value; 
        } // City

        // строковое представление полей объекта
        public override string ToString() => 
            $"{_fullName}, лет: {_age}; рост {_height} см; вес {_weight:f2} кг; город: {_city}";

        // представление объекта в виде строки таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber, 3} │ {_fullName, -18} │ {_age, 5}    " +
            $"│ {_height, 4}  │ {_weight, 6:f2} │ {_city, -16} │";
        
        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent); 
            string str = 
                $"{spaces}┌─────┬────────────────────┬──────────┬───────┬────────┬──────────────────┐\n" +
                $"{spaces}│  №  │ Фамилия и          │ Возраст, │ Рост, │ Вес,   │ Город            │\n" +
                $"{spaces}│ п/п │           инициалы │   лет    │  см   │     кг │       проживания │\n" +  
                $"{spaces}├─────┼────────────────────┼──────────┼───────┼────────┼──────────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) => 
            $"{" ".PadRight(indent)}└─────┴────────────────────┴──────────┴───────┴────────┴──────────────────┘";
        
        // Компараторы для сортировки по заданию
        // Компаратор для сортировки по городу проживания
        public static int CityComparer(Person p1, Person p2) => 
            p1._city.CompareTo(p2._city);
        // String.Compare(p1._city, p2._city, StringComparison.Ordinal); 
        
        // Компаратор для сортировки по убыванию веса
        public static int WeightDescComparer(Person p1, Person p2) =>
            p2._weight.CompareTo(p1._weight);
        
        // Компаратор для сортировки по увеличению роста
        public static int HeightComparer(Person p1, Person p2) =>
            p1._height.CompareTo(p2._height);
    } // class Person
}
