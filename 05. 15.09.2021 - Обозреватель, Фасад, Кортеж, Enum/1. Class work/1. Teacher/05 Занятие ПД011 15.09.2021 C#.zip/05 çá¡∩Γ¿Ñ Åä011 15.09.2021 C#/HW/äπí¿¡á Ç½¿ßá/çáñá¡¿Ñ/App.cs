﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    class App {

        private ArrayConoid _arrayConoid = new ArrayConoid();


        public void Task1() {
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 1. Демонстрация работы методов ArrayConoid");

            // заполнение массива данными конусов 
            _arrayConoid.Create(1d, 15d);
            _arrayConoid.Show();

            WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
            Console.ReadKey(true);
            Console.Clear();
            ShowNavBarTask("  Задача 1. Демонстрация работы методов ArrayConoid");


            // Сортировка массива конусов по убыванию высот
            _arrayConoid.Name = "\n\tМассив из усеченных конусов, отсортированный по убыванию высот";
            _arrayConoid.SortByH();
            _arrayConoid.Show();

            WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
            Console.ReadKey(true);
            Console.Clear();
            ShowNavBarTask("  Задача 1. Демонстрация работы методов ArrayConoid");




            // сортировка массива конусов по возрастанию объемов
            _arrayConoid.Name = "\n\tМассив из усеченных конусов, отсортированный по возрастанию объемов";
            _arrayConoid.SortByVolume();
            _arrayConoid.Show();

            // ожидать нажатия любой клавиши, не отображать нажатую клавишу
            // в окне консоли
            WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
            Console.ReadKey(true);
            Console.Clear();
        } // Task1

        public void Task2() {
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 2. Выполнить обработки для массива персон");

            Person[] persons = {
                new Person{Name = "Семенов Р.О."  , City = "Донецк"         , Age = 18, Height = 170, Weight = 75d},
                new Person{Name = "Дунаев Д.Н."   , City = "Москва"         , Age = 28, Height = 181, Weight = 78d},
                new Person{Name = "Харламова Ю.Т.", City = "Санкт-Петербург", Age = 41, Height = 164, Weight = 61d},
                new Person{Name = "Олегова Б.Д."  , City = "Казань"         , Age = 55, Height = 159, Weight = 56d},
                new Person{Name = "Янковский Н.К.", City = "Екатеринбург"   , Age = 19, Height = 168, Weight = 64d},
                new Person{Name = "Абалкин Л.П."  , City = "Сочи"           , Age = 31, Height = 181, Weight = 78d},
                new Person{Name = "Романова А.Г." , City = "Краснодар"      , Age = 18, Height = 165, Weight = 63d},
                new Person{Name = "Воликов Б.Е."  , City = "Донецк"         , Age = 32, Height = 173, Weight = 77d},
                new Person{Name = "Абалкин Л.Ю."  , City = "Санкт-Петербург", Age = 65, Height = 169, Weight = 68d},
                new Person{Name = "Жукова П.В."   , City = "Казань"         , Age = 25, Height = 167, Weight = 67d},
                new Person{Name = "Соколов А.С."  , City = "Екатеринбург"   , Age = 51, Height = 183, Weight = 79d},
                new Person{Name = "Лебедев Л.А."  , City = "Сочи"           , Age = 33, Height = 183, Weight = 77d},
            };

            Console.WriteLine("\n    Массив персон для обработки:");
            ShowPersons(persons);

            int maxHeight = MaxHeight(persons);

            bool IsMaxHeight(Person p) => p.Height == maxHeight;
            Person[] maxHeightPersons = Array.FindAll(persons, IsMaxHeight);

            int minAge = MinAge(persons);

            bool IsMinAge(Person p) => p.Age == minAge;
            Person[] minAgePersons = Array.FindAll(persons, IsMinAge);

            Console.WriteLine("\n    Персона/персоны с максимальным ростом:");
            ShowPersons(maxHeightPersons);
            Console.WriteLine("\n    Персона/персоны с минимальным возрастом:");
            ShowPersons(minAgePersons);


            // ожидать нажатия любой клавиши, не отображать нажатую клавишу
            // в окне консоли
            WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
            Console.ReadKey(true);
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 2. Выполнить обработки для массива персон");

            // сортировка по городу проживания
            Array.Sort(persons, Person.CompareByCity);
            Console.WriteLine("\n    Массив персон отсортирован по городу проживания:");
            ShowPersons(persons);

            // сортировкa по убыванию веса
            Array.Sort(persons, Person.CompareByHeight);
            Console.WriteLine("\n    Массив персон отсортирован по убыванию веса:");
            ShowPersons(persons);

            WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
            Console.ReadKey(true);
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 2. Выполнить обработки для массива персон");

            // сортировкa по возрастанию роста
            Array.Sort(persons, Person.CompareByWeight);
            Console.WriteLine("\n    Массив персон отсортирован по возрастанию роста:");
            ShowPersons(persons);

            WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
            Console.ReadKey(true);
            Console.Clear();
        } // Task2



        #region Вспомогательные методы

        // вывод массива персон
        private void ShowPersons(Person[] persons)
        {
            Console.WriteLine($"\t{Person.Header}");
            foreach (Person item in persons)
                Console.WriteLine($"\t{item.ToTableRow}");
            Console.WriteLine($"\t{Person.Footer}");
        } // ShowPersons

        // поиск максимального роста
        private int MaxHeight(Person[] persons)
        {
            int Max = persons[0].Height;

            for (int i = 1; i < persons.Length; ++i)
            {
                if (persons[i].Height > Max)
                    Max = persons[i].Height;
            } // for i
            return Max;
        } // MaxHeight

        // поиск минимального возраста
        private int MinAge(Person[] persons)
        {
            int Min = persons[0].Age;

            for (int i = 1; i < persons.Length; ++i)
            {
                if (persons[i].Age < Min)
                    Min = persons[i].Age;
            } // for i
            return Min;
        } // MinAge


        // формирует и выводит верхнюю строку для задач
        public void ShowNavBarTask(string line)
        {
            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;
            ConsoleColor oldFgColor = Console.ForegroundColor;

            // при выводе немного используем методы класса strring :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
            Console.ForegroundColor = oldFgColor;
        } // ShowNavBarTask


        // вывод текста задания в консоль
        public void ShowStartText(int taskNumber = -1)
        {

            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;

            string[] hotKeys = { "F5", "F6", "F10" };
            string[] descs = { "Задача 1. Демонстрация работы методов ArrayConoid", "Задача 2. Выполнить обработки для массива персон ", "Выход" };

            Console.BackgroundColor = ConsoleColor.Gray;

            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2, (Console.WindowHeight - 12) / 2, " ".PadRight(descs[1].Length + 6), ConsoleColor.Black);
            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2, (Console.WindowHeight - 10) / 2, " ".PadRight(descs[1].Length + 6), ConsoleColor.Black);
            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2, (Console.WindowHeight - 8) / 2, " ".PadRight(descs[1].Length + 6), ConsoleColor.Black);
            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2, (Console.WindowHeight - 6) / 2, " ".PadRight(descs[1].Length + 6), ConsoleColor.Black);
            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2, (Console.WindowHeight - 4) / 2, " ".PadRight(descs[1].Length + 6), ConsoleColor.Black);
            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2, (Console.WindowHeight - 2) / 2, " ".PadRight(descs[1].Length + 6), ConsoleColor.Black);
            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2, Console.WindowHeight / 2, " ".PadRight(descs[1].Length + 6), ConsoleColor.Black);

            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2 + 1, (Console.WindowHeight - 10) / 2, hotKeys[0], ConsoleColor.Red);
            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2 + 5, (Console.WindowHeight - 10) / 2, descs[0], ConsoleColor.Black);


            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2 + 1, (Console.WindowHeight - 6) / 2, hotKeys[1], ConsoleColor.Red);
            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2 + 5, (Console.WindowHeight - 6) / 2, descs[1], ConsoleColor.Black);

            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2 + 1, (Console.WindowHeight - 2) / 2, hotKeys[2], ConsoleColor.Red);
            WriteXY((Console.WindowWidth - (descs[1].Length + 6)) / 2 + 5, (Console.WindowHeight - 2) / 2, descs[2], ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
        } // ShowText

        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        #endregion
    } // App
}
