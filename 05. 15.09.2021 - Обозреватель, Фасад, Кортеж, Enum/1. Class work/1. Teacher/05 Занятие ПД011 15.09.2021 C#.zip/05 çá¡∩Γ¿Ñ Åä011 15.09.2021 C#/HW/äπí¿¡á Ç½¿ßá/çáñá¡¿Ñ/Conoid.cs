﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    class Conoid{

        private double _r1;  // радиус верхнего основания
        public double R1 {
            get { return _r1; }
            set { if (value > 0) _r1 = value; }
        }


        private double _r2;  // радиус нижнего основания
        public double R2 {
            get { return _r2; }
            set { if (value > 0) _r2 = value; }
        }

        private double _h;  // высота
        public double H {
            get { return _h; }
            set { if (value > 0) _h = value; }
        }


        // вычисляемое свойство для площади
        public double Area => Math.PI * Math.Sqrt(_h * _h + ((_r1 - _r2) * (_r1 - _r2))) * (_r1 + _r2) + Math.PI * _r1 * _r1 + Math.PI * _r2 * _r2;
        
        // вычисляемое свойство для объема
        public double Volume => 1d/ 3d * Math.PI * _h * (_r1 * _r1 + _r1 * _r2 + _r2 * _r2);

        public static string Header => "┌────────────────────┬───────────────────┬──────────┬───────────┬───────────┐\n\t│       Радиус       │      Радиус       │  Высота  │  Площадь  │   Объем   │\n\t│ верхнего основания │ нижнего основания │          │           │           │\n\t├────────────────────┼───────────────────┼──────────┼───────────┼───────────┤";
        public static string Footer => "└────────────────────┴───────────────────┴──────────┴───────────┴───────────┘";

        // метод формирующий строку таблицы со сведениями о конусе
        public string ToTableRow => $"│ {_r1,18:f2} │ {_r2,17:f2} │ {_h,8:f2} │ {this.Area, 9:f2} │ {this.Volume, 9:f2} │";


        public override string ToString() =>
            $"Радиус верхнего основания: {_r1:f2}, радиус нижнего основания: {_r2:f2}, высота {_h:f2}";

        // компаратор для сортировки по убыванию высот
        public static int CompareByH(Conoid x, Conoid y) =>
           x.H > y.H ? -1 : x.H < y.H ? 1 : 0;

        // компаратор для сортировки по возрастанию объемов
        public static int CompareByVolume(Conoid x, Conoid y) =>
            x.Volume < y.Volume ? -1 : x.Volume > y.Volume ? 1 : 0;
    } // Conoid
}
