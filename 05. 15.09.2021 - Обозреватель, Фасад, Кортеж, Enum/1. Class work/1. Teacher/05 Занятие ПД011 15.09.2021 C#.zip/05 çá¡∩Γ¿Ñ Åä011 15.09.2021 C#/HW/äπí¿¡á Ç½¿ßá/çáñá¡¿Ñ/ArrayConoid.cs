﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    class ArrayConoid
    {
        private Conoid[] conoids; // массив из усеченных конусов

        public string Name { get; set; } = "Массив из усеченных конусов"; // название коллекции конусов


        private static Random rand = new Random();

        // заполнение массива данными конусов
        public void Create(double lo, double hi){
            conoids = new Conoid[]{
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
                new Conoid { R1 = lo + (hi - lo) * rand.NextDouble(), R2 = lo + (hi - lo) * rand.NextDouble(), H = lo + (hi - lo) * rand.NextDouble() },
            };
        } // Create

        // вывод названия коллекции и массива конусов в консоль, в табличном виде
        public void Show(){
            Console.WriteLine($"\t{this.Name}");
            Console.WriteLine($"\t{Conoid.Header}");
            foreach (Conoid item in conoids)
                Console.WriteLine($"\t{item.ToTableRow}");


            Console.WriteLine($"\t├────────────────────┴───────────────────┴──────────┼───────────┼───────────┤");
            Console.WriteLine($"\t│ {"Суммарные значения: ", -49} │ {this.SumArea(), 9:f2} │ {this.SumVolume(),9:f2} │");

            Console.WriteLine($"\t└───────────────────────────────────────────────────┴───────────┴───────────┘");

        } // Show

        // Сортировка массива конусов по возрастанию объемов
        public void SortByVolume() =>
            Array.Sort(conoids, Conoid.CompareByVolume);

        // Сортировка массива конусов по убыванию высот
        public void SortByH() =>
            Array.Sort(conoids, Conoid.CompareByH);

        // вычисление суммарной площади поверхности конусов
        public double SumArea() {
            double sum = 0;
            foreach (Conoid item in conoids)
                sum += item.Area;
            return sum;
        } // SumArea

        // вычисление суммарного объема конусов 
        public double SumVolume() {
            double sum = 0;
            foreach (Conoid item in conoids)
                sum += item.Volume;
            return sum;
        } // SumVolume


    } // ArrayConoid
}
