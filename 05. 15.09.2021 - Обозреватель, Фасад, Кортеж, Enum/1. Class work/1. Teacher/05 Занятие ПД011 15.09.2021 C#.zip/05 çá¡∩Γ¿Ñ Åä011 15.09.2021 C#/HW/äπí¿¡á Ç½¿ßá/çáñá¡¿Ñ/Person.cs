﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    class Person{

        // фамилия и инициалы имени и отчества
        public string Name { get; set; } = "Иванов И. И."; 

        // название города проживания
        public string City { get; set; } = "Донецк";        

        // возраст в полных годах 
        private int _age;                                  
        public int Age {
            get { return _age; }
            set { if (value >= 0) _age = value; } 
        }

        // рост в сантиметрах
        private int _height;                              
        public int Height {
            get { return _height; }
            set { if (value >= 0) _height = value; }
        }

        // вес в кг 
        private double _weight;
        public double Weight {
            get { return _weight; }
            set { if (value >= 0) _weight = value; }
        }

        public static string Header => "┌───────────────────┬──────────────────┬─────────┬────────────┬───────────┐\n\t│   Фамилия И. О.   │ Город проживания │ Возраст │    Рост    │    Вес    │\n\t├───────────────────┼──────────────────┼─────────┼────────────┼───────────┤";
        public static string Footer => "└───────────────────┴──────────────────┴─────────┴────────────┴───────────┘";

        public string ToTableRow => $"│ {this.Name, -17} │ {this.City, -16} │ {_age,3} лет │ {_height,7} см │ {_weight,6:f2} кг │";

        // компаратор для сортировки по городу проживания
        public static int CompareByCity(Person x, Person y) =>
           x.City.CompareTo(y.City);

        // компаратор для сортировки по убыванию веса
        public static int CompareByWeight(Person x, Person y) =>
           x._weight < y._weight ? -1 : x._weight > y._weight ? 1 : 0;

        // компаратор для сортировки по возрастанию роста
        public static int CompareByHeight(Person x, Person y) =>
           x._height > y._height ? -1 : x._height < y._height ? 1 : 0;

    } // Person
}
