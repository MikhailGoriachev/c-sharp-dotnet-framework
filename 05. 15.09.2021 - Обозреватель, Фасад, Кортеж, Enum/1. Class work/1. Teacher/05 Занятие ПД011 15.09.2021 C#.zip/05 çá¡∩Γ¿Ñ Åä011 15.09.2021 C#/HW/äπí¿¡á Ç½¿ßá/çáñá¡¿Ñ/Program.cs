﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    class Program
    {

        static void Main(string[] args) {
            App app = new App();
            Console.Title = "Задание на 15.09.2021";
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.CursorVisible = false;

            // главный цикл работы приложения 
            while (true)
            {
                app.ShowStartText();

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                switch (key)
                {
                    // решение задачи 1 назначено на клавишу F5
                    case ConsoleKey.F5:
                        app.Task1();
                        break;

                    // решение задачи 2 назначено на клавишу F6
                    case ConsoleKey.F6:
                        app.Task2();
                        break;

                    // выход из приложения назначен на клавишу F10
                    case ConsoleKey.F10:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Console.SetCursorPosition(0, Console.WindowHeight - 1);
                        Console.CursorVisible = true;
                        return;
                } // switch
            } // while
        } // Main
    }
}
