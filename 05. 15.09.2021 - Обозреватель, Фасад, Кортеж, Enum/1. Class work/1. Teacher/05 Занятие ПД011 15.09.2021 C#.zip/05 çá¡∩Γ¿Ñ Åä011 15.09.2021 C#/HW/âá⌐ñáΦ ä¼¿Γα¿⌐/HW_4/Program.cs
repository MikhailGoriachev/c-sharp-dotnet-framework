﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HW_4
{
    class Program{
        static void Main(string[] args){
            App app = new App();

            Console.Title = "Задание на 15.09.2021 -  Математические операции и массивы";
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.CursorVisible = false;

            int _key = 0;

            while (true){
                Console.Clear();
                Console.Write("\n\t\t   Меню\n");
                Console.Write("\t1 - Массив усеченных конусов\n");
                Console.Write("\t2 - Персоны\n");
                Console.Write("------------------------------------------");
                _key = InputInt(8,5,"Выберите задание(0-exit)> ");
                if (_key == 0) break;  
                switch (_key){
                    case 0:
                        break;
                    case 1:
                        app.task1();
                        break;
                    case 2:
                        app.task2();
                        break;
                } // switch
            } // while

        } // Main
        #region Вспомогатльные функции
        public static int InputInt(int x, int y, string prompt){
            // сохранить цвета консоли
            ConsoleColor bgColor = Console.BackgroundColor;
            ConsoleColor fgColor = Console.ForegroundColor;
            bool result;
            int value = 0;

            // отобразить курсор для удобства ввода 
            Console.CursorVisible = true;

            do{
                // вывод подсказки
                Console.BackgroundColor = bgColor;
                WriteXY(x, y, prompt, fgColor);

                // вывод имитации строки ввода 
                Console.BackgroundColor = ConsoleColor.Cyan;
                WriteXY(x + prompt.Length + 1, y, " ".PadRight(10), Console.ForegroundColor);

                // собственно ввод
                Console.ForegroundColor = ConsoleColor.Black;
                Console.SetCursorPosition(x + prompt.Length + 2, y);
                result = int.TryParse(Console.ReadLine(), out value);
            } while (!result);

            // восстановить цвет консоли, спрятать текстовый курсор
            Console.ForegroundColor = fgColor;
            Console.BackgroundColor = bgColor;
            Console.CursorVisible = false;
            return value;
        } // InputDouble

        static void WriteXY(int x, int y, string s, ConsoleColor color){
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY
        #endregion
    } // Programm
}
