﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HW_4 {
	class App{

		private static Random rand = new Random();

		public App() { }

	public void task1(){

			int n = 12;
			Conoid[] conoids = new Conoid[n];
			ArrayConoid arrCon = new ArrayConoid("\n\tМассив усеченых конусов:", conoids);
			bool flag = false;
			int _key = 0;
			double sum = 0d;
			while (true){
				Console.Clear();
				Console.Write("\n\t\t   Меню\n");
				Console.Write("\t1 - Заполнить массив данными конусов\n");
				Console.Write("\t2 - Вычисление суммарного объема конусов\n");
				Console.Write("\t3 - Вычисление суммарной площади конусов\n");
				Console.Write("\t4 - Вывод названия коллекции и массива конусов\n");
				Console.Write("\t5 - Вывод названия коллекции и массива конусов с цветом\n");
				Console.Write("\t6 - Сортировка массива по возростанию объемов\n");
				Console.Write("\t7 - Сортировка массива по убыванию высот\n");
				Console.Write("------------------------------------------");
				_key = InputInt(8, 11, "Выберите задание(0-exit)> ");
				if (_key == 0) break;
				switch (_key) {
					case 0:
						break;

					case 1:
						Console.Clear();
						for (int i = 0; i < n; i++) {
							double rTop = GetRandDouble(1d, 2.5d);
							double rDown = GetRandDouble(1d, 2.5d) + rTop;
							conoids[i] = new Conoid(rTop, rDown, GetRandDouble(2d, 3d));
						} // for i
						Console.WriteLine(arrCon);
						flag = true;
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 2:
						Console.Clear();
						if (!flag) {
							Console.WriteLine("\n\tИзначально необходимо создать массив конусов!\n");
							Thread.Sleep(3_000);
							continue;
						} // if

						Console.Write("\n\tСуммарный объем конусов = ");
						sum = 0d;
						for (int i = 0; i < arrCon.Conoids.Length; i++)
							sum += arrCon.Conoids[i].Volume;
						Console.WriteLine($"{sum:n}");
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 3:
						Console.Clear();
						if (!flag) {
							Console.WriteLine("\n\tИзначально необходимо создать массив конусов!\n");
							Thread.Sleep(3_000);
							continue;
						} // if

						Console.Write("\n\tСуммарная площадь конусов = ");
						sum = 0d;
						for (int i = 0; i < arrCon.Conoids.Length; i++)
							sum += arrCon.Conoids[i].Area;
						Console.WriteLine($"{sum:n}");
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 4:
						Console.Clear();
						if (!flag)
						{
							Console.WriteLine("\n\tИзначально необходимо создать массив конусов!\n");
							Thread.Sleep(3_000);
							continue;
						} // if
						Console.Write(arrCon);
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 5:
						Console.Clear();
						if (!flag)
						{
							Console.WriteLine("\n\tИзначально необходимо создать массив конусов!\n");
							Thread.Sleep(3_000);
							continue;
						} // if
						int ind = 0;
						for (int i = 0; i < arrCon.Conoids.Length; i++)
							if (arrCon.Conoids[ind].Area < arrCon.Conoids[i].Area) ind = i;

						ConsoleColor oldColor = Console.ForegroundColor;
						Console.Write($"\n\t{arrCon.Name}" +
										   "\n┌─────┬────────┬─────────┬────────┬─────────┬───────┐\n" +
											 "│  №  │ R. ниж │ R. верх │ Высота │  Объем  │   S   │\n" +
											 "├─────┼────────┼─────────┼────────┼─────────┼───────┤\n");

						for (int i = 0; i < arrCon.Conoids.Length; i++) {
							Console.ForegroundColor = i == ind ? ConsoleColor.Yellow : oldColor;
							Console.Write($"│ {i + 1,2}  {arrCon.Conoids[i]}");
						} // for i

						Console.Write("└─────┴────────┴─────────┴────────┴─────────┴───────┘\n");
						sum = 0d;
						for (int i = 0; i < arrCon.Conoids.Length; i++)
							sum += arrCon.Conoids[i].Area;
						Console.Write($"\tОбщая сумма площадей = {sum:n}\n");
						sum = 0d;
						for (int i = 0; i < arrCon.Conoids.Length; i++)
							sum += arrCon.Conoids[i].Volume;
						Console.Write($"\tОбщая сумма объемов= {sum:n}\n");
						Console.ForegroundColor = oldColor;
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 6:
						Console.Clear();
						if (!flag)
						{
							Console.WriteLine("\n\tИзначально необходимо создать массив конусов!\n");
							Thread.Sleep(3_000);
							continue;
						} // if
						Array.Sort(arrCon.Conoids, Conoid.CompareByVolume);
						Console.Write(arrCon);
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 7:
						Console.Clear();
						if (!flag)
						{
							Console.WriteLine("\n\tИзначально необходимо создать массив конусов!\n");
							Thread.Sleep(3_000);
							continue;
						} // if
						Array.Sort(arrCon.Conoids, Conoid.CompareByHeight);
						Console.Write(arrCon);
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;
				} // switch
			} // while


			WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
			Console.ReadKey(true);
			Console.Clear();
		} // task1
	public void task2(){
			int n = 12, iM= 0;
			Person[] persons= new Person[n];
			persons[0] = new Person("Черкизова И. И.", 40, 187, 99.2d, "Макеевка");
			persons[1] = new Person("Черкасова Е. М.", 30, 160, 69.1d, "Макеевка");
			persons[2] = new Person("Чернышева К. И.", 50, 173, 87.8d, "Донецк");
			persons[3] = new Person("Прекасова М. А.", 41, 180, 93.5d, "Донецк");
			persons[4] = new Person("Совакиная А. М.", 42, 175, 62.4d, "Москва");
			persons[5] = new Person("Лермасова А. Л.", 34, 177, 86.6d, "Москва");
			persons[6] = new Person("Аферасова М. М.", 54, 165, 82.9d, "Лондон");
			persons[7] = new Person("Черникова П. Т.", 21, 155, 93.1d, "Лондон");
			persons[8] = new Person("Узчбекина М. М.", 64, 159, 92.5d, "Киев");
			persons[9] = new Person("Максимова Е. Я.", 24, 168, 73.5d, "Киев");
			persons[10] = new Person("Лермонова В. Н.", 47, 184, 98.3d, "Макеевка");
			persons[11] = new Person("Мониорина В. М.", 61, 181, 87.8d, "Киев");
			int _key = 0;
			while (true)
			{
				Console.Clear();
				Console.Write("\n\t\t   Меню\n");
				Console.Write("\t1 - Вывод массива\n");
				Console.Write("\t2 - Вывести персону с максимальным ростом\n");
				Console.Write("\t3 - Вывести персону с минимальным возрастом\n");
				Console.Write("\t4 - Сортировка по городу проживания\n");
				Console.Write("\t5 - Сортировка по убыванию веса\n");
				Console.Write("\t6 - Сортировка по возрастанию роста\n");
				Console.Write("------------------------------------------");
				_key = InputInt(8, 11, "Выберите задание(0-exit)> ");
				if (_key == 0) break;
				switch (_key)
				{
					case 0:
						break;

					case 1:
						Console.Clear();
						Show(persons);

						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 2:
						Console.Clear();
						iM = 0;
						for (int i = 0; i < persons.Length; i++)
							if (persons[iM].Height < persons[i].Height) iM = i;

						Console.WriteLine($"\n\tПерсона с максимальным ростом>\n\t{persons[iM].Name}   {persons[iM].Age}   {persons[iM].Height}   {persons[iM].Weight}   {persons[iM].City}\n");


						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 3:
						Console.Clear();
						iM = 0;
						for (int i = 0; i < persons.Length; i++)
							if (persons[iM].Age > persons[i].Age) iM = i;

						Console.WriteLine($"\n\tПерсона с минимальным возрастом>\n\t{persons[iM].Name}   {persons[iM].Age}   {persons[iM].Height}   {persons[iM].Weight}   {persons[iM].City}\n");
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 4:
						Console.Clear();
						Array.Sort(persons, Person.CompareByCity);
						Show(persons);
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 5:
						Console.Clear();
						Array.Sort(persons, Person.CompareByWeight);
						Show(persons);
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;

					case 6:
						Console.Clear();
						Array.Sort(persons, Person.CompareByHeight);
						Show(persons);
						WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
						Console.ReadKey(true);
						Console.Clear();
						break;
				} // switch
			} // while


			WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
			Console.ReadKey(true);
			Console.Clear();
		} // task2

		private void Show(Person[] persons){
			Console.Write(
										   "\n┌─────┬────────────────────┬────────┬────────┬────────┬───────────┐\n" +
											 "│  №  │        Имя         │ Возраст│  Рост  │  Вес   │   Город   │\n" +
											 "├─────┼────────────────────┼────────┼────────┼────────┼───────────┤\n");
			for (int i = 0; i < persons.Length; i++)
			{
				Console.Write($"│ {i + 1,2}  {persons[i]}");
			} // for i

			Console.Write("└─────┴────────────────────┴────────┴────────┴────────┴───────────┘\n");
		} // Show

		#region Вспомогательные функции
		private static double GetRandDouble(double low = -10d, double high = 10d) => low + (high - low) * rand.NextDouble();

		public static int InputInt(int x, int y, string prompt){
			// сохранить цвета консоли
			ConsoleColor bgColor = Console.BackgroundColor;
			ConsoleColor fgColor = Console.ForegroundColor;
			bool result;
			int value = 0;

			// отобразить курсор для удобства ввода 
			Console.CursorVisible = true;

			do
			{
				// вывод подсказки
				Console.BackgroundColor = bgColor;
				WriteXY(x, y, prompt, fgColor);

				// вывод имитации строки ввода 
				Console.BackgroundColor = ConsoleColor.Cyan;
				WriteXY(x + prompt.Length + 1, y, " ".PadRight(10), Console.ForegroundColor);

				// собственно ввод
				Console.ForegroundColor = ConsoleColor.Black;
				Console.SetCursorPosition(x + prompt.Length + 2, y);
				result = int.TryParse(Console.ReadLine(), out value);
			} while (!result);

			// восстановить цвет консоли, спрятать текстовый курсор
			Console.ForegroundColor = fgColor;
			Console.BackgroundColor = bgColor;
			Console.CursorVisible = false;
			return value;
		} // InputDouble

		static void WriteXY(int x, int y, string s, ConsoleColor color){
			// сохранить текущий цвет консоли и установить заданный
			ConsoleColor oldColor = Console.ForegroundColor;
			Console.ForegroundColor = color;

			Console.SetCursorPosition(x, y);
			Console.Write(s);

			// восстановить цвет консоли
			Console.ForegroundColor = oldColor;
		} // WriteXY
        #endregion

    } // class App
}
