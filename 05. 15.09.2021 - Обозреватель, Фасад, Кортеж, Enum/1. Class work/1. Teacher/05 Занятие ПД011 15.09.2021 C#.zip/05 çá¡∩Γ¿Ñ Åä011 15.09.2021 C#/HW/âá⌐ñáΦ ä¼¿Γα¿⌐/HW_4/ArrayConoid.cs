﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_4
{
    class ArrayConoid{
        public ArrayConoid(string name, Conoid[] conoids){
            _name = name;
            _conoids = conoids;
        } // Conoid

        private string _name;
        public string Name{
            get => _name;
            set => _name = value;
        } // Name

        private Conoid[] _conoids;
        public Conoid[] Conoids{
            get => _conoids;
            set => _conoids = value;
        } // Conoid

        public override string ToString(){
            string str = $"\n\t{_name}" +
                       "\n┌─────┬────────┬─────────┬────────┬─────────┬───────┐\n" +
                         "│  №  │ R. ниж │ R. верх │ Высота │  Объем  │   S   │\n" +
                         "├─────┼────────┼─────────┼────────┼─────────┼───────┤\n";
            for(int i = 0;i<_conoids.Length;i++)
                str+=$"│ {i+1, 2}  {_conoids[i]}";

            str += "└─────┴────────┴─────────┴────────┴─────────┴───────┘";
            return str;
        } // ToString

    } // class ArrayConoid
}
