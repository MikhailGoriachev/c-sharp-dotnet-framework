﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_4
{
    class Conoid{

        public Conoid(double rtop, double rdown, double height) {
            _rTop = rtop;
            _rDown = rdown;
            _height = height;
        } // Conoid
        public Conoid() : this(1d, 2d, 1d) { }

        private double _rTop;
        public double rTop{
            get => _rTop;
            set => _rTop = value > 0 ? value : _rTop;
        } // rTop

        private double _rDown;
        public double rDown{
            get => _rDown; 
            set => _rDown = value > 0 ? value : _rDown;
        } // rDown

        private double _height;
        public double Height{
            get => _height;
            set => _height = value > 0 ? value : _height; 
        } // Height

        public double Volume => 1d / 3d * _height * Math.PI * (_rDown * _rDown + _rDown * _rTop + _rTop * _rTop);
        public double Area => Math.PI * (_rTop + _rDown) * Math.Sqrt(_height * _height + Math.Pow((_rDown - _rTop), 2));

        public override string ToString()=>$"│   {_rDown:n1}  │   {_rTop:n1}   │  {_height:n1}   │  {Volume:n1}   │ {Area:n1}  │\n";

        public static int CompareByVolume(Conoid c1, Conoid c2) => c1.Volume.CompareTo(c2.Volume);
        public static int CompareByHeight(Conoid c1, Conoid c2) => c2._height.CompareTo(c1._height);

    } // class Conoid
}
