﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_4
{
    class Person{
        public Person(string name, int age, int height, double weight, string city){
            _name = name;
            _age = age;
            _height = height;
            _weight = weight;
            _city = city;
        } // Conoid
        public Person() { }

        private string _name;
        public string Name{
            get => _name;
            set => _name = value;
        } // Name

        private int _age;
        public int Age{
            get => _age;
            set => _age = value > 0 ? value : _age;
        } // Age

        private int _height;
        public int Height{
            get => _height;
            set => _height = value > 130 ? value : _height;
        } // Height

        private double _weight;
        public double Weight{
            get => _weight;
            set => _weight = value > 30 ? value : _weight;
        } // Weight

        private string _city;
        public string City{
            get => _city;
            set => _city = value;
        } // City
        public override string ToString() => $"│   {_name}  │   {_age}   │  {_height}   │  {_weight:n1}  │  {_city,8} │\n";

        public static int CompareByCity(Person p1, Person p2) => p1._city.CompareTo(p2._city);
        public static int CompareByWeight(Person p1, Person p2) => p2._weight.CompareTo(p1._weight);
        public static int CompareByHeight(Person p1, Person p2) => p1._height.CompareTo(p2._height);

    } // class Person
}
