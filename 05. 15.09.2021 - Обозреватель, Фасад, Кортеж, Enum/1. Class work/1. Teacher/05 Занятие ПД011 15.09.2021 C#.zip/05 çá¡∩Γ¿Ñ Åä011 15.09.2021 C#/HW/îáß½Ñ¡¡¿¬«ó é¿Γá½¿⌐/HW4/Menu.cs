﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4
{
	class Menu
	{
		public static class Palette
		{
			public static (ConsoleColor Foreground, ConsoleColor Background) OrdinaryColors { get; set; }
				= (ConsoleColor.Green, ConsoleColor.Black);

			public static (ConsoleColor Foreground, ConsoleColor Background) HighlitedColors { get; set; }
				= (ConsoleColor.Black, ConsoleColor.Green);
		}

		public class MenuItem
		{
			public Action Callback { get; set; }
			public string  Text    { get; set; }

		}

		private Point MenuPosition { get; set; }
		private MenuItem[] Items   { get; set; }
		private string Title       { get; set; }

		private int _maxLength;
		private int _current;
		private int _previous;
		private int _nItems;

		public Menu(MenuItem[] items, Point menuPosition, string title)
		{
			Items = items;
			MenuPosition = menuPosition;
			_previous = 1;
			_current = 1;
			_nItems = Items.Length;
			_maxLength = Items.Max(x => x.Text.Length);
			Title = title;
		}


		public void Run()
		{
			Console.Clear();
			Console.SetCursorPosition(MenuPosition.X, MenuPosition.Y);
			Console.CursorVisible = false;
			ShowMenu();
			ChangeSelection(_previous, _current);

			ConsoleKeyInfo key;
			do
			{
				// Ожидание нажатия клавиши
				while (true)
				{
					if (Console.KeyAvailable)
					{
						key = Console.ReadKey();
						break;
					}
				}

				switch (key.Key)
				{
					case ConsoleKey.UpArrow:
						_previous = _current;
						_current = _current > 1 ? --_current : _nItems;
						ChangeSelection(_previous, _current);
						break;
					case ConsoleKey.DownArrow:
						_previous = _current;
						_current = _current < _nItems ? ++_current : 1;
						ChangeSelection(_previous, _current);
						break;
					case ConsoleKey.Enter:
						if (_current == _nItems)
						{
							_current = 0;
							break;
						}
						Console.Clear();
						try
						{
							Items[_current - 1].Callback();
						}
						catch (Exception ex)
						{
							Console.WriteLine($"\n\n\n{ex}\n\n");
						}

						Console.ReadKey();

						Console.Clear();
						ShowMenu();
						ChangeSelection(_previous, _current);
						break;

					case ConsoleKey.Escape:
						_current = 0;
						break;
				}
			} while (_current != 0);
			Console.Clear();

		}

		// Вывод меню
		public void ShowMenu()
		{
			ConsoleColor curColorB = Console.BackgroundColor;
			ConsoleColor curColorF = Console.ForegroundColor;

			Console.ForegroundColor = Palette.OrdinaryColors.Foreground;
			Console.BackgroundColor = Palette.OrdinaryColors.Background;
			Console.SetCursorPosition(MenuPosition.X, MenuPosition.Y);

			Console.Write($"{Title}\n\n");

			foreach (var menuItem in Items)
			{
				Console.SetCursorPosition(MenuPosition.X, Console.CursorTop);
				Console.WriteLine($"{menuItem.Text.PadRight(_maxLength)}");
			}

			Console.ForegroundColor = curColorF;
			Console.BackgroundColor = curColorB;

		}

		public void ChangeSelection(int prev, int cur)
		{
			ConsoleColor curColorB = Console.BackgroundColor;
			ConsoleColor curColorF = Console.ForegroundColor;

			Console.SetCursorPosition(MenuPosition.X, MenuPosition.Y + prev + 1);
			Console.ForegroundColor = Palette.OrdinaryColors.Foreground;
			Console.BackgroundColor = Palette.OrdinaryColors.Background;
			Console.Write($"{Items[prev - 1].Text.PadRight(_maxLength)}");

			Console.SetCursorPosition(MenuPosition.X, MenuPosition.Y + cur + 1);
			Console.ForegroundColor = Palette.HighlitedColors.Foreground;
			Console.BackgroundColor = Palette.HighlitedColors.Background;
			Console.Write($"{Items[cur - 1].Text.PadRight(_maxLength)}");

			Console.ForegroundColor = curColorF;
			Console.BackgroundColor = curColorB;
		}


	}
}
