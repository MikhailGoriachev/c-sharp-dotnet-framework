﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Runtime.InteropServices;
using HW4.TaskClasses;


namespace HW4
{
	// Класс приложения 
	class App
	{
		private ArrayConoids _conoids = null;
		public void Run()
		{
			Console.ForegroundColor = ConsoleColor.Green;
			Console.BackgroundColor = ConsoleColor.Black;

			Menu menu = new Menu(new[]
			{
				new Menu.MenuItem() {Text = "Генерация массива конусов", Callback = MenuItem1},
				new Menu.MenuItem() {Text = "Вывод коллекции в табличном виде", Callback = MenuItem2},
				new Menu.MenuItem() {Text = "Вывод коллекции в табличном виде с дополнительной информацией", Callback = MenuItem3},
				new Menu.MenuItem() {Text = "Сортировка массива конусов по возрастанию объемов", Callback = MenuItem4},
				new Menu.MenuItem() {Text = "Сортировка массива конусов по убыванию высот", Callback = MenuItem5},
				new Menu.MenuItem() {Text = "Выход"}
			}, new Point(5, 5),
				"Меню приложения");

			menu.Run();
		}

		// Генерация массива конусов
		private void MenuItem1()
		{
			Utilities.ShowNavBar("    Генерация массива конусов");
			_conoids = new ArrayConoids();
			_conoids.Generate("Массив конусов");

			Console.WriteLine("\n    Массив конусов созздан и заполнен случайными значениями.");
		}

		// Вывод коллекции в табличном виде
		private void MenuItem2()
		{
			Utilities.ShowNavBar("    Вывод коллекции в табличном виде");

			if (_conoids == null)
				throw new Exception("\n    Коллекция конусов не создана");

			Console.WriteLine(_conoids);
		}

		// Вывод коллекции в табличном виде с дополнительной информацией
		private void MenuItem3()
		{
			Utilities.ShowNavBar("    Вывод коллекции в табличном виде с дополнительной информацией");
			
			if (_conoids == null)
				throw new Exception("\n    Коллекция конусов не создана");

			_conoids.ShowExtendedTable(true);
		}

		// Сортировка массива конусов по возрастанию объемов
		private void MenuItem4()
		{
			Utilities.ShowNavBar("    Сортировка массива конусов по возрастанию объемов");

			if (_conoids == null)
				throw new Exception("\n    Коллекция конусов не создана");

			_conoids.SortVolumesAscend();

			_conoids.ShowExtendedTable();
		}

		// Сортировка массива конусов по убыванию высот
		private void MenuItem5()
		{
			Utilities.ShowNavBar("    Сортировка массива конусов по убыванию высот");

			if (_conoids == null)
				throw new Exception("\n    Коллекция конусов не создана");

			_conoids.SortHeightDescend();

			_conoids.ShowExtendedTable();
		}
		
	}
}
