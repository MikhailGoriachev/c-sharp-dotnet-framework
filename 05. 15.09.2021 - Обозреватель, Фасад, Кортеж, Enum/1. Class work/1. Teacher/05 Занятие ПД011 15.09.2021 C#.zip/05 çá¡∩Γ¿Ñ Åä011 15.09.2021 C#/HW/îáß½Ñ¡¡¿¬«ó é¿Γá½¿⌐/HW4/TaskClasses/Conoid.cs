﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4.TaskClasses
{
	/// <summary>
	/// Класс, описывающий геометрическую фигуру усеченный конус 
	/// </summary>
	internal class Conoid
	{
		// Верхнее основание
		private double _rTop; 
		public double RTop
		{
			get => _rTop;
			set {
				if (value <= 0) 
					throw new Exception($"Недопустимый радиус верхнего основания усеченного конуса: {value, 5:F3}");
				_rTop = value;
			}
		}

		// Нижнее основание
		private double _rBottom; 
		public double RBottom
		{
			get => _rBottom;
			set
			{
				if (value <= 0)
					throw new Exception($"Недопустимый радиус нижнего основания усеченного конуса: {value, 5:F3}");
				_rBottom = value;
			}
		}

		// Высота
		private double _height; 
		public double Height
		{
			get => _height;
			set
			{
				if (value <= 0)
					throw new Exception($"Недопустимая высота усеченного конуса: {value, 5:F3}");
				_height = value;
			}
		}

		// Полная площадь поверхности усеченного конуса
		// https://www-formula.ru/2011-09-21-04-35-14
		public double Area
		{
			get
			{
				double l = Math.Sqrt(RTop * RBottom + Math.Pow((RBottom - RTop), 2));
				return Math.PI * (l * RBottom + l * RTop + RBottom * RBottom + RTop * RTop);
			}
		}

		// Объем усеченного конуса
		// https://www-formula.ru/2011-09-21-10-55-40
		public double Volume => 1D / 3D * Math.PI * Height * (RBottom * RBottom + RBottom * RTop + RTop * RTop);

		// Вывод в строку по заданию
		public override string ToString() =>
		   $"r1 = {RTop, 5:F3}, r2 = {RBottom, 5:F3}, h: {Height, 5:F3}";

		// Выводит данные усеченного конуса в строку таблицы
		public string ToTableRow() => $"│ {RTop,15:F3} │ {RBottom,15:F3} │ {Height,9:F3} │ {Area, 5:F3} │ {Volume, 5:F3} │";

		public static int CompareByVolumeAscend(Conoid a, Conoid b) => a.Volume.CompareTo(b.Volume);
		public static int CompareByAreaDescend(Conoid a, Conoid b) => b.Area.CompareTo(a.Area);

		public static int CompareByHeightDescend(Conoid a, Conoid b) => b.Height.CompareTo(a.Height);


	}
}
