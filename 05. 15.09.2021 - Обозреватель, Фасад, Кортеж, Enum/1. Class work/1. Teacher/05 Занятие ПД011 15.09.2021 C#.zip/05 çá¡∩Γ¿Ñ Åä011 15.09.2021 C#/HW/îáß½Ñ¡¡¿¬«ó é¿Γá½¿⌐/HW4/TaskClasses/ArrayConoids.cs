﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4.TaskClasses
{
	// Класс, описывающий коллекцию конусов
	class ArrayConoids
	{
		// Количество элементов для создания
		public int NElements { get; set; } = 12;

		private double _lo = 1; // Нижняя граница для генерации значений
		private double _hi = 5; // Верхняя граница для генерации значений

		// Название коллекции
		private string _title;
		public string Title
		{
			get { return _title; }
			set { _title = value; }
		}

		private Conoid[] _conoids;

		public Conoid[] Conoids
		{
			get { return _conoids; }
			set { _conoids = value; }
		}

		// Генерация и заполнение объектов случайными значениями
		public void Generate(string title)
		{
			Conoids = new[]
			{
				new Conoid(),
				new Conoid(),
				new Conoid(),
				new Conoid(),
				new Conoid(),
				new Conoid(),
				new Conoid(),
				new Conoid(),
				new Conoid(),
				new Conoid(),
				new Conoid(),
				new Conoid()
			};

			foreach (var elem in Conoids)
			{
				elem.RBottom = Utilities.GenerateDouble(_lo, _hi);
				elem.RTop = Utilities.GenerateDouble(_lo, _hi);
				elem.Height = Utilities.GenerateDouble(_lo, _hi);
			}

			Title = title;
		}


		// Вычисление суммарного объема конусов 
		public double CountVolumes()
		{
			double volumesSum = 0;
			
			foreach (var elem in Conoids)
				volumesSum += elem.Volume;

			return volumesSum;
		}

		// Вычисление суммарной площади поверхности конусов
		public double CountAreas()
		{
			double areaSum = 0;

			foreach (var elem in Conoids)
				areaSum += elem.Area;

			return areaSum;
		}

		// Вычисление значения конуса с максимальным объемом
		public double MaxVolume()
		{
			double maxVolume = _conoids[0].Volume;
			foreach (var elem in _conoids)
			{
				var elemVolume = elem.Volume;
				maxVolume = (elemVolume - maxVolume) > double.Epsilon ? elemVolume : maxVolume ;
			}

			return maxVolume;
		}

		// Вычисление значения конуса с максимальной площадью
		public double MaxArea()
		{
			double maxArea = _conoids[0].Area;
			foreach (var elem in _conoids)
			{
				var elemArea = elem.Area;
				maxArea = (elemArea - maxArea) > double.Epsilon ? elemArea : maxArea;
			}

			return maxArea;
		}


		// Вывод названия коллекции и массива конусов в консоль, в табличном виде
		public override string ToString()
		{
			string info = "\n    " + Title + ":\n\n" +
						  "    ┌────┬─────────────────┬─────────────────┬───────────┐\n" +
			              "    │  N | Верх. радиус, r | Нижн. радиус, R | Высота, H |\n" +
						  "    ├────┼─────────────────┼─────────────────┼───────────┤\n" ;

			int n = 1;
			foreach (var elem in Conoids)
				info += $"    │ {n++, 2} │ {elem.RTop, 15:f3} │ {elem.RBottom, 15:f3} │ {elem.Height, 9:f3} │\n";

			info += "    └────┴─────────────────┴─────────────────┴───────────┘\n\n";
			return info;
		}

		/*
		 * вывод названия коллекции и массива в консоль в табличном виде:
		 * радиусы и высота усеченного конуса, площадь и объем с выделением цветом конуса/конусов
		 * с максимальной площадью, также выводить итоговую информацию – суммарный объем конусов,
		 * суммарную площадь поверхности конусов
		 */
		public void ShowExtendedTable(bool highlightMax = false)
		{
			Console.Write("\n    " + Title + ":\n\n" +
			                  "    ┌────┬─────────────────┬─────────────────┬───────────┬────────────┬──────────┐\n" +
			                  "    │  N | Верх. радиус, r | Нижн. радиус, R | Высота, H | Площадь, S | Объем, V |\n" +
			                  "    ├────┼─────────────────┼─────────────────┼───────────┼────────────┼──────────┤\n");

			int n = 1;

			var maxArea = MaxArea();
			var maxVolume = MaxVolume();

			foreach (var elem in Conoids)
			{
				Console.Write($"    │ {n++,2} │ {elem.RTop,15:f3} │ {elem.RBottom,15:f3} │ {elem.Height,9:f3} │");
				if(highlightMax)
					Console.ForegroundColor = elem.Area == maxArea ? ConsoleColor.Red : ConsoleColor.Green;
				Console.Write($" {elem.Area, 10:f3} │");
				if (highlightMax)
					Console.ForegroundColor = elem.Volume == maxVolume ? ConsoleColor.Red : ConsoleColor.Green;
				Console.Write($" {elem.Volume, 8:f3} │\n");
				if (highlightMax)
					Console.ForegroundColor = ConsoleColor.Green;
			}

			Console.WriteLine("    └────┴─────────────────┴─────────────────┴───────────┴────────────┴──────────┘\n\n");
		}


		// Cортировка массива конусов по возрастанию объемов
		public void SortVolumesAscend()
		{
			Array.Sort(_conoids, Conoid.CompareByVolumeAscend);
		}

		// Cортировка массива конусов по убыванию высот
		public void SortHeightDescend()
		{
			Array.Sort(_conoids, Conoid.CompareByHeightDescend);
		}


	}
}
