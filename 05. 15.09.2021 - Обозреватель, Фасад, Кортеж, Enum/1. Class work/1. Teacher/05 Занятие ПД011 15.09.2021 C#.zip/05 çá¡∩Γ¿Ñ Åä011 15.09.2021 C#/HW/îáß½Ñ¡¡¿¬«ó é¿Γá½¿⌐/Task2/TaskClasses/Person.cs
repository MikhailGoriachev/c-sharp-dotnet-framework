﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2.TaskClasses
{
	/// <summary>
	/// Класс, описывающий персону
	/// </summary>
	class Person
	{
		#region Поля и свойства
		/// <summary>
		/// Фамилия и инициалы
		/// </summary>
		private string _name;

		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}

		/// <summary>
		/// Возраст в полных годах
		/// </summary>
		private int _age;

		public int Age
		{
			get { return _age; }
			set { _age = value; }
		}

		/// <summary>
		/// Рост в сантиметрах
		/// </summary>
		private int _height;

		public int Height
		{
			get { return _height; }
			set { _height = value; }
		}

		/// <summary>
		/// Вес в кг
		/// </summary>
		private double _weight;

		public double Weight
		{
			get { return _weight; }
			set { _weight = value; }
		}

		/// <summary>
		/// Название города проживания
		/// </summary>
		private string _city;

		public string City
		{
			get { return _city; }
			set { _city = value; }
		}
		#endregion


		public override string ToString() =>
			$"ФИО: {Name}, Возраст: {Age}, Рост: {Height}, Вес: {Weight, 3:f1}, Город: {City}";

		public static int CompareByCity(Person a, Person b) => a.City.CompareTo(b.City);
		public static int CompareByWeightDescend(Person a, Person b) => b.Weight.CompareTo(a.Weight);
		public static int CompareByHeight(Person a, Person b) => a.Height.CompareTo(b.Height);




	}
}
