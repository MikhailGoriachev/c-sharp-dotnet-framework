﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Runtime.InteropServices;
using Task2.TaskClasses;


namespace Task2
{
	// Класс приложения 
	class App
	{
		private Person[] _persons = new[]
		{
			new Person(){ Name = "Фамилия И.О.1", Age = 25, Height = 183, Weight = 85.6, City = "Донецк"},
			new Person(){ Name = "Фамилия И.О.2", Age = 36, Height = 169, Weight = 76.3, City = "Луганск"},
			new Person(){ Name = "Фамилия И.О.3", Age = 21, Height = 181, Weight = 97.5, City = "Макеевка"},
			new Person(){ Name = "Фамилия И.О.4", Age = 42, Height = 173, Weight = 67.4, City = "Амвросиевка"},
			new Person(){ Name = "Фамилия И.О.5", Age = 34, Height = 178, Weight = 77.5, City = "Горловка"},
			new Person(){ Name = "Фамилия И.О.6", Age = 27, Height = 165, Weight = 84.3, City = "Дебальцево"},
			new Person(){ Name = "Фамилия И.О.7", Age = 28, Height = 174, Weight = 66.4, City = "Докучаевск"},
			new Person(){ Name = "Фамилия И.О.8", Age = 29, Height = 183, Weight = 97.9, City = "Енакиево"},
			new Person(){ Name = "Фамилия И.О.9", Age = 31, Height = 171, Weight = 71.2, City = "Ждановка"},
			new Person(){ Name = "Фамилия И.О.10", Age = 53, Height = 177, Weight = 85.1, City = "Зугрэс"},
			new Person(){ Name = "Фамилия И.О.11", Age = 21, Height = 168, Weight = 66.6, City = "Снежное"},
			new Person(){ Name = "Фамилия И.О.12", Age = 50, Height = 179, Weight = 101.2, City = "Торез"}
		};
		public void Run()
		{
			Console.ForegroundColor = ConsoleColor.Green;
			Console.BackgroundColor = ConsoleColor.Black;
			
			Menu menu = new Menu(new[]
			{
				new Menu.MenuItem() {Text = "Вывод массив персон в консоль", Callback = MenuItem1},
				new Menu.MenuItem() {Text = "Вывод в консоль персону/персон с максимальным ростом", Callback = MenuItem2},
				new Menu.MenuItem() {Text = "Вывод в консоль персону/персон с минимальным возрастом", Callback = MenuItem3},
				new Menu.MenuItem() {Text = "Упорядочить массив по городу проживания и вывести в консоль", Callback = MenuItem4},
				new Menu.MenuItem() {Text = "Упорядочить массив по убыванию веса и вывести в консоль", Callback = MenuItem5},
				new Menu.MenuItem() {Text = "Упорядочить массив по возрастанию роста и вывести в консоль", Callback = MenuItem6},
				new Menu.MenuItem() {Text = "Выход"}
			}, new Point(5, 5),
				"Меню приложения");

			menu.Run();
		}

		// Вывести массив персон в консоль
		private void MenuItem1()
		{
			Utilities.ShowNavBar("    Вывод массива персон в консоль");
			Console.WriteLine("\n    Массив персон:\n\n");

			ShowPersons();
		}

		// Вывести в консоль персону/персон с максимальным ростом.
		private void MenuItem2()
		{
			Utilities.ShowNavBar("    Вывод в консоль персону/персон с максимальным ростом");

			Console.WriteLine("\n\n    Персона/персоны с максимальным ростом:\n");
			ShowPersonsMaxHeight();
			
		}

		// Вывести в консоль персону/персон с минимальным возрастом. 
		private void MenuItem3()
		{
			Utilities.ShowNavBar("    Вывод в консоль персону/персон с минимальным возрастом");

			Console.WriteLine("\n\n    Персона/персоны с минимальным возрастом:\n");
			ShowPersonsMinAge();

		}

		// Упорядочить массив по городу проживания и вывести в консоль
		private void MenuItem4()
		{
			Utilities.ShowNavBar("    Упорядочить массив по городу проживания и вывести в консоль");

			Console.WriteLine("\n\n    Массив, упорядоченный по городу проживания:\n");

			SortByCity(ref _persons);

			ShowPersons();

		}

		// Упорядочить массив по убыванию веса и вывести в консоль
		private void MenuItem5()
		{
			Utilities.ShowNavBar("    Упорядочить массив по убыванию веса и вывести в консоль");

			Console.WriteLine("\n\n    Массив, упорядоченный по убыванию веса:\n");

			SortByWeightDescend(ref _persons);

			ShowPersons();
		}

		// Упорядочить массив по возрастанию роста и вывести в консоль
		private void MenuItem6()
		{
			Utilities.ShowNavBar("    Упорядочить массив по возрастанию роста и вывести в консоль");

			Console.WriteLine("\n\n    Массив, упорядоченный по возрастанию роста:\n");

			SortByHeight(ref _persons);

			ShowPersons();

		}

		private void ShowPersons()
		{
			foreach (var elem in _persons)
				Console.WriteLine($"    {elem}");
		}

		private void ShowPersonsMaxHeight()
		{
			int max = MaxHeight();
			foreach (var elem in _persons)
			{
				if(elem.Height == max)
					Console.WriteLine($"    {elem}");
			}
		}

		private void ShowPersonsMinAge()
		{
			int min = MinAge();
			foreach (var elem in _persons)
			{
				if (elem.Age == min)
					Console.WriteLine($"    {elem}");
			}
		}


		private int MaxHeight()
		{
			int max = _persons[0].Height;
			foreach (var elem in _persons)
			{
				var elemHeight = elem.Height;
				if (elemHeight > max) max = elem.Height;
			}

			return max;
		}

		private int MinAge()
		{
			int min = _persons[0].Age;
			foreach (var elem in _persons)
			{
				var elemAge = elem.Age;
				if (elemAge < min) min = elem.Age;
			}

			return min;
		}

		private void SortByCity(ref Person[] persons)
		{
			Array.Sort(persons, Person.CompareByCity);
		}

		private void SortByWeightDescend(ref Person[] persons)
		{
			Array.Sort(persons, Person.CompareByWeightDescend);
		}

		private void SortByHeight(ref Person[] persons)
		{
			Array.Sort(persons, Person.CompareByHeight);
		}
	}
}
