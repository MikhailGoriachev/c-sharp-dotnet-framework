﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConoidPerson
{
    class ArrayConoid
    {
        private Conoid[] _conoids; // массив конусов
        public Conoid[] Conoids
        {
            get => _conoids;

        }
        private string _title = "Массив конусов"; // название коллекции

        public Random rand = new Random();
        private double low = 5.1;
        private double high = 15.1; 

        public ArrayConoid(int size)
        {
            _conoids = new Conoid[size];
            for(int i =0; i<_conoids.Length;++i)
            {
                _conoids[i] = new Conoid();
            }

        }

        // заполнение случайными числами
        public void Fill ()
        {
            
            foreach(var item in _conoids)
            {
                item.Height = low + (high - low) * rand.NextDouble();
                item.RadiusLower = low + (high - low) * rand.NextDouble();
                item.RadiusUpper = low + (high - low) * rand.NextDouble();
                item.Generatrix = low + (high - low) * rand.NextDouble();
            }        
        }

        // вычисление сумарного объема конусов

        public double SumVolume ()
        {
            double sum = 0;

            foreach(var item in _conoids)
            {
                sum += item.Volume;
            }

            return sum;
        }

        //вычисление суммарной площади всех конусов

        public double SumSquare ()
        {
            double sum = 0;
            foreach(var item in _conoids)
            {
                sum += item.Square;
            }
            return sum; 

        }
        // вывод в табличном виде 

        public double MaxSquare()
        {
            double max = 0;

            for(int i =0; i< _conoids.Length; ++i)
            {
                double currentSquare = _conoids[i].Square;
                if (currentSquare> max )
                {
                    max = currentSquare;
                }
            } 
            return max; 
        }
        public void ShowTable (string line)
        {
            Console.WriteLine($"\n\n{_title} {line}");
            Conoid.ShowHeader();
            double maxSquare = MaxSquare();
            foreach(var item in _conoids)
            {
                if(item.Square == maxSquare) { Console.ForegroundColor = ConsoleColor.Red; } 
                item.ShowRow();
                Console.ForegroundColor = ConsoleColor.Gray; 
            }
            Conoid.ShowFooter();
            //Console.WriteLine($"\n Сумарный объем конусов : {SumVolume():n2}");
            //Console.WriteLine($"\n Сумарная площадь поверхностей конусов равна : {SumVolume():n2}");

        }

        public void SortByvolume()
        {
            Array.Sort(_conoids, Conoid.ComparatorVolume);
        }

        public void SortByHeight()
        {
            Array.Sort(_conoids, Conoid.ComparatorHeight);
        }

 

    }
}
