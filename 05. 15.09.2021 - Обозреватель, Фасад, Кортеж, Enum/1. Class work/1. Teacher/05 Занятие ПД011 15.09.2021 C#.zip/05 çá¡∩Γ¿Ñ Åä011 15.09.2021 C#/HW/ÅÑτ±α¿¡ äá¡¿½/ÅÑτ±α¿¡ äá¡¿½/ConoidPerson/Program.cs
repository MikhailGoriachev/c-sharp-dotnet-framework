﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConoidPerson
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 15.09.2021 - работа с классами";
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.CursorVisible = false; 

            while(true)
            {
                Console.Clear();
                ShowNavBar();
                ShowTask();

                //получить код клавиши
                ConsoleKey key = Console.ReadKey(true).Key;

                switch(key)
                {
                    // решение задачи 1 назначено на клавишу F5
                    case ConsoleKey.F5:
                        App.Task1();
                        break;

                    //решение задачи 2 назначение на клавишу F6
                    case ConsoleKey.F6:
                        App.Task2();
                        break;

                }

            }// while

            
        }// Main

        private static void ShowNavBar()
        {
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // выводим текст   в верхнюю строку
            WriteXY(2, 0, "F5", ConsoleColor.Red);
            WriteXY(5, 0, "Задача1", ConsoleColor.Black);

            WriteXY(16, 0, "F6", ConsoleColor.Red);
            WriteXY(19, 0, "Задача 2", ConsoleColor.Black);

          
            //восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        }

        static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текцщий цвет консоли и установить заданнный 
            ConsoleColor oldcolor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            //восстановить цвет консоли
            Console.ForegroundColor = oldcolor;
        }

        private static void ShowTask()
        {
            string text = @"Задача 1.  
            Создайте класс, описывающий усеченный конус Conoid (радиус верхнего основания, 
            радиус нижнего основания, высота – тип полей double).Реализуйте полные свойства, 
            вычисляемые свойства для площади и объема усеченного конуса, метод формирующий 
            строковое представление конуса (ToString(), выводить только радиус и высоту), 
            метод формирующий строку таблицы со сведениями о конусе (радиус, высота, площадь 
            поверхности, объем). Разработайте компараторы для сортировки по возрастанию объемов, 
            для сортировки по убыванию высот. 

            Создайте класс ArrayConoid, хранящий массив из усеченных конусов – 
            объектов класса Conoid и название коллекции конусов. 
            Реализуйте методы класса ArrayConoid:
            •	заполнение массива данными конусов (не менее 12 элементов, используйте генератор случайных чисел, вводить с клавиатуры ничего не надо)
            •	вычисления суммарного объема конусов 
            •	вычисления суммарной площади поверхности конусов
            •	вывод названия коллекции и массива конусов в консоль, в табличном виде
            •	вывод названия коллекции и массива в консоль в табличном виде: радиусы и высота усеченного конуса, 
                площадь и объем с 
            выделением цветом конуса/конусов с максимальной площадью, также выводить итоговую 
            информацию – суммарный объем конусов, суммарную площадь поверхности конусов
            •	сортировка массива конусов по возрастанию объемов
            •	сортировка массива конусов по убыванию высот

           Продемонстрируйте работу методов ArrayConoid, напоминаю  – в массиве должно быть не менее 12 конусов.  

           Задача 2. Разработайте класс Персона со следующими полными свойствами: 

           •	фамилия и инициалы имени и отчества (например, Семенов Р.О.) 
           •	возраст в полных годах (целое число)
           •	рост в сантиметрах (целое число)
           •	вес в кг (вещественное число)
           •	название города проживания (строка)


          Заполнить массив данными для не менее чем 12 персон. 
          Рекомендую для наработки навыков кодирования не генерировать объекты массива, 
          а создавать с использованием свойств. Для массива персон выполнить следующие обработки:
          •	Вывести массив персон в консоль.
          •	Вывести в консоль персону/персон с максимальным ростом.
          •	Вывести в консоль персону/персон с минимальным возрастом. 
          •	Разработайте методы-компараторы для упорядочивания массива. Упорядочить массив и вывести его в консоль. Упорядочивать по:
         o	по городу проживания
         o	по убыванию веса
         o	по возрастанию роста";
            WriteXY(0, 2, text, ConsoleColor.Gray);
        }

        public static void ShowNavTask1()
        {
            //сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            //Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 1", ConsoleColor.Red);
            WriteXY(11, 0, "Конус. Массив конусов", ConsoleColor.Black);

            //восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        }

        public static void ShowNavTask2()
        {
            //сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            //Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 2", ConsoleColor.Red);
            WriteXY(11, 0, "Персона. Массив персон", ConsoleColor.Black);

            //восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        }







    }// Program
}
