﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConoidPerson
{
    /*Создайте класс, описывающий усеченный конус Conoid 
     * (радиус верхнего основания, радиус нижнего основания, 
     * высота – тип полей double). Реализуйте полные свойства, 
     * вычисляемые свойства для площади и объема усеченного конуса, 
     * метод формирующий строковое представление конуса (ToString(), 
     * выводить только радиус и высоту), метод формирующий строку 
     * таблицы со сведениями о конусе (радиус, высота, площадь 
     * поверхности, объем). Разработайте компараторы для сортировки 
     * по возрастанию объемов, для сортировки по убыванию высот. */
    class Conoid
    {
        // полные свойства полей
        private double _rUpper; // радиус верхнего основания
        
        public double RadiusUpper
        {
            get => _rUpper;
            set => _rUpper = value <= 0 ? 0 : value;
        }

        private double _rLower; // радиус нижнего основания

        public double RadiusLower
        {
            get => _rLower; 
            set => _rLower = value <=0? 0:value; 
        }

        private double _generatrix; // образующая

        public double Generatrix
        {
            get=> _generatrix;
            set => _generatrix = value <= 0 ? 0 : value;
        }

        private double _height; // высота

        public double Height
        {
            get => _height;
            set => _height = value < 0 ? 0 : value;
        }


        // вычисляемые свойста: площадь полной поверхности конуса
        public double Square { get { return Math.PI *(Generatrix*_rUpper + Generatrix*_rLower
                     + Math.Pow(_rUpper,2)+ Math.Pow(_rLower, 2)); } } 
        // объем усеченного конуса
        public double Volume { get { return 1d/3d*Math.PI*_height*(Math.Pow(_rUpper,2)+ _rUpper*_rLower
                    +Math.Pow(_rLower,2)); } }

        public override string ToString() =>
            $"Радиус Верхнего основание: {_rUpper}, Радиус нижнего основание: {_rLower}, Высота: {_height}";

        public static void ShowHeader()
        {
            Console.WriteLine("\n\n      __________________________________________________________________________________");
            Console.WriteLine("     | Радиус в. основания | Радиус н. основания | Высота  |Площадь      | Объем       | ");
            Console.WriteLine("     |---------------------|---------------------|---------|-------------|-------------| ");
            
        }

        public static void ShowFooter()
        {
            Console.WriteLine("     |---------------------|---------------------|---------|-------------|-------------|");
        }

        public void ShowRow()
        {

            Console.WriteLine($"     | {_rUpper, 18:n2}  | {_rLower, 19:n2} | {_height, 8:n2}|{Square, 12:n2} | {Volume, 10:n2}  |");
            
            
        }

        // компаратор по возрастанию объема 
        public static int ComparatorVolume(Conoid x, Conoid y) => y.Volume.CompareTo(x.Volume);


        // компаратор по убыванию высот
        public static int ComparatorHeight(Conoid x, Conoid y) => x._height.CompareTo(y._height);



    }
}
