﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConoidPerson
{
    class App
    {
        public static void Task1()
        {
            Console.Clear();
            Program.ShowNavTask1();

            //заполнение массива конусов случайными значениями
            ArrayConoid arr = new ArrayConoid(12);
            arr.Fill();

            arr.ShowTable(" Конус с максимальной площадью выделен красным");
            Console.WriteLine($"\n Сумарный объем конусов : {arr.SumVolume():n2}");
            Console.WriteLine($"\n Сумарная площадь поверхностей конусов равна : {arr.SumVolume():n2}");
            

            // сортировка по возрастанию объема
            Array.Sort(arr.Conoids, Conoid.ComparatorHeight);
            arr.ShowTable(" упорядочен по возрастанию объема");
            

            // сортировка по убыванию высот
            Array.Sort(arr.Conoids, Conoid.ComparatorVolume);
            arr.ShowTable(" упорядочен по убыванию высот");
            

            Console.ReadKey();


        }

        public static void Task2()
        {
            Console.Clear();
            Program.ShowNavTask2();

            Person[] persons =
            {
                new Person{Name= "Иванов И.И", Age = 20, Height = 167, Weight = 67, City = "Макеевка"},
                new Person {Name ="Петров В.А.", Age = 25, Height = 170, Weight = 70, City ="Донецк" },
                new Person{Name = "Сидоров С.А.", Age = 30, Height = 155, Weight = 80, City = "Харцызск"}, 
                new Person{Name = "Параманов С.А.", Age = 35, Height = 178, Weight = 83, City = "Москва" }, 
                new Person{Name = "Кострова А.В.", Age = 45, Height = 160, Weight = 47, City = "Курск"},
                new Person{Name = "Янаева М.А.", Age =  65, Height = 189, Weight = 50, City = "Таганрог"},
                new Person{Name = "Митюков В.К.", Age = 74, Height = 191, Weight = 69, City ="Волгоград"},
                new Person{Name = "Васильев К.Н", Age = 38, Height = 159, Weight = 74, City = "Новосибирск"},
                new Person{Name = "Васильев К.И", Age = 56, Height = 173, Weight = 84, City = "Мурманск"},
                new Person{Name = "Николаев И.Н", Age = 73, Height = 169, Weight = 68, City = "Волоколамск"},
                new Person{Name = "Пронин Н.Н", Age = 81, Height = 172, Weight = 56, City = "Пенза"},
                new Person{Name = "Болдунов В.Н", Age = 73, Height = 177, Weight = 59, City = "Рязань"},
            };

            Console.WriteLine("\n\n Массив объектов класса Person");
            Array.ForEach(persons, Console.WriteLine);

            // нахождение максимального роста в массиве персон
            int maxHeight = Person.MaxHeight(persons);

            Console.WriteLine($"\n Максимальный рост равен : {maxHeight}");

            // нахождение минимального возраста в массиве персон
            int minage = Person.MinAge(persons);

            Console.WriteLine($"\n Минимальный возраст равен : {minage}");

            // сортировка по городу проживания 
            Array.Sort(persons, Person.ComparotorByCity);
            Console.WriteLine("\n\n Массив упорядочен по городу проживания\n");
            Array.ForEach(persons, Console.WriteLine);

            // сортировка по убыванию веса 
            Array.Sort(persons, Person.ComparatorByWeight);
            Console.WriteLine("\n\n Массив упорядочен по убыванию веса\n");
            Array.ForEach(persons, Console.WriteLine);

            // сортировака по возрастанию роста
            Array.Sort(persons, Person.ComparatorByHeight);
            Console.WriteLine("\n\n Массив упорядочен по возрастанию роста\n");
            Array.ForEach(persons, Console.WriteLine);


            Console.ReadKey();
        }


    }
}
