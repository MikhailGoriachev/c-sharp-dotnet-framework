﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConoidPerson
{
    class Person
    {
        private string _name;

        public string Name  // имя 
        {
            get { return _name; }
            set { _name = value; }
        }

        private int _age;  // возраст

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

        private int _height; // рост в самнтиметрах

        public int Height
        {
            get { return _height; }
            set { _height = value; }
        }

        private double _weight;

        public double Weight  // вес

        {
            get { return _weight; }
            set { _weight = value; }
        }

        private string _city;

        public string City   // город прожиания 
        {
            get { return _city; }
            set { _city = value; }
        }

        public override string ToString() =>
            $" Фамилия : {Name, 15}, Возраст : {Age, 5}, Рост : {Height, 5}, Вес : {Weight, 5}, Город :{City, 15}";

        public static int MaxHeight (Person[] arr)
        {
            
            int max = 0;
            for(int i = 0; i< arr.Length; ++i)
            {
               int height = arr[i].Height;
                if(height > max)
                {
                    max = height;
                }
            }


            return max; 
        }

        public static int MinAge (Person[] arr)
        {
            int minage = int.MaxValue;
            for(int i =0; i< arr.Length; ++i)
            {
                int age = arr[i].Age;
                if(age < minage)
                {
                    minage = age;
                }

            }

            return minage;
        }

        // комаратора для сортировки по городу
        public static int ComparotorByCity(Person x, Person y) => x.City.CompareTo(y.Name);

        // компаратор для сортировки по убыванию веса 
        public static int ComparatorByWeight(Person x, Person y) => y.Weight.CompareTo(x.Weight);

        // компаратор для сортировки по возрастанию роста
        public static int ComparatorByHeight(Person x, Person y) => x.Height.CompareTo(y.Height);
           
        

    }
}
