﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W4C_
{
    class Program
    {
        static void Main(string[] args)
        {
            // Настройка консоли 
            Console.Title = "Домашнее задание № 4";
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.CursorVisible = false;

            Console.Clear();
            Console.WriteLine("    Выберите пункт меню:\n");
            Console.WriteLine("    F5.Задача 1. Класс ArrayConoid");
            Console.WriteLine("    F6.Задача 2. Класс Persona");
            Console.WriteLine("    Esc. Выход");

            ConsoleKey key = Console.ReadKey(true).Key;
            switch (key)
            {
                case ConsoleKey.Escape:
                    Environment.Exit(0);
                    break;
                case ConsoleKey.F5:
                    App.Task_1();
                    break;
                case ConsoleKey.F6:
                    App.Task_2();
                    break;

            }// switch

        }// Main

        class App
        {
            #region Решение Задачи 1 Класс Conoid
            public static void Task_1()
            {
                ArrayConoid arraycone = new ArrayConoid();
                Conoid[] conoid1 = new[]
                {
                    new Conoid(2d, 4d, 6d),
                    new Conoid(3d, 5d, 8d),
                    new Conoid(1d, 3d, 9d),
                    new Conoid(7d, 4d, 10d),
                    new Conoid(3d, 5d, 12d),
                    new Conoid(4d, 6d, 7d),
                };

                Console.WriteLine("\n Максимальная площадь конуса выделена цветом: ");
                ShowMaxArea(conoid1);


                Console.WriteLine($" Суммарный объём конусов :    {TotalVolume(conoid1) }\n" +
                    $" Суммарная площадь конусов :  {TotalArea(conoid1) }");

                // сортировка массива объектов при помощи компаратора
                Array.Sort(conoid1, ComparatorConoid);

                Console.WriteLine("\n Усечённые конусы отсортированы по возрастанию объемов:");
                Show();
                Array.ForEach(conoid1, Console.WriteLine);
                Console.WriteLine($"  └─────────┴────────┴─────────┴─────────┘\n\n ");

                // сортировка массива объектов при помощи компаратора
                Array.Sort(conoid1, ComparatorHight);

                Console.WriteLine("\n Усечённые конусы отсортированы по убыванию высот:");
                Show();
                Array.ForEach(conoid1, Console.WriteLine);
                Console.WriteLine($"  └─────────┴────────┴─────────┴─────────┘\n\n ");

               Console.Write("\n\n\nНажмите любую клавишу для продолжения...");
               Console.ReadKey(false);
            }// Task_1
            #endregion

            #region Решение Задачи 2 Класс Persona
            public static void Task_2()
            {
                Persona[] persons = {
                new Persona {FullName = "Михалков Б.Д.", Age = 34, Drowsh = 168, Weight = 55, City = "Нью-Йорк"},
                new Persona {FullName = "Турчин М.С.", Age = 42, Drowsh = 180, Weight = 105, City = "Донецк"},
                new Persona {FullName = "Головко Р.Д.", Age = 54, Drowsh = 165, Weight = 80, City = "Макеевка"},
                new Persona {FullName = "Лютий Б.Л.", Age = 22, Drowsh = 168, Weight = 92, City = "Харцызск"},
                new Persona {FullName = "Кудряшов П.Д.", Age = 60, Drowsh = 185, Weight = 75, City = "Москва"},
                new Persona {FullName = "Дудник Б.О.", Age = 38, Drowsh = 190, Weight = 104, City = "Париж"},
                new Persona {FullName = "Мельник С.Ю.", Age = 32, Drowsh = 184, Weight = 95, City = "Донецк"},
                new Persona {FullName = "Заяц С.Р.", Age = 70, Drowsh = 165, Weight = 80, City = "Ростов"},

            };

                Console.WriteLine("\n\nМассив объектов класса Person:");
                ShowPerson();
                Array.ForEach(persons, Console.WriteLine);
                Console.WriteLine($"  └───────────────┴─────────┴──────┴────────┴──────────┘\n ");

                Console.WriteLine("\nПерсона с максимальным ростом :");
                ShowPerson();
                ShowMaxDrowsh(persons);
                

                Console.WriteLine("\n\nПерсона с минимальным возрастом :");
                ShowPerson();
                ShowMinAge(persons);

                Array.Sort(persons, Persona.CompareByCity);

                
                Console.WriteLine("\nУпорядоченный массив объектов класса Persona по городу проживания:");
                ShowPerson();
                Array.ForEach(persons, Console.WriteLine);
                Console.WriteLine($"  └───────────────┴─────────┴──────┴────────┴──────────┘\n ");

                Array.Sort(persons, Persona.CompareByWeight);

                
                Console.WriteLine("\nУпорядоченный массив объектов класса Persona по убыванию веса:");
                ShowPerson();
                Array.ForEach(persons, Console.WriteLine);
                Console.WriteLine($"  └───────────────┴─────────┴──────┴────────┴──────────┘\n ");


                Array.Sort(persons, Persona.CompareByDrowsh);

                
                Console.WriteLine("\nУпорядоченный массив объектов класса Persona по возрастанию роста:");
                ShowPerson();
                Array.ForEach(persons, Console.WriteLine);
                Console.WriteLine($"  └───────────────┴─────────┴──────┴────────┴──────────┘\n ");


            }// Task_2
            #endregion

            #region  Вспомагательные методы
            // индекс персоны с максимальным ростом.
            private static int MaxDrowsh(Persona[] persona)
            {
                int Imax = 0;
                for (int i = 1; i < persona.Length; i++)
                {
                    if (persona[i].Drowsh > persona[Imax].Drowsh)
                        Imax = i;
                }// for i

                return Imax;
            }// MaxDrowsh 

            // индекс персоны с минимальным возрастом
            private static int MinAge(Persona[] persona)
            {
                int Imin = 0;
                for (int i = 0; i < persona.Length; i++)
                {
                    if (persona[i].Age < persona[Imin].Age)
                        Imin = i;
                }// for i
                return Imin;
            }// MinAge

            private static void ShowMaxDrowsh(Persona[] persona)
            {
                for (int i = 0; i < persona.Length; i++)
                {
                    if (persona[i].Drowsh == persona[MaxDrowsh(persona)].Drowsh)
                        Console.ForegroundColor = ConsoleColor.Red;
                    else Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{persona[i]}\n");
                }// for i
                Console.ForegroundColor = ConsoleColor.White;
            }// ShowMaxDrowsh

            private static void ShowMinAge(Persona[] persona)
            {
                for (int i = 0; i < persona.Length; i++)
                {
                    if (persona[i].Age == persona[MinAge(persona)].Age)
                        Console.ForegroundColor = ConsoleColor.Red;
                    else Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{persona[i]}\n");
                }// for i
                Console.ForegroundColor = ConsoleColor.White;
            }// ShowMaxDrowsh

            private static void ShowPerson()
            {    
                Console.WriteLine($"\n" +
                                  $"  ┌───────────────┬─────────┬──────┬────────┬──────────┐\n" +
                                   "  │ Фамилия И.О.  | Возраст | Рост |  Вес   |   Город  |\n" +
                                   "  ├───────────────┼─────────┼──────┼────────┼──────────┤");
            }// ShowPerson

            // вывод конусов
            private static void Show()
            {
                ArrayConoid name = new ArrayConoid();
                Console.WriteLine($"\n\n {name}\n" +
                                  $"  ┌─────────┬────────┬─────────┬─────────┐\n" +
                                   "  │ Радиус  | Высота | Площадь |  Объём  |\n" +
                                   "  ├─────────┼────────┼─────────┼─────────┤");
            }// Show


            // компаратор для сортировки по возрастанию объёмов
            private static int ComparatorConoid(Conoid x, Conoid y) =>
                x.Volume().CompareTo(y.Volume());

            // компаратор для сортировки по убыванию высот
            private static int ComparatorHight(Conoid x, Conoid y) =>
               x.GetH() > y.GetH() ? -1 : x.GetH() < y.GetH() ? 1 : 0;

            // общая сумма объёма конусов
            private static double TotalVolume(Conoid[] cone)
            {
                double tVolume = 0d;
                for (int i = 0; i < cone.Length; i++)
                {
                    tVolume += cone[i].Volume();
                } // for i
                return tVolume;
            }// TotalVolume

            // общая сумма площадей конуса 
            private static double TotalArea(Conoid[] cone)
            {
                double tArea = 0d;
                for (int i = 0; i < cone.Length; i++)
                {
                    tArea += cone[i].Area();
                } // for i
                return tArea;
            }// TotalArea

            // индекс максимальной площади конуса
            private static int MaxArea(Conoid[] cone)
            {
                int iMax = 0;
                for (int i = 1; i < cone.Length; i++)
                {
                    if (cone[i].Area() > cone[iMax].Area()) iMax = i;
                } // for i
                return iMax;
            } // MaxArea

            private static void ShowMaxArea(Conoid[] cone)
            {
                ArrayConoid name = new ArrayConoid();
                
                Console.WriteLine($"\n\n {name}\n" +
                                  $"  ┌─────────┬────────┬─────────┬─────────┐\n" +
                                   "  │ Радиус  | Высота | Площадь |  Объём  |\n" +
                                   "  ├─────────┼────────┼─────────┼─────────┤");
                for (int i = 0; i < cone.Length; i++)
                {
                    if(cone[i].Area() == cone[MaxArea(cone)].Area())
                        Console.ForegroundColor = ConsoleColor.Red;
                    else Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{cone[i]}\n");
                }
                Console.WriteLine($"  └─────────┴────────┴─────────┴─────────┘\n\n ");
                Console.ForegroundColor = ConsoleColor.White;
            }// ShowMaxArea
            #endregion
        }
    }
}
