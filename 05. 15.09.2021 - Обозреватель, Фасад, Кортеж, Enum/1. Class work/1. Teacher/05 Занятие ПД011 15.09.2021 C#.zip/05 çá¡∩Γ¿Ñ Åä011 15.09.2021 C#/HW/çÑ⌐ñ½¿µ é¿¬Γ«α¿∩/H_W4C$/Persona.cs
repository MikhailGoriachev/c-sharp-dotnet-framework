﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W4C_
{
    /// <summary>
    /// Разработайте класс Персона со следующими полными свойствами: 
    ///•	фамилия и инициалы имени и отчества(например, Семенов Р.О.)
    ///•	возраст в полных годах(целое число)
    ///•	рост в сантиметрах(целое число)
    ///•	вес в кг(вещественное число)
    ///•	название города проживания(строка)
    /// </summary>
    /// 
     // класс, построенный на свойствах
    class Persona
    {
        private string _fullName;         // фамилия и инициалы имени и отчества
        private int    _age;              // возраст в полных годах
        private int    _drowsh;           // рост в сантиметрах
        private double _weight;           // вес в кг
        private string _city;             // название города проживания

        // конструктор по умолчанию
        public Persona():this("Иванов И.И.", 42, 190, 94d, "Москва")
        { }

        public Persona(string fullName, int age, int drowsh, double weight, string city)
        {
            _fullName = fullName;
            _age = age;
            _drowsh = drowsh;
            _weight = weight;
            _city = city;
        }// Persona

        // частичный конструктор - одно или несколько значений задаем по умолчанию
        public Persona(string fullName, int age) : this(fullName, age, 185, 90, "Донецк")
        { } // Persona

        
        public string FullName{
            get { return _fullName; }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                    _fullName = value;
            }
        }// FullName
        
        public int Age{
            get { return _age; }
            set { if (value > 0) _age = value; }
        } // Age

        public int Drowsh{
            get { return _drowsh; }
            set { _drowsh = value > 0 ? value : _drowsh; }
        }// Drowsh

        public double Weight{
            get { return _weight; }
            set { if (value > 0) _weight = value; }
        }// Weight

        public string City{
            get { return _city; }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                    _city = value;
            }
        }// City

        // компаратор для сортировки по городу проживания
        public static int CompareByCity(Persona x, Persona y) =>
        x.City.CompareTo(y.City);

        // компаратор для сортировки по убыванию веса
        public static int CompareByWeight(Persona x, Persona y) =>
        y.Weight.CompareTo(x.Weight);

        // компаратор для сортировки по возрастанию роста
        public static int CompareByDrowsh(Persona x, Persona y) =>
        x.Drowsh.CompareTo(y.Drowsh);


        public override string ToString()
        {
            return $"  | {_fullName, 13} | {_age, 7} | {_drowsh, 4} | {_weight, 6:n2} | {_city, 8} |";
        } // ToString
        /*
        public override string ToString()
        {
            return $"ФИО: {_fullName}; возраст: {_age}; рост:" +
                $" {_drowsh}; вес {_weight :n2}; город проживания {_city}";
        } // ToString
        */
    }// class Persona
}
