﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Создайте класс, описывающий усеченный конус Conoid
/// (*радиус верхнего основания, 
/// *радиус нижнего основания, 
/// *высота – тип полей double). 
/// Реализуйте полные свойства, вычисляемые свойства для площади и объема усеченного конуса,
/// метод формирующий строковое представление конуса (ToString(),
/// выводить только радиус и высоту), метод формирующий строку таблицы
/// со сведениями о конусе (радиус, высота, площадь поверхности, объем).
/// Разработайте компараторы для сортировки по возрастанию объемов,
/// для сортировки по убыванию высот
/// </summary>
namespace H_W4C_
{
    class Conoid
    {
        protected double _r1;           // радиус нижнего осования усечённого конуса
        protected double _r2;           // радиус вернего осования усечённого конуса
        protected double _h;            // высота усечённого конуса

        public Conoid():this(1d, 1d, 4d)
        { }

        public Conoid(double r1, double r2, double h) {
            _r1 = r1;
            _r2 = r2;
            _h = h;
        }

        // метод для вычисления площади конуса
        public double Area()
        {
            double _l = Math.Sqrt(_h * _h + Math.Pow((_r1 - _r2),2));
            return Math.PI * (_r1 + _r2) * _l;
        }

        // метод для вычисления объема конуса
        public double Volume() {

            return _h / 3d * Math.PI*((_r1 * _r1) + (_r1 * _r2) + (_r2*_r2));
        }// Volume

        public double GetH() => _h;
        
        public override string ToString()
        {
            return  $"  | {_r2,7:n2} | {_h,6:n2} | {Area(),7:n2} | {Volume(),7:n2} |";

        } // ToString

        public string Heder()
        {
            return $"  ┌─────────┬────────┬─────────┬─────────┐\n " +
                    "  │ Радиус  | Высота | Площадь |  Объём  |\n" +
                    "  ├─────────┼────────┼─────────┼─────────┤\n";
        }

        public string Footer()
        {
            return $"  └─────────┴────────┴─────────┴─────────┘\n\n";
        }
    }// class Conoid
}
