#pragma once
#include "pch.h"

class Memento{
	string nameSender_;    
	string surnameSender_; 
	string codeSender_;    
	string codeRecipient_; 
public:

	Memento(string nameSender, string surnameSender, string codeSender, string codeRecipient) {
		nameSender_ = nameSender;
		surnameSender_ = surnameSender;
		codeSender_ = codeSender;
		codeRecipient_ = codeRecipient;
	} // Memento

	string GetName() const { return nameSender_; }
	void SetName(string pName) { nameSender_ = pName; }

	string GetSurname() const { return surnameSender_; }
	void SetSurname(string pSurname) { surnameSender_ = pSurname; }

	string GetCodeSender() const { return codeSender_; }
	void SetCodeSender(string codeSender) { codeSender_ = codeSender; }

	string GetCodeRecipient() const { return codeRecipient_; }
	void SetCodeRecipient(string codeRecipient) { codeRecipient_ = codeRecipient; }
};

