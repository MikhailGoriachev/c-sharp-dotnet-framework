﻿#include "pch.h"
#include "Utils.h"
#include "MenuItem.h"
#include "Menu.h"
#include "App.h"
#include "Palette.h"


int main()
{
	// настройка вывода в консоль
	init(L"Задание на 08.09.2021");

	// коды команд
    enum Commands {
        CMD_ONE,    // Демонстрация обмена сообщениями через менеджера проектов
        CMD_TWO,    // Демонстрация возможности сохранения и восстановления данных о переводе
    };

	// массив пунктов меню
    const int N_MENU = 3;
    MenuItem items[N_MENU] = {
        MenuItem ("Задача 1. Демонстрация обмена сообщениями через менеджера проектов", CMD_ONE),
        MenuItem ("Задача 2. Демонстрация возможности сохранения и восстановления данных о переводе", CMD_TWO),
        MenuItem ("Выход",  Menu::CMD_QUIT) 
    };

	// палитра вывода меню
    const int N_PALETTE = 5;
	//                          заголовок       пункт меню       выбранный пункт  текст консоли  
    short palette[N_PALETTE] = {arrColor, LTCYAN_ON_BLACK, BLACK_ON_LTCYAN, mainColor};

    Menu mainMenu("Главное меню приложения", items, N_MENU, palette, COORD{5, 5});
    App app;

    while(true) {
        try {
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            int cmd = mainMenu.Navigate();
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            if (cmd == Menu::CMD_QUIT) break;

            switch (cmd) {
                // Демонстрация обмена сообщениями через менеджера проектов
            case CMD_ONE:
                app.task1();
                break;

                // Демонстрация возможности сохранения и восстановления данных о переводе
            case CMD_TWO:
                app.task2();
                break;
            }
        } catch (exception &ex) {
            setColor(mainColor);
            cls();
            showNavBarMessage(hintColor, "  Ошибка приложения, нажмите любую клавишу для продолжения...");

	        // добавим 4 пробела перед выводимым сообщением об ошибке, длина строки 64 символа
            char buf[65];
            sprintf(buf, "    %-60s", ex.what());

        	// в эту секцию передается управление оператором throw
            const char* msg[] = {
                " ",
                "    [Ошибка]",
                buf,
                " ",
                " ",
                nullptr
            };
            showMessage(8, 4, 64, msg, errColor);
        } // try-catch
        cout << endlm(2);
        getKey();
    } // while

    cout << cls << pos(0,24);
    getKey();
	
	return 0;
} // main