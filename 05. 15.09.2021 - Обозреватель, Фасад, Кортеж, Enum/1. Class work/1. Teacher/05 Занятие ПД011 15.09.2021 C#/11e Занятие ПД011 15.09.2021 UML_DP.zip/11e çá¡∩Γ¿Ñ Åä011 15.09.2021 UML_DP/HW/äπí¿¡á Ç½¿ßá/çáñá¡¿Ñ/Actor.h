#pragma once
#include "pch.h"
#include "Manager.h"

class Actor{
	string position_;
	Manager* manager_;
public:
	Actor(string pName){
		SetPosition(pName);
	} // Actor

	string GetPosition() const { return position_; }
	void   SetPosition(string pName) { position_ = pName; }

	Manager* GetManager() const { return manager_; }
	void SetManager(Manager* pManager) { manager_ = pManager; }

	// ������� ���������
	void Send(string to, string message) {
		manager_->Send(position_, to, message);
	} // Send

	virtual void Receive(string from, string message){
		cout << "    ��������� �� " << from << " � " << position_ << " : " << message << endl;
	} // Receive
};

