#include "pch.h"
#include "Trainee.h"

void Trainee::Send(string to, string message)
{
	company_->Send(name_, to, message);
} // Trainee::Send