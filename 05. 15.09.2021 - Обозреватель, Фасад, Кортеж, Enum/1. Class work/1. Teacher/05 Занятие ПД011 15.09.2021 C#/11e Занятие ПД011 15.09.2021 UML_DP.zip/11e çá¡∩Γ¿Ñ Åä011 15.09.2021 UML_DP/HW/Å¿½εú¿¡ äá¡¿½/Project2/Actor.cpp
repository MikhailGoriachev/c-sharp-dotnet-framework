#include "pch.h"
#include "Actor.h"
#include "ProjectManager.h"


void Actor::Send(string to, string message)
{
	room->Send(name, to, message);
}
