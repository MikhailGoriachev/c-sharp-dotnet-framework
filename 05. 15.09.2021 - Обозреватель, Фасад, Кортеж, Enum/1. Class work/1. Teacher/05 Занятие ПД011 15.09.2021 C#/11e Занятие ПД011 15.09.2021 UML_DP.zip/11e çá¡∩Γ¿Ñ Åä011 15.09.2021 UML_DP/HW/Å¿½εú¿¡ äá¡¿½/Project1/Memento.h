#pragma once
#include <iostream>
using namespace std;

class Memento
{
	string name;
	string codeSender;
	string codeReceiver;
	int sum;

public:
	Memento(string nm, string cs, string cr, int s)
	{
		name = nm;
		codeSender = cs;
		codeReceiver = cr;
		sum = s;
	}

	string getName() const { return name; }
	void setName(string nm)
	{
		name = nm;
	}

	string getSender() const { return codeSender; }
	void setSender(string cs)
	{
		codeSender = cs;
	}

	string getReceiver() const { return codeReceiver; }
	void setReceiver(string cr)
	{
		codeReceiver = cr;
	}

	int getSum() const { return sum; }
	void setSum(int sm)
	{
		if (sm < 0)
			throw exception("������������� �����!");
		sum = sm;
	}
};

