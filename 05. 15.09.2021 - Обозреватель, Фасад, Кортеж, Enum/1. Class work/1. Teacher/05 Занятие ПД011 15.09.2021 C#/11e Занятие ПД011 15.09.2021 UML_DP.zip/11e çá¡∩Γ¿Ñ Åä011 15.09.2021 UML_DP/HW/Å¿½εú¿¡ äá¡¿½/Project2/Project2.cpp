﻿#include "pch.h"


int main()
{
	SetConsoleOutputCP(1251);

	ProjectManager* messager = new ProjectManager();

	Actor* customer = new Messager("Толстой");
	Actor* programmer = new Messager("Грибоедов");
	Actor* tester = new Messager("Булгаков");
	Actor* admin = new Messager("Маяковский");

	messager->Register(customer);
	messager->Register(programmer);
	messager->Register(tester);
	messager->Register(admin);

	customer->Send("Маяковский", "Все работает?");
	admin->Send("Толстой", "Кажется - да...");

	tester->Send("Маяковский", "Кажется)))");

	delete customer;
	delete programmer;
	delete tester;
	delete admin;

	delete messager;
}
