#pragma once
#include "pch.h"
class Actor;

class Manager
{
public:
	virtual void Register(Actor* actor) = 0;

	virtual void Send(string from, string to, string message) = 0;
};

class ProjectManager :public Manager
{
	map<string, Actor*> actors;
public:

	void Register(Actor* actor);
	void Send(string from, string to, string message);
};


