#pragma once
#include "Memento.h"


class Payment
{
	string name;
	string codeSender;
	string codeReceiver;
	int sum;

public:
	Payment(string nm, string cs, string cr, int s)
	{
		name = nm;
		codeSender = cs;
		codeReceiver = cr;
		sum = s;
	}

	string getName() const { return name; }
	void setName(string nm)
	{
		name = nm;
	}

	string getSender() const { return codeSender; }
	void setSender(string cs)
	{
		codeSender = cs;
	}

	string getReceiver() const { return codeReceiver; }
	void setReceiver(string cr)
	{
		codeReceiver = cr;
	}

	int getSum() const { return sum; }
	void setSum(int sm)
	{
		if (sm < 0)
			throw exception("������������� �����!");
		sum = sm;
	}

	Memento* saveMemento() const
	{
		cout << "\nPayment: �������� ���������\n";
		return new Memento(name, codeSender, codeReceiver, sum);
	}

	void restoreMemento(Memento* pMemento)
	{
		cout << "\nPayment: �������������� ���������\n";
		name = pMemento->getName();
		codeSender = pMemento->getSender();
		codeReceiver = pMemento->getReceiver();
		sum = pMemento->getSum();
	}


	friend ostream& operator<< (ostream& os, const Payment& pay)
	{
		return os << pay.name << " ("
			<< pay.codeSender << ") to "
			<< pay.codeReceiver << " : "
			<< pay.sum;
	}
};

