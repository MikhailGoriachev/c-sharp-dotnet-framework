#include "ProjectManager.h"
#include "Actor.h"


void ProjectManager::Register(Actor* actor)
{
	if (actors.find(actor->GetName()) == actors.end())
	{
		actors[actor->GetName()] = actor;
	}
	actor->SetClassroom(this);
}

void ProjectManager::Send(string from, string to, string message)
{
	auto ptrActor = actors.find(to);

	if (ptrActor != actors.end()) 
	{
		(*ptrActor).second->Receive(from, message);
	}
	else 
	{
		cout << "\n������ ���������� \"" << to << "\" ���!\n";
	}
}
