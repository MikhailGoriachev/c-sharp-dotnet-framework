﻿// Project1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "pch.h"
#include <iostream>
#include "Payment.h"
#include "CareTaker.h"
using namespace std;

int main()
{
	try
	{
		MemoryState memory;

		Payment pay("Гоголь Н.В.", "9090 2332 3433 1233", "2334 3423 4899 1238", 23000);

		cout << pay << endl;

		memory.SetMemento(pay.saveMemento());

		pay.setName("Пушкин А.С.");
		pay.setReceiver("9090 2332 3433 1233");
		pay.setSender("2334 3423 4899 1238");
		pay.setSum(24000);

		cout << pay << endl;

		pay.restoreMemento(memory.GetMemento());

		cout << pay << endl;
	}
	catch (exception& ex)
	{
		cout << ex.what();
	}
}

