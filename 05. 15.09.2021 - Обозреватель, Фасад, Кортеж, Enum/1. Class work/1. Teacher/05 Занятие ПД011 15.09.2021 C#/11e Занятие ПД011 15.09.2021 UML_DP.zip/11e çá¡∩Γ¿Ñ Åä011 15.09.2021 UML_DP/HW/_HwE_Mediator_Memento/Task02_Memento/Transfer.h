﻿#pragma once
#include "pch.h"

class Memento;

// Денежный перевод:
//     ☼ фамилию и имя отправителя
//     ☼ код счета отправителя
//     ☼ код счета получателя
//     ☼ сумма перевода
class Transfer
{
	string fullName_; // фамилия и имя отправителя
	string from_;     // код счета отправителя
	string to_;       // код счета получателя
	int    amount_;   // сумма перевода

public:
	Transfer() = default;
	Transfer(const string& fullName, const string& from, const string& to, int amount)
		: fullName_(fullName), from_(from), to_(to), amount_(amount) { }

	string getFullName() const { return fullName_; }
	void setFullName(const string& fullName)
	{
		fullName_ = fullName;
	}

	string getFrom() const { return from_; }
	void setFrom(const string& from)
	{
		from_ = from;
	}

	string getTo() const { return to_; }
	void setTo(const string& to)
	{
		to_ = to;
	}

	int getAmount() const { return amount_; }
	void setAmount(const int amount)
	{
		amount_ = amount;
	}

	// получаем снимок текущего состояния объекта - сохраняем только то,
	// что, по заданию и должно быть сохранено
	Memento* saveMemento() const;

	// восстанавливаем состояние
	void restoreMemento(Memento* pMemento);

	// строковое представление полей
	string toString();
};

