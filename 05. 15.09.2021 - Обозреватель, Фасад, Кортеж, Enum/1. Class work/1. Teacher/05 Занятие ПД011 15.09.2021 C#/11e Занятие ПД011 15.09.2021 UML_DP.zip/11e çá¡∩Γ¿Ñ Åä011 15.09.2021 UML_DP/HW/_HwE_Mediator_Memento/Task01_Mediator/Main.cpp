﻿/*
 * Задание по UML_DP.
 * Разработайте консольное приложение (как обычно, макет приложения) на C++ для
 * демонстрации паттернов Хранитель и Посредник.
 *
 * Посредник.
 * Процесс разработки программных продуктов в одной из компаний включает ряд
 * экторов: заказчики, программисты, тестировщики, администраторы. Эти экторы
 * должны взаимодействовать между собой – обмениваться сообщениями.
 * Для упрощения взаимодействия между экторами реализуйте обмен сообщениями
 * через менеджера проектов, выполняющего роль посредника.
 * 
 */


#include "pch.h"
#include "Utils.h"
#include "MenuItem.h"
#include "Menu.h"
#include "App.h"
#include "Palette.h"


int main()
{
	// настройка вывода в консоль
	init(L"Задание на 08.09.2021 - паттерн \"Посредник (Mediator)\"");

	// коды команд
    enum Commands {
    	CMD_ONE,      // Начальное заполнение коллекций данных для демонстрации паттерна
    	CMD_TWO,      // Обмен сообщениями с зарегистрированными экторами
    	CMD_THREE     // Обмен сообщениями с несуществующими экторами
    };

	// массив пунктов меню
    vector<MenuItem> items = {
        MenuItem ("Начальное заполнение коллекций данных для демонстрации паттерна", CMD_ONE), 
        MenuItem ("Обмен сообщениями с зарегистрированными экторами", CMD_TWO), 
        MenuItem ("Обмен сообщениями с несуществующими экторами", CMD_THREE), 
        MenuItem ("Выход",  Menu::CMD_QUIT) 
    };

	// палитра вывода меню
	//                          заголовок       пункт меню       выбранный пункт  текст консоли  
    vector<short> palette = {arrColor, LTCYAN_ON_BLACK, BLACK_ON_LTCYAN, mainColor};

    Menu mainMenu("Главное меню приложения", items, palette, COORD{5, 5});

	// Объект класса для обработки по заданию
    App *app = new App();   
    
    while(true) {
        try {
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            showNavBarMessage(hintColor, "  Демонстрация паттерна \"Посредник (Mediator)\"");
            int cmd = mainMenu.navigate();
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            if (cmd == Menu::CMD_QUIT) break;

            switch (cmd) {
            // Начальное заполнение коллекций данных для демонстрации паттерна
            case CMD_ONE:
                app->doInitialize();
                break;

            // Обмен сообщениями с зарегистрированными экторами
            case CMD_TWO:
                app->demoRegisteredActors();
                break;

            // Обмен сообщениями с несуществующими экторами
            case CMD_THREE:
                app->demoNonExistActors();
                break;
            } // switch

        } catch (exception &ex) {
            setColor(mainColor);
            cls();
            showNavBarMessage(hintColor, "  Ошибка приложения, нажмите любую клавишу для продолжения...");

        	// в эту секцию передается управление оператором throw
            vector<string> msg = {
                " ",
                "    [Ошибка]",
                " ",
                "    "s + ex.what(),  // добавим 4 пробела перед выводимым сообщением об ошибке
                " ",
            };
            showMessage(8, 4, 64, msg, errColor);
        } // try-catch
        cout << endlm(2);
        getKey();
    } // while

    cout << cls << pos(0,24);
    getKey();
	
    delete app;
	return 0;
} // main