﻿#include "System/pch.h"
#include "System/Utils.h"
#include "App.h"
#include "Memento.h"
#include "CareTaker.h"
#include "Remittance.h"

void App::menuItem1()
{
	ShowNavBarMessage(hintColor, "  Демонстрация работы паттерна Хранитель");
	cout << color(resColor) << "\n\n\n";

	Remittance remit("Пётр", "Иванов", "354894564", "674817168", 500);

	cout << remit.ToString() << endl;
	
	MemoryState state;
	state.SetMemento(remit.SaveMemento());

	remit.SetCodeSender("1111111");
	remit.SetCodeReciever("2222222");
	remit.SetName("Иван");
	remit.SetSurname("Петров");
	remit.SetAmount(777);

	cout << "\n\n    Данные изменены:\n    " << remit.ToString() << endl;

	remit.RestoreMemento(state.GetMemento());

	cout << "\n    " << remit.ToString();


}

