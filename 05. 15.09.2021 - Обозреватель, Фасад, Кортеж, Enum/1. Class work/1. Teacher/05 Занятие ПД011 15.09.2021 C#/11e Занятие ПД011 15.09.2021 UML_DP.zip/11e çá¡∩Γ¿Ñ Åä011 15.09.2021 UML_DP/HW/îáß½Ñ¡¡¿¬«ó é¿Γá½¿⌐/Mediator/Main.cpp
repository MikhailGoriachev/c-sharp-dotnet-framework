﻿#include "System/pch.h"
#include "System/Utils.h"
#include "App.h"


int main()
{
	Init(L"Масленников В. Домашнее задание.");

	App* app{ new App };
	
	app->run();
	
	delete app;

	cout << cls << pos(0, 0);
	return 0;
}


