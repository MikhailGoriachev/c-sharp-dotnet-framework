﻿#include "System/pch.h"
#include "System/Utils.h"
#include "App.h"
#include "Manager.h"
#include "Staff.h"

void App::menuItem1()
{
	ShowNavBarMessage(hintColor, "  Демонстрация паттерна \"Посредник\"");
	cout << color(resColor) << "\n\n\n";

	Manager* manager = new Manager();

	Staff* jack = new Customer("Джэк");
	Staff* john = new Programmer("Джон");
	Staff* helen = new Tester("Хелен");
	Staff* brad = new Administrator("Брэд");

	manager->Register(jack);
	manager->Register(john);
	manager->Register(helen);
	manager->Register(brad);

	jack->Send("Брэд", "Есть новые пожелания к реализации.");
	cout << "\n\n";
	
	brad->Send("Джон", "В задачи добавлен новый спринт.");
	cout << "\n\n";

	john->Send("Хелен", "Отправлены новые тикеты на тесты.");
	cout << "\n\n";

	helen->Send("Брэд", "Прошу выдать аванс по текущему проекту.");
	cout << "\n\n";
}

