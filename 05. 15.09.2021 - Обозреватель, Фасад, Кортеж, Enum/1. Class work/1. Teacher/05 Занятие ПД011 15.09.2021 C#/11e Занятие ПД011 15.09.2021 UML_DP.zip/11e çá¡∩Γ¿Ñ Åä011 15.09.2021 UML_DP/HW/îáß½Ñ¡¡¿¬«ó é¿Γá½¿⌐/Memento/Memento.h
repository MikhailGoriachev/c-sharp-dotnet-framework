#pragma once
#include "System/pch.h"
#include "System/Menu.h"


// ������ ������ ��������� ������� Remittance
class Memento {
	string name;
	string surname;
	string codeSender;
	string codeReciever;
	int amount;

public:
	Memento(string name, string surname, string codeSender, string codeReciever, int amount) :
		name(name), surname(surname), codeSender(codeSender), codeReciever(codeReciever), amount(amount)
	{}

	string GetName() const { return name; }
	string GetSurname() const { return surname; }
	string GetCodeSender() const { return codeSender; }
	string GetCodeReciever() const { return codeReciever; }
	int GetAmount() const { return amount; }

	void SetName(string pName) { name = pName; }
	void SetSurname(string pSurname) { surname = pSurname; }
	void SetCodeSender(string pCodeSender) { codeSender = pCodeSender; }
	void SetCodeReciever(string pCodeReciever) { codeReciever = pCodeReciever; }
	void SetAmount(int pAmount) { amount = pAmount; }


};