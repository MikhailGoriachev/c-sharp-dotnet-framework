﻿#ifndef PCH_H
#define PCH_H

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>    
#include <iomanip>  
#include <Windows.h>
#include <conio.h>
#include <cmath>
#include <corecrt_math_defines.h>
#include <sstream>
#include <functional>
#include <random>
#include <chrono>
#include <sstream>   // для работы со строковым потоком вывода
#include <fstream>   // для работы со файловыми потоками ввода/вывода
#include <filesystem>
#include <deque>
#include <stack>
#include <list>
#include <vector>
#include <queue>
#include <map>
using namespace std;

#define CODE_PAGE 1251

#define KB_ESC 27
#define KB_UP 72
#define KB_DOWN 80
#define KB_ENTER 13
#define CLEAR "cls"



#endif //PCH_H
