#include "Staff.h"

void Staff::Send(string to, string message)
{
	manager->Send(name, this->GetRole(), to, message);
}