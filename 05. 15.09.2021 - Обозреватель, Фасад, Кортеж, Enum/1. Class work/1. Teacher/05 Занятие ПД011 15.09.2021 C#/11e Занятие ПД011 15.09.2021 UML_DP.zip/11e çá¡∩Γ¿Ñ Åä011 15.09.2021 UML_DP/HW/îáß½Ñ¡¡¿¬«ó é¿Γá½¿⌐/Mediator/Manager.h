#pragma once
#include "System/pch.h"
#include "System/Utils.h"

class Staff;

class AbstractManager
{
public:
	virtual void Register(Staff* role) = 0;

	virtual void Send(string from, string role, string to, string message) = 0;
};

class Manager : public AbstractManager
{
	map <string, Staff*> staff;

public:
	void Register(Staff* role);
	void Send(string from, string role, string to, string message);

};
