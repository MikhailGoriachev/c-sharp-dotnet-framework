﻿#include "Utils.h"
#include "Colors.h"
#include "App.h"
#include "MenuItem.h"
#include "Menu.h"
#include "pch.h"


int main()
{
    // настройка вывода в консоль
    Init(L"Домашнее задание");
    ostringstream oss;

    // коды команд
    enum Commands {
        CMD_TASK1,       //Демонстрация паттерна посредник
        CMD_TASK2,       //Демонстрация паттерна Хранитель
    };

    const int N_MENU = 3;
    MenuItem items[N_MENU] = {
        MenuItem("Демонстрация паттерна Посредник", CMD_TASK1),
        MenuItem("Демонстрация паттерна Хранитель", CMD_TASK2),
        MenuItem("Выход",  Menu::CMD_QUIT),
    };

    // палитра вывода меню
    const int N_PALETTE = 5;
    //                            заголовок       пункт меню       выбранный пункт  текст консоли  
    short palette[N_PALETTE] = { WHITE_ON_BLACK, LTCYAN_ON_BLACK, BLACK_ON_LTCYAN, GRAY_ON_BLACK };

    Menu mainMenu("Главное меню приложения", items, N_MENU, palette, COORD{ 5, 5 });

    App app;

    while (true) {
        try{
        cout << color(palette[Menu::PAL_CONSOLE]) << cls;
        int cmd = mainMenu.Navigate();
        cout << color(palette[Menu::PAL_CONSOLE]) << cls;
        if (cmd == Menu::CMD_QUIT) break;

        switch (cmd)
        {
        case CMD_TASK1:
            app.Task1();
            break;

        case CMD_TASK2:
            app.Task2();
            break;
        } // switch

        cout << endlm(2);
        GetKey();
    }
    catch (const exception& ex) {
        oss.str("");
        oss << "\n\n\n\n\n"
            << "\t\t\t                                                                     \n"
            << "\t\t\t    Исключение.                                                      \n"
            << "\t\t\t    " << left << setw(61) << ex.what() << right << "    \n"
            << "\t\t\t                                                                     \n"
            << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t";
        OutText(oss.str().c_str(), errColor, mainColor);
        system("pause");
    } // try-catch
    } // while

    cout << cls << pos(0, 24);
    GetKey();

	system(CLEAR);
	return 0;
}