#include "pch.h"
#include "Developer.h"
#include "Manager.h"


void Developer::Send(string to, string message)
{
	manager_->Send(actorName_, to, message);
}//Send
