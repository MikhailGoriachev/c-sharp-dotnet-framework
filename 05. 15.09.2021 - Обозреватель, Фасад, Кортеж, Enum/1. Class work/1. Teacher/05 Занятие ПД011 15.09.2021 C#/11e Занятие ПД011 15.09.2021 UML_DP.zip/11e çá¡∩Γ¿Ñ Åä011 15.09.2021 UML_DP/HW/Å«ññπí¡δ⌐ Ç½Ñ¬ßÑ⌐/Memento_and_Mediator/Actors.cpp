#include "Actors.h"

void Actors::Send(string to, string message)
{
	company->Send(name, to, message);
} // Trainee::Send