#include "Libraries.h"
#include "IMemento.h"
#include "Transfer.h"
#include "Caretaker.h"


int main()
{
	Utilities::init();

	Transfer transfer("Sender", "SenderCode", "ReceiverCode", 50'000);
	Caretaker taker(transfer);

	cout << transfer.toString() << "\n\n";
	taker.save();
	cout << transfer.toString() << "\n\n";

	transfer.setValue(100'000);
	cout << transfer.toString() << "\n\n";

	taker.undo();
	cout << transfer.toString() << "\n\n";
	
	Utilities::Console::switchCursorVisibility(false);
	Utilities::Console::setCoordInBottomLeft(3);
	return 0;
} 