#pragma once
#include "IMemento.h"


class Caretaker
{
	IMementoObject&             _originator;
	stack<unique_ptr<IMemento>> _history {};

public:
	Caretaker(IMementoObject& originator)
		: _originator { originator } {}

	void save() { _history.push(_originator.save()); }

	void undo()
	{
		if (_history.empty())
			return;

		auto ptr = move(_history.top());
		_history.pop();

		_originator.restore(*ptr);
	}

	void clear()
	{
		while (!_history.empty())
			_history.pop();
	}
};
