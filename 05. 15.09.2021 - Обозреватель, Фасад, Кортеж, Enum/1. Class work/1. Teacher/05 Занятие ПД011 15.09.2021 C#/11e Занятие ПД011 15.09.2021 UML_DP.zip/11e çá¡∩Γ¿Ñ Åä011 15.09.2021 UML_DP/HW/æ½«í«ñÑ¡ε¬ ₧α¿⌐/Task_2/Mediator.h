#pragma once
#include "Libraries.h"
#include "Actor.h"


class Mediator
{
protected:
	deque<Actor*> _actors {};

public:
	Mediator()          = default;
	virtual ~Mediator() = default;

	virtual void add(Actor* actor) = 0;

	virtual void notify(const Actor* sender, const string& receiverName, const string& message) = 0;
};


class Manager : public Mediator
{
public:
	void add(Actor* actor) override
	{
		auto iter = find_if(_actors.begin(), _actors.end(),
			[actor](const Actor* obj) { return obj->getName() == actor->getName(); });

		if (iter == _actors.end())
		{
			_actors.push_back(actor);
			actor->setMediator(this);
		}
	}

	void notify(const Actor* sender, const string& receiverName, const string& message) override
	{
		auto iter = find_if(_actors.begin(), _actors.end(),
			[&receiverName](const Actor* obj) { return obj->getName() == receiverName; });

		if (iter != _actors.end())
			(*iter)->receive(*sender, message);
	}
};
