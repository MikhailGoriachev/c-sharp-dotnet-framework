#pragma once
#include "Libraries.h"


class Mediator;


class Actor
{
	Mediator* _mediator {};
	string    _name {};

public:
	Actor() = default;
	explicit Actor(const string& name) { setName(name); }
	virtual ~Actor() = default;

	void setMediator(Mediator* const mediator) { _mediator = mediator; }

	const string& getName() const { return _name; }
	void          setName(const string& name) { _name = name; }

	virtual void receive(const Actor& sender, const string& message);

	virtual void send(const string& receiverName, const string& message);
};


class Customer : public Actor
{
	using Actor::Actor;
};


class Programmer : public Actor
{
	using Actor::Actor;
};


class Tester : public Actor
{
	using Actor::Actor;
};


class Administrator : public Actor
{
	using Actor::Actor;
};

