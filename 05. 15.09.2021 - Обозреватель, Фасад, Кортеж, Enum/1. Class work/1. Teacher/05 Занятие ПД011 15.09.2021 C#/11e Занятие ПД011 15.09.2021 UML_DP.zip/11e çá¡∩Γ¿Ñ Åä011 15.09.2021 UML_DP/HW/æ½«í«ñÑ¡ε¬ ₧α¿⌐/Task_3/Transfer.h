#pragma once
#include "Libraries.h"
#include "IMemento.h"


class Transfer : public IMementoObject
{
	string _sender{};
	string _senderCode{};
	string _receiverCode{};
	unsigned _value{};
	
public:
	Transfer() = default;
	Transfer(const string& sender, const string& senderCode, const string& receiverCode, const unsigned value)
	{
		setSender(sender);
		setSenderCode(senderCode);
		setReceiverCode(receiverCode);
		setValue(value);
	}

	const string& getSender() const { return _sender; }
	void          setSender(const string& sender) { _sender = sender; }
	
	const string& getSenderCode() const { return _senderCode; }
	void          setSenderCode(const string& senderCode) { _senderCode = senderCode; }
	
	const string& getReceiverCode() const { return _receiverCode; }
	void          setReceiverCode(const string& receiverCode) { _receiverCode = receiverCode; }
	
	unsigned      getValue() const { return _value; }
	void          setValue(const unsigned value) { _value = value; }

	string toString()
	{
		ostringstream oss;

		oss
			<< "Sender: " << _sender << " " << "SenderCode: " << _senderCode << "\n"
			<< "ReceiverCode: " << _receiverCode << " "
			<< "Value: " << _value;

		return oss.str();
	}
	
	unique_ptr<IMemento> save() override;
	void restore(IMemento& memento) override;
};


class TransferMemento : public IMemento
{
	Transfer _object;

public:
	Transfer& getState() { return _object; }
};


inline unique_ptr<IMemento> Transfer::save()
{
	TransferMemento* memento = new TransferMemento;

	Transfer& ref = memento->getState();

	ref._receiverCode = _receiverCode;
	ref._senderCode = _senderCode;
	ref._sender = _sender;
	ref._value = _value;

	return unique_ptr<IMemento>(memento);
}


inline void Transfer::restore(IMemento& memento)
{
	Transfer& ref = dynamic_cast<TransferMemento&>(memento).getState();

	_receiverCode = ref._receiverCode;
	_sender = ref._sender;
	_senderCode = ref._senderCode;
	_value = ref._value;
}