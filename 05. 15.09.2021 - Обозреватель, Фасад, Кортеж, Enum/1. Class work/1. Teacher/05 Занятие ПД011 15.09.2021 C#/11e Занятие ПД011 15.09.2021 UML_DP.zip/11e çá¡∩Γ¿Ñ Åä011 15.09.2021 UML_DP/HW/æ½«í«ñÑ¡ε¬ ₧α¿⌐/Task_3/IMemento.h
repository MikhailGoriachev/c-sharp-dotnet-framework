#pragma once
#include "Libraries.h"


class IMemento
{
public:
	virtual ~IMemento() = default;
};


class IMementoObject
{
public:
	virtual ~IMementoObject() = default;
	
	virtual unique_ptr<IMemento> save() = 0;
	virtual void restore(IMemento& memento) = 0;
};