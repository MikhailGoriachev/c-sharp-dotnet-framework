#include "Libraries.h"
#include "Mediator.h"
#include "Actor.h"


int main()
{
	Utilities::init();

	unique_ptr<Mediator> mediator(new Manager);
	deque<shared_ptr<Actor>> actors
	{
		make_shared<Programmer>("Programmer"),
		make_shared<Customer>("Customer"),
		make_shared<Tester>("Tester"),
		make_shared<Administrator>("Administrator"),
	};

	for (auto& actor : actors)
		mediator->add(actor.get());

	actors[0]->send("Tester", "Message");
	
	Utilities::Console::switchCursorVisibility(false);
	Utilities::Console::setCoordInBottomLeft(3);
	return 0;
} 