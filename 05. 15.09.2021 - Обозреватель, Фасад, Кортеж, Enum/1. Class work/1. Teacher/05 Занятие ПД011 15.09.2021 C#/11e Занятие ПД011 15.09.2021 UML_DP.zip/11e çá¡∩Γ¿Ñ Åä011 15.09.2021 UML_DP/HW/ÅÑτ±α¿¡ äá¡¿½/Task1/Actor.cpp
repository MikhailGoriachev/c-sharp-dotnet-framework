#include "pch.h"
#include "ProductManager.h"

void Actor::Send(string to, string message)
{
	manager->Send(name, to, message);
}

void Actor::Receive(string message, string from)
{

	cout << "�������� �� " << from << " � " << name << " : " << message << endl;
}
