﻿
#include "pch.h"
#include "Utils.h"
#include "Actor.h"
#include "ProductManager.h"


int main()
{
	// настройка вывода в консоль
	Init(L"Mediator");

	// создание менеджера для координации переписки 
	ConcreteManager* manager = new ConcreteManager();

	// коллектив участников переписки
	Actor* customer = new Customer("John"); 
	Actor* programmer = new Programmer("Mike"); 
	Actor* tester = new Tester("Alex"); 
	Actor* admin = new Administrator("Nick");

	// регистрация участников у менеджера
	manager->Register(customer);
	manager->Register(programmer);
	manager->Register(tester);
	manager->Register(admin);

	// посылаем сообщения 
	tester->Send("Nick", "ok. got it"); 
	admin->Send("Mike", "Nevermind");
	customer->Send("Nick", "5 give or take"); 

	

	GetKey();
	return 0;
} // main


