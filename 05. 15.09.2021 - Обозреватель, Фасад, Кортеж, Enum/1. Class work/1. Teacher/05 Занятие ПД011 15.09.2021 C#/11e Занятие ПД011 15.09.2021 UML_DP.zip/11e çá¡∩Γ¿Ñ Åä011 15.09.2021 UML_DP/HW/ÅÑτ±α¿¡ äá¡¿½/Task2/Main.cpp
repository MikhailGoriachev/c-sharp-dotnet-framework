﻿#include "pch.h"
#include "Utils.h"
#include "MoneyTransfer.h"
#include "CareTaker.h"



int main()
{
	// настройка вывода в консоль
	Init(L"Хранитель");

	// создает объек денежного перевода
	MoneyTransfer transfer1("Иванов И.", 123123, 23212, 34'000); 

	cout << endl << transfer1.GetName() << " " << transfer1.GetSender()
		<< " " << transfer1.GetReceiver() << " " << transfer1.GetSum();

	CareTaker obj;  // хранитель

	// сохраняем состояние
	obj.SetMemnto(transfer1.SaveMemento());

	cout << "\nизменяем данные\n"; 
	transfer1.SetName("Волков");
	transfer1.SetSender(323434);
	transfer1.SetReceiver(323117);
	transfer1.SetSum(12'000);
	cout << endl << transfer1.GetName() << " " << transfer1.GetSender() << " "
		<< transfer1.GetReceiver() << " " << transfer1.GetSum() << endl;

	// возвращаем состояние 
	transfer1.RestoreMemento(obj.GetMemnto()); 
	cout << "\nВосстановленные данные\n";
	cout << endl << transfer1.GetName() << " " << transfer1.GetSender() << " "
		<< transfer1.GetReceiver() << " " << transfer1.GetSum() << endl;



	GetKey();
	return 0;
} // main


