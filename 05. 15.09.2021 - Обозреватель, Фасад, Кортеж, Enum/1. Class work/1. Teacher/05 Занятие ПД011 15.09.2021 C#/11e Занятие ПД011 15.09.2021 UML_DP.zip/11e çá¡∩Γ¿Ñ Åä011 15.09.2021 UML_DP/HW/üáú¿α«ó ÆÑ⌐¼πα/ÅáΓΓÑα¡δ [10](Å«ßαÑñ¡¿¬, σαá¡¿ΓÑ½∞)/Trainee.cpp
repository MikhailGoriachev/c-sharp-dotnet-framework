#include "Trainee.h"

void Trainee::Send(string to, string message)
{
	project->Send(name, to, message);
} // Trainee::Send