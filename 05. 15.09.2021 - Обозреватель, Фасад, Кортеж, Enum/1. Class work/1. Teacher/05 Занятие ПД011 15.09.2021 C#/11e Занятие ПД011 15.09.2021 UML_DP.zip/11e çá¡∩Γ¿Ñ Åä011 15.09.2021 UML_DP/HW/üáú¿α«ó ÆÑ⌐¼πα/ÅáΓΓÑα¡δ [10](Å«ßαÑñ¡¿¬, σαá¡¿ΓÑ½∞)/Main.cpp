﻿#include "pch.h"
#include "App.h"
#include "Colors.h"
#include "Utils.h"
#include "MenuItem.h"
#include "Menu.h"


int main()
{
	// Дата задания
    wstring date = L"";
	
    // настройка вывода в консоль
    Init(L"" );

    // класс приложения
    App* app = new App();

    // коды команд приложения
    enum Commands {
        CMD_ONE_TASK1_BROKER,                        	// Паттерн посредник (Работа в проекте)
        CMD_TWO_TASK2_KEEPER,                     	   // Паттерн хранитель (денежный перевод)

    };
   
    // пункты меню приложения

    const int N_MENU = 3;
    MenuItem items[N_MENU] = {
        MenuItem("Паттерн посредник(Работа в проекте)", CMD_ONE_TASK1_BROKER),
        MenuItem("Паттерн хранитель (денежный перевод)", CMD_TWO_TASK2_KEEPER),

        MenuItem("Выход",  Menu::CMD_QUIT)
    };

    const int N_PALETTE = 5;
    //                          заголовок       пункт     выбранный пункт  консоль
    short palette[N_PALETTE] = { LTMAGENTA, LTYELLOW, BLACK_ON_LTYELLOW, LTBLUE };

    Menu mainMenu("Главное меню", items, N_MENU, palette, COORD{ 5, 5 });


    while (true) {  
        try {
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            int cmd = mainMenu.Navigate();
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            if (cmd == Menu::CMD_QUIT) break;

            switch (cmd) {

                // Паттерн посредник (Работа в проекте)
            case CMD_ONE_TASK1_BROKER:
                app->task1();
                break;

                // Паттерн хранитель (денежный перевод)
            case CMD_TWO_TASK2_KEEPER:
                app->task2();
            
                break;

            } //switch

        }
        catch (exception ex) {

            SetColor(RED_ON_WHITE);
            cout << "\n\n\n\t\t\t\a" << ex.what() << "\n";
            SetColor(BLACK_ON_WHITE);
           // app->showMsg("Ошибка программы");
        }// try-catch
        GetKey();
 
    } // while
    delete app;
    

    return 0;
} // main