#pragma once

// ���������� ��������� - ���� ����� � �������
const short BLACK = 0b0000;
const short BLUE = 0b0001;
const short GREEN = 0b0010;
const short CYAN = 0b0011;
const short RED = 0b0100;
const short MAGENTA = 0b0101;
const short YELLOW = 0b0110;
const short GRAY = 0b0111;

const short LTBLACK = 0b1000;
const short LTBLUE = 0b1001;
const short LTGREEN = 0b1010;
const short LTCYAN = 0b1011;
const short LTRED = 0b1100;
const short LTMAGENTA = 0b1101;
const short LTYELLOW = 0b1110;
const short WHITE = 0b1111;

const short GRAY_ON_BLACK = GRAY | BLACK << 4;
const short GRAY_ON_WHITE = GRAY | WHITE << 4;
const short GRAY_ON_BLUE = GRAY | BLUE << 4;

const short LTGREEN_ON_BLUE = LTGREEN | BLUE << 4;

const short LTYELLOW_ON_WHITE = LTYELLOW | WHITE << 4;
const short LTYELLOW_ON_BLACK = LTYELLOW | BLACK << 4;

const short YELLOW_ON_LTMAGENTA = YELLOW | LTMAGENTA << 4;
const short YELLOW_ON_WHITE = YELLOW | WHITE << 4;
const short YELLOW_ON_BLACK = YELLOW | BLACK << 4;
const short YELLOW_ON_RED = YELLOW | RED << 4;
const short YELLOW_ON_MAGENTA = YELLOW | MAGENTA << 4;

const short BLACK_ON_LTYELLOW = BLACK | LTYELLOW << 4;
const short BLACK_ON_LTGREEN = BLACK | LTGREEN << 4;
const short BLACK_ON_LTRED = BLACK | LTRED << 4;
const short BLACK_ON_LTMAGENTA = BLACK | LTMAGENTA << 4;
const short BLACK_ON_LTBLUE = BLACK | LTBLUE << 4;
const short BLACK_ON_LTCYAN = BLACK | LTCYAN << 4;
const short BLACK_ON_GREEN = BLACK | GREEN << 4;
const short BLACK_ON_RED = BLACK | RED << 4;
const short BLACK_ON_GRAY = BLACK | GRAY << 4;
const short BLACK_ON_WHITE = BLACK | WHITE << 4;
const short BLACK_ON_MAGENTA = BLACK | MAGENTA << 4;
const short BLACK_ON_CYAN = BLACK | CYAN << 4;
const short BLACK_ON_YELLOW = BLACK | YELLOW << 4;
const short BLACK_ON_BLUE = BLACK | BLUE << 4;

const short WHITE_ON_BLACK = WHITE | BLACK << 4;

const short CYAN_ON_WHITE = CYAN | WHITE << 4;

const short BLUE_ON_WHITE = BLUE | WHITE << 4;

const short GREEN_ON_BLACK = GREEN | BLACK << 4;
const short GREEN_ON_WHITE = GREEN | WHITE << 4;

const short LTGREEN_ON_BLACK = LTGREEN | BLACK << 4;

const short LTYELLOW_ON_LTMAGENTA = LTYELLOW | LTMAGENTA << 4;
const short LTYELLOW_ON_RED = LTYELLOW | RED << 4;

const short RED_ON_WHITE = RED | WHITE << 4;

const short MAGENTA_ON_WHITE = MAGENTA | WHITE << 4;

const short WHITE_ON_RED = WHITE | RED << 4;
const short WHITE_ON_GREEN = WHITE | GREEN << 4;
const short WHITE_ON_YELLOW = WHITE | YELLOW << 4;
const short WHITE_ON_LTYELLOW = WHITE | LTYELLOW << 4;
const short WHITE_ON_MAGENTA = WHITE | MAGENTA << 4;
const short WHITE_ON_CYAN = WHITE | CYAN << 4;
const short WHITE_ON_BLUE = WHITE | BLUE << 4;


