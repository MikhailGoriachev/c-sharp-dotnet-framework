﻿
#include "pch.h"
#include "Utils.h"
#include "MyMenu.h"
#include "MyMenuItem.h"
#include "App.h"

// Посредник. Процесс разработки программных продуктов в одной
// из компаний включает ряд экторов :
// *заказчики, программисты, тестировщики, администраторы.
// Эти экторы должны взаимодействовать между собой – обмениваться сообщениями.
// Для упрощения взаимодействия между экторами реализуйте 
// обмен сообщения через менеджера проектов, выполняющего роль посредника.

// Хранитель. Данные о денежном переводе содержат фамилию и имя отправителя,
// код счета отправителя, код счета получателя, сумму перевода.
// Реализовать хранение данных о переводе при помощи паттерна Хранитель,
// продемонстрировать возможности сохранения и восстановления данных о переводе.


int main()
{
	// настройка вывода в консоль
	Init();


	// коды команд
	enum Commands {
		CMD_TASK1, CMD_TASK2
		
	};

	const int N_MENU = 3;
	MenuItem items[N_MENU] = {
		MenuItem("Задача 1.Паттерн 'Посредник' Процесс разработки программных продуктов в одной из компаний .", CMD_TASK1),
		MenuItem("Задача 2.Паттерн 'Хранитель' 'Хранение данных о денежном переводе'.", CMD_TASK2),
		MenuItem("Выход",  Menu::CMD_QUIT),
	};

	// палитра вывода меню
	const int N_PALETTE = 5;
	//                          заголовок       пункт меню  выбранный пункт  текст консоли  
	short palette[N_PALETTE] = { RED_ON_CYAN, BLACK_ON_CYAN, CYAN_ON_BLACK, WHITE_ON_CYAN };

	Menu myMenu("Главное меню приложения:  ", items, N_MENU, palette, COORD{ 18, 5 });
	App* app = new App();
	
	while(true)
	{
		cout << color(palette[Menu::PAL_CONSOLE]) << cls;
		int cmd = myMenu.Navigate();
		cout << color(palette[Menu::PAL_CONSOLE]) << cls;
		if (cmd == Menu::CMD_QUIT) break;
		try
		{
			switch (cmd)
			{
				// Паттерн 'Посредник'
			case CMD_TASK1:
				app->mediator();
				break;
				// Паттерн 'Хранитель'
			case CMD_TASK2:
				app->memento();
				break;
			}// switch
		}
		catch (exception ex) {
			cout << ex.what() << "\n";
		}// try-catch
		SetColor(MAGENTA_ON_CYAN);
		GetKey("\n\n\nНажмите любую клавишу. . .");
		SetColor(WHITE_ON_CYAN);
		
	}// while
	cout << cls << pos(0, 24);
	delete app;
	
	return 0;
}//main



