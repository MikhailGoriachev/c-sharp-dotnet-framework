#pragma once
#include"pch.h"
#include"Application.h"

class Transfer {
protected:
	Transfer* pSuccessor = nullptr;
public:
	void SetSuccessor(Transfer* tp) {
		pSuccessor = tp;
	}

	virtual void Process(const Application& aplic) = 0;
	virtual ~Transfer() = default;

};
