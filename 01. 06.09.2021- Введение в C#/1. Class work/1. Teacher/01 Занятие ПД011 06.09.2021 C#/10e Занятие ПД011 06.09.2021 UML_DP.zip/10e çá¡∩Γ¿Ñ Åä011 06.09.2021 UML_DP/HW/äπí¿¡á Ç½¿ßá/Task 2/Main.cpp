﻿#include "pch.h"
#include "Utils.h"
#include "MethodToTransferMoney.h"
#include "BankTransfer.h"
#include "OnlineWallet.h"
#include "PostalOrder.h"
#include "MoneyTransfer.h"
#include "Palette.h"

/*
*   Паттерн Цепочка обязанностей – разработайте макет приложения в консоли, 
*   с использованием ООП C++, STL. Моделировать работу системы перевода суммы 
*   денег адресату – через банковский перевод, почтовым переводом, через 
*   Интернет-кошелек. Конкретный объект перевода определяется в зависимости 
*   от суммы:
*       o	до 10000 – почтовый перевод
* 
*       o	до 100000 – Интернет-кошелек
* 
*       o	до 1000000 – банковский перевод
* 
*       o	не переводить сумму, превышающую 1000000
* 
*/

int main()
{
	// настройка вывода в консоль
	init(L"Задание на 06.09.2021");

    try {

        MethodToTransferMoney* postalOrder  = new PostalOrder();
        MethodToTransferMoney* onlineWallet = new OnlineWallet();
        MethodToTransferMoney* bankTransfer = new BankTransfer();

        // настройка цепочки обязанностей
        postalOrder->SetSuccessor(onlineWallet);
        onlineWallet->SetSuccessor(bankTransfer);

        // почтовый перевод
        cout << color(hintColor) << "    Перевод до 10'000:" << setw(118) << " " << color(mainColor);
        MoneyTransfer m1("Иванов И. И.", "Федоров Ф. Ф.", getRand(10., 10000.));
        postalOrder->Process(m1);
        cout << "\n\n";

        // Интернет-кошелек
        cout << color(hintColor) << "    Перевод до 100'000:" << setw(117) << " " << color(mainColor);
        MoneyTransfer m2("Иванов И. И.", "Федоров Ф. Ф.", getRand(10001., 100000.));
        postalOrder->Process(m2);
        cout << "\n\n";

        // банковский перевод
        cout << color(hintColor) << "    Перевод до 1'000'000:" << setw(115) << " " << color(mainColor);
        MoneyTransfer m3("Иванов И. И.", "Федоров Ф. Ф.", getRand(100001., 1000000.));
        postalOrder->Process(m3);
        cout << "\n\n";

        // не переводить сумму, превышающую 1'000'000
        cout << color(hintColor) << "    Перевод от 1'000'000:" << setw(115) << " " << color(mainColor);
        MoneyTransfer m4("Иванов И. И.", "Федоров Ф. Ф.", getRand(1000000., 10000000.));
        postalOrder->Process(m4);
        cout << "\n\n";

    }
    catch (exception& ex) {
        setColor(mainColor);
        cls();
        showNavBarMessage(hintColor, "  Ошибка приложения, нажмите любую клавишу для продолжения...");

        // добавим 4 пробела перед выводимым сообщением об ошибке, длина строки 64 символа
        char buf[65];
        sprintf(buf, "    %-60s", ex.what());

        // в эту секцию передается управление оператором throw
        const char* msg[] = {
            " ",
            "    [Ошибка]",
            buf,
            " ",
            " ",
            nullptr
        };
        showMessage(8, 4, 64, msg, errColor);
    } // try-catch
    cout << endlm(2);

	return 0;
} // main