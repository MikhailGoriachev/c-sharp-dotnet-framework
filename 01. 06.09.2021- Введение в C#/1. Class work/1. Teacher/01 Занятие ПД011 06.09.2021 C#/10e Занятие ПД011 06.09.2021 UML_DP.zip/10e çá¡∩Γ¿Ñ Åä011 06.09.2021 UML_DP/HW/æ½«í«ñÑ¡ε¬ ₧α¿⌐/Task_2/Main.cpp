﻿#include "Libraries.h"
#include "Handlers.h"
#include "Transfer.h"


int main()
{
	Utilities::init();
	
	Transfer transfer({
		make_unique<Mail>(),
		make_unique<Ethernet>(),
		make_unique<Bank>(),
	});

	transfer.handle(5000);
	transfer.handle(50000);
	transfer.handle(500000);

	Utilities::Console::switchCursorVisibility(false);
	Utilities::Console::setCoordInBottomLeft(3);
	return 0;
}
