#pragma once
#include "Libraries.h"


class Transfer
{	
	unique_ptr<Transfer> _nextHandler {};

public:
	Transfer() = default;
	
	Transfer(initializer_list<unique_ptr<Transfer>>&& chain)
	{
		list<unique_ptr<Transfer>> deq;

		for (auto& PTR : chain)
			deq.push_back(move(const_cast<unique_ptr<Transfer>&>(PTR)));
		
		while (!deq.empty())
			add(move(deq.front())), deq.pop_front();
	}

	Transfer& add(unique_ptr<Transfer> next)
	{
		return _nextHandler != nullptr
				   ? _nextHandler->add(move(next))
				   : (_nextHandler = move(next), *this);
	}

	virtual void handle(unsigned sum)
	{
		if (_nextHandler != nullptr)
			_nextHandler->handle(sum);
	}
};
