#include "Libraries.h"
#include "Grant.h"


int main()
{
	Utilities::init();

	Grant grant("Name"s, "Course"s, 11.);
	while (grant.review());
	
	Utilities::Console::switchCursorVisibility(false);
	Utilities::Console::setCoordInBottomLeft(3);
	return 0;
} 