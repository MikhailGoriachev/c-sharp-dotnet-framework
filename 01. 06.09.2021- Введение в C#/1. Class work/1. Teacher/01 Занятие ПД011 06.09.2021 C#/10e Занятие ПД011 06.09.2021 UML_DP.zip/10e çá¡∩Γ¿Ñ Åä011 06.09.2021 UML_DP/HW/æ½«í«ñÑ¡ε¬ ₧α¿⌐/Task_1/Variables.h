#pragma once


#pragma region �����


using ColorCode = unsigned short;


namespace Colors
{


	namespace SingleColor
	{


		constexpr ColorCode BLACK = 0b0000;
		constexpr ColorCode BLUE = 0b0001;
		constexpr ColorCode GREEN = 0b0010;
		constexpr ColorCode CYAN = 0b0011;
		constexpr ColorCode RED = 0b0100;
		constexpr ColorCode MAGENTA = 0b0101;
		constexpr ColorCode YELLOW = 0b0110;
		constexpr ColorCode GRAY = 0b0111;

		constexpr ColorCode LTBLACK = 0b1000;
		constexpr ColorCode LTBLUE = 0b1001;
		constexpr ColorCode LTGREEN = 0b1010;
		constexpr ColorCode LTCYAN = 0b1011;
		constexpr ColorCode LTRED = 0b1100;
		constexpr ColorCode LTMAGENTA = 0b1101;
		constexpr ColorCode LTYELLOW = 0b1110;
		constexpr ColorCode WHITE = 0b1111;


	} // SingleColor


	namespace OnBlack
	{


		// ����� �� ������ ����
		constexpr ColorCode BLACK_ON_BLACK = SingleColor::BLACK | SingleColor::BLACK << 4;
		constexpr ColorCode BLUE_ON_BLACK = SingleColor::BLUE | SingleColor::BLACK << 4;
		constexpr ColorCode GREEN_ON_BLACK = SingleColor::GREEN | SingleColor::BLACK << 4;
		constexpr ColorCode CYAN_ON_BLACK = SingleColor::CYAN | SingleColor::BLACK << 4;
		constexpr ColorCode RED_ON_BLACK = SingleColor::RED | SingleColor::BLACK << 4;
		constexpr ColorCode MAGENTA_ON_BLACK = SingleColor::MAGENTA | SingleColor::BLACK << 4;
		constexpr ColorCode YELLOW_ON_BLACK = SingleColor::YELLOW | SingleColor::BLACK << 4;
		constexpr ColorCode GRAY_ON_BLACK = SingleColor::GRAY | SingleColor::BLACK << 4;

		constexpr ColorCode LTBLACK_ON_BLACK = SingleColor::LTBLACK | SingleColor::BLACK << 4;
		constexpr ColorCode LTBLUE_ON_BLACK = SingleColor::LTBLUE | SingleColor::BLACK << 4;
		constexpr ColorCode LTGREEN_ON_BLACK = SingleColor::LTGREEN | SingleColor::BLACK << 4;
		constexpr ColorCode LTCYAN_ON_BLACK = SingleColor::LTCYAN | SingleColor::BLACK << 4;
		constexpr ColorCode LTRED_ON_BLACK = SingleColor::LTRED | SingleColor::BLACK << 4;
		constexpr ColorCode LTMAGENTA_ON_BLACK = SingleColor::LTMAGENTA | SingleColor::BLACK << 4;
		constexpr ColorCode LTYELLOW_ON_BLACK = SingleColor::LTYELLOW | SingleColor::BLACK << 4;
		constexpr ColorCode WHITE_ON_BLACK = SingleColor::WHITE | SingleColor::BLACK << 4;


	} // OnBlack


	namespace OnBlue
	{


		constexpr ColorCode BLACK_ON_BLUE = SingleColor::BLACK | SingleColor::BLUE << 4;
		constexpr ColorCode BLUE_ON_BLUE = SingleColor::BLUE | SingleColor::BLUE << 4;
		constexpr ColorCode GREEN_ON_BLUE = SingleColor::GREEN | SingleColor::BLUE << 4;
		constexpr ColorCode CYAN_ON_BLUE = SingleColor::CYAN | SingleColor::BLUE << 4;
		constexpr ColorCode RED_ON_BLUE = SingleColor::RED | SingleColor::BLUE << 4;
		constexpr ColorCode MAGENTA_ON_BLUE = SingleColor::MAGENTA | SingleColor::BLUE << 4;
		constexpr ColorCode YELLOW_ON_BLUE = SingleColor::YELLOW | SingleColor::BLUE << 4;
		constexpr ColorCode GRAY_ON_BLUE = SingleColor::GRAY | SingleColor::BLUE << 4;

		constexpr ColorCode LTBLACK_ON_BLUE = SingleColor::LTBLACK | SingleColor::BLUE << 4;
		constexpr ColorCode LTBLUE_ON_BLUE = SingleColor::LTBLUE | SingleColor::BLUE << 4;
		constexpr ColorCode LTGREEN_ON_BLUE = SingleColor::LTGREEN | SingleColor::BLUE << 4;
		constexpr ColorCode LTCYAN_ON_BLUE = SingleColor::LTCYAN | SingleColor::BLUE << 4;
		constexpr ColorCode LTRED_ON_BLUE = SingleColor::LTRED | SingleColor::BLUE << 4;
		constexpr ColorCode LTMAGENTA_ON_BLUE = SingleColor::LTMAGENTA | SingleColor::BLUE << 4;
		constexpr ColorCode LTYELLOW_ON_BLUE = SingleColor::LTYELLOW | SingleColor::BLUE << 4;
		constexpr ColorCode WHITE_ON_BLUE = SingleColor::WHITE | SingleColor::BLUE << 4;


	} // OnBlue


	namespace OnGreen
	{


		constexpr ColorCode BLACK_ON_GREEN = SingleColor::BLACK | SingleColor::GREEN << 4;
		constexpr ColorCode BLUE_ON_GREEN = SingleColor::BLUE | SingleColor::GREEN << 4;
		constexpr ColorCode GREEN_ON_GREEN = SingleColor::GREEN | SingleColor::GREEN << 4;
		constexpr ColorCode CYAN_ON_GREEN = SingleColor::CYAN | SingleColor::GREEN << 4;
		constexpr ColorCode RED_ON_GREEN = SingleColor::RED | SingleColor::GREEN << 4;
		constexpr ColorCode MAGENTA_ON_GREEN = SingleColor::MAGENTA | SingleColor::GREEN << 4;
		constexpr ColorCode YELLOW_ON_GREEN = SingleColor::YELLOW | SingleColor::GREEN << 4;
		constexpr ColorCode GRAY_ON_GREEN = SingleColor::GRAY | SingleColor::GREEN << 4;

		constexpr ColorCode LTBLACK_ON_GREEN = SingleColor::LTBLACK | SingleColor::GREEN << 4;
		constexpr ColorCode LTBLUE_ON_GREEN = SingleColor::LTBLUE | SingleColor::GREEN << 4;
		constexpr ColorCode LTGREEN_ON_GREEN = SingleColor::LTGREEN | SingleColor::GREEN << 4;
		constexpr ColorCode LTCYAN_ON_GREEN = SingleColor::LTCYAN | SingleColor::GREEN << 4;
		constexpr ColorCode LTRED_ON_GREEN = SingleColor::LTRED | SingleColor::GREEN << 4;
		constexpr ColorCode LTMAGENTA_ON_GREEN = SingleColor::LTMAGENTA | SingleColor::GREEN << 4;
		constexpr ColorCode LTYELLOW_ON_GREEN = SingleColor::LTYELLOW | SingleColor::GREEN << 4;
		constexpr ColorCode WHITE_ON_GREEN = SingleColor::WHITE | SingleColor::GREEN << 4;


	} // OnGreen


	namespace OnCyan
	{


		constexpr ColorCode BLACK_ON_CYAN = SingleColor::BLACK | SingleColor::CYAN << 4;
		constexpr ColorCode BLUE_ON_CYAN = SingleColor::BLUE | SingleColor::CYAN << 4;
		constexpr ColorCode GREEN_ON_CYAN = SingleColor::GREEN | SingleColor::CYAN << 4;
		constexpr ColorCode CYAN_ON_CYAN = SingleColor::CYAN | SingleColor::CYAN << 4;
		constexpr ColorCode RED_ON_CYAN = SingleColor::RED | SingleColor::CYAN << 4;
		constexpr ColorCode MAGENTA_ON_CYAN = SingleColor::MAGENTA | SingleColor::CYAN << 4;
		constexpr ColorCode YELLOW_ON_CYAN = SingleColor::YELLOW | SingleColor::CYAN << 4;
		constexpr ColorCode GRAY_ON_CYAN = SingleColor::GRAY | SingleColor::CYAN << 4;

		constexpr ColorCode LTBLACK_ON_CYAN = SingleColor::LTBLACK | SingleColor::CYAN << 4;
		constexpr ColorCode LTBLUE_ON_CYAN = SingleColor::LTBLUE | SingleColor::CYAN << 4;
		constexpr ColorCode LTGREEN_ON_CYAN = SingleColor::LTGREEN | SingleColor::CYAN << 4;
		constexpr ColorCode LTCYAN_ON_CYAN = SingleColor::LTCYAN | SingleColor::CYAN << 4;
		constexpr ColorCode LTRED_ON_CYAN = SingleColor::LTRED | SingleColor::CYAN << 4;
		constexpr ColorCode LTMAGENTA_ON_CYAN = SingleColor::LTMAGENTA | SingleColor::CYAN << 4;
		constexpr ColorCode LTYELLOW_ON_CYAN = SingleColor::LTYELLOW | SingleColor::CYAN << 4;
		constexpr ColorCode WHITE_ON_CYAN = SingleColor::WHITE | SingleColor::CYAN << 4;


	} // OnCyan


	namespace OnRed
	{


		constexpr ColorCode BLACK_ON_RED = SingleColor::BLACK | SingleColor::RED << 4;
		constexpr ColorCode BLUE_ON_RED = SingleColor::BLUE | SingleColor::RED << 4;
		constexpr ColorCode GREEN_ON_RED = SingleColor::GREEN | SingleColor::RED << 4;
		constexpr ColorCode CYAN_ON_RED = SingleColor::CYAN | SingleColor::RED << 4;
		constexpr ColorCode RED_ON_RED = SingleColor::RED | SingleColor::RED << 4;
		constexpr ColorCode MAGENTA_ON_RED = SingleColor::MAGENTA | SingleColor::RED << 4;
		constexpr ColorCode YELLOW_ON_RED = SingleColor::YELLOW | SingleColor::RED << 4;
		constexpr ColorCode GRAY_ON_RED = SingleColor::GRAY | SingleColor::RED << 4;

		constexpr ColorCode LTBLACK_ON_RED = SingleColor::LTBLACK | SingleColor::RED << 4;
		constexpr ColorCode LTBLUE_ON_RED = SingleColor::LTBLUE | SingleColor::RED << 4;
		constexpr ColorCode LTGREEN_ON_RED = SingleColor::LTGREEN | SingleColor::RED << 4;
		constexpr ColorCode LTCYAN_ON_RED = SingleColor::LTCYAN | SingleColor::RED << 4;
		constexpr ColorCode LTRED_ON_RED = SingleColor::LTRED | SingleColor::RED << 4;
		constexpr ColorCode LTMAGENTA_ON_RED = SingleColor::LTMAGENTA | SingleColor::RED << 4;
		constexpr ColorCode LTYELLOW_ON_RED = SingleColor::LTYELLOW | SingleColor::RED << 4;
		constexpr ColorCode WHITE_ON_RED = SingleColor::WHITE | SingleColor::RED << 4;


	} // OnRed


	namespace OnMagenta
	{


		constexpr ColorCode BLACK_ON_MAGENTA = SingleColor::BLACK | SingleColor::MAGENTA << 4;
		constexpr ColorCode BLUE_ON_MAGENTA = SingleColor::BLUE | SingleColor::MAGENTA << 4;
		constexpr ColorCode GREEN_ON_MAGENTA = SingleColor::GREEN | SingleColor::MAGENTA << 4;
		constexpr ColorCode CYAN_ON_MAGENTA = SingleColor::CYAN | SingleColor::MAGENTA << 4;
		constexpr ColorCode RED_ON_MAGENTA = SingleColor::RED | SingleColor::MAGENTA << 4;
		constexpr ColorCode MAGENTA_ON_MAGENTA = SingleColor::MAGENTA | SingleColor::MAGENTA << 4;
		constexpr ColorCode YELLOW_ON_MAGENTA = SingleColor::YELLOW | SingleColor::MAGENTA << 4;
		constexpr ColorCode GRAY_ON_MAGENTA = SingleColor::GRAY | SingleColor::MAGENTA << 4;

		constexpr ColorCode LTBLACK_ON_MAGENTA = SingleColor::LTBLACK | SingleColor::MAGENTA << 4;
		constexpr ColorCode LTBLUE_ON_MAGENTA = SingleColor::LTBLUE | SingleColor::MAGENTA << 4;
		constexpr ColorCode LTGREEN_ON_MAGENTA = SingleColor::LTGREEN | SingleColor::MAGENTA << 4;
		constexpr ColorCode LTCYAN_ON_MAGENTA = SingleColor::LTCYAN | SingleColor::MAGENTA << 4;
		constexpr ColorCode LTRED_ON_MAGENTA = SingleColor::LTRED | SingleColor::MAGENTA << 4;
		constexpr ColorCode LTMAGENTA_ON_MAGENTA = SingleColor::LTMAGENTA | SingleColor::MAGENTA << 4;
		constexpr ColorCode LTYELLOW_ON_MAGENTA = SingleColor::LTYELLOW | SingleColor::MAGENTA << 4;
		constexpr ColorCode WHITE_ON_MAGENTA = SingleColor::WHITE | SingleColor::MAGENTA << 4;


	} // OnMagenta


	namespace OnYellow
	{


		constexpr ColorCode BLACK_ON_YELLOW = SingleColor::BLACK | SingleColor::YELLOW << 4;
		constexpr ColorCode BLUE_ON_YELLOW = SingleColor::BLUE | SingleColor::YELLOW << 4;
		constexpr ColorCode GREEN_ON_YELLOW = SingleColor::GREEN | SingleColor::YELLOW << 4;
		constexpr ColorCode CYAN_ON_YELLOW = SingleColor::CYAN | SingleColor::YELLOW << 4;
		constexpr ColorCode RED_ON_YELLOW = SingleColor::RED | SingleColor::YELLOW << 4;
		constexpr ColorCode MAGENTA_ON_YELLOW = SingleColor::MAGENTA | SingleColor::YELLOW << 4;
		constexpr ColorCode YELLOW_ON_YELLOW = SingleColor::YELLOW | SingleColor::YELLOW << 4;
		constexpr ColorCode GRAY_ON_YELLOW = SingleColor::GRAY | SingleColor::YELLOW << 4;

		constexpr ColorCode LTBLACK_ON_YELLOW = SingleColor::LTBLACK | SingleColor::YELLOW << 4;
		constexpr ColorCode LTBLUE_ON_YELLOW = SingleColor::LTBLUE | SingleColor::YELLOW << 4;
		constexpr ColorCode LTGREEN_ON_YELLOW = SingleColor::LTGREEN | SingleColor::YELLOW << 4;
		constexpr ColorCode LTCYAN_ON_YELLOW = SingleColor::LTCYAN | SingleColor::YELLOW << 4;
		constexpr ColorCode LTRED_ON_YELLOW = SingleColor::LTRED | SingleColor::YELLOW << 4;
		constexpr ColorCode LTMAGENTA_ON_YELLOW = SingleColor::LTMAGENTA | SingleColor::YELLOW << 4;
		constexpr ColorCode LTYELLOW_ON_YELLOW = SingleColor::LTYELLOW | SingleColor::YELLOW << 4;
		constexpr ColorCode WHITE_ON_YELLOW = SingleColor::WHITE | SingleColor::YELLOW << 4;


	} // OnYellow


	namespace OnGray
	{


		constexpr ColorCode BLACK_ON_GRAY = SingleColor::BLACK | SingleColor::GRAY << 4;
		constexpr ColorCode BLUE_ON_GRAY = SingleColor::BLUE | SingleColor::GRAY << 4;
		constexpr ColorCode GREEN_ON_GRAY = SingleColor::GREEN | SingleColor::GRAY << 4;
		constexpr ColorCode CYAN_ON_GRAY = SingleColor::CYAN | SingleColor::GRAY << 4;
		constexpr ColorCode RED_ON_GRAY = SingleColor::RED | SingleColor::GRAY << 4;
		constexpr ColorCode MAGENTA_ON_GRAY = SingleColor::MAGENTA | SingleColor::GRAY << 4;
		constexpr ColorCode YELLOW_ON_GRAY = SingleColor::YELLOW | SingleColor::GRAY << 4;
		constexpr ColorCode GRAY_ON_GRAY = SingleColor::GRAY | SingleColor::GRAY << 4;

		constexpr ColorCode LTBLACK_ON_GRAY = SingleColor::LTBLACK | SingleColor::GRAY << 4;
		constexpr ColorCode LTBLUE_ON_GRAY = SingleColor::LTBLUE | SingleColor::GRAY << 4;
		constexpr ColorCode LTGREEN_ON_GRAY = SingleColor::LTGREEN | SingleColor::GRAY << 4;
		constexpr ColorCode LTCYAN_ON_GRAY = SingleColor::LTCYAN | SingleColor::GRAY << 4;
		constexpr ColorCode LTRED_ON_GRAY = SingleColor::LTRED | SingleColor::GRAY << 4;
		constexpr ColorCode LTMAGENTA_ON_GRAY = SingleColor::LTMAGENTA | SingleColor::GRAY << 4;
		constexpr ColorCode LTYELLOW_ON_GRAY = SingleColor::LTYELLOW | SingleColor::GRAY << 4;
		constexpr ColorCode WHITE_ON_GRAY = SingleColor::WHITE | SingleColor::GRAY << 4;


	} // OnGray


	namespace OnLightBlack
	{


		constexpr ColorCode BLACK_ON_LTBLACK = SingleColor::BLACK | SingleColor::LTBLACK << 4;
		constexpr ColorCode BLUE_ON_LTBLACK = SingleColor::BLUE | SingleColor::LTBLACK << 4;
		constexpr ColorCode GREEN_ON_LTBLACK = SingleColor::GREEN | SingleColor::LTBLACK << 4;
		constexpr ColorCode CYAN_ON_LTBLACK = SingleColor::CYAN | SingleColor::LTBLACK << 4;
		constexpr ColorCode RED_ON_LTBLACK = SingleColor::RED | SingleColor::LTBLACK << 4;
		constexpr ColorCode MAGENTA_ON_LTBLACK = SingleColor::MAGENTA | SingleColor::LTBLACK << 4;
		constexpr ColorCode YELLOW_ON_LTBLACK = SingleColor::YELLOW | SingleColor::LTBLACK << 4;
		constexpr ColorCode GRAY_ON_LTBLACK = SingleColor::GRAY | SingleColor::LTBLACK << 4;

		constexpr ColorCode LTBLACK_ON_LTBLACK = SingleColor::LTBLACK | SingleColor::LTBLACK << 4;
		constexpr ColorCode LTBLUE_ON_LTBLACK = SingleColor::LTBLUE | SingleColor::LTBLACK << 4;
		constexpr ColorCode LTGREEN_ON_LTBLACK = SingleColor::LTGREEN | SingleColor::LTBLACK << 4;
		constexpr ColorCode LTCYAN_ON_LTBLACK = SingleColor::LTCYAN | SingleColor::LTBLACK << 4;
		constexpr ColorCode LTRED_ON_LTBLACK = SingleColor::LTRED | SingleColor::LTBLACK << 4;
		constexpr ColorCode LTMAGENTA_ON_LTBLACK = SingleColor::LTMAGENTA | SingleColor::LTBLACK << 4;
		constexpr ColorCode LTYELLOW_ON_LTBLACK = SingleColor::LTYELLOW | SingleColor::LTBLACK << 4;
		constexpr ColorCode WHITE_ON_LTBLACK = SingleColor::WHITE | SingleColor::LTBLACK << 4;


	} // OnLightBlack


	namespace OnLightBlue
	{


		constexpr ColorCode BLACK_ON_LTBLUE = SingleColor::BLACK | SingleColor::LTBLUE << 4;
		constexpr ColorCode BLUE_ON_LTBLUE = SingleColor::BLUE | SingleColor::LTBLUE << 4;
		constexpr ColorCode GREEN_ON_LTBLUE = SingleColor::GREEN | SingleColor::LTBLUE << 4;
		constexpr ColorCode CYAN_ON_LTBLUE = SingleColor::CYAN | SingleColor::LTBLUE << 4;
		constexpr ColorCode RED_ON_LTBLUE = SingleColor::RED | SingleColor::LTBLUE << 4;
		constexpr ColorCode MAGENTA_ON_LTBLUE = SingleColor::MAGENTA | SingleColor::LTBLUE << 4;
		constexpr ColorCode YELLOW_ON_LTBLUE = SingleColor::YELLOW | SingleColor::LTBLUE << 4;
		constexpr ColorCode GRAY_ON_LTBLUE = SingleColor::GRAY | SingleColor::LTBLUE << 4;

		constexpr ColorCode LTBLACK_ON_LTBLUE = SingleColor::LTBLACK | SingleColor::LTBLUE << 4;
		constexpr ColorCode LTBLUE_ON_LTBLUE = SingleColor::LTBLUE | SingleColor::LTBLUE << 4;
		constexpr ColorCode LTGREEN_ON_LTBLUE = SingleColor::LTGREEN | SingleColor::LTBLUE << 4;
		constexpr ColorCode LTCYAN_ON_LTBLUE = SingleColor::LTCYAN | SingleColor::LTBLUE << 4;
		constexpr ColorCode LTRED_ON_LTBLUE = SingleColor::LTRED | SingleColor::LTBLUE << 4;
		constexpr ColorCode LTMAGENTA_ON_LTBLUE = SingleColor::LTMAGENTA | SingleColor::LTBLUE << 4;
		constexpr ColorCode LTYELLOW_ON_LTBLUE = SingleColor::LTYELLOW | SingleColor::LTBLUE << 4;
		constexpr ColorCode WHITE_ON_LTBLUE = SingleColor::WHITE | SingleColor::LTBLUE << 4;


	} // OnLightBlue


	namespace OnLightGreen
	{


		constexpr ColorCode BLACK_ON_LTGREEN = SingleColor::BLACK | SingleColor::LTGREEN << 4;
		constexpr ColorCode BLUE_ON_LTGREEN = SingleColor::BLUE | SingleColor::LTGREEN << 4;
		constexpr ColorCode GREEN_ON_LTGREEN = SingleColor::GREEN | SingleColor::LTGREEN << 4;
		constexpr ColorCode CYAN_ON_LTGREEN = SingleColor::CYAN | SingleColor::LTGREEN << 4;
		constexpr ColorCode RED_ON_LTGREEN = SingleColor::RED | SingleColor::LTGREEN << 4;
		constexpr ColorCode MAGENTA_ON_LTGREEN = SingleColor::MAGENTA | SingleColor::LTGREEN << 4;
		constexpr ColorCode YELLOW_ON_LTGREEN = SingleColor::YELLOW | SingleColor::LTGREEN << 4;
		constexpr ColorCode GRAY_ON_LTGREEN = SingleColor::GRAY | SingleColor::LTGREEN << 4;

		constexpr ColorCode LTBLACK_ON_LTGREEN = SingleColor::LTBLACK | SingleColor::LTGREEN << 4;
		constexpr ColorCode LTBLUE_ON_LTGREEN = SingleColor::LTBLUE | SingleColor::LTGREEN << 4;
		constexpr ColorCode LTGREEN_ON_LTGREEN = SingleColor::LTGREEN | SingleColor::LTGREEN << 4;
		constexpr ColorCode LTCYAN_ON_LTGREEN = SingleColor::LTCYAN | SingleColor::LTGREEN << 4;
		constexpr ColorCode LTRED_ON_LTGREEN = SingleColor::LTRED | SingleColor::LTGREEN << 4;
		constexpr ColorCode LTMAGENTA_ON_LTGREEN = SingleColor::LTMAGENTA | SingleColor::LTGREEN << 4;
		constexpr ColorCode LTYELLOW_ON_LTGREEN = SingleColor::LTYELLOW | SingleColor::LTGREEN << 4;
		constexpr ColorCode WHITE_ON_LTGREEN = SingleColor::WHITE | SingleColor::LTGREEN << 4;


	} // OnLightGreen


	namespace OnLightCyan
	{


		constexpr ColorCode BLACK_ON_LTCYAN = SingleColor::BLACK | SingleColor::LTCYAN << 4;
		constexpr ColorCode BLUE_ON_LTCYAN = SingleColor::BLUE | SingleColor::LTCYAN << 4;
		constexpr ColorCode GREEN_ON_LTCYAN = SingleColor::GREEN | SingleColor::LTCYAN << 4;
		constexpr ColorCode CYAN_ON_LTCYAN = SingleColor::CYAN | SingleColor::LTCYAN << 4;
		constexpr ColorCode RED_ON_LTCYAN = SingleColor::RED | SingleColor::LTCYAN << 4;
		constexpr ColorCode MAGENTA_ON_LTCYAN = SingleColor::MAGENTA | SingleColor::LTCYAN << 4;
		constexpr ColorCode YELLOW_ON_LTCYAN = SingleColor::YELLOW | SingleColor::LTCYAN << 4;
		constexpr ColorCode GRAY_ON_LTCYAN = SingleColor::GRAY | SingleColor::LTCYAN << 4;

		constexpr ColorCode LTBLACK_ON_LTCYAN = SingleColor::LTBLACK | SingleColor::LTCYAN << 4;
		constexpr ColorCode LTBLUE_ON_LTCYAN = SingleColor::LTBLUE | SingleColor::LTCYAN << 4;
		constexpr ColorCode LTGREEN_ON_LTCYAN = SingleColor::LTGREEN | SingleColor::LTCYAN << 4;
		constexpr ColorCode LTCYAN_ON_LTCYAN = SingleColor::LTCYAN | SingleColor::LTCYAN << 4;
		constexpr ColorCode LTRED_ON_LTCYAN = SingleColor::LTRED | SingleColor::LTCYAN << 4;
		constexpr ColorCode LTMAGENTA_ON_LTCYAN = SingleColor::LTMAGENTA | SingleColor::LTCYAN << 4;
		constexpr ColorCode LTYELLOW_ON_LTCYAN = SingleColor::LTYELLOW | SingleColor::LTCYAN << 4;
		constexpr ColorCode WHITE_ON_LTCYAN = SingleColor::WHITE | SingleColor::LTCYAN << 4;


	} // OnLightCyan


	namespace OnLightRed
	{


		constexpr ColorCode BLACK_ON_LTRED = SingleColor::BLACK | SingleColor::LTRED << 4;
		constexpr ColorCode BLUE_ON_LTRED = SingleColor::BLUE | SingleColor::LTRED << 4;
		constexpr ColorCode GREEN_ON_LTRED = SingleColor::GREEN | SingleColor::LTRED << 4;
		constexpr ColorCode CYAN_ON_LTRED = SingleColor::CYAN | SingleColor::LTRED << 4;
		constexpr ColorCode RED_ON_LTRED = SingleColor::RED | SingleColor::LTRED << 4;
		constexpr ColorCode MAGENTA_ON_LTRED = SingleColor::MAGENTA | SingleColor::LTRED << 4;
		constexpr ColorCode YELLOW_ON_LTRED = SingleColor::YELLOW | SingleColor::LTRED << 4;
		constexpr ColorCode GRAY_ON_LTRED = SingleColor::GRAY | SingleColor::LTRED << 4;

		constexpr ColorCode LTBLACK_ON_LTRED = SingleColor::LTBLACK | SingleColor::LTRED << 4;
		constexpr ColorCode LTBLUE_ON_LTRED = SingleColor::LTBLUE | SingleColor::LTRED << 4;
		constexpr ColorCode LTGREEN_ON_LTRED = SingleColor::LTGREEN | SingleColor::LTRED << 4;
		constexpr ColorCode LTCYAN_ON_LTRED = SingleColor::LTCYAN | SingleColor::LTRED << 4;
		constexpr ColorCode LTRED_ON_LTRED = SingleColor::LTRED | SingleColor::LTRED << 4;
		constexpr ColorCode LTMAGENTA_ON_LTRED = SingleColor::LTMAGENTA | SingleColor::LTRED << 4;
		constexpr ColorCode LTYELLOW_ON_LTRED = SingleColor::LTYELLOW | SingleColor::LTRED << 4;
		constexpr ColorCode WHITE_ON_LTRED = SingleColor::WHITE | SingleColor::LTRED << 4;


	} // OnLightRed


	namespace OnLightMagenta
	{


		constexpr ColorCode BLACK_ON_LTMAGENTA = SingleColor::BLACK | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode BLUE_ON_LTMAGENTA = SingleColor::BLUE | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode GREEN_ON_LTMAGENTA = SingleColor::GREEN | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode CYAN_ON_LTMAGENTA = SingleColor::CYAN | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode RED_ON_LTMAGENTA = SingleColor::RED | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode MAGENTA_ON_LTMAGENTA = SingleColor::MAGENTA | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode YELLOW_ON_LTMAGENTA = SingleColor::YELLOW | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode GRAY_ON_LTMAGENTA = SingleColor::GRAY | SingleColor::LTMAGENTA << 4;

		constexpr ColorCode LTBLACK_ON_LTMAGENTA = SingleColor::LTBLACK | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode LTBLUE_ON_LTMAGENTA = SingleColor::LTBLUE | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode LTGREEN_ON_LTMAGENTA = SingleColor::LTGREEN | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode LTCYAN_ON_LTMAGENTA = SingleColor::LTCYAN | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode LTRED_ON_LTMAGENTA = SingleColor::LTRED | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode LTMAGENTA_ON_LTMAGENTA = SingleColor::LTMAGENTA | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode LTYELLOW_ON_LTMAGENTA = SingleColor::LTYELLOW | SingleColor::LTMAGENTA << 4;
		constexpr ColorCode WHITE_ON_LTMAGENTA = SingleColor::WHITE | SingleColor::LTMAGENTA << 4;


	} // OnLightMagenta


	namespace OnLightYellow
	{


		constexpr ColorCode BLACK_ON_LTYELLOW = SingleColor::BLACK | SingleColor::LTYELLOW << 4;
		constexpr ColorCode BLUE_ON_LTYELLOW = SingleColor::BLUE | SingleColor::LTYELLOW << 4;
		constexpr ColorCode GREEN_ON_LTYELLOW = SingleColor::GREEN | SingleColor::LTYELLOW << 4;
		constexpr ColorCode CYAN_ON_LTYELLOW = SingleColor::CYAN | SingleColor::LTYELLOW << 4;
		constexpr ColorCode RED_ON_LTYELLOW = SingleColor::RED | SingleColor::LTYELLOW << 4;
		constexpr ColorCode MAGENTA_ON_LTYELLOW = SingleColor::MAGENTA | SingleColor::LTYELLOW << 4;
		constexpr ColorCode YELLOW_ON_LTYELLOW = SingleColor::YELLOW | SingleColor::LTYELLOW << 4;
		constexpr ColorCode GRAY_ON_LTYELLOW = SingleColor::GRAY | SingleColor::LTYELLOW << 4;

		constexpr ColorCode LTBLACK_ON_LTYELLOW = SingleColor::LTBLACK | SingleColor::LTYELLOW << 4;
		constexpr ColorCode LTBLUE_ON_LTYELLOW = SingleColor::LTBLUE | SingleColor::LTYELLOW << 4;
		constexpr ColorCode LTGREEN_ON_LTYELLOW = SingleColor::LTGREEN | SingleColor::LTYELLOW << 4;
		constexpr ColorCode LTCYAN_ON_LTYELLOW = SingleColor::LTCYAN | SingleColor::LTYELLOW << 4;
		constexpr ColorCode LTRED_ON_LTYELLOW = SingleColor::LTRED | SingleColor::LTYELLOW << 4;
		constexpr ColorCode LTMAGENTA_ON_LTYELLOW = SingleColor::LTMAGENTA | SingleColor::LTYELLOW << 4;
		constexpr ColorCode LTYELLOW_ON_LTYELLOW = SingleColor::LTYELLOW | SingleColor::LTYELLOW << 4;
		constexpr ColorCode WHITE_ON_LTYELLOW = SingleColor::WHITE | SingleColor::LTYELLOW << 4;


	} // OnLightYellow


	namespace OnWhite
	{


		constexpr ColorCode BLACK_ON_WHITE = SingleColor::BLACK | SingleColor::WHITE << 4;
		constexpr ColorCode BLUE_ON_WHITE = SingleColor::BLUE | SingleColor::WHITE << 4;
		constexpr ColorCode GREEN_ON_WHITE = SingleColor::GREEN | SingleColor::WHITE << 4;
		constexpr ColorCode CYAN_ON_WHITE = SingleColor::CYAN | SingleColor::WHITE << 4;
		constexpr ColorCode RED_ON_WHITE = SingleColor::RED | SingleColor::WHITE << 4;
		constexpr ColorCode MAGENTA_ON_WHITE = SingleColor::MAGENTA | SingleColor::WHITE << 4;
		constexpr ColorCode YELLOW_ON_WHITE = SingleColor::YELLOW | SingleColor::WHITE << 4;
		constexpr ColorCode GRAY_ON_WHITE = SingleColor::GRAY | SingleColor::WHITE << 4;

		constexpr ColorCode LTBLACK_ON_WHITE = SingleColor::LTBLACK | SingleColor::WHITE << 4;
		constexpr ColorCode LTBLUE_ON_WHITE = SingleColor::LTBLUE | SingleColor::WHITE << 4;
		constexpr ColorCode LTGREEN_ON_WHITE = SingleColor::LTGREEN | SingleColor::WHITE << 4;
		constexpr ColorCode LTCYAN_ON_WHITE = SingleColor::LTCYAN | SingleColor::WHITE << 4;
		constexpr ColorCode LTRED_ON_WHITE = SingleColor::LTRED | SingleColor::WHITE << 4;
		constexpr ColorCode LTMAGENTA_ON_WHITE = SingleColor::LTMAGENTA | SingleColor::WHITE << 4;
		constexpr ColorCode LTYELLOW_ON_WHITE = SingleColor::LTYELLOW | SingleColor::WHITE << 4;
		constexpr ColorCode WHITE_ON_WHITE = SingleColor::WHITE | SingleColor::WHITE << 4;


	} // OnWhite


} // Colors


namespace Output
{


	constexpr ColorCode DEFAULT{ Colors::OnLightBlack::BLACK_ON_LTBLACK };
	constexpr ColorCode WRONG{ Colors::OnLightBlack::RED_ON_LTBLACK };
	constexpr ColorCode INFO{ Colors::OnLightBlack::LTCYAN_ON_LTBLACK };

	constexpr ColorCode ACCENT{ Colors::OnLightBlack::LTGREEN_ON_LTBLACK };
	constexpr ColorCode ACCENT_DEDICATED{ Colors::OnGray::LTGREEN_ON_GRAY };

	constexpr ColorCode SECONDARY{ Colors::OnLightBlack::LTMAGENTA_ON_LTBLACK };
	constexpr ColorCode SECONDARY_DEDICATED{ Colors::OnGray::LTMAGENTA_ON_GRAY };

	constexpr ColorCode TERTIARY{ Colors::OnLightBlack::LTYELLOW_ON_LTBLACK };
	constexpr ColorCode TERTIARY_DEDICATED{ Colors::OnGray::YELLOW_ON_GRAY };


} // Output


#pragma endregion


#pragma region ���� ������


using KeyCode = unsigned char;


namespace Keys
{


	namespace FKeys
	{
		enum
		{
			F1 = 59, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11 = 133, F12
		};
	} // FKeys


	namespace Services
	{

		
		enum
		{
			ENTER = 13,
			BACKSPACE = 8, TAB,
			ESC = 27,
			SPACE = 32
		};

		
	} // Services


	namespace Letters
	{
		enum
		{
			A = 97, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z
		};
	} // Letters


	namespace Arrows
	{


		enum
		{
			UP = 72,
			DOWN = 80,
			RIGHT = 77,
			LEFT = 75,
		};

		
	} // Arrows


	namespace Numbers
	{
		enum
		{
			NUM0 = 48, NUM1, NUM2, NUM3, NUM4, NUM5, NUM6, NUM7, NUM8, NUM9,
		};
	} // Numbers


} // Keys


#pragma endregion


#pragma region ������


constexpr short ENCODING{ 1251 };


static HANDLE h_Console{ GetStdHandle(STD_OUTPUT_HANDLE) };


enum class Access
{
	EXISTS = 00,
	ONLY_WRITE = 02,
	ONLY_READ = 04,
	WRITE_READ = 06
};


#pragma endregion