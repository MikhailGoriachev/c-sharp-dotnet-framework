#pragma once
#include "pch.h"

class Context;

class BaseState
{
public:
	BaseState(){}
	~BaseState() {}

	virtual void Handle(Context* context) = 0;
	virtual string GetNameOfState()const = 0;
};