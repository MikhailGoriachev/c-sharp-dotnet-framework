﻿#ifndef PCH_H
#define PCH_H

// TODO: add headers that you want to pre-compile here
#define _USE_MATH_DEFINES
#define _CRT_SECURE_NO_WARNINGS

#include <iostream>  // этот файл делает доступными инженерные функции  
#include <iomanip>   // для манипуляторов вывода setw(), setprecision()
#include <Windows.h>
#include <conio.h>
#include <sstream>   // для работы со строковым потоком вывода

#include <sstream>   // для работы со строковым потоком вывода
#include <fstream>   // для работы со файловыми потоками ввода/вывода

#include <vector>    // подключение класса vector
#include <deque>     // подключение класса deque
#include <list>      // двусвязный список
#include <stack>     // двусвязный стек
#include <queue>     // очередь

using namespace std;

// объявление символической константы - кодовой страницы
#define CODE_PAGE 1251



// команда очистки консоли
#define CLEAR "cls"

#endif //PCH_H
