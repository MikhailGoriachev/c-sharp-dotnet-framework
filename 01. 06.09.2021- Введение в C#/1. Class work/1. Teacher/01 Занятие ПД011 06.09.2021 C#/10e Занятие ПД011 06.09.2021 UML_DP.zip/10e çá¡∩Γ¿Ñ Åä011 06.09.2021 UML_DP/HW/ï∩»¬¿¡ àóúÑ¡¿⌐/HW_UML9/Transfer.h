#pragma once
#include "Claim.h"

//������� �����
class Transfer
{
protected:
	Transfer* succesor_ = nullptr;
public:
	void SetSuccesor(Transfer* temp)
	{
		succesor_ = temp;
	}//SetSuccesor

	virtual void Process(const Claim& request) = 0;
	virtual ~Transfer() = default;
};