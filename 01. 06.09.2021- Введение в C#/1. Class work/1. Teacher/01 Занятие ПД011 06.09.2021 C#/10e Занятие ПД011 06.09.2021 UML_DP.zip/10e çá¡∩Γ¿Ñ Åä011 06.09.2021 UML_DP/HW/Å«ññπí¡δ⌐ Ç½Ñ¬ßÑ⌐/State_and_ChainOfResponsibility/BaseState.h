#ifndef _BASE_STATE_
#define _BASE_STATE_

#include "pch.h"


class Request;


class BaseState
{
public:

	BaseState() {}
	~BaseState() {}

	virtual void Handle(Request* request) = 0;
	virtual string GetNameOfState()const = 0;

};

#endif