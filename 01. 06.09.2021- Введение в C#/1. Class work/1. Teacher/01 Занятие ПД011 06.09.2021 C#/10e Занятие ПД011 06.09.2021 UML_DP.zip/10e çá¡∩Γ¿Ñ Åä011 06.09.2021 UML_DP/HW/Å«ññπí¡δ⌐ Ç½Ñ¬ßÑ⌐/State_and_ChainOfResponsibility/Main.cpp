﻿// Шаблон консольного приложения для начала курса "ООП на C++"
//

#include "pch.h"
#include "App.h"
#include "Utils.h"
#include "MenuItem.h"
#include "Menu.h"
#include "Palette.h"

int main()
{
    init(L"Домашние задание на 06.09.21");

    ostringstream oss;

    enum Commands {

        CMD_TASK1, CMD_TASK2, CMD_TASK3, CMD_QUIT
    };

    const int N_MENU = 3;
    MenuItem items[N_MENU] = {
        MenuItem("Задача 1. Паттерн Состояние", CMD_TASK1),
        MenuItem("Задача 2. Паттерн Цепочка обязанностей", CMD_TASK2),


        MenuItem("Выход",  Menu::CMD_QUIT),
    };

    const int N_PALETTE = 5;
    short palette[N_PALETTE] = { WHITE_ON_BLACK, LTCYAN_ON_BLACK, BLACK_ON_LTCYAN, GRAY_ON_BLACK };

    Menu mainMenu("Главное меню приложения", items, N_MENU, palette, COORD{ 5, 5 });


    App app;

    while (true) {
        try {
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            int cmd = mainMenu.Navigate();
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            if (cmd == Menu::CMD_QUIT) break;

            switch (cmd)
            {
            case CMD_TASK1:
                app.task1();
                getKey();
                break;

            case CMD_TASK2:
                app.task2();
                getKey();
                break;

            } // switch

            cout << endlm(2);
            //getKey();
        }
        catch (exception& ex) {

            oss.str("");  // очистка строки - буфера вывода
            oss << "\n\t" << ex.what() << "\n";

            // вывод строки с сообщением об ошибке в цвете
            cputs(oss.str().c_str(), errColor);
            getKey();


        } // try-catch

    } // while

    cout << cls << pos(0, 24);
    //getKey();

    return 0;


} // main
