#include "pch.h"
#include "BaseState.h"
#include "GrantEnquiry.h"

void GrantEnquiry::SetFullName(string value)
{
	FullName_ = value;
}

void GrantEnquiry::SetCourse(string value)
{
	Course_ = value; 
}

void GrantEnquiry::SetAverageScore(double value)
{
	AverageScore_ = value; 
}

void GrantEnquiry::Request()
{
	pCurrent->Handle(this);
}
