#include "pch.h"
#include "Approved.h"

void Approved::Handle(GrantEnquiry* context)
{
}


