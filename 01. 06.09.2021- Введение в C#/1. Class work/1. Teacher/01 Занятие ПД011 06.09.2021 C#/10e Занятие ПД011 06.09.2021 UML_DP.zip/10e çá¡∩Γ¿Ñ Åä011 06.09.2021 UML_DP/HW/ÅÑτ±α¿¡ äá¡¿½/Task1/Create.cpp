#include "pch.h"
#include "Create.h"
#include "Pending.h"

void Create::Handle(GrantEnquiry* context)
{
	cout << GetNameofState() << endl;
	if(context->GetAverageScore() > GrantEnquiry::MIN && context->GetAverageScore() 
	< GrantEnquiry::MAX)
	context->SetState(new Pending);
}
