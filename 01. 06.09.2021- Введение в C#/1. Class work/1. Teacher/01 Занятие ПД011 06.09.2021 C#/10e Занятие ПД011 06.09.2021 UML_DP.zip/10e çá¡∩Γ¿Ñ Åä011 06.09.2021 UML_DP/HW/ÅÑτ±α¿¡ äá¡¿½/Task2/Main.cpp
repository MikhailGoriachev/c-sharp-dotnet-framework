﻿
#include "pch.h"
#include "Utils.h"
#include "MoneyTransfer.h"
#include "Claim.h"


int main()
{
	// настройка вывода в консоль
	Init(L"Цепочка обязанностей ");

	MoneyTransfer* sum1 = new ByMail(); 
	MoneyTransfer* sum2 = new ViaInternet();
	MoneyTransfer* sum3 = new BankTransfer(); 

	// настройка цепочки обязанностей
	sum1->SetSuccessor(sum2);
	sum2->SetSuccessor(sum3); 

	// claim - запрос
	Claim first("Перевод 1", "от Иванова", 1000);
	sum1->Process(first);

	Claim second("Перевод 2", "от Петрова", 10000);
	sum2->Process(second);

	Claim third("Перевод 3", "от Сидорова", 100000);
	sum3->Process(third);

	delete sum1;
	delete sum2;
	delete sum3; 


 
	GetKey();
	return 0;
} // main


