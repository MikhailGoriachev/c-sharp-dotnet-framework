#pragma once
#include "pch.h"
#include "GrantEnquiry.h"



class BaseState 
{
public:

	BaseState() {}
	~BaseState() {}

	virtual void Handle(GrantEnquiry* context) = 0;
	virtual string GetNameofState() const = 0; 
};

