#include "pch.h"
#include "Pending.h"
#include "Approved.h"
#include "Dismissed.h"

void Pending::Handle(GrantEnquiry* context)
{
    cout << GetNameofState() << endl;
    if (context->GetFullName().empty() || context->GetCourse().empty())
        context->SetState(new Suspended);
    else if (context->GetAverageScore() >= 11)
        context->SetState(new Approved);
    else context->SetState(new Dismissed);
}

