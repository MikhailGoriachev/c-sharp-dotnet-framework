#include "pch.h"
#include "Dismissed.h"

void Dismissed::Handle(GrantEnquiry* context)
{
    cout << GetNameofState() << endl;
    context->SetState(new Approved);
}


