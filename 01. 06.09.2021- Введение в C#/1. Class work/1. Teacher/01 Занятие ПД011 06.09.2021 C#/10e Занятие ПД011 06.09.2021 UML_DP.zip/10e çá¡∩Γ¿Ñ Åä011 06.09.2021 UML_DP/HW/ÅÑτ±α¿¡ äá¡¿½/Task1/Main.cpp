﻿
#include "pch.h"
#include "Utils.h"
#include "Create.h"
#include "BaseState.h"
#include "GrantEnquiry.h"



int main()
{
	// настройка вывода в консоль
	Init(L"Паттерны Состояния и Цепочка обязанностей");

	GrantEnquiry v1("Иванов", "Курс", 10);
	v1.SetState(new Create); 
	v1.Request();
	v1.Request();
	v1.Request();
	v1.Request();
	v1.Request();



	GetKey();
	return 0;
} // main


