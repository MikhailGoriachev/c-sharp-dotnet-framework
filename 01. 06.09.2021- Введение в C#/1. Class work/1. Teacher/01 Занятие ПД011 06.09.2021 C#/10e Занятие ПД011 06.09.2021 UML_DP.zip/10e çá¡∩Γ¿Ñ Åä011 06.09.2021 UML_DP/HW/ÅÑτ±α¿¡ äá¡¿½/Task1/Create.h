#pragma once
#include "BaseState.h"
class Create : public BaseState
{
public:

	

	Create() {}
	~Create() {}

	void Handle(GrantEnquiry* context) override;

	string GetNameofState() const override { return "������ ������"; }
};

