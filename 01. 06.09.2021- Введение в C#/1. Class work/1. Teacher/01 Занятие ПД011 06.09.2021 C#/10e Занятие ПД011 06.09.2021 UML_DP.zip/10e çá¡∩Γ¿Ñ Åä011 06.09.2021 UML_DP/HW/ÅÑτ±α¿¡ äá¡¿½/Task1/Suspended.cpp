#include "pch.h"
#include "Suspended.h"
#include "Dismissed.h"

void Suspended::Handle(GrantEnquiry* context)
{
    cout << GetNameofState() << endl;
    context->SetState(new Dismissed);
}


