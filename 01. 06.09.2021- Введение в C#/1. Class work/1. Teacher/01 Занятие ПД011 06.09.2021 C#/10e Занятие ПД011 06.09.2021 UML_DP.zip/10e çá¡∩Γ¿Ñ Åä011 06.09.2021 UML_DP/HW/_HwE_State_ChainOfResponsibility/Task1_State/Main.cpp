﻿/*
 * Задача 1.
 * Паттерн Состояние (State) – консольное приложение. Разработать приложение
 * макет системы обработки грантов на обучение. Заявка на получение гранта 
 * для обучения может находиться в нескольких состояниях: 
 *     o Создана (должны быть указаны имя и фамилия претендента, курс для
 *       обучения, средний балл по другим курсам, некоторые поля могут быть
 *       пустыми)
 *     o Рассматривается (в течение 10 дней после создания, если указан
 *       средний балл)
 *     o Отложена (если данные не полны – есть пустые поля)
 *     o Подтверждена (после рассмотрения, если средний балл претендента
 *       не менее 11)
 *     o Отозвана (если заявка отложена и средний балл не указывается
 *       в течение 10 дней после создания). 
 * 
 */

#include "pch.h"
#include "Utils.h"
#include "MenuItem.h"
#include "Menu.h"
#include "App.h"
#include "Palette.h"


int main()
{
	// настройка вывода в консоль
	init(L"Задание на 06.09.2021 - поведенческий паттерн \"Состояние\"");

	// коды команд
    enum Commands {
    	CMD_ONE,      // Прохождение корректно оформленной заявки
    	CMD_TWO,      // Прохождение заявки с некоторыми пустыми полями
    	CMD_THREE     // Прохождение заявки со всеми пустыми полями
    };

	// массив пунктов меню
    const int N_MENU = 4;
    MenuItem items[N_MENU] = {
        MenuItem ("Прохождение корректно оформленной заявки", CMD_ONE), 
        MenuItem ("Прохождение заявки с некоторыми пустыми полями", CMD_TWO), 
        MenuItem ("Прохождение заявки со всеми пустыми полями", CMD_THREE), 
        MenuItem ("Выход",  Menu::CMD_QUIT) 
    };

	// палитра вывода меню
    const int N_PALETTE = 5;
	//                          заголовок       пункт меню       выбранный пункт  текст консоли  
    short palette[N_PALETTE] = {arrColor, LTCYAN_ON_BLACK, BLACK_ON_LTCYAN, mainColor};

    Menu mainMenu("Главное меню приложения", items, N_MENU, palette, COORD{5, 5});

	// Объект класса для обработки по заданию
    App *app = new App();   
    
    while(true) {
        try {
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            showNavBarMessage(hintColor, "  Демонстрация паттерна \"Состояние\"");
            int cmd = mainMenu.Navigate();
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            if (cmd == Menu::CMD_QUIT) break;

            switch (cmd) {
            // Прохождение корректно оформленной заявки
            case CMD_ONE:
                app->doCorrectFill();
                break;

            // Прохождение заявки с некоторыми пустыми полями
            case CMD_TWO:
                app->doSomeEmptyFields();
                break;

            // Прохождение заявки со всеми пустыми полями
            case CMD_THREE:
                app->doEmptyFields();
                break;
            } // switch

        } catch (exception &ex) {
            setColor(mainColor);
            cls();
            showNavBarMessage(hintColor, "  Ошибка приложения, нажмите любую клавишу для продолжения...");

	        // добавим 4 пробела перед выводимым сообщением об ошибке, длина строки 64 символа
            char buf[65];
            sprintf(buf, "    %-60s", ex.what());

        	// в эту секцию передается управление оператором throw
            const char* msg[] = {
                " ",
                "    [Ошибка]",
                buf,
                " ",
                " ",
                nullptr
            };
            showMessage(8, 4, 64, msg, errColor);
        } // try-catch
        cout << endlm(2);
        getKey();
    } // while

    cout << cls << pos(0,24);
    getKey();
	
    delete app;
	return 0;
} // main