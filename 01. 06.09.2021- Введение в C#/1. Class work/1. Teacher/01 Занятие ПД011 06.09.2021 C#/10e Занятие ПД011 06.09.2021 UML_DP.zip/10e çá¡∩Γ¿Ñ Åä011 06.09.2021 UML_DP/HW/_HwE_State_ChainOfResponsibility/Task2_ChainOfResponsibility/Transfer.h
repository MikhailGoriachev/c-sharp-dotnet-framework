﻿#pragma once
#include "Claim.h"

// Базовый класс для цепочки обработок
class Transfer
{
protected:
    // следующий в цепочке обработки 
	Transfer* pSuccessor = nullptr;

public:
	void setSuccessor(Transfer* pTransfer) {
		pSuccessor = pTransfer;
	}

	// обработка по заданию
	virtual void process(const Claim& request) = 0;
	virtual ~Transfer() = default;
};
