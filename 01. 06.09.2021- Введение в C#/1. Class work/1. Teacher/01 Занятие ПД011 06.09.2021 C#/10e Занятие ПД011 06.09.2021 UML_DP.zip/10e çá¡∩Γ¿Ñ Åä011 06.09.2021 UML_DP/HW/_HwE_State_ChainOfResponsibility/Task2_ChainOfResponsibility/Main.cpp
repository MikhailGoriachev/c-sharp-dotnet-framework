﻿/*
 * Задача 2.
 * Паттерн Цепочка обязанностей – разработайте макет приложения в консоли,
 * с использованием ООП C++, STL. Моделировать работу системы перевода суммы
 * денег адресату – через банковский перевод, почтовым переводом, через
 * Интернет-кошелек. Конкретный объект перевода определяется в зависимости от
 * суммы:
 *     o до 10000 – почтовый перевод
 *     o до 100000 – Интернет-кошелек
 *     o до 1000000 – банковский перевод
 *     o не переводить сумму, превышающую 1000000
 * 
 */

#include "pch.h"
#include "Utils.h"
#include "MenuItem.h"
#include "Menu.h"
#include "App.h"
#include "Palette.h"


int main()
{
	// настройка вывода в консоль
	init(L"Задание на 08.09.2021 - поведенческий паттерн \"Цепочка обязанностей\"");

	// коды команд
    enum Commands {
    	CMD_ONE,      // Выполнить почтовый перевод
    	CMD_TWO,      // Перевести деньги на Интернет-кошелек
    	CMD_THREE,    // Выполнить банковскй перевод
    	CMD_FOUR      // Запрос перевода с превышением лимита
    };

	// массив пунктов меню
    const int N_MENU = 5;
    MenuItem items[N_MENU] = {
        MenuItem ("Выполнить почтовый перевод", CMD_ONE), 
        MenuItem ("Перевести деньги на Интернет-кошелек", CMD_TWO), 
        MenuItem ("Выполнить банковскй перевод", CMD_THREE), 
        MenuItem ("Запрос перевода с превышением лимита", CMD_FOUR), 
        MenuItem ("Выход",  Menu::CMD_QUIT) 
    };

	// палитра вывода меню
    const int N_PALETTE = 5;
	//                          заголовок       пункт меню       выбранный пункт  текст консоли  
    short palette[N_PALETTE] = {arrColor, LTCYAN_ON_BLACK, BLACK_ON_LTCYAN, mainColor};

    Menu mainMenu("Главное меню приложения", items, N_MENU, palette, COORD{5, 5});

	// Объект класса для обработки по заданию
    App *app = new App();   
    
    while(true) {
        try {
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            showNavBarMessage(hintColor, "  Демонстрация паттерна \"Цепочка обязанностей\"");
            int cmd = mainMenu.Navigate();
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            if (cmd == Menu::CMD_QUIT) break;

            switch (cmd) {
            // Выполнить почтовый перевод
            case CMD_ONE:
                app->doPostalTransfer();
                break;

            // Перевести деньги на Интернет-кошелек
            case CMD_TWO:
                app->doWebWalletTransfer();
                break;

            // Выполнить банковскй перевод
            case CMD_THREE:
                app->doBankTransfer();
                break;

            // Запрос перевода с превышением лимита
            case CMD_FOUR:
                app->doOverLimitTransfer();
                break;
            } // switch

        } catch (exception &ex) {
            setColor(mainColor);
            cls();
            showNavBarMessage(hintColor, "  Ошибка приложения, нажмите любую клавишу для продолжения...");

	        // добавим 4 пробела перед выводимым сообщением об ошибке, длина строки 64 символа
            char buf[65];
            sprintf(buf, "    %-60s", ex.what());

        	// в эту секцию передается управление оператором throw
            const char* msg[] = {
                " ",
                "    [Ошибка]",
                buf,
                " ",
                " ",
                nullptr
            };
            showMessage(8, 4, 64, msg, errColor);
        } // try-catch
        cout << endlm(2);
        getKey();
    } // while

    cout << cls << pos(0,24);
    getKey();
	
    delete app;
	return 0;
} // main