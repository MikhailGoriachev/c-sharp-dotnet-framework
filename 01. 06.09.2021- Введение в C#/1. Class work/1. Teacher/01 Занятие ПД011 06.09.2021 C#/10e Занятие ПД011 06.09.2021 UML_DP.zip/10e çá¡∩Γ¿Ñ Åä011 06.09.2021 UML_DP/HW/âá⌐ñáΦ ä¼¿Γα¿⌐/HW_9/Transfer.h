#pragma once
#include "Claim.h"

// ������� �����
class Transfer{
protected:
	Transfer* pSuccessor = nullptr;

public:
	void SetSuccessor(Transfer* pTemp) {
		pSuccessor = pTemp;
	} // SetSuccessor

	virtual void Process(const Claim& request) = 0;
	virtual ~Transfer() = default;
};
