﻿
#include "pch.h"
#include "Menu.h"
#include "MenuItem.h"
#include "Utils.h"
#include "Colors.h"
#include "App.h"

int main() {
    init(L"HW\n");
    enum Commands {
        CMD_FIRST, CMD_SECOND
    };
    const int N_MENU = 3;
    MenuItem items[N_MENU] = {
        MenuItem("Задача 1. State", CMD_FIRST),
        MenuItem("Задача 2. Цепочка обязанностей", CMD_SECOND),
        MenuItem("Выход",  Menu::CMD_QUIT),
    };
    // палитра вывода меню
    const int N_PALETTE = 5;
    //                          заголовок       пункт меню       выбранный пункт  текст консоли  
    short palette[N_PALETTE] = { WHITE_ON_BLACK, LTCYAN_ON_BLACK, BLACK_ON_LTCYAN, GRAY_ON_BLACK };

    Menu mainMenu("Главное меню приложения", items, N_MENU, palette, COORD{ 5, 5 });

    App* app = nullptr;

    try {
        while (true) {
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            int cmd = mainMenu.Navigate();
            cout << color(palette[Menu::PAL_CONSOLE]) << cls;
            if (cmd == Menu::CMD_QUIT) break;
            switch (cmd) {
            case CMD_FIRST:
                app->task1();
                break;

            case CMD_SECOND:
                app->task2();
                break;
            } // switch

            cout << endlm(2);
            getKey();
        } // while
    }
    catch (exception ex) {
        setColor(RED);
        cout << "\n\t\t\t" << ex.what() << "\n";
        setColor(LTBLUE);
        getKey();
    } // try-catch
    cout << cls << pos(0, 24);

    getKey();
    return 0;
}//main

