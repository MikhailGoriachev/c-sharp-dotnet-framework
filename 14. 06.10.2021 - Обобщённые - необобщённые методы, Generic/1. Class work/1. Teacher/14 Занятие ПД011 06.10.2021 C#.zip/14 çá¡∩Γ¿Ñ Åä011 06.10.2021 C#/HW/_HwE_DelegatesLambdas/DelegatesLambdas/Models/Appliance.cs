﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DelegatesLambdas.Helpers;

namespace DelegatesLambdas.Models
{
    // Класс, описывающий электроприбор (название, мощность, цена
    // и состояние прибора: включен/выключен)
    internal class Appliance
    {
        // название электроприбора
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrEmpty(value)) 
                    throw new ArgumentNullException("Пустая строка в названии прибора");
                
                _name = value; 
            } // set
        } // Name

        // мощность электроприбора
        private int _power;
        public int Power {
            get => _power; 
            set {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"Недопустимая мощность электроприбора: {value}");

                _power = value; 
            } // set
        } // Power


        // цена электроприбора
        private int _price;
        public int Price {
            get => _price;
            set {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"Недопустимая цена электроприбора: {value}");

                _price = value;
            } // set
        } // Price

        // состояние электроприбора: включен/выключен
        private bool _state;
        public bool State {
            get => _state;
            set => _state = value; 
        } // State

        // ансамбль конструкторов
        public Appliance():this("чайник", 1_200, 3_200, false) { } // Appliance

        public Appliance(string name, int power, int price, bool state) {
            Name = name;
            Power = power;
            Price = price;
            State = state;
        } // Appliance

        // строковое представление объекта
        override public string ToString() =>
            $"{_name}: {_power} Вт, {_price} руб., {(_state?"Включен":"Выключен")}" ;

        // формирование строки таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,5} │ {_name, -22} │ {_power, 12:n2} │ {_price, 10:n2} │ " +
            $"{(_state ? "Включен" : "Выключен"), -10} │";


        // Шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}┌───────┬────────────────────────┬──────────────┬────────────┬────────────┐\n" +
            $"{spaces}│ N п/п │ Название прибора       │ Мощность, Вт │ Цена, руб. │ Состояние  │\n" +
            $"{spaces}├───────┼────────────────────────┼──────────────┼────────────┼────────────┤\n";
        } // Header

        // Подвал таблицы, статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└───────┴────────────────────────┴──────────────┴────────────┴────────────┘\n";

        // Фабричный метод для создания электроприбора из случайных данных
        public static Appliance Generate() {
            (string Name, int Power, int Price)[] data = { 
                ("чайник", 1_200, 2_100), ("блендер", 300, 900), ("утюг", 1_100, 1_900), 
                ("миксер", 780, 1_100),   ("хлебопечка", 1_100, 9_200), 
                ("стиральная машина", 2_100, 13_800), ("микроволновка", 900, 9_600), 
                ("светильник", 20, 600), ("панель управления", 20, 900), 
                ("посудомоечная машина", 2_100, 13_000), ("вертикальный пылесос", 900, 11_300)
            };
            int index = Utils.Random.Next(0, data.Length);
            return new Appliance { 
                _name = data[index].Name, 
                _power = data[index].Power, 
                _price = data[index].Price,
                // сформировать состояние прибора - включен или выключен
                _state = Utils.Random.Next(0, 2) == 1  
            };
        } // Generate
    } // class Appliance
}
