﻿using System;
using DelegatesLambdas.Helpers;

namespace DelegatesLambdas.Controllers
{
    // делегаты предикатов обработки
    internal delegate bool Predicate(int item);               // для сравнения с 0
    internal delegate bool BiPredicate(int item, int value);  // для сравнения с некоторым значением 
    
    // Обработка массива по заданию - массив делаем полем контроллера
    internal class Task1Controller {
        // собственно модель данных
        private const int Number = 23;
        public int[] Data {
            get;
            private set;
        }

        public Task1Controller() : this(new int [Number]) {
            Initialize();
        } // Task1Controller

        public Task1Controller(int[] data) {
            Data = data;
        } // Task1Controller

        // Заполнение массива случайными числами
        public void Initialize(int lo = -10, int hi = 10) {
            for (int i = 0; i < Data.Length; i++) {
                Data[i] = Utils.Random.Next(lo, hi+1);
            } // for i
        } // Initialize
        
        // предикаты для задачи 1
        public static bool IsPositive(int item) => item >= 0;
        public static bool IsNegative(int item) => item < 0;
        
        // значение item по модулю не меньше value
        public static bool LessAbs(int item, int value) => Math.Abs(item) <= value; 
        
        // Вывод массива в консоль
        // Вывод массива по 10 элементов в строку - стандартный код с выделением 
        // цветом фона и символа элементов, для которых сработает предикат
        public void Show(string title, Predicate predicate) {
            Console.Write($"\t{title}\n\t");
            int i = 1;
            foreach (var datum in Data) {
                // выделение цветом элементов, для которых сработал предикат
                var oldColor = (Console.ForegroundColor, Console.BackgroundColor);
                if (predicate(datum)) 
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);
                Console.Write($"  {datum, 5}  ");
                (Console.ForegroundColor, Console.BackgroundColor) = oldColor;
                Console.Write(" ");

                // переход на новую строку, отступ 8 позиций на новой строке 
                if (i++ % 10 == 0) Console.Write("\n\t");
            } // for i
            Console.WriteLine();
        } // Show

        // Вывод массива по 10 элементов в строку - стандартный код с выделением 
        // цветом фона и символа элементов, индексы которых между first и last 
        public void Show(string title, int first, int last) {
            Console.Write($"\t{title}\n\t");
            int i = 0;
            foreach (var datum in Data) {
                // выделение цветом элементов, индекс которых в диапазоне [first, last]
                var oldColor = (Console.ForegroundColor, Console.BackgroundColor);
                if (i == first)
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.DarkRed, ConsoleColor.Gray);
                else if (i == last)
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.DarkBlue, ConsoleColor.Gray);
                else if (first < i && i < last)
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);
                
                Console.Write($"  {datum,5}  ");
                (Console.ForegroundColor, Console.BackgroundColor) = oldColor;
                Console.Write(" ");

                // переход на новую строку, отступ 8 позиций на новой строке 
                if (++i % 10 == 0) Console.Write("\n\t");
            } // for i
            Console.WriteLine();
        } // Show

        // Вывод массива по 10 элементов в строку - стандартный код с выделением 
        // цветом фона и символа элементов, для которых сработает предикат
        public void Show(string title, BiPredicate predicate, int value) {
            Console.Write($"\t{title}\n\t");
            int i = 1;
            foreach (var datum in Data) {
                // выделение цветом элементов, для которых сработает предикат
                var oldColor = (Console.ForegroundColor, Console.BackgroundColor);
                if (predicate(datum, value)) 
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);
                Console.Write($"  {datum, 5}  ");
                (Console.ForegroundColor, Console.BackgroundColor) = oldColor;
                Console.Write(" ");

                // переход на новую строку, отступ 8 позиций на новой строке 
                if (i++ % 10 == 0) Console.Write("\n\t");
            } // for i
            Console.WriteLine();
        } // Show
        

        
        // поиск минимального элемента массива
        public int Min() {
            int min = Data[0]; // замыкание в делегате!!  closure 
            // int min = int.MaxValue; // замыкание в делегате!!  closure 
            Array.ForEach(Data, delegate (int item) { min = item < min ? item : min; });
            return min;
        } // Min
        
        // Подсчет количества элементов, для которых срабатывает предикат, сравнивающий
        // элемент массива с заданным значением
        public int CounterIf(BiPredicate predicate, int value) {
            int counter = 0;    // замыкание в делегате!!  closure 
            Array.ForEach(Data, delegate(int item) { counter += predicate(item, value)?1:0; });
            return counter;
        } // CounterIf

        // Подсчет количества элементов, для которых срабатывает предикат
        // предикат анализирует только элемент массива
        public int CounterIf(Predicate predicate) {
            int counter = 0;
            Array.ForEach(Data, delegate(int item) { counter += predicate(item)?1:0; });
            return counter;
        } // CounterIf

        // Сумма элементов массива между элементами с заданными индексами
        public bool SummaBetweenFirstLast(int first, int last, out int sum) {
            sum = 0;

            // проверка корректности входных параметров
            if (first < 0 || last < 0 || first == last) return false;

            // суммирование элементов массива по заданию
            for (int i = first+1; i < last; i++) {
                sum += Data[i];
            } // for i

            return true;
        } // SummaBetweenFirstLast
    } // class Task1Controller
}
