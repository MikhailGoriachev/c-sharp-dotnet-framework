﻿
using System;

using DelegatesLambdas.Helpers;
using DelegatesLambdas.Controllers;

namespace DelegatesLambdas.Application
{
    // делегат для вызова методов без параметров
    internal delegate void ProcessArray();

    /*
     * Методы для решения задачи 1 
     */
    internal partial class App
    {
        /*
         * Обработка массива по пункту А.
         * В одномерном массиве, состоящем из п целых элементов:
         *     • вычислить количество элементов, равных минимальному элементу массива;
         *     • вычислить сумму элементов массива, расположенных между первым и 
         *       последним положительными элементами;
         *     • преобразовать массив таким образом, чтобы сначала располагались все   
         *       элементы, равные нулю, а потом — все остальные.    
         */
        public void Task1PointA() {
            Utils.ShowNavBarTask("  Задача 1 - обработка массива по заданию пункта А");

            // начало формирования делегата
            ProcessArray processArray = delegate { _task1Controller.Initialize(); };

            // вычислить количество элементов, равных минимальному элементу массива
            int minimals = 0;

            // обработка 1
            // предикат используетя в первой и третьей обработках
            BiPredicate biPredicate = delegate (int x, int y) { return x == y; };
            processArray += delegate {
                _task1Controller.Show("\n\n\n\n\tМассив данных для обработки по пункту А задачи 1:", 
                    Task1Controller.IsNegative);

                int min = _task1Controller.Min();
                minimals = _task1Controller.CounterIf(biPredicate, min);

                _task1Controller.Show("\n\n\tМассив для обработки с выделенными цветом минимальными элементами:",
                    biPredicate, min);
                Console.WriteLine($"\n\t    Количество элементов, равных минимальному: {minimals}");
            };

            // обработка 2
            // вычислить сумму элементов массива, расположенных между первым и
            // последним положительными элементами
            int sum = 0;
            processArray += delegate {
                int first = Array.FindIndex(_task1Controller.Data, Task1Controller.IsPositive);
                int last = Array.FindLastIndex(_task1Controller.Data, Task1Controller.IsPositive);
                
                bool resultOk = _task1Controller.SummaBetweenFirstLast(first, last, out sum);
                _task1Controller.Show(
                    "\n\n\tВыделены первый и последний положительные элементы и элементы меду ними:",
                    first, last);
                string answer = resultOk
                    ? $"\n\tСумма элементов между первым и последним положительными элементами: {sum}"
                    : "\n\tНедостаточно положительных элементов в массиве для вычисления суммы между ними";
                Console.WriteLine(answer);
            };

            // обработка 3
            // преобразовать массив таким образом, чтобы сначала располагались все
            // элементы, равные нулю, а потом — все остальные
            processArray += delegate {
                Array.Sort(_task1Controller.Data, 
                    delegate (int a, int b) { return a == 0 && b != 0 ? -1 : a != 0 && b == 0 ? 1 : 0; });

                // вывод массива после упорядочивания по заданному правилу
                _task1Controller.Show(
                    "\n\n\tМассив упорядочен по правилу \"Нули в начало массива\"",
                    biPredicate, 0
                );
            };

            // выполнение делегата - вызов всех обработок
            processArray();
        } // Task1PointA

        /*
         * Обработка массива по пункту Б.
         * В одномерном массиве, состоящем из п целых элементов:
         *     • вычислить количество отрицательных элементов массива;
         *     • вычислить сумму элементов массива, расположенных между первым и вторым
         *       отрицательными элементами;
         *     • преобразовать массив таким образом, чтобы сначала располагались все 
         *       элементы, модуль которых не превышает 3, а потом — все остальные.
         */
        public void Task1PointB() {
            Utils.ShowNavBarTask("  Задача 1 - обработка массива по заданию пункта Б");
            
            // начало формирования делегата
            ProcessArray processArray = delegate { _task1Controller.Initialize(); };

            // обработка 1
            // вычислить количество отрицательных элементов массива
            int negatives = 0;
            processArray += delegate {
                _task1Controller.Show("\n\n\n\n\tМассив данных для обработки по пункту Б задачи 1:", Task1Controller.IsNegative);

                negatives = _task1Controller.CounterIf(Task1Controller.IsNegative);
                Console.WriteLine($"\n\tКоличество отрицательных элементов в массиве: {negatives}");
            };

            // обработка 2
            // вычислить сумму элементов массива, расположенных между первым и вторым
            // отрицательными элементами
            int sum = 0;
            processArray += delegate {
                // первое вхождение отрицательного элемента
                int first = Array.FindIndex(_task1Controller.Data, Task1Controller.IsNegative);

                // второе вхождение отрицательного элемента
                int secnd = Array.FindIndex(_task1Controller.Data, first+1, Task1Controller.IsNegative);

                // сумма элементов между ними - все проверки выполняем внутри метода суммирования
                bool resultOk = _task1Controller.SummaBetweenFirstLast(first, secnd, out sum);
                _task1Controller.Show(
                    "\n\n\tВыделены первый и второй отрицательные элементы и элементы между ними:",
                    first, secnd);
                string answer = resultOk
                    ? $"\n\tСумма элементов между первым и вторым отрицательными элементами: {sum}"
                    : "\n\tНедостаточно отрицательных элементов в массиве для вычисления суммы между ними";
                Console.WriteLine(answer);
            };

            // обработка 3
            // преобразовать массив таким образом, чтобы сначала располагались все 
            // элементы, модуль которых не превышает 3, а потом — все остальные
            int value = 3;
            processArray += delegate {
                Array.Sort(_task1Controller.Data, delegate(int x, int y) {
                    return Math.Abs(x) <= value && Math.Abs(y) > 3
                        ? -1
                        : Math.Abs(y) <= value && Math.Abs(x) > 3
                            ? 1
                            : 0;
                });
           
                // вывод массива после упорядочивания по заданному правилу
                _task1Controller.Show(
                    $"\n\n\tМассив упорядочен по правилу \"Элементы по модулю меньшие {value} в начало массива\"", 
                    Task1Controller.LessAbs, value
                );
            };
            
            // выполнение делегата - вызов всех обработок
            processArray();
        } // Task1PointB
    } // class App
}
