﻿using System;
using Microsoft.VisualBasic;

using DelegatesLambdas.Application;
using DelegatesLambdas.Helpers;

/* 
 * В консольном приложении решите следующие задачи.
 * 
 * Задача 1. 
 * Разработайте классы для обработки массивов, при этом предикаты и компараторы
 * реализовать при помощи делегатов. Реализация компараторов анонимными 
 * методами, предикатов – именованными делегатами (сохраненными в переменных).
 * А. В одномерном массиве, состоящем из п целых элементов:
 *     • вычислить количество элементов, равных минимальному элементу массива;
 *     • вычислить сумму элементов массива, расположенных между первым и 
 *       последним положительными элементами;
 *     • преобразовать массив таким образом, чтобы сначала располагались все   
 *       элементы, равные нулю, а потом — все остальные.
 * Все три обработки запускать одним делегатом.
 * Б. В одномерном массиве, состоящем из п целых элементов:
 *     • вычислить количество отрицательных элементов массива;
 *     • вычислить сумму элементов массива, расположенных между первым и вторым
 *       отрицательными элементами;
 *     • преобразовать массив таким образом, чтобы сначала располагались все 
 *       элементы, модуль которых не превышает 3, а потом — все остальные.
 * Все три обработки запускать одним делегатом.
 * 
 * Задача 2. 
 * Разработайте класс, описывающий электроприбор (название, мощность, цена, 
 * включен/выключен). 
 * Сформируйте массив электроприборов (от 10 до 12 элементов), для массива 
 * реализуйте обработки:
 *     • вывод массива в табличном формате, используйте лямбда-выражение 
 *       для Array.Foreach()
 *     • перемешивание элементов массива
 *     • сортировка по названию, компаратор реализуйте лямбда-выражением
 *     • сортировка по мощности прибора, компаратор реализуйте 
 *       лямбда-выражением
 *     • включение всех приборов, используйте лямбда-выражение 
 *       для Array.ForEach()
 *     • выключение всех приборов, используйте лямбда-выражение 
 *       для Array.ForEach()
 *
 */

namespace DelegatesLambdas
{
    internal class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 06.10.2021 - Делегаты и лямбда-выражения в C#";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Задача 1. Обработка целочисленного массива - вариант А"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Задача 1. Обработка целочисленного массива - вариант Б"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.A, Text = "Формирование массива данных по элетроприборам"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Вывод массива данных по электроприборам"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Перемешать массив данных об электроприборах"},
                new MenuItem {HotKey = ConsoleKey.F, Text = "Сортировка массива электроприборов по названию"},
                new MenuItem {HotKey = ConsoleKey.G, Text = "Сортировка массива электроприборов по мощности"},
                new MenuItem {HotKey = ConsoleKey.H, Text = "Включение всех электроприборов массива"},
                new MenuItem {HotKey = ConsoleKey.J, Text = "Выключение всех электроприборов массива"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - делегаты, лямбда-выражения");
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации делегатов и лямбда-выражений в C#", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1

                        #region Задача 1

                        // Задача 1. Обработка целочисленного массива - вариант А
                        case ConsoleKey.Q:
                            app.Task1PointA();
                            break;

                        // Задача 1. Обработка целочисленного массива - вариант А
                        case ConsoleKey.W:
                            app.Task1PointB();
                            break;
                        #endregion

                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 2

                        #region Задача 2

                        // Формирование массива данных по элетроприборам
                        case ConsoleKey.A:
                            app.GenerateAppliances();
                            break;

                        // Вывод массива данных по электроприборам
                        case ConsoleKey.S:
                            app.ShowAppliances();
                            break;

                        // Перемешать массив данных об электроприборах
                        case ConsoleKey.D:
                            app.ShuffleAppliances();
                            break;

                        // Сортировка массива электроприборов по названию
                        case ConsoleKey.F:
                            app.OrderAppliancesByName();
                            break;

                        // Сортировка массива электроприборов по мощности
                        case ConsoleKey.G:
                            app.OdrerAppliancesByPower();
                            break;

                        // Включение всех электроприборов массива
                        case ConsoleKey.H:
                            app.AllAppliancesPowerOn();
                            break;

                        // Выключение всех электроприборов массива
                        case ConsoleKey.J:
                            app.AllAppliancesPowerOff();
                            break;
                        #endregion

                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    } // class Program
}
