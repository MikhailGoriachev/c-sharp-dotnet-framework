﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DelegatesLambdas.Controllers;

namespace DelegatesLambdas.Application
{
    // Общая часть приложения, создание объектов для выполнения задач
    internal partial class App
    {
        // объекты для решения
        private Task1Controller _task1Controller;
        private Task2Controller _task2Controller;

        // ансамбль конструктлоров
        public App():this(new Task1Controller(), new Task2Controller()) { } // App

        public App(Task1Controller task1Controller, Task2Controller task2Controller) {
            _task1Controller = task1Controller;
            _task2Controller = task2Controller;
        } // App

    } // class App
}
