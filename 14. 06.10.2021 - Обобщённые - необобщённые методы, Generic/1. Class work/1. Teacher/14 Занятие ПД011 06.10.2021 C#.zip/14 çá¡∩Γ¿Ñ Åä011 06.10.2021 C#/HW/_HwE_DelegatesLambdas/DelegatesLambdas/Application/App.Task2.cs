﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DelegatesLambdas.Controllers;
using DelegatesLambdas.Helpers;
using DelegatesLambdas.Models;

namespace DelegatesLambdas.Application
{
    // методы - действия по реализации обработок задачи 2
    internal partial class App
    {
        // Формирование массива данных по электроприборам
        internal void GenerateAppliances() {
            Utils.ShowNavBarTask("  Задача 2 - Формирование массива данных по электроприборам");

            _task2Controller.Initialize();
            Console.WriteLine(_task2Controller.View("\n\n\n\n\t    Сформирован массив приборов:", 12));
        } // GenerateAppliances


        // Вывод массива данных по электроприборам
        internal void ShowAppliances() {
            Utils.ShowNavBarTask("  Задача 2 - Вывод массива данных по электроприборам");

            Console.WriteLine(_task2Controller.View("\n\n\n\n\t    Массив электроприборов для обработки:", 12));
        } // ShowAppliances

        // Перемешать массив данных об электроприборах
        internal void ShuffleAppliances() {
            Utils.ShowNavBarTask("  Задача 2 - Перемешать массив данных об электроприборах");

            _task2Controller.Shuffle();
            Console.WriteLine(_task2Controller.View(
                "\n\n\n\n\t    Данные в массиве электроприборов перемешаны для дальнейшей работы:", 12));
        } // ShuffleAppliances

        // Сортировка массива электроприборов по названию
        internal void OrderAppliancesByName() {
            Utils.ShowNavBarTask("  Задача 2 - Сортировка массива электроприборов по названию");

            _task2Controller.OrderByApplianceName();
            Console.WriteLine(_task2Controller.View(
                "\n\n\n\n\t    Данные в массиве электроприборов упорядочены по названию электроприбора:", 12));
        } // OrderAppliancesByName

        // Сортировка массива электроприборов по мощности
        internal void OdrerAppliancesByPower() {
            Utils.ShowNavBarTask("  Задача 2 - Сортировка массива электроприборов по мощности");

            _task2Controller.OrderByAppliancePower();
            Console.WriteLine(_task2Controller.View(
                "\n\n\n\n\t    Данные в массиве электроприборов упорядочены по мощности электроприбора:", 12));
        } // OdrerAppliancesByPower

        // Включение всех электроприборов массива
        internal void AllAppliancesPowerOn() {
            Utils.ShowNavBarTask("  Задача 2 - Включение всех электроприборов массива");

            _task2Controller.AllTurnOnOff(true);
            Console.WriteLine(_task2Controller.View("\n\n\n\n\t    Все электроприборы включены:", 12));
        } // AllAppliancesPowerOn

        // Выключение всех электроприборов массива
        internal void AllAppliancesPowerOff() {
            Utils.ShowNavBarTask("  Задача 2 - Выключение всех электроприборов массива");

            _task2Controller.AllTurnOnOff(false);
            Console.WriteLine(_task2Controller.View("\n\n\n\n\t    Все электроприборы выключены:", 12));
        } // AllAppliancesPowerOff
    } // class App

}
