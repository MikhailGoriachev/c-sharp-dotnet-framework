﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using DelegatesLambdas.Application;
using DelegatesLambdas.Helpers;
using DelegatesLambdas.Models;

namespace DelegatesLambdas.Controllers
{
    // Массив электроприборов и его обработки
    internal class Task2Controller {
        private const int Number = 12;
        public Appliance[] Appliances { get; private set; }

        public Task2Controller():this(new Appliance[Number]) {
            Initialize();
        } // Task2Controller

        public Task2Controller(Appliance[] appliances) {
            Appliances = appliances;
        } // Task2Controller
        
        // фрмирование данных в массиве приборов
        public void Initialize() {
            for (int i = 0; i < Appliances.Length; i++) {
                Appliances[i] = Appliance.Generate();
            } // for i
        } // Initialize

        // вывод массива приборов - свойства контроллера
        public string View(string title, int indent) => ResultView(title, Appliances, indent);
        
        // Вывод массива приборов с заголовком - может пригодится при выводе выборок
        public static string ResultView(string title, Appliance[] appliances, int indent) {
            // формирование заголовка и шапки таблицы
            StringBuilder sbr = new StringBuilder($"{title}\n{Appliance.Header(indent)}");

            // формирование строк таблицы
            int row = 1;                            // номер строки таблицы приборов
            string spaces = " ".PadRight(indent);   // отступ перед каждой строкой таблицы
            Array.ForEach(appliances, appliance => sbr.Append($"{spaces}{appliance.ToTableRow(row++)}\n"));
            
            // формирование подвала таблицы
            sbr.Append(Appliance.Footer(indent));
            
            // возвращаем сформированную строку для вывода одной операцией
            return sbr.ToString();
        } // ResultView

        // перемешивание массива приборов по алгоритму "Тасование Фишера-Йетса"
        // https://vscode.ru/prog-lessons/kak-peremeshat-massiv-ili-spisok.html
        public void Shuffle() {
            // просматриваем массив с конца
            for (int i = Appliances.Length - 1; i >= 1; i--) {

                // определяем элемент, с которым меняем элемент с индексами i
                int j = Utils.Random.Next(0, i + 1);  // фактически генерится 0, ..., i

                // меняем местами элементы массива при помощи кортежа
                (Appliances[i], Appliances[j]) = (Appliances[j], Appliances[i]);
            } // for i
        } // Shuffle 

        // Сортировка массива электроприборов по названию
        public void OrderByApplianceName() => 
            Array.Sort(Appliances, (a1, a2) => a1.Name.CompareTo(a2.Name));

        // Сортировка массива электроприборов по мощности
        public void OrderByAppliancePower() =>
            Array.Sort(Appliances, (a1, a2) => a1.Power.CompareTo(a2.Power));

        // Включение/выключение всех электроприборов
        public void AllTurnOnOff(bool state) =>
            Array.ForEach(Appliances, appliance => appliance.State = state);
    } // class Task2Controller
}
