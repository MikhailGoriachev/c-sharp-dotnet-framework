﻿using System;

namespace HW_13.Application{
    internal partial class App{
        public void Task1_1(){
            _task1.Del1();
        } // Task1_1

        public void Task1_2(){
            _task1.Del2();
        } // Task1_2

    } // App
}
