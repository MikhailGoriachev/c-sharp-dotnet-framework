﻿using System;
using HW_13.Helpers;

namespace HW_13.Models{
    internal class ArrayEA{
        public string Name { get; set; }      // наименование магазина электроники
        ElectricalAppliance[] _appliances;    // товары магазина они же электроприборы
        private int _n;                       // количество товаров в магазине

        public int N{
            get => _n;
            set => _n = value;
        } // N

        // свойство для массива электроприборов
        public ElectricalAppliance[] Appliances{
            get => _appliances;
            set => _appliances = value;
        } // ElectricalAppliance

        // конструктор по умолчанию
        public ArrayEA(){
            Name = "М.Руфи";
            N = Utils.Random.Next(10, 12);
            Appliances = new ElectricalAppliance[N];
            Initialize();
        } // ArrayEA

        // конструктор с парамметрами
        public ArrayEA(string name, ElectricalAppliance[] arr){
            Name = name;
            Appliances = arr;
        } // ArrayEA

        // кывод массива приборов с цветом
        public void Show(string title = ""){
            ConsoleColor old = Console.ForegroundColor;

            Console.Write($"\n\n\t {title}\n \t Название магазина: ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.WriteLine($" {Name} ");
            // Возврат к цветам консоли по умолчанию
            Console.ResetColor();

            Console.Write($"{ElectricalAppliance.Header()}"); // вершина таблицы

            Array.ForEach(Appliances, elec => {
                // ConsoleColor temp = elec.State?ConsoleColor.Green:ConsoleColor.Red;
                // Console.ForegroundColor = temp;
                Console.ForegroundColor = elec.State ? ConsoleColor.Green : ConsoleColor.Red;
                Console.WriteLine($"{elec.ToTableRow()}");
            });

            Console.ForegroundColor = old;
            Console.WriteLine(ElectricalAppliance.Footer()); // подвал таблицы

        } // Show

        // заполнение массива приборов данными
        public void Initialize(){
            // Array.ForEach(Appliances, x=> x = ElectricalAppliance.CreateElectricalAppliance());
            for (int i = 0; i < N; i++) Appliances[i] = ElectricalAppliance.CreateElectricalAppliance();
        } // Initialize

        // перегруженная операция унаследованная от класса Object
        public override string ToString() => $"Название массива: {Name}\nПриборы:\n{Appliances}";

        // перемешивание коллекции электроприборов по алгоритму "Тасование Фишера-Йетса"
        // https://vscode.ru/prog-lessons/kak-peremeshat-massiv-ili-spisok.html
        public void Shuffle(){
            // просматриваем массив с конца
            for (int i = N - 1; i >= 1; i--){
                // определяем элемент, с которым меням элемент с индексами i
                int j = Utils.Random.Next(0, i + 1);  // фактически генерится 0, ..., i
                // меняем местами элементы массива при помощи кортежа
                (Appliances[i], Appliances[j]) = (Appliances[j], Appliances[i]);
            } // for i
        } // Shuffle

        // случайный переход между состояниями (включен/выключен) для электроприборов
        public void RandomState() => Array.ForEach(Appliances, elem => elem.State = Utils.GetTrueOrFalse());

        // сортировка электроприборов по их названию
        public void OrderByElectroName() => Array.Sort(Appliances, (elem1, elem2) => elem1.Name.CompareTo(elem2.Name));

        // сортировка электроприборов по их мощности (убывание)
        public void OrderByElectroPower() => Array.Sort(Appliances, (elem1, elem2) => elem1.Power.CompareTo(elem2.Power));

        // сортировка электроприборов по их мощности (возростание)
        public void OrderByDecreasingElectroPower() => Array.Sort(Appliances, (elem1, elem2) => elem2.Power.CompareTo(elem1.Power));

        // включение всех электроприборов
        public void AllON() => Array.ForEach(Appliances, elem => elem.State = true);

        // выключение всех электроприборов
        public void AllOFF() => Array.ForEach(Appliances, elem => elem.State = false);
    } // ArrayIrons
}
