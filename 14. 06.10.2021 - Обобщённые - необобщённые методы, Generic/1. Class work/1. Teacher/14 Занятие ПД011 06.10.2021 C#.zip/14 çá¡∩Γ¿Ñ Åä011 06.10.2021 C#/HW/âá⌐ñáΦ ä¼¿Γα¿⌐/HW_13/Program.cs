﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

using HW_13.Helpers;
using HW_13.Application;

namespace HW_13{
    class Program{
        static void Main(string[] args){
            Console.Title = "HW";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Работа с 1 массивом"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Работа со 2 массивом"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.A, Text = "Вывод массива"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Перемешивание элементов массива"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Сортировка по названию"},
                new MenuItem {HotKey = ConsoleKey.F, Text = "Сортировка по мощности"},
                new MenuItem {HotKey = ConsoleKey.G, Text = "Перемешать состояние всех эл.приборов"},
                new MenuItem {HotKey = ConsoleKey.H, Text = "Включение всех приборов"},
                new MenuItem {HotKey = ConsoleKey.J, Text = "Выключение всех приборов"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true){
                try{
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();

                    switch (key){
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1

                        #region Задача 1

                        // Работа с 1 массивом
                        case ConsoleKey.Q:
                            app.Task1_1();
                            break;

                        // Работа со 2 массивом
                        case ConsoleKey.W:
                            app.Task1_2();
                            break;
                        #endregion

                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 2

                        #region Задача 2

                        // Вывод массива
                        case ConsoleKey.A:
                            app.task2_1();
                            break;

                        // Перемешивание элементов массива
                        case ConsoleKey.S:
                            app.task2_2();
                            break;

                        // Сортировка по названию
                        case ConsoleKey.D:
                            app.task2_3();
                            break;

                        // Сортировка по мощности
                        case ConsoleKey.F:
                            app.task2_4();
                            break;

                        // Перемешать состояние всех эл.приборов
                        case ConsoleKey.G:
                            app.task2_5();
                            break;

                        // Включение всех приборов
                        case ConsoleKey.H:
                            app.task2_6();
                            break;

                        // Выключение всех приборов
                        case ConsoleKey.J:
                            app.task2_7();
                            break;

                        #endregion

                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    } // Program
}
