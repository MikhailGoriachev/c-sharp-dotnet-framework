﻿using System;
using HW_13.Helpers;

namespace HW_13.Models{
    internal class ElectricalAppliance{

        private string _name;   // название электроприбора
        private int _power;     // мощность 
        private double _price;  // цена 
        private bool _state;    // состояние электроприбора 

        private const int MinPower = 10;      //   Минимальная мощность электроприбора 
        private const int MaxPower = 2_500;   //  Максимальная мощность электроприбора 
        private const double MinPrice = 500;  // Минимальная стоимость электроприбора


        // название электроприбора
        public string Name{
            get => _name;
            set => _name = !string.IsNullOrWhiteSpace(value) ? value : throw new Exception($"Нельзя дать такое название электроприбору!");
        } // Name

        // мощность электроприбора
        public int Power{
            get => _power;
            set => _power = value >= MinPower && value <= MaxPower ? value : throw new Exception($"Нельзя дать такую мощность электроприбору!");
        } // Power

        // стоимость электроприбора
        public double Price{
            get => _price;
            set => _price = value >= MinPrice ? value : throw new Exception($"Нельзя дать такую стоимость электроприбору!");
        } // Price

        // Состояние электроприбора [включен / выключен]
        public bool State
        {
            get => _state;
            set => _state = value;
        } // State

        // Строковое предстовление состояния электроприбора
        // * Можно ли сделать это свойством ?       *
        // * или свойства только для полей класса ? *
        public string StrState => State == true ? "Включен" : "Выключен";

        public ElectricalAppliance() : this("Микроволновая печь", 600, 23_152.14, false) { }

        // конструктор с парамметрами
        public ElectricalAppliance(string name, int power, double price, bool state){
            Name = name;
            Power = power;
            Price = price;
            State = state;
        } // ElectricalAppliance

        public override string ToString() =>
            $"Название электроприбора: {Name}, состояние: {StrState}.\n" +
            $"Мощность электроприбора: {Power} Вт, стоимость: {Price:f2} руб.";


        public string ToTableRow() =>
         $"\t| {Name,-20} │ {Power,11} │ {Price,10:n2} " +
         $"  │ {StrState,-17} │";


        public static string Header() =>
                "\t┌──────────────────────┬─────────────┬──────────────┬───────────────────┬\n" +
                "\t│       Название       │   Мощность  │  Стоимость   │ Текущее состояние │\n" +
                "\t│    электроприбора    │ (Вт - ватт) │ (р. - рублю) │  электроприбора   │\n" +
                "\t├──────────────────────┼─────────────┼──────────────┼───────────────────┼\n";

        public static string Footer() => "\t└──────────────────────┴─────────────┴──────────────┴───────────────────┘";


        public static ElectricalAppliance CreateElectricalAppliance(){
            string[] type = {
            "Су-вид", "Кофемашина", "Пылесос", "Паровая швабра", "Посудомоечная машина", "Увлажнитель воздуха",
            "Холодильник", "Микроволновая печь", "Стиральная машина", "Сушильная машина", "Мультиварка", "Пароварка",
            "Умная колонка", "Док-станция", "Блендер", "Аэрогриль", "Кухонные весы", "Цифровой таймер", "Утюг"
            };
            bool state = Utils.GetRandom(1, 2) == 1 ? true : false;
            return new ElectricalAppliance(type[Utils.Random.Next(0, type.Length - 1)], Utils.Random.Next(MinPower, MaxPower),
                  Utils.GetRandom(MinPrice, Utils.GetRandom(1_000, 100_000)), state);

        } // ElectricalAppliance

    } // Iron
}
