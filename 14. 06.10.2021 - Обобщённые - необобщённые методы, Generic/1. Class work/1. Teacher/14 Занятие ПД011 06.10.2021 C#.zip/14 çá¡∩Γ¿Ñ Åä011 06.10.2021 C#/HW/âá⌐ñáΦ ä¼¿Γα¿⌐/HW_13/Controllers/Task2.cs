﻿using System;
using HW_13.Models;

namespace HW_13.Controllers{
    internal class Task2{
        private ArrayEA _arrEA;
        public ArrayEA Arr{
            get => _arrEA;
            set => _arrEA = value;
        } // Arr

        public Task2() : this(new ArrayEA()) { }
        public Task2(ArrayEA arrEA) => _arrEA = arrEA;

        // генерация и вывод данных массива электроприборов
        public void ShowInitializer(){
            Arr.Initialize();
            Arr.Show("Массив товаров был сформирован");
        } // ShowInitializer

        // вывод данных коллекции электроприборов
        public void Show() => Arr.Show("Массив приборов");

        // перемешивание и вывод данных массива электроприборов
        public void MixingDate(){
            Arr.Shuffle();
            Arr.Show("Список перемешанных приборов");
        } // MixingDate

        // сортировка электроприборов по их названию
        public void SortByElectroName(){
            Arr.OrderByElectroName();
            Arr.Show("Массив электроприборов отсортирован по названию");
        } // SortByElectroName

        // сортировка электроприборов по их мощности (возростание)
        public void SortByElectroPower(){
            Arr.OrderByElectroPower();
            Arr.Show("Массив электроприборов отсортирован по мощности");
        } // SortByElectroPower

        // случайный переход между состояниями (включен/выключен) для электроприборов
        public void RandomStateElectroElectro(){
            Arr.RandomState();
            Arr.Show("Все электроприборы случайным образом перешли в определенное состояние");
        } // RandomStateElectroElectro

        // включение всех электроприборов в коллекции
        public void TurnOnAllElectro(){
            Arr.AllON();
            Arr.Show("Все электроприборы были переведенны в состояние \"Включен\"");
        } // TurnOnAllElectro

        // выключение всех электроприборов в коллекции
        public void TurnOffAllElectro(){
            Arr.AllOFF();
            Arr.Show("Все электроприборы были переведенны в состояние \"Выключен\"");
        } // TurnOffAllElectro
    } // Task2
}
