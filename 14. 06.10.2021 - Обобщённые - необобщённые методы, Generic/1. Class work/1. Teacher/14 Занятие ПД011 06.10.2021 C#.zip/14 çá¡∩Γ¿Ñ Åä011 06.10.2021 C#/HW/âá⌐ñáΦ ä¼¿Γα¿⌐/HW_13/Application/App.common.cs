﻿using System;
using HW_13.Controllers;

namespace HW_13.Application{
    internal partial class App{

        Task1 _task1;
        Task2 _task2;

        public App() : this(new Task1(), new Task2()) { }
        public App(Task1 task1, Task2 task2){
            _task1 = task1;
            _task2 = task2;
        } // App


    } // App
}
