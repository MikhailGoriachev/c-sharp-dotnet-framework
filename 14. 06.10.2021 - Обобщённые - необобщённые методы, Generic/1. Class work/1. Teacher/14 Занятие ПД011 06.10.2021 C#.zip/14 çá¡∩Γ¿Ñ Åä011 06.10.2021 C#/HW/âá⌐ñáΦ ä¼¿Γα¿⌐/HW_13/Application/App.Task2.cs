﻿using System;

namespace HW_13.Application{
    internal partial class App{

        // Вывод массива
        public void task2_1(){
            _task2.ShowInitializer();
        } // task2_1

        // Перемешивание элементов массива
        public void task2_2(){
            _task2.MixingDate();
        } // task2_2

        // Сортировка по названию
        public void task2_3(){
            _task2.SortByElectroName();
        } // task2_3

        // Сортировка по мощности
        public void task2_4(){
            _task2.SortByElectroPower();
        } // task2_4

        // Перемешать состояние всех эл.приборов
        public void task2_5(){
            _task2.RandomStateElectroElectro();
        } // task2_5

        // Включение всех приборов
        public void task2_6(){
            _task2.TurnOnAllElectro();
        } // task2_6

        // Выключение всех приборов
        public void task2_7(){
            _task2.TurnOffAllElectro();
        } // task2_7
    } // App
}
