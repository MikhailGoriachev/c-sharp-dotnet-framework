﻿using System;
using HW_13.Helpers;

namespace HW_13.Controllers{
    internal class Task1{
        private const int N = 10; // какой длины будет массив

        private int[] _arr; // сам массив
        public int[] Arr { 
            get=>_arr;
            set=>_arr = value; 
        } // Arr

        // конструктор по умолчанию
        public Task1() : this(new int[N]) { Init(); }
        // конструктор с параметрами
        public Task1(int[] arr) {
            Arr = arr;
        } // Task1

        public void Init(){ // для инициализации массива

            // Array.ForEach(Arr, x => x = Utils.Random.Next(-10, 11));
            // я сделал так, потому что не понял почему код строкой выше не работает
            for(int i = 0;i<Arr.Length;i++)
                Arr[i] = Utils.Random.Next(-10, 11);

        } // Init

        public delegate void Delegate();


        // показ массива
        public void Show(){
            Console.Write("\n\tМассив целых чисел:\n\t");
            Array.ForEach(Arr, x => Console.Write($"{x}\t"));
            Console.WriteLine();
        } // Show

        // ------------------------------------------------------------------------------
        
        // поиск минимального элемента
        public int MinElem(){
            int minEl = Arr[0];
            Array.ForEach(Arr, x => minEl = x < minEl ? minEl = x : minEl);
            return minEl;
        } // MinElem

        // сколько всего минимальных элементов
        public int CountMinElements(){
            int minEl = MinElem();
            int count = 0;
            Array.ForEach(Arr, x => count += x==minEl?1:0);
            return count;
        } // CountMinElements
        
        // специальный метод для вывода минимальных элементов
        public void ShowWithMinElements(){
            int minEl = MinElem();
            Console.Write("\n\tМассив целых чисел с выделленными минимальными элементами:\n\t");
            Array.ForEach(Arr, x => {
                Console.ForegroundColor = x == minEl? ConsoleColor.Red : ConsoleColor.Gray;
                Console.Write($"{x}\t");
            });
            Console.ForegroundColor = ConsoleColor.Gray;
            minEl = CountMinElements();
            Console.Write($"\n\n\tКол-во минимальных элементов = {minEl}\n");
        } // ShowWithMinElements

        // ----------------------------------------------------------------------------
        
        // поиск индекса первого положительного
        public int FirstPos()=>
            Array.FindIndex(Arr, x=> x >= 0);

        // поиск индекса последнего положительного
        public int LastPos()=>
            Array.FindLastIndex(Arr, x=> x>= 0);

        // сумма в диапазоне
        public int SumDiapazone(int firstEl, int lastEl) {
            int sum = 0, i = 0;
            Array.ForEach(Arr, x => { sum += firstEl < i && i < lastEl ? x : 0;i++; });
            return sum;
        } // SumDiapazone

        // показать элементы в диапазоне и вывести их сумму
        public void ShowDiapazone(){
            int FP = FirstPos(), LP = LastPos(), sum = SumDiapazone(FP, LP);
            Console.Write("\n\tМассив целых чисел с выделенным в нем диапазоне:\n\t");
            int i = 0;
            Array.ForEach(Arr, x => {
                Console.ForegroundColor = (i == FP || i == LP) ? ConsoleColor.Yellow : FP < i && i < LP ? ConsoleColor.Red : ConsoleColor.Gray;
                Console.Write($"{x}\t");
                i++;
            });
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write($"\n\n\tСумма чисел в диапазоне = {sum}\n");
        } // ShowDiapazone

        // ----------------------------------------------------------------------

        public void SortArrNul() =>
           Array.Sort(Arr, (a, b) => a == 0 ? -1 : a == 0 ? 1 : 0);

        public void Del1(){
            Init();
            Delegate de = Show;
            de += ShowWithMinElements;
            de += ShowDiapazone;
            de += SortArrNul;
            de += Show;
            de.Invoke();
        } // Del1

        // -----------------------------------------------------------------------

        // для 2 задания в 1 задании
        public void NewInit(){
            Init();
        } // NewInit

        // кол-во отрицательных элементов
        public int CountNegElements(){
            int count = 0;
            Array.ForEach(Arr, x => count += x<0?1:0);
            return count;
        } // CountNegElements

        // Показать кол-во отрицательных элементов 
        public void ShowNegatives(){
            int count = CountNegElements();
            Console.Write("\n\tМассив целых чисел, с выделленными отрицательными элементами\n\t");
            Array.ForEach(Arr, x => {
                Console.ForegroundColor = x <0 ? ConsoleColor.Red : ConsoleColor.Gray;
                Console.Write($"{x}\t");
            });
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write($"\n\n\tКол-во отрицательных элементов в массиве = {count}\n");
        } // ShowNegatives

        // первый отрицательный элемент
        public int FirstNeg() =>
            Array.FindIndex(Arr, x=>x<0);
        
        // второй отрицательный элемент
        public int SecondNeg()=>
            Array.FindIndex(Arr, FirstNeg()+1, x => x < 0);

        // показать элементы в диапазоне и вывести их сумму
        public void ShowDiapazoneNeg(){
            int FP = FirstNeg(), SP = SecondNeg(); int sum = SumDiapazone(FP, SP);
            Console.Write("\n\tМассив целых числе с диапазоном между 1(-) и вторым(-)\n\t");
            int i = 0;
            Array.ForEach(Arr, x => {
                Console.ForegroundColor = (i == FP || i == SP) ? ConsoleColor.Yellow : FP < i && i < SP ? ConsoleColor.Red : ConsoleColor.Gray;
                Console.Write($"{x}\t");
                i++;
            });
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write($"\n\n\tСумма в диапазоне = {sum}\n");
        } // ShowDiapazone

        public void SortArrAbs() =>
          Array.Sort(Arr, (a, b) => Math.Abs(a) <= 3 && Math.Abs(b) > 3 ? -1 : Math.Abs(a) > 3 && Math.Abs(b) <= 3 ? 1 : 0);

        public void Del2(){
            Delegate de = NewInit;
            de += ShowNegatives;
            de += ShowDiapazoneNeg;
            de += SortArrAbs;
            de += Show;
            de.Invoke();
        } // Del2

    } // Task1
}
