﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW13.Models.Task1
{
	static internal class ArrayOperations
	{
		internal delegate bool Predicate(int x);

		// Вычислить количество элементов, по условию
		public static int CountOf(int[] arr, Predicate pred)
		{
			int count = 0;
			foreach (var elem in arr)
				if (pred(elem)) count++;

			return count;
		}

		// Вычислить сумму элементов по условию
		public static int SumInRange(int[] arr, Predicate pred)
		{
			int sum = 0;
			for (int i = 0; i < arr.Length; i++)
				if (pred(i)) sum += arr[i];
			return sum;
		}

		// Найти первое вхождение по условию
		public static int IndexOf(int[] arr, Predicate pred)
		{
			int index = -1;
			for (int i = 0; i < arr.Length; i++)
			{
				if (pred(arr[i]))
				{
					index = i;
					break;
				}
			}

			return index;
		}

		// Найти последнее вхождение по условию
		public static int LastIndexOf(int[] arr, Predicate pred)
		{
			int index = -1;
			for (int i = 0; i < arr.Length; i++)
				if (pred(arr[i]))
					index = i;

			return index;
		}


	}
}
