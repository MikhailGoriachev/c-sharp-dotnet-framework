﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW13.Models.Task1;

namespace HW13.Controllers
{
	class Task1Controller
	{
		private Array1 _firstArray;
		private Array2 _secondArray;

		private delegate void Proc();

		public Task1Controller() : this(new Array1(), new Array2())
		{}

		public Task1Controller(Array1 firstArray, Array2 secondArray)
		{
			_firstArray = firstArray;
			_secondArray = secondArray;
		}


		public void DemoHandlesGroup1()
		{
			Proc proc = DemoHandle1;
			proc += DemoHandle2;
			proc += DemoHandle3;

			Console.WriteLine($"{Utilities.spaces}Элементы массива: {_firstArray}\n\n");
			proc();
		}

		public void DemoHandlesGroup2()
		{
			Proc proc = DemoHandle4;
			proc += DemoHandle5;
			proc += DemoHandle6;
			Console.WriteLine($"{Utilities.spaces}Элементы массива: {_secondArray}\n\n");
			proc();
		}

		// •	вычислить количество элементов, равных минимальному элементу массива;
		private void DemoHandle1() => 
			Console.WriteLine($"{Utilities.spaces}Количество элементов, равных минимальному элементу: {_firstArray.CountMinValueEquals()}");
		

		//•	вычислить сумму элементов массива, расположенных между первым и последним положительными элементами;
		private void DemoHandle2() =>
			Console.WriteLine($"{Utilities.spaces}Сумма элементов, между первым и последним положительными элементами: {_firstArray.FindSumBetweenFirstLastPositives()}");

		//•	преобразовать массив таким образом, чтобы сначала располагались все   элементы, равные нулю,
		//а потом — все остальные.
		private void DemoHandle3() {
			_firstArray.SortByZeroes();
			Console.WriteLine($"{Utilities.spaces}" +
			                  $"Элементы, равные нулю расположены в начале массива:\n" +
			                  $"{Utilities.spaces}{_firstArray}");
		}

		//•	вычислить количество отрицательных элементов массива;
		private void DemoHandle4() => 
			Console.WriteLine($"{Utilities.spaces}Количество отрицательных элементов массива: {_secondArray.CountNegatives()}");
		

		//•	вычислить сумму элементов массива, расположенных между первым и вторым отрицательными элементами;
		private void DemoHandle5() =>
			Console.WriteLine($"{Utilities.spaces}Сумма элементов, между первым и вторым отрицательными элементами: {_secondArray.FindSumBetweenFirstSecondNegatives()}");


		//•	преобразовать массив таким образом, чтобы сначала располагались все элементы, модуль которых не превышает 3,
		//а потом — все остальные.
		private void DemoHandle6()
		{
			_secondArray.SortByZeroes();
			Console.WriteLine($"{Utilities.spaces}" +
			                  $"Элементы, модуль которых не превышает 3 расположены в начале массива:\n" +
			                  $"{Utilities.spaces}{_secondArray}");
		}
	}
}
