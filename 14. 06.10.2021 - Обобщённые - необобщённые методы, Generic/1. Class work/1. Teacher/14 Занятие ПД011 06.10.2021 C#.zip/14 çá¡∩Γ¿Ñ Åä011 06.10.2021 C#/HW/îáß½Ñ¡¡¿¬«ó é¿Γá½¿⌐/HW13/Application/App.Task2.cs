﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW13
{
	internal partial class App
	{
		private void Task2MenuItem1()
		{
			Utilities.ShowNavBar("Вывести массив электроприборов", 2);
			
			_task2Controller.Show();
		}

		private void Task2MenuItem2()
		{
			Utilities.ShowNavBar("Перемешать элементы массива", 2);

			_task2Controller.ShowShuffled();
		}

		private void Task2MenuItem3()
		{
			Utilities.ShowNavBar("Сортировка по названию", 2);
			
			_task2Controller.ShowOrderedByName();
		}
		private void Task2MenuItem4()
		{
			Utilities.ShowNavBar("Сортировка по мощности прибора", 2);

			_task2Controller.ShowOrderedByPower();
		}

		private void Task2MenuItem5()
		{
			Utilities.ShowNavBar("Включение всех приборов", 2);

			_task2Controller.TurnOnAll();
		}

		private void Task2MenuItem6()
		{
			Utilities.ShowNavBar("Выключение всех приборов", 2);

			_task2Controller.TurnOffAll();
		}

	}
}