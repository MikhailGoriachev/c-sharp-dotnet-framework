﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW13.Models.Task2
{
	// класс, описывающий электроприбор 
	class ElectricAppliance
	{
		// название
		public string Name { get; private set; }
		
		// мощность
		public int Power { get; private set; }

		// цена
		public int Price { get; private set; }

		// включен/выключен
		public bool IsOn { get;  set; }

		public ElectricAppliance() {}
		public ElectricAppliance(string name, int power, int price, bool isOn)
		{
			Name = name;
			Power = power;
			Price = price;
			IsOn = isOn;
		}

		// строковое представление
		public override string ToString() => $"Название: {Name}, Цена: {Price}, Мощность: {Power}, Состояние: {IsOn}";

		// в табличную строку
		public string ToTableRow(int i)
		{
			string state = IsOn ? "Включен" : "Выключен";
			return $"{Utilities.spaces}║ {i,2} ║ {Name,-23} ║ {Price,12} ║ {Power,10} ║ {state,-16} ║\n";
		}

		// шапка таблицы
		static public string Header() =>
				$"{Utilities.spaces}╔════╦═════════════════════════╦══════════════╦════════════╦══════════════════╗\n" +
				$"{Utilities.spaces}║ №  ║ Название электроприбора ║     Цена     ║  Мощность  ║    Состояние     ║\n" +
				$"{Utilities.spaces}╠════╬═════════════════════════╬══════════════╬════════════╬══════════════════╣\n";
		
		// подвал таблицы
		static public string Footer() =>
				$"{Utilities.spaces}╚════╩═════════════════════════╩══════════════╩════════════╩══════════════════╝\n";

		static public ElectricAppliance Generate(string name) =>
			new ElectricAppliance
			{
				Name = name,
				Power = Utilities.GenerateInt(500, 3000),
				Price = Utilities.GenerateInt(1000, 100000),
				IsOn = Utilities.GenerateInt(1, 3) == 1 ? true : false
			};
	}
}
