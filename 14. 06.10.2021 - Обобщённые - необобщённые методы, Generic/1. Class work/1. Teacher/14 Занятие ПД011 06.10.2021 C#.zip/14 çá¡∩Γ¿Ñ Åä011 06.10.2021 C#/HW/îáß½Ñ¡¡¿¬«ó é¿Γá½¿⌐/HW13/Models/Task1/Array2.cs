﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW13.Models.Task1
{
	internal class Array2
	{
		// Границы генерации
		private const int _lo = -5;
		private const int _hi = 5;

		// Массив целочисленных элементов
		private int[] _arr;

		// Конструкторы
		public Array2() : this(new int[Utilities.GenerateInt(10, 20)])
		{ }

		public Array2(int[] arr)
		{
			_arr = arr;
			Fill();
		}


		// Заполнение массива
		public void Fill(int lo = _lo, int hi = _hi)
		{
			for (int i = 0; i < _arr.Length; i++)
				_arr[i] = Utilities.GenerateInt(_lo, _hi + 1);
		}

		// Строковое представление
		public override string ToString()
		{
			string str = "";
			Array.ForEach(_arr, x => str += $"{x,4:D}");
			return str;
		}

		// Вычислить количество отрицательных элементов массива
		public int CountNegatives()
		{
			ArrayOperations.Predicate pred = x => x < 0;
			return ArrayOperations.CountOf(_arr, pred);
		}

		// Вычислить сумму элементов массива, расположенных между первым и вторым отрицательными элементами;
		public int FindSumBetweenFirstSecondNegatives()
		{
			int firstNegative = ArrayOperations.IndexOf(_arr, x => x < 0);
			int[] arr = new int[_arr.Length - firstNegative - 1];
			Array.Copy(_arr, firstNegative + 1, arr, 0, arr.Length);
			int secondNegative = ArrayOperations.IndexOf(arr, x => x < 0) + firstNegative + 1;

			ArrayOperations.Predicate pred = x => x > firstNegative && x < secondNegative;

			return ArrayOperations.SumInRange(_arr, pred);
		}

		// Преобразовать массив таким образом, чтобы сначала располагались все элементы,
		// модуль которых не превышает 3, а потом — все остальные
		public void SortByZeroes()
		{
			Array.Sort(_arr, delegate (int a, int b)
			{
				return Math.Abs(a) <= 3 && Math.Abs(b) > 3 ? -1 : Math.Abs(a) > 3 && Math.Abs(b) <= 3 ? 0 : 1;
			});
		}
	}
}
