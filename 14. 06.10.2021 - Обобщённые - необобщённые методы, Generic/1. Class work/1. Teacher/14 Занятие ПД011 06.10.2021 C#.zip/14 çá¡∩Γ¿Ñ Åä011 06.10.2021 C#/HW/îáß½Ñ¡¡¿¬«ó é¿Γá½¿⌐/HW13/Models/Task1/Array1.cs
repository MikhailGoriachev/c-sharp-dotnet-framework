﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW13.Models.Task1
{
	class Array1
	{
		// Границы генерации
		private const int _lo = -5;
		private const int _hi = 5;

		// Массив целочисленных элементов
		private int[] _arr;

		// Конструкторы
		public Array1() :this(new int[Utilities.GenerateInt(10,20)])
		{}

		public Array1(int[] arr)
		{
			_arr = arr;
			Fill();
		}


		
		// Заполнение массива
		public void Fill(int lo = _lo, int hi = _hi)
		{
			for (int i = 0; i < _arr.Length; i++)
				_arr[i] = Utilities.GenerateInt(_lo, _hi + 1);
		}

		// Строковое представление
		public override string ToString()
		{
			string str = "";
			Array.ForEach(_arr, x => str += $"{x,4:D}");
			return str;
		}

		// Вычислить количество элементов, равных минимальному элементу массива
		public int CountMinValueEquals()
		{
			int min = _arr.Min();
			ArrayOperations.Predicate pred = x => x == min;
			return ArrayOperations.CountOf(_arr, pred);
		}

		// Вычислить сумму элементов массива, расположенных между первым и последним положительными элементами;
		public int FindSumBetweenFirstLastPositives()
		{
			int firstPositive = ArrayOperations.IndexOf(_arr, x => x >= 0);
			int lastPositive = ArrayOperations.LastIndexOf(_arr, x => x >= 0);

			ArrayOperations.Predicate pred = x => x > firstPositive && x < lastPositive;

			return ArrayOperations.SumInRange(_arr, pred);
		}

		// Преобразовать массив таким образом, чтобы сначала располагались все элементы, равные нулю, а потом — все остальные
		public void SortByZeroes()
		{
			Array.Sort(_arr, delegate(int a, int b)
			{
				return a == 0 && b != 0 ? -1 : a != 0 && b == 0 ? 0 : 1;
			});
		}
	}
}
