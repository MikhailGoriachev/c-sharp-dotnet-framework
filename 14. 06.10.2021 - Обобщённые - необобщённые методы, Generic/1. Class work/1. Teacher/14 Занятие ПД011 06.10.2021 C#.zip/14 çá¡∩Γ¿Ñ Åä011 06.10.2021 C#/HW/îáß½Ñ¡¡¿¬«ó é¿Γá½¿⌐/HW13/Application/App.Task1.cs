﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace HW13
{
	internal partial class App
	{
		// Серия обработок массива №1
		private void Task1MenuItem1()
		{
			Utilities.ShowNavBar("Серия обработок массива №1", 2);
			_task1Controller.DemoHandlesGroup1();
		}

		// Серия обработок массива №2
		private void Task1MenuItem2()
		{
			Utilities.ShowNavBar("Серия обработок массива №2", 2);
			_task1Controller.DemoHandlesGroup2();
		}

	}
}
