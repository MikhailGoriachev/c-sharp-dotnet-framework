﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW13.Controllers;

namespace HW13
{
	internal partial class App
	{
		private Menu _mainMenu;
		private Menu _subMenu1;
		private Menu _subMenu2;

		// объекты для решения
		private Task1Controller _task1Controller;
		private Task2Controller _task2Controller;

		public App() : this(new Task1Controller(), new Task2Controller())
		{ }

		public App(Task1Controller task1Controller, Task2Controller task2Controller)
		{
			_task1Controller = task1Controller;
			_task2Controller = task2Controller;
			InitMenu();
		}

		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem("Задание 1", MainMenuItem1),
					new Menu.MenuItem("Задание 2", MainMenuItem2),
					new Menu.MenuItem("Выход")
				}, new Point(5, 5),
				"Меню приложения");

			// Подменю - первое задание
			_subMenu1 = new Menu(new[]
				{
					new Menu.MenuItem("Серия обработок №1", Task1MenuItem1),
					new Menu.MenuItem("Серия обработок №2", Task1MenuItem2),
					new Menu.MenuItem("Назад")
				}, new Point(5, 5),
				"Задание 1");

			// Подменю - второе задание
			_subMenu2 = new Menu(new[]
				{
					new Menu.MenuItem("Вывести массив электроприборов", Task2MenuItem1),
					new Menu.MenuItem("Перемешать элементы массива", Task2MenuItem2),
					new Menu.MenuItem("Сортировка по названию", Task2MenuItem3),
					new Menu.MenuItem("Сортировка по мощности прибора", Task2MenuItem4),
					new Menu.MenuItem("Включение всех приборов", Task2MenuItem5),
					new Menu.MenuItem("Выключение всех приборов", Task2MenuItem6),
					new Menu.MenuItem("Назад")
				}, new Point(5, 5),
				"Задание 2");
			
		}
		
		public void Run() =>_mainMenu.Run();
		private void MainMenuItem1() => _subMenu1.Run(true);
		private void MainMenuItem2() => _subMenu2.Run(true);
		}
}
