﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW13.Models.Task2;

namespace HW13.Controllers
{
	class Task2Controller
	{
		private AppliancesCollection _appliances;
		public Task2Controller() : this(new AppliancesCollection())
		{}

		public Task2Controller(AppliancesCollection appliances) => _appliances = appliances;


		public void Show() => _appliances.Show("Список электроприборов:");

		public void ShowShuffled()
		{
			_appliances.Shuffle();
			_appliances.Show("Список электроприборов перемешан:");
		}

		public void ShowOrderedByName()
		{
			_appliances.OrderByName();
			_appliances.Show("Список электроприборов, упорядоченный по названию:");
		}

		public void ShowOrderedByPower()
		{
			_appliances.OrderByPower();
			_appliances.Show("Список электроприборов, упорядоченный по мощности:");
		}

		public void TurnOnAll()
		{
			_appliances.TurnOnAll();
			_appliances.Show("Все электроприборы включены:");
		}

		public void TurnOffAll()
		{
			_appliances.TurnOffAll();
			_appliances.Show("Все электроприборы выключены:");
		}
	}
}
