﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW13.Models.Task2
{
	// Класс коллекции приборов с её обработками
	class AppliancesCollection
	{
		private const int n = 12;

		// Массив приборов
		private ElectricAppliance[] _appliances;

		public AppliancesCollection() : this(new ElectricAppliance[n])
		{}

		public AppliancesCollection(ElectricAppliance[] appliances)
		{
			_appliances = appliances;
			Initialize();
		}


		// Табличный вывод коллекции
		public void Show(string caption)
		{
			Console.WriteLine($"{Utilities.spaces}{caption}\n");
			Console.Write(ElectricAppliance.Header());
			int i = 1;
			Array.ForEach(_appliances, x => Console.Write(x.ToTableRow(i++)));
			Console.Write(ElectricAppliance.Footer());
		}

		// Перемешивание элементов коллекции
		public void Shuffle()
		{
			int n = _appliances.Length;
			for (int i = 0; i < n - 1; i++)
			{
				int x = i + Utilities._rand.Next(n - i);
				(_appliances[x], _appliances[i]) = (_appliances[i], _appliances[x]);
			}
		}


		// Сортировка по названию
		public void OrderByName() => 
			Array.Sort(_appliances,
				(x1, x2) =>				x1.Name.CompareTo(x2.Name));

		// Сортировка по мощности
		public void OrderByPower() => 
			Array.Sort(_appliances,
				(x1, x2) => x1.Power.CompareTo(x2.Power));

		// Включить все приборы
		public void TurnOnAll() => Array.ForEach(_appliances, x => x.IsOn = true);
		

		// Выключить все приборы
		public void TurnOffAll() => Array.ForEach(_appliances, x => x.IsOn = false);
		

		// Инициализация коллекции
		public void Initialize()
		{
			_appliances = new ElectricAppliance[]
			{
			ElectricAppliance.Generate("Утюг"),
			ElectricAppliance.Generate("Вентилятор"),
			ElectricAppliance.Generate("Холодильник"),
			ElectricAppliance.Generate("Телевизор"),
			ElectricAppliance.Generate("Тостер"),
			ElectricAppliance.Generate("Обогреватель"),
			ElectricAppliance.Generate("Кондиционер"),
			ElectricAppliance.Generate("Телевизор"),
			ElectricAppliance.Generate("Ресивер"),
			ElectricAppliance.Generate("Бойлер"),
			ElectricAppliance.Generate("Микроволновая печь"),
			ElectricAppliance.Generate("Стиральная машинка"),
			};
		}
		
	}
}
