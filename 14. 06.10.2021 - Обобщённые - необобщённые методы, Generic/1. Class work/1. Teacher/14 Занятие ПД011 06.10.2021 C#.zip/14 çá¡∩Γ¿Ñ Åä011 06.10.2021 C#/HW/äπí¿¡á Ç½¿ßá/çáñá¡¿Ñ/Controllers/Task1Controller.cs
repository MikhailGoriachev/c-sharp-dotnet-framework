﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Helpers;
using Задание.Models.Task1;

namespace Задание.Controllers
{
    class Task1Controller {
        private int[] _arr; // массив для обработки

        // количество элементов в массиве по умолчанию
        private const int NElem = 10;

        public delegate bool ForShow(int a);
        public Task1Controller() : this(new int[NElem]) {
            Initialize();
        } // Task1Controller

        public void Initialize(int lo = -5, int hi = 8) {
            for(int i =0; i < _arr.Length; i++) _arr[i] = Utils.Random.Next(lo, hi + 1);
        } // Initialize

        Task1Controller(int[] arr) {
            _arr = arr;
        } // Task1Controller


        #region Обработка №1

        // вычислить количество элементов, равных минимальному элементу массива
        public void Processing1Part1(int indent = 8) {
            string space = " ".PadRight(indent);

            ShowTitle("Вычислить количество элементов, равных минимальному элементу массива", indent);

             int iMin = _arr[0];
             // поиск минимального элемента для вывода
             Array.ForEach(_arr, a => { iMin = a < iMin ? a : iMin; });

            Show(_arr, $"{space}Исходный массив: ", delegate(int a) { return a == iMin; });


            Console.WriteLine($"{space}Количество элементов, равных минимальному элементу массива: {Processing1.Part1(_arr)}");
        } // Processing1Part2

        // вычислить сумму элементов массива, расположенных между первым и последним положительными элементами
        public void Processing1Part2(int indent = 8) {
            string space = " ".PadRight(indent);

            ShowTitle("Вычислить сумму элементов массива, расположенных между первым и последним положительными элементами", indent);

            ShowDiapazone(_arr, $"{space}Исходный массив: ",
                Array.FindIndex(_arr, delegate (int a) { return a > 0; }),
                Array.FindLastIndex(_arr, delegate (int a) { return a > 0; }));

            Console.WriteLine($"{space}Cумма элементов массива, расположенных между первым и последним положительными элементами: {Processing1.Part2(_arr)}");
        } // Processing1Part2

        // Преобразовать массив таким образом, чтобы сначала располагались все элементы, равные нулю, а потом — все остальные
        public void Processing1Part3(int indent = 8) { 
            string space = " ".PadRight(indent);

            ShowTitle("Преобразовать массив таким образом, чтобы сначала располагались все элементы, равные нулю, а потом — все остальные", indent);

            Show(_arr, $"{space}Массив до обработки   : ");
            Processing1.Part3(_arr);
            Show(_arr, $"{space}Массив после обработки: ");

        } // Processing1Part3
        #endregion

        #region Обработка №2
        // Вычислить количество отрицательных элементов массива
        public void Processing2Part1(int indent = 8) {
            string space = " ".PadRight(indent);

            ShowTitle("Вычислить количество отрицательных элементов массива", indent);

            Show(_arr, $"{space}Исходный массив: ", delegate (int a) { return a < 0; });

            Console.WriteLine($"{space}Количество отрицательных элементов массива: {Processing2.Part1(_arr)}");
        } // Processing2Part2

        // Вычислить сумму элементов массива, расположенных между первым и вторым отрицательными элементами
        public void Processing2Part2(int indent = 8) {
            string space = " ".PadRight(indent);

            ShowTitle("Вычислить сумму элементов массива, расположенных между первым и вторым отрицательными элементами", indent);

            int first = Array.FindIndex(_arr, delegate (int a) { return a < 0; });

            ShowDiapazone(_arr, $"{space}Исходный массив: ",
                first,  // индекс первого отрицательного элемента
                Array.FindIndex(_arr, first + 1, delegate (int a) { return a < 0; })); // индекс второго отрицательного элемента

            Console.WriteLine($"{space}Cумма элементов массива, расположенных между первым и вторым отрицательными элементами: {Processing2.Part2(_arr)}");
        } // Processing2Part2

        // Преобразовать массив таким образом, чтобы сначала располагались все элементы, модуль которых не превышает 3, а потом — все остальные
        public void Processing2Part3(int indent = 8) {
            string space = " ".PadRight(indent);

            ShowTitle("Преобразовать массив таким образом, чтобы сначала располагались все элементы, модуль которых не превышает 3, а потом — все остальные", indent);

            Show(_arr, $"{space}Массив до обработки   : ");
            Processing2.Part3(_arr);
            Show(_arr, $"{space}Массив после обработки: ");

        } // Processing1Part3
        #endregion

        #region Виды вывода массива
        private static void Show(int[] arr, string s) {
            Console.Write(s);
            Array.ForEach(arr, a => { Console.Write($"{a,5} "); });
            Console.WriteLine();
        } // Show

        private static void Show(int[] arr, string s, ForShow forShow) {
            Console.Write(s);

            (ConsoleColor fg, ConsoleColor bg) oldColor = (Console.ForegroundColor, Console.BackgroundColor);

            Array.ForEach(arr, a => {
                // выделение цветом
                (Console.ForegroundColor, Console.BackgroundColor) =
                forShow(a)? (ConsoleColor.Black, ConsoleColor.Cyan)
                : oldColor;

                Console.Write($"{a,5} ");

                (Console.ForegroundColor, Console.BackgroundColor) = oldColor;
            });

            Console.WriteLine();
        } // Show

        private static void ShowDiapazone(int[] arr, string s, int first, int last) {
            Console.Write(s);

            (ConsoleColor fg, ConsoleColor bg) oldColor = (Console.ForegroundColor, Console.BackgroundColor);

            for (int i = 0; i < arr.Length; i++) {
                // выделение цветом 
                (Console.ForegroundColor, Console.BackgroundColor) =
                i == first || i == last ? (ConsoleColor.Black, ConsoleColor.Cyan) : 
                i > first && i < last ? (ConsoleColor.Black, ConsoleColor.Green) : 
                oldColor;

                Console.Write($"{arr[i],5} ");

                (Console.ForegroundColor, Console.BackgroundColor) = oldColor;
            } // for i

            Console.WriteLine();
        } // Show

        private static void ShowTitle(string s, int indent) {
            string space = " ".PadRight(indent);
            (ConsoleColor fg, ConsoleColor bg) oldColor = (Console.ForegroundColor, Console.BackgroundColor);

            (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Cyan);
            Console.WriteLine($"\n\n{space}{s}  \n");
            (Console.ForegroundColor, Console.BackgroundColor) = oldColor;
        } // ShowTitle

        #endregion

    } // Task1Controller
}
