﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    // Обработка №1:
    //      •	вычислить количество элементов, равных минимальному элементу массива;
    //      •	вычислить сумму элементов массива, расположенных между первым и последним положительными элементами;
    //      •	преобразовать массив таким образом, чтобы сначала располагались все элементы, равные нулю, а потом — все остальные.

    class Processing1 {
        // вычислить количество элементов, равных минимальному элементу массива
        static public int Part1(int[] arr) {
            int iMin = arr[0];
            // поиск минимального элемента
            Array.ForEach(arr, delegate (int a) { iMin = a < iMin ? a : iMin; });

            // количество элементов, равных минимальному элементу массива
            return Array.FindAll(arr, delegate (int a) { return a == iMin; }).Length;
        } // Part1

        // вычислить сумму элементов массива, расположенных между первым и последним положительными элементами
        static public int Part2(int[] arr) {
            // поиск индекса первого положительного элемента
            int first = Array.FindIndex(arr, delegate (int a) { return a > 0; });
            // поиск индекса последнего положительного элемента
            int last  = Array.FindLastIndex(arr, delegate (int a) { return a > 0; });

            // сумма элементов массива, расположенных между первым и последним положительными элементами
            int sum = 0;
            for (int i = first + 1; i < last; i++) sum += arr[i];

            return sum;
        } // Part2

        // Преобразовать массив таким образом, чтобы сначала располагались все элементы, равные нулю, а потом — все остальные
        static public void Part3(int[] arr) {
            Array.Sort(arr, delegate (int x, int y) { return x == 0 && y != 0 ? -1 : x != 0 && y == 0 ? 1 : 0; });
        } // Part3

    }
}
