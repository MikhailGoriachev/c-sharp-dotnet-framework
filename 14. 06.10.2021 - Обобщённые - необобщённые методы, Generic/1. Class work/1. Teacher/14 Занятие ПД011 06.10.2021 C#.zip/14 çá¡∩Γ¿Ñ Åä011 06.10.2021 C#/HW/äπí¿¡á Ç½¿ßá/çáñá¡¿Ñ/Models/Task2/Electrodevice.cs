﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    class Electrodevice {
        private string _name; // название
        private int _power;   // мощность
        private int _price;   // цена
        private bool _state;  // состояние (включен/выключен)

        public string Name {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Electrodevice: Некорректное название электроприбора!"); _name = value; }
        } // Name

        public int Power {
            get => _power;
            set { if (value < 0) throw new Exception("Electrodevice: Некорректная мощность электроприбора!"); _power = value; }
        } // Power

        public int Price {
            get => _price;
            set { if (value <= 0) throw new Exception("Electrodevice: Некорректная цена электроприбора!"); _price = value; }
        } // Price

        public bool State { get => _state; set => _state = value; }

        // Шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}┌───────┬──────────────────────┬──────────┬──────────┬───────────┐\n" +
            $"{spaces}│ N п/п │       Название       │ Мощность │   Цена   │ Состояние │\n" +
            $"{spaces}├───────┼──────────────────────┼──────────┼──────────┼───────────┤\n";
        } // Header

        // Подвал таблицы, статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└───────┴──────────────────────┴──────────┴──────────┴───────────┘\n";

        // вывод в табличном формате
        public string ToTableRow(int row) {
            string state = _state ? "ON" : "OFF";
            return $"│ {row,5} │ {_name,-20} │ {_power,5} Вт │ {_price,8} │ {state,9} │";
        } // ToTableRow


    } // Electrodevice
}
