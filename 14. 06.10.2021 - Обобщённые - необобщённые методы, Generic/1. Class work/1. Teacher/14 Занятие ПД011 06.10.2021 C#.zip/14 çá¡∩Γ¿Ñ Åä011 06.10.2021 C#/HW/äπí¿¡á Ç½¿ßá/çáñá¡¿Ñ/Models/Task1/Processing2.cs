﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    // Обработка №2:
    // •	вычислить количество отрицательных элементов массива
    // •	вычислить сумму элементов массива, расположенных между первым и вторым отрицательными элементами
    // •	преобразовать массив таким образом, чтобы сначала располагались все элементы, модуль которых не превышает 3, а потом — все остальные.

    class Processing2 {
        // вычислить количество отрицательных элементов массива
        static public int Part1(int[] arr) =>
            Array.FindAll(arr, delegate (int a) { return a < 0; }).Length;
        

        // вычислить сумму элементов массива, расположенных между первым и вторым отрицательными элементами
        static public int Part2(int[] arr) {
            // поиск индекса первого отрицательного элемента
            int first = Array.FindIndex(arr, delegate (int a) { return a < 0; });
            // поиск индекса второго отрицательного элемента
            int second = Array.FindIndex(arr, first + 1, delegate (int a) { return a < 0; });

            // сумма элементов массива, расположенных между первым и вторым отрицательными элементами
            int sum = 0;
            for (int i = first + 1; i < second; i++) sum += arr[i];

            return sum;
        } // Part2

        // преобразовать массив таким образом, чтобы сначала располагались все элементы, модуль которых не превышает 3, а потом — все остальные.
        static public void Part3(int[] arr) {
            Array.Sort(arr, delegate (int x, int y) { 
                (int AbsX, int AbsY) = (Math.Abs(x), Math.Abs(y));
                return AbsX < 3 && AbsY >= 3 ? -1 : AbsY < 3 && AbsX >= 3 ? 1 : 0; });
        } // Part3
    } // Processing2
}
