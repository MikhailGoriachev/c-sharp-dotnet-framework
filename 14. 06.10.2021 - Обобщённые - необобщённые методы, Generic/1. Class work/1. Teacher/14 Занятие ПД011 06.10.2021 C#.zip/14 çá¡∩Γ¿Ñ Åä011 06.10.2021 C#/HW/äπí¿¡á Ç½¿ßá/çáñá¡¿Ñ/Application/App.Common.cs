﻿using System;
using Задание.Models.Task1;
using Задание.Controllers;
using Задание.Models.Task2;

namespace Задание.Application
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        Task1Controller _task1;  // объект для решения задачи 1
        Task2Controller _task2;  // объект для решения задачи 2

        // конструктор по умолчанию
        public App() : this(new Task1Controller(), new Task2Controller()) { }

        // конструктор с внедрением зависимостей
        public App(Task1Controller task1, Task2Controller task2) {
            _task1 = task1;
            _task2 = task2;
        } // App

    } // class App
}