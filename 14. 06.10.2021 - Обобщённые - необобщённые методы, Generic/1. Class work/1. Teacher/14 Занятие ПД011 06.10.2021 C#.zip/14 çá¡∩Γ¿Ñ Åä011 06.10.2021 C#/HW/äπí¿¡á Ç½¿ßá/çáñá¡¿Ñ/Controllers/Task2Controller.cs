﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Helpers;
using Задание.Models.Task2;

namespace Задание.Controllers
{
    class Task2Controller {
        // контейнер данных
        private Electrodevice[] _devices;

        public Task2Controller() {
            Initialize();
        } // Task2Controller

        public Task2Controller(Electrodevice[] devices) {
            _devices = devices;
        } // Task2Controller

        // Заполнение массива электроприборов
        public void Initialize() {
            _devices = new Electrodevice[] {
                new Electrodevice{Name = "Фен"              , Power = 1538, Price =  1_200, State = false},
                new Electrodevice{Name = "Утюг"             , Power = 1100, Price =  2_500, State = false},
                new Electrodevice{Name = "Тостер"           , Power = 1100, Price =  1_100, State = false},
                new Electrodevice{Name = "Кофеварка"        , Power = 1500, Price =  1_800, State = false},
                new Electrodevice{Name = "Пылесос"          , Power =  650, Price =  3_400, State = false},
                new Electrodevice{Name = "Блендер"          , Power =  300, Price =  1_450, State = false},
                new Electrodevice{Name = "Холодильник"      , Power =  188, Price = 20_400, State = false},
                new Electrodevice{Name = "Принтер"          , Power =   45, Price =  4_500, State = false},
                new Electrodevice{Name = "Кондиционер"      , Power = 1000, Price = 19_400, State = false},
                new Electrodevice{Name = "Стиральная машина", Power =  425, Price = 18_100, State = false},
            };
        } // Initialize

        public string Show(string caption, int indent) =>
            Show(caption, indent, _devices);

        // Вывести данные массива  в консоль - для вывода 
        public static string Show(string caption, int indent, Electrodevice[] devices) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            StringBuilder sb = new StringBuilder($"\n\n{space}{caption}\n{Electrodevice.Header(indent)}");

            // вывод всех элементов массива объектов данных
            int row = 1;
            Array.ForEach(devices, el => { sb.Append($"{space}{el.ToTableRow(row++)}\n"); });

            // вывод подвала таблицы
            return sb.Append($"{Electrodevice.Footer(indent)}\n").ToString();
        } // Show

        public void Shuffle() {
            for (int i = _devices.Length - 1; i >= 1; i--) {
                int temp = Utils.Random.Next(i + 1);
                (_devices[i], _devices[temp]) = (_devices[temp], _devices[i]);
            } // for i
        } // Shuffle

        // включение всех приборов
        public void TurnOn() =>
            Array.ForEach(_devices, (Electrodevice x) => { x.State = true; });

        // выключение всех приборов
        public void TurnOff() =>
            Array.ForEach(_devices, (Electrodevice x) => { x.State = false; });

        // сортировка по названию
        public void OrderByName() => 
            Array.Sort(_devices, (Electrodevice x, Electrodevice y) => { return x.Name.CompareTo(y.Name); });

        // сортировка по мощности прибора
        public void OrderByPower() => 
            Array.Sort(_devices, (Electrodevice x, Electrodevice y) => { return x.Power.CompareTo(y.Power); });
    } // Task2Controller
}
