﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Models.Task1;
using Задание.Controllers;
using Задание.Helpers;

namespace Задание.Application
{
    /* 
    * Методы для решения задачи 1
    */
    internal partial class App {

        public delegate void Proc(int n);


        // Обработка №1
        public void Processing1() {
            Utils.ShowNavBarTask("    Обработка №1");
            _task1.Initialize();

            Proc dlg;

            dlg  = _task1.Processing1Part1;
            dlg += _task1.Processing1Part2;
            dlg +=  _task1.Processing1Part3;

            dlg(6); // отработает такая цепочка делегатов: Processing1Part1(); Processing1Part2(); Processing1Part3()

        } // Processing1

        // Обработка №2
        public void Processing2() {
            Utils.ShowNavBarTask("   Обработка №2");
            _task1.Initialize();

            Proc dlg;

            dlg =  _task1.Processing2Part1;
            dlg += _task1.Processing2Part2;
            dlg += _task1.Processing2Part3;

            dlg(6); // отработает такая цепочка делегатов: Processing2Part1(); Processing2Part2(); Processing2Part3()
        } // Processing2
    } // App
}
