﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction
using Задание.Helpers;
using Задание.Application;

namespace Задание
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 06.10.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Обработка №1" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Обработка №2" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Начальное формирование массива электроприборов" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Вывод массива электроприборов" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2. Перемешивание массива электроприборов" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2. Упорядочить массив по названию" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Задача 2. Упорядочить массив по мощности прибора" },
                new MenuItem { HotKey = ConsoleKey.H, Text = "Задача 2. Включение всех приборов" },
                new MenuItem { HotKey = ConsoleKey.J, Text = "Задача 2. Выключение всех приборов" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 06.10.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Обработка №1
                        case ConsoleKey.Q:
                            app.Processing1();
                            break;

                        // Обработка №2
                        case ConsoleKey.W:
                            app.Processing2();
                            break;

                        // ------------------------------------------------------------

                        // Начальное формирование массива электроприборов
                        case ConsoleKey.A:
                            app.ElectrodevicesInitialize();
                            break;

                        // Вывод массива электроприборов
                        case ConsoleKey.S:
                            app.ShowElectrodevices();
                            break;

                        // Перемешивание массива электроприборов
                        case ConsoleKey.D:
                            app.DemoShuffle();
                            break;

                        // Упорядочить массив по названию
                        case ConsoleKey.F:
                            app.DemoOrderByName();
                            break;

                        // Упорядочить массив по мощности прибора
                        case ConsoleKey.G:
                            app.DemoOrderByPower();
                            break;

                        // Включение всех приборов
                        case ConsoleKey.H:
                            app.DemoTurnOn();
                            break;

                        // Выключение всех приборов
                        case ConsoleKey.J:
                            app.DemoTurnOff();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
