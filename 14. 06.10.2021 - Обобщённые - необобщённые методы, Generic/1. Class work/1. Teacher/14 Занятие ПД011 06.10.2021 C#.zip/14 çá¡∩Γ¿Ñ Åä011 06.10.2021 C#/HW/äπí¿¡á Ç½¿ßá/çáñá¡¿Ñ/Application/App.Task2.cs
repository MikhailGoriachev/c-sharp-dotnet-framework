﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Models.Task2;
using Задание.Helpers;

namespace Задание.Application
{
    /* 
    * Методы для решения задачи 2
    */
    internal partial class App {

        // Начальное формирование массива электроприборов
        public void ElectrodevicesInitialize() {
            Utils.ShowNavBarTask("   Начальное формирование массива электроприборов");
            _task2.Initialize();
            Console.WriteLine(_task2.Show("Данные сформированы:", 12));
        } // StudentsInitialize

        // Вывод массива электроприборов
        public void ShowElectrodevices() {
            Utils.ShowNavBarTask("   Вывод массива электроприборов");
            _task2.Initialize();
            Console.WriteLine(_task2.Show("Массив электроприборов:", 12));
        } // StudentsInitialize

        // Перемешивание массива электроприборов
        public void DemoShuffle() {
            Utils.ShowNavBarTask("   Перемешивание массива электроприборов");
            _task2.Shuffle();
            Console.WriteLine(_task2.Show("Массив электроприборов перемешан:", 12));
        } // DemoShuffle

        // Упорядочить массив по названию
        public void DemoOrderByName() {
            Utils.ShowNavBarTask("   Упорядочить массив по названию");
            _task2.OrderByName();
            Console.WriteLine(_task2.Show("Массив упорядочен по названию:", 12));
        } // DemoOrderByName

        // Упорядочить массив по мощности прибора
        public void DemoOrderByPower() {
            Utils.ShowNavBarTask("   Упорядочить массив по мощности прибора");
            _task2.OrderByPower();
            Console.WriteLine(_task2.Show("Массив упорядочен по мощности прибора:", 12));
        } // DemoOrderByName

        // Включение всех приборов
        public void DemoTurnOn() {
            Utils.ShowNavBarTask("   Включение всех приборов");
            _task2.TurnOn();
            Console.WriteLine(_task2.Show("Все приборы включены:", 12));
        } // DemoTurnOn

        // Выключение всех приборов
        public void DemoTurnOff() {
            Utils.ShowNavBarTask("   Выключение всех приборов");
            _task2.TurnOff();
            Console.WriteLine(_task2.Show("Все приборы выключены:", 12));
        } // DemoTurnOn

    } // App
}
