﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates.Tasks.Task1
{
    class ArrayTask2
    {
        public int[] _array;

        public ArrayTask2(int n)
        {
            _array = new int[n];
        }

        public void Fill()
        {
            foreach (var item in _array)
            {
                _array[item] = Utils.GetRandomInt(-5, 5);
            }
        }

        public int _totalNegatives;
        public void TotalNegatives() // количество отрицательных элементов 
        {
            int counter = 0;
            foreach(var item in _array)
            {
                if(item < 0)
                {
                    counter++; 
                }
            }

            _totalNegatives = counter;
        }

        public int _sum; // сумма между первым и вторым отрицательными

        public void SumBetweenNegatives()
        {
            int sum = 0;
            int firstindex = Array.FindIndex(_array, i => i < 0);
            int secondindex = Array.FindIndex(_array, firstindex + 1, i => i < 0);

            for(int i = firstindex; i < secondindex; i++)
            {
                sum += _array[i];
            }

            _sum = sum;
        }


        
                         

    }
}
