﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Delegates.Tasks.Task2;

namespace Delegates.Tasks.Task2
{
    class Task2
    {
        Random rand = new Random();
        Appliance[] array = new Appliance[10]
        {
            new Appliance { _title = "Дрель", _capacity = 250, _price = 1200},
            new Appliance { _title = "Кипятильник", _capacity = 345, _price = 1110},
            new Appliance { _title = "Пылесос", _capacity = 120, _price = 1765},
            new Appliance { _title = "Утюг", _capacity = 156, _price = 2300},
            new Appliance { _title = "Чайник", _capacity = 321, _price = 3400},
            new Appliance { _title = "Фен", _capacity = 500, _price = 2345},
            new Appliance { _title = "Миксер", _capacity = 600, _price = 4534},
            new Appliance { _title = "Мясорубка", _capacity = 567, _price = 7343},
            new Appliance { _title = "Тостер", _capacity = 456, _price = 5634},
            new Appliance { _title = "Бритва", _capacity = 745, _price = 2300},
        };

        public void ShowTable()
        {
            Console.WriteLine("\n\n");

            Console.WriteLine($"\t\t ");
            Console.WriteLine("┌──────────────┬─────────────┬───────────────┐");
            Console.WriteLine("│   Название   │  Мощность   │     Цена      |");
            Console.WriteLine("├──────────────┼─────────────┼───────────────┤");


            Array.ForEach(array, item => Console.WriteLine(item.ToTableRow()));
            
            Console.WriteLine("└──────────────┴─────────────┴───────────────┘");

        }

        public void Shuffle()
        {
            for(int i = 0; i<array.Length; i++)
            {
                int j = rand.Next(array.Length - 1);

                (array[i], array[j]) = (array[j], array[i]);
            }
        }

        
    }
}
