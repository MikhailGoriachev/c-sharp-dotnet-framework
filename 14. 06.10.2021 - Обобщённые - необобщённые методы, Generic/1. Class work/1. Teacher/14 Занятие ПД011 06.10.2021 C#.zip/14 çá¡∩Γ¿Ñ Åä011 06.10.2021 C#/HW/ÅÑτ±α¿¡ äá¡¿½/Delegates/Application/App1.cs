﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates.Application
{
    internal partial class App
    {
        public void Task1Point1()
        {
            Utils.ShowNavBarTask(" Вычислить количество элементов, равных минимальному элементу массива");

            Console.WriteLine("\n\n");
            task1.FillArray();
            task1.Show();
            

            Console.ReadKey();
        }

        public void Task1Poit2()
        {
            Utils.ShowNavBarTask(" Вычислить количество элементов, между первым и последним положительными элементами");

            Console.ReadKey();
        }
        public void Task1Poit3()
        {
            Utils.ShowNavBarTask(" Преобразовать массив - все   элементы, равные нулю, а потом — все остальные");

            Console.ReadKey();
        }
        public void Task1Poit4()
        {
            Utils.ShowNavBarTask("Вычислить количество отрицательных элементов массива");

            Console.ReadKey();
        }
        public void Task1Poit5()
        {
            Utils.ShowNavBarTask(" Вычислить сумму элементов массива, между первым и вторым отрицательными элементами");

            Console.ReadKey();
        }
        public void Task1Poit6()
        {
            Utils.ShowNavBarTask("  Преобразовать массив, все элементы, модуль которых не превышает 3, а потом — все остальные");

            Console.ReadKey();
        }
    }
}
