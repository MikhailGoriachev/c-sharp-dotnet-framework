﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates.Tasks.Task1
{
    class ArrayTask1
    {
        public int[] _array;

        public int _lenght => _array.Length;

        public ArrayTask1(int n) 
        {
            _array = new int[n];
        }

        public void Fill()
        {
            for(int i =0; i<_array.Length; i++)
            {
                _array[i] = Utils.GetRandomInt(-5, 5);
            }
        }
        public int _min { get; set; } // количество минимальных элементов
        public void  MinElem()
        {
            
            int min = int.MaxValue;
            foreach(var item in _array)
            {
                if(item < min)
                {
                    min = item;
                    
                }
            }

           int counter = 0;

            foreach(var item in _array)
            {
                if (item == min)
                    counter++;
            }

            _min = counter; 
            
        }

        public int _sum { get; set; }  // сумма между первым и последним положительным

        public void SumBetweenPositives()
        {
            int sum = 0;
            int firstindex = Array.FindIndex(_array, i => i < 0);
            int lastindex = Array.FindLastIndex(_array, i => i < 0);
            for(int i = firstindex; i<lastindex; ++i)
            {
                sum += _array[i];
            }

            _sum = sum;
        } 

        // индексатор
        public int this[int index]
        {
            get => _array[index];
            set => _array[index] = value;
        }

        // сортировка 
        public void SortZerosFirts() => Array.Sort(_array, (int x, int y) => x == 0 && y != 0 ? -1 : x != 0 && y == 0 ? 1 : 0);


    }
}
