﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Delegates.Tasks.Task1;
using Delegates.Tasks.Task2;


namespace Delegates.Application
{
    internal partial class App
    {
        Task1 task1 = new Task1();
        Task2 task2 = new Task2();
        
    }
}
