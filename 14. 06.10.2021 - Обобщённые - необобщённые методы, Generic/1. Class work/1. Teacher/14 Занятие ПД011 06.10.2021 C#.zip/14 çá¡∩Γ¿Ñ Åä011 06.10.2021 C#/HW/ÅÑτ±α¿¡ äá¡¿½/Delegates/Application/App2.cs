﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates.Application
{
    internal partial class App
    {
        public void Task2Point1()
        {
            Utils.ShowNavBarTask(" Вывод массива приборов в табличном формате");

            task2.ShowTable();

            Console.ReadKey();
        }
        public void Task2Point2()
        {
            Utils.ShowNavBarTask(" Перемешивание элементов массива");
            
            Console.WriteLine("Массив до перемешивания");
            task2.ShowTable();
            task2.Shuffle();
            Console.WriteLine("Массив после перемешивания");
            task2.ShowTable();
            

            Console.ReadKey();
        }
        public void Task2Point3()
        {
            Utils.ShowNavBarTask(" Сортировка по названию");

            Console.ReadKey();
        }
        public void Task2Point4()
        {
            Utils.ShowNavBarTask(" Сортировка по  мощности прибора");

            Console.ReadKey();
        }
        public void Task2Point5()
        {
            Utils.ShowNavBarTask(" Включение всех приборов");

            Console.ReadKey();
        }
        public void Task2Point6()
        {
            Utils.ShowNavBarTask("Включение всех приборов");

            Console.ReadKey();
        }
    }
}
