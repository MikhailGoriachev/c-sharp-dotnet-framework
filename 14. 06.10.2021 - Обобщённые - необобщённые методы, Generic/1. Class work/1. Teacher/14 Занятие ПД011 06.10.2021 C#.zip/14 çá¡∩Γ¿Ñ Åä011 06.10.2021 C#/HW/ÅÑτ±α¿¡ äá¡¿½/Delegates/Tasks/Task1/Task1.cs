﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Delegates.Tasks.Task1;

namespace Delegates.Tasks.Task1
{
    class Task1
    {
        public const int N = 12;
        ArrayTask1 arr = new ArrayTask1(N);

        public ArrayTask1 _arr => arr;

        public void FillArray()
        {
            arr.Fill();
        }

        public void Show()
        {
            Console.Write("Массив сгенерирован : ");
            for(int i =0; i<arr._lenght; i++)
            {
                Console.Write($" {arr[i]} ");
            }
        }
    }
}
