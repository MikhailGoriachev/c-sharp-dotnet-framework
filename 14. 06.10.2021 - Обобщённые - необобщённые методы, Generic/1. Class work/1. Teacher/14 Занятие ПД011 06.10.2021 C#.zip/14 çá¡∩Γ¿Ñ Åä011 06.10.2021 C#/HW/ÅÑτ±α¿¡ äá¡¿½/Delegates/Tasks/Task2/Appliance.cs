﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates.Tasks.Task2
{
    /*Класс электроприбор*/
    public class Appliance
    {
        public string _title {get; set;} // название 
        public double _capacity { get; set; }// мощность 

        public decimal _price { get; set; } // цена

        

        public string ToTableRow() => $"| {_title, -12} | {_capacity, 11} | {_price, 13} | ";
    }
}
