﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Delegates.Application;

namespace Delegates
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 06.09.2021. Делегаты. Лямбда выражения";

            // меню приложеения
            MenuItem[] menu = new[]
            {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задание 1. Вычислить количество элементов, равных минимальному элементу массива"},
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задание 1. Вычислить количество элементов, между первым и последним положительными элементами"},
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задание 1. Преобразовать массив - все   элементы, равные нулю, а потом — все остальные"},
                //------------------------------------------------------------------------------------------------------------------------------------------
                new MenuItem{ HotKey = ConsoleKey.T, Text = "Задание 1. Вычислить количество отрицательных элементов массива"},
                new MenuItem{ HotKey = ConsoleKey.Y, Text = "Задание 1. Вычислить сумму элементов массива, между первым и вторым отрицательными элементами"},
                new MenuItem{ HotKey = ConsoleKey.A, Text = "Задание 1. Преобразовать массив, все элементы, модуль которых не превышает 3, а потом — все остальные"},
                //----------------------------------------------------------------------------------------------------------------------------------------------------
                new MenuItem{ HotKey = ConsoleKey.S, Text = "Задание 2. Вывод массива приборов в табличном формате"},
                new MenuItem{ HotKey = ConsoleKey.D, Text = "Задание 2. Перемешивание элементов массива"},
                new MenuItem{ HotKey = ConsoleKey.F, Text = "Задание 2. Сортировка по названию"},
                new MenuItem{ HotKey = ConsoleKey.G, Text = "Задание 2. Сортировка по  мощности прибора"},
                new MenuItem{ HotKey = ConsoleKey.H, Text = "Задание 2. Включение всех приборов"},
                new MenuItem{ HotKey = ConsoleKey.J, Text = "Задание 2. Выключение всех приборов"},


            };
            // экземпляр приложения 
            App app = new App();

            while(true)
            {
                try
                {
                    //настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП С# - Делегаты. Лямбда выражения");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с делегатами", menu);

                    // получения кода клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = " Нажмите выделенныую цветом клавишу для выбора ".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch(key)
                    {
                        //пункты меню, относящиеся  к Задаче  1 
                        #region Задача 1
                        case ConsoleKey.Q:
                            app.Task1Point1();
                            break;
                        case ConsoleKey.W:
                            app.Task1Poit2();
                            break;
                        case ConsoleKey.R:
                            app.Task1Poit3();
                            break;
                        case ConsoleKey.T:
                            app.Task1Poit4();
                            break;
                        case ConsoleKey.Y:
                            app.Task1Poit5();
                            break;
                        case ConsoleKey.A:
                            app.Task1Poit6();
                            break;
                        #endregion

                        // пункты меню, относящиеся к Задаче 2
                        #region Задача 2
                        case ConsoleKey.S:
                            app.Task2Point1();
                            break;
                        case ConsoleKey.D:
                            app.Task2Point2();
                            break;
                        case ConsoleKey.F:
                            app.Task2Point3();
                            break;
                        case ConsoleKey.G:
                            app.Task2Point4();
                            break;
                        case ConsoleKey.H:
                            app.Task2Point5();
                            break;
                        case ConsoleKey.J:
                            app.Task2Point6();
                            break;
                        #endregion
                    }
                }
                catch(Exception ex)
                {
                    Console.Clear();
                    Console.WriteLine(ex);
                    Console.ReadKey();
                }
            }// while
        }
    }
}
