﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    // Интерфейс ПлоскаяФигура 
    interface FlatFigure {
        // метод для вычисления площади
        double Area();
        // метод для вычисления периметра   
        double Perimeter();
    } // FlatFidure
}
