﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    // Треугольник, наследует от Фигура, реализует интерфейс ПлоскаяФигура
    class Triangle : Figure, FlatFigure {
        private double _a;
        private double _b;
        private double _c;

        // свойство типа кортеж для задания трех сторон
        public (double a, double b, double c) Sides {
            set {
                if (!IsCorrectTriangle(value.a, value.b, value.c)) throw new Exception("Triangle: Некорректные значения сторон! ");
                (_a, _b, _c) = value;
            }
        } // Sides

        // свойства для получения сторон треугольника
        public double A { get => _a; }
        public double B { get => _b; }
        public double C { get => _c; }


        public Triangle(double a, double b, double c) {
            this.Sides = (a, b, c);
        } // Triangle
        public Triangle(double a, double b) : this(a, b, b) { } // Triangle
        public Triangle(double a) : this(a, a) { } // Triangle

        public static Triangle CreateTriangle(double lo = 1d, double hi = 10d) {
            double a, b, c;
            do (a, b, c) = (Utils.GetRandom(lo, hi), Utils.GetRandom(lo, hi), Utils.GetRandom(lo, hi));
            while (!Triangle.IsCorrectTriangle(a, b, c));

            return new Triangle(a, b, c);
        } // CreateTriangle

        // проверка возможности создания треугольника
        public static bool IsCorrectTriangle(double a, double b, double c) =>
            a > 0d && c > 0d & b > 0d && a < c + b && c < a + b && b < c + a;


        public override double Area() {
            double p = Perimeter() / 2d;
            return Math.Sqrt(p * (p - _a) * (p - _b) * (p - _c));
        } // Area

        public double Perimeter() => _a + _b + _c;

        public override string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {"Треугольник",-20} │ {Perimeter(), 12:f2} см │ {Area(),9:f2} см^2 │ {"───", 14} │";
    }
}
