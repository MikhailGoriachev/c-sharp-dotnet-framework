﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    // Класс Фигура – базовый класс иерархии
    abstract class Figure {
        // представление объекта в виде строки таблицы
        public abstract string ToTableRow(int rowNumber);
        public abstract double Area();

        // статический метод для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬──────────────────────┬─────────────────┬────────────────┬────────────────┐\n" +
                $"{spaces}│  №  │        Фигура        │    Периметр     │    Площадь     │      Объём     │\n" +
                $"{spaces}├─────┼──────────────────────┼─────────────────┼────────────────┼────────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴──────────────────────┴─────────────────┴────────────────┴────────────────┘";

        // Компаратор для сортировки по убыванию площади
        public static int AreaComparer(Figure f1, Figure f2) =>
            f2.Area().CompareTo(f1.Area());
    } // Figure
}
