﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Models.Task1;

namespace Задание
{
    /* 
    * Методы для решения задачи 1
    */
    internal partial class App {

        // Начальное формирование массива транспортных средств
        public void VehiclesInitialize() {
            Utils.ShowNavBarTask("   Начальное формирование массива транспортных средств");

            _task1.Initialize();
            _task1.Show("Данные сформированы:", 12);
        } // VehiclesInitialize

        // Вывод массива транспортных средств в консоль
        public void VehiclesShow() {
            Utils.ShowNavBarTask("   Вывод массива транспортных средств в консоль");
            _task1.Show("Массив транспортных средств:", 12);
        } // VehiclesShow


        // Самое старое транспортное средство
        public void OldestVehicle() {
            Utils.ShowNavBarTask("   Самое старое транспортное средство");
            _task1.ShowOldest("Самые старые транспортные средства выделены цветом:", 12);
        } // OldestVehicle


        // Самые быстрые и самые медленные транспортные средства
        public void FastestSlowestVehicles() {
            Utils.ShowNavBarTask("   Самые быстрые и самые медленные транспортные средства");
            Vehicle[] fastest = _task1.FindBySpeed(_task1.FastestVehicle());
            Vehicle[] slowest = _task1.FindBySpeed(_task1.SlowestVehicle());

            ArrayVehicle.Show($"Самые быстрые транспортные средства:", 12, fastest);
            Console.WriteLine("\n\n");
            ArrayVehicle.Show("Самые медленные транспортные средства:", 12, slowest);

        } // FastestSlowestVehicles

    } // App
}
