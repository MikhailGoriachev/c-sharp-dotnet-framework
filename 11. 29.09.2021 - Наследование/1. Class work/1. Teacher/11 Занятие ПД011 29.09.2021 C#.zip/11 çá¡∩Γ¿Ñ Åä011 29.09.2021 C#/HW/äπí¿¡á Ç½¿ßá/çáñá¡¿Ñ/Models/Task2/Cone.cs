﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    // Конус, наследует от Фигура, реализует интерфейс ОбъемнаяФигура
    class Cone: Figure, VolumetricFigure {
        private double _r; // радиус основания
        private double _h; // высота

        public double R {
            get => _r;
            set { if (value <= 0d) throw new Exception("Cone: Некорректное значения радиуса основания!"); _r = value; }
        } // R
        public double H {
            get => _h;
            set { if (value <= 0d) throw new Exception("Cone: Некорректное значения высоты!"); _h = value; }
        } // H

        // длина образующей
        public double L {
            get => Math.Sqrt(_h * _h + _r * _r);
        } // H
        public override double Area() => Math.PI * _r * (L + _r);
        public double Volume() => 1d/3d * Math.PI * _h * _r * _r;

        public override string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {"Конус",-20} │ {"───",15} │ {Area(),9:f2} см^2 │ {Volume(),9:f2} см^3 │";

    } // Cone
}
