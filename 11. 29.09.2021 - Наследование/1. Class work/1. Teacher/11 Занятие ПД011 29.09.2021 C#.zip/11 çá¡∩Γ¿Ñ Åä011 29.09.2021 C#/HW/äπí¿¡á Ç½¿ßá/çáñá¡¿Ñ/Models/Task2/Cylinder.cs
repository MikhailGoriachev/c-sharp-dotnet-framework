﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2 { 
    // Цилиндр, наследует от Фигура, реализует интерфейс ОбъемнаяФигура
    class Cylinder : Figure, VolumetricFigure {
        private double _r; // радиус основания
        private double _h; // высота

        public double R {
            get => _r;
            set { if (value <= 0d) throw new Exception("Cylinder: Некорректное значения радиуса основания!"); _r = value; }
        } // R
        public double H {
            get => _h;
            set { if (value <= 0d) throw new Exception("Cylinder: Некорректное значения высоты!"); _h = value; }
        } // H

        public override double Area() => 2d * Math.PI * _r * (_h + _r);
        public double Volume() => Math.PI * _r * _r * _h;

        public override string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {"Цилиндр",-20} │ {"───",15} │ {Area(),9:f2} cм^2 │ {Volume(),9:f2} cм^3 │";

    } // Cylinder
}
