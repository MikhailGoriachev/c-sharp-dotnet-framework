﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    class ArrayFigure {
        private Figure[] _figures;         // коллекция фигур

        public bool Empty => _figures.Length == 0;

        public ArrayFigure(Figure[] figures) {
            _figures = figures;
        } // ArrayFigure
        public ArrayFigure() {
            Initialize();
        } // ArrayFigure

        public void Initialize() {
            _figures = new Figure[] {
                Triangle.CreateTriangle(),
                Triangle.CreateTriangle(),
                new Rectangle{A = Utils.GetRandom(1d, 10d), B = Utils.GetRandom(1d, 10d)},
                new Rectangle{A = Utils.GetRandom(1d, 10d), B = Utils.GetRandom(1d, 10d)},
                new Cylinder {H = Utils.GetRandom(1d, 10d), R = Utils.GetRandom(1d, 10d)},
                new Cylinder {H = Utils.GetRandom(1d, 10d), R = Utils.GetRandom(1d, 10d)},
                new Cone     {H = Utils.GetRandom(1d, 10d), R = Utils.GetRandom(1d, 10d)},
                new Cone     {H = Utils.GetRandom(1d, 10d), R = Utils.GetRandom(1d, 10d)}
            };
        } // Initialize

        // Вывести массив фигур
        public void Show(string caption, int indent)
        {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n{space}{caption}\n" +
                              $"{Figure.Header(indent)}");

            // вывод всех элементов массива фигур
            int row = 1;
            void OutItem(Figure p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(_figures, OutItem);

            // вывод подвала таблицы 
            Console.WriteLine(Figure.Footer(indent));
        } // Show

        // Вывести массив фигур
        static public void Show(string caption, int indent, Figure[] figures) {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n{space}{caption}\n" +
                              $"{Figure.Header(indent)}");

            // вывод всех элементов массива фигур
            int row = 1;
            void OutItem(Figure p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(figures, OutItem);

            // вывод подвала таблицы 
            Console.WriteLine(Figure.Footer(indent));
        } // Show

        // Выбор фигур, площадь которых, равна некоторому числу
        public Figure[] FindByArea(double area) {
            // предикат для отбора товаров
            bool IsFind(Figure v) => Math.Abs(v.Area() - area) <= 1e-5;

            // отбор товаров 
            Figure[] selected = Array.FindAll(_figures, IsFind);

            return selected;
        } // FindBySpeed

        // поиск минимальной площади
        public double MinArea() {
            double area = _figures[0].Area();

            foreach (var item in _figures)
                if (item.Area() < area) area = item.Area();

            return area;
        } // MinArea

        // поиск максимальной площади
        public double MaxArea() {
            double area = _figures[0].Area();

            foreach (var item in _figures)
                if (item.Area() > area) area = item.Area();

            return area;
        } // MaxArea

        // сортировка массива фигур по убыванию площади
        public void OrderByArea() => Array.Sort(_figures, Figure.AreaComparer);

    }
}
