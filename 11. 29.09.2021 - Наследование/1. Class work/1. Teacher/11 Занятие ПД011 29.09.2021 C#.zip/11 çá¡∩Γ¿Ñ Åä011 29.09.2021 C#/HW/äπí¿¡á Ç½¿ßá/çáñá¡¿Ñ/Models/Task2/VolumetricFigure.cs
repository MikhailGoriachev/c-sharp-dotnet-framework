﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    // Интерфейс ОбъемнаяФигура
    interface VolumetricFigure {
        // метод для вычисления площади поверхности
        double Area();
        // метод для вычисления объема
        double Volume();
    }
}
