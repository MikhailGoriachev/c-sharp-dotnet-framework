﻿using Main.Utilities.Guards;


namespace Main.Models.Task1
{


	public class Ship : Vehicle
	{
		private int _passengers;
		private string _harbor;

		
		public string Harbor
		{
			get => _harbor;
			set => _harbor = Guard.Against.NullEmptyWhitespace(value, nameof(value));
		}

		
		public int Passengers
		{
			get => _passengers;
			set => _passengers = Guard.Against.Negative(value, nameof(value));
		}
	}


}
