﻿using System;
using System.Drawing;


namespace Main.Utilities.TableFormatter
{


	public sealed class TableOptions
	{
		public Color ColorByPredicate { get; set; }
		public Color DefaultColor { get; set; }
		public Point CursorPosition { get; set; } = new Point(Console.CursorLeft, Console.CursorTop);
	}


}
