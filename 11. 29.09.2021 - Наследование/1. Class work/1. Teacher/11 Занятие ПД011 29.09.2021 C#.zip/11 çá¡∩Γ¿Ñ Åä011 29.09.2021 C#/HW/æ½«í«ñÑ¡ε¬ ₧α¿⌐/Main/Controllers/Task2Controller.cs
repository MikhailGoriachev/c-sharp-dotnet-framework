﻿using System;
using Main.Models.Task2;
using Main.Utilities.TableFormatter;


namespace Main.Controllers
{


	public class Task2Controller
	{
		public static readonly double Eps = 0.5;
		
		private Figure[] _figures = new Figure[]
		{
			new Conoid(5.78, 12.3),
			new Conoid(9.2, 4.8),
			new Cylinder(7.53, 12.8),
			new Cylinder(7.528, 12.8),
			new Rectangle(4,5),
			new Rectangle(9, 3),
			new Triangle(6.17, 6.64, 4.20),
			new Triangle(6.17, 6.63, 4.20)
		};
		
		
		public void Show() => new TableFormatter<Figure>().Show(_figures);

		
		public static void Show(Figure[] figures) => new TableFormatter<Figure>().Show(figures);
		

		public void OrderByAreaDescending()
		{
			int CompareByAreaDescending(Figure lhs, Figure rhs) => rhs.Area.CompareTo(lhs.Area);
			
			Array.Sort(_figures, CompareByAreaDescending);
		}


		public Figure[] SelectWithMinArea()
		{
			double minArea = FindMinArea();

			bool IsMinArea(Figure obj) => Math.Abs(obj.Area - minArea) < Eps;

			return Array.FindAll(_figures, IsMinArea);
		}


		private double FindMinArea()
		{
			double minArea = double.MaxValue;

			foreach (Figure f in _figures)
			{
				double currentArea = f.Area;
				
				if (currentArea < minArea)
					minArea = currentArea;
			}
			
			return minArea;
		}
		
		
		public Figure[] SelectWithMaxArea()
		{
			double maxArea = FindMaxArea();

			bool IsMaxArea(Figure obj) => Math.Abs(obj.Area - maxArea) < Eps;

			return Array.FindAll(_figures, IsMaxArea);
		}


		private double FindMaxArea()
		{
			double maxArea = double.MinValue;

			foreach (Figure f in _figures)
			{
				double currentArea = f.Area;
				
				if (currentArea > maxArea)
					maxArea = currentArea;
			}
			
			return maxArea;
		}
	}


}
