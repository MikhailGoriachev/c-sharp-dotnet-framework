﻿using System;


namespace Main.Models.Task2
{


	public class Rectangle : Figure, IFlatFigure
	{
		public Rectangle() { }

		public Rectangle(double a, double b) => Sides = (a, b);

		public double A { get; private set; }
		public double B { get; private set; }

		public (double a, double b) Sides
		{
			get => (A, B);
			set
			{
				var (a, b) = value;

				if (value.CompareTo((0d, 0d)) != 1)
					throw new ArgumentOutOfRangeException(nameof(value));

				(A, B) = value;
			}
		}
		
		
		public override string ParametersAsString => $"A: {A, OutputWidth:F} B: {B, OutputWidth:F}";
		
		public override double Area => (this as IFlatFigure).Area();
		
		public override double PerimeterOrVolume => (this as IFlatFigure).Perimeter();


		double IFlatFigure.Area() => A * B;


		double IFlatFigure.Perimeter() => 2 * (A + B);
	}


}
