﻿using Main.Utilities.Menu;
using Main.Views;


namespace Main
{


	public class App : MenuWrapper
	{
		private readonly Task1View _task1 = new Task1View();
		private readonly Task2View _task2 = new Task2View();


		public App() =>
			Menu = new Menu("Главное меню приложения", new[]
			{
				new MenuItem("Задача 1. Vehicle, Plane, Car, Ship", _task1.Run)
					{ IsSimpleInvoke = true },
				new MenuItem("Задача 2. Обработка фигур", _task2.Run)
					{ IsSimpleInvoke = true }
			});
	}


}
