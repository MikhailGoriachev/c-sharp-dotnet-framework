﻿using Main.Utilities.TableFormatter;


namespace Main.Models.Task2
{


	public abstract class Figure
	{
		protected const int OutputWidth = -13;
		
		[TableData("Параметры",  "{0, -50}")]
		public abstract string ParametersAsString { get; }
		
		[TableData("Площадь", "{0, -12:F}")]
		public abstract double Area { get; }
		
		[TableData("Периметр/Обьем", "{0, -16:F}")]
		public abstract double PerimeterOrVolume { get; }
	}


}
