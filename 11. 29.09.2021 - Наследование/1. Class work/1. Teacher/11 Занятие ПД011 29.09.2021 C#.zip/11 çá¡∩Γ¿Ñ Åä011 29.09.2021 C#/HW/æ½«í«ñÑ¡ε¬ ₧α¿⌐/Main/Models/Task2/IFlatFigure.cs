﻿namespace Main.Models.Task2
{


	public interface IFlatFigure
	{
		double Area();

		double Perimeter();
	}


}
