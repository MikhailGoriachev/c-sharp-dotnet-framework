﻿using System;


namespace Main.Models.Task2
{


	public class Triangle : Figure, IFlatFigure
	{
		public Triangle() { }

		public Triangle(double a, double b, double c) => Sides = (a, b, c);

		public double A { get; private set; }
		public double B { get; private set; }
		public double C { get; private set; }

		public (double a, double b, double c) Sides
		{
			get => (A, B, C);
			set
			{
				var (a, b, c) = value;

				if (value.CompareTo((0d, 0d, 0d)) != 1 || !IsTriangleCanBeFormed(a, b, c))
					throw new ArgumentOutOfRangeException(nameof(value));

				(A, B, C) = value;
			}
		}


		private static bool IsTriangleCanBeFormed(double a, double b, double c) =>
			(a + b > c) & (b + c > a) & (a + c > b);


		public override string ParametersAsString => $"A: {A,OutputWidth:F} B: {B,OutputWidth:F} C: {C,OutputWidth:F}";

		public override double Area => (this as IFlatFigure).Area();

		public override double PerimeterOrVolume => (this as IFlatFigure).Perimeter();


		double IFlatFigure.Area()
		{
			double p = (A + B + C) / 2;

			return Math.Sqrt(p * (p - A) * (p - B) * (p - C));
		}


		double IFlatFigure.Perimeter() => A + B + C;
	}


}
