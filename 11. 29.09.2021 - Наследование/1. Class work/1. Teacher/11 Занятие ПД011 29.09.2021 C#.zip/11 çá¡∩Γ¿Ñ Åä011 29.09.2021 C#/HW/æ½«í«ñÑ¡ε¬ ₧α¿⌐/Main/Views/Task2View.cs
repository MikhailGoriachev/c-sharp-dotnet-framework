﻿using System;
using Main.Controllers;
using Main.Utilities.Menu;


namespace Main.Views
{


	public class Task2View : MenuWrapper
	{
		private readonly Task2Controller _controller = new Task2Controller();
		
		public Task2View() =>
			Menu = new Menu("Задача 2. Обработка фигур", new[]
			{
				new MenuItem("Вывести массив фигур", Show),
				new MenuItem("Упорядочить массив по убыванию площади", OrderByAreaDescending),
				new MenuItem("Выбрать обьекты с минимальной площадью", SelectByMinArea),
				new MenuItem("Выбрать обьекты с максимальной площадью", SelectByMaxArea),
			});


		private void Show()
		{
			Console.WriteLine("Массив фигур:");
			
			_controller.Show();
		}


		private void OrderByAreaDescending()
		{
			_controller.OrderByAreaDescending();

			Console.WriteLine("Массив отсортирован по убыванию площадей");
			_controller.Show();
		}


		private void SelectByMinArea()
		{
			var minAreaFigures = _controller.SelectWithMinArea();

			Console.WriteLine("Исходный массив:");
			_controller.Show();
			
			Console.WriteLine("\n\nФигуры выбраны в отдельный массив по минимальной площади");
			Console.WriteLine($"Погрешность при выборке фигур: {Task2Controller.Eps}");
			Task2Controller.Show(minAreaFigures);
		}
		
		
		private void SelectByMaxArea()
		{
			var maxAreaFigures = _controller.SelectWithMaxArea();

			Console.WriteLine("Исходный массив:");
			_controller.Show();
			
			Console.WriteLine("\n\nФигуры выбраны в отдельный массив по максимальной площади");
			Console.WriteLine($"Погрешность при выборке фигур: {Task2Controller.Eps}");
			Task2Controller.Show(maxAreaFigures);
		}
	}


}
