﻿namespace Main.Models.Task1
{


	public class Car : Vehicle
	{ }


}
