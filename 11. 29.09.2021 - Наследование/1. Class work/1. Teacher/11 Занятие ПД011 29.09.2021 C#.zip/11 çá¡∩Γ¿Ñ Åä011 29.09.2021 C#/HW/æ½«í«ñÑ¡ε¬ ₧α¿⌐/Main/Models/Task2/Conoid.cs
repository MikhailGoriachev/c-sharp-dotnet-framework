﻿using System;
using System.Runtime.CompilerServices;


namespace Main.Models.Task2
{


	public class Conoid : Figure, IVolumeFigure
	{
		public Conoid() { }

		public Conoid(double radius, double height) => Parameters = (radius, height);

		public double Radius { get; private set; }

		public double Height { get; private set; }

		public (double radius, double height) Parameters
		{
			get => (Radius, Height);
			set
			{
				var (radius, height) = value;

				if (value.CompareTo((0d, 0d)) != 1)
					throw new ArgumentOutOfRangeException(nameof(value));

				(Radius, Height) = value;
			}
		}


		public override string ParametersAsString => $"R: {Radius,OutputWidth:F} H: {Height,OutputWidth:F}";

		public override double Area => (this as IVolumeFigure).SurfaceArea();

		public override double PerimeterOrVolume => (this as IVolumeFigure).Volume();


		public double Generatrix() => Math.Sqrt(Math.Pow(Height, 2) + Math.Pow(Radius, 2));


		double IVolumeFigure.SurfaceArea() => Math.PI * Radius * (Radius + Generatrix());


		double IVolumeFigure.Volume() => (1d / 3d * Math.PI) + Math.Pow(Radius, 2) * Height;
	}


}
