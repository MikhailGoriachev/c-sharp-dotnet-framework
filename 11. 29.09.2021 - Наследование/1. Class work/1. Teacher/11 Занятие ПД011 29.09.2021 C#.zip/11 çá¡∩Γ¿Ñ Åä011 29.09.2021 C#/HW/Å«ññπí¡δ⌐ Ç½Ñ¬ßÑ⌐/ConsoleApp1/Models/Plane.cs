﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClasses.Models
{
    // классы Plane самолет
    class Plane : Vehicle
    {
        // высота
        private double _height;
        public double Height
        {
            get { return _height; }
            set {
                if (value <= 0)
                    throw new Exception("Plane: ошибка высоты");
                _height = value; }
        }


        // количество пассажиров
        private int _pass;
        public int Pass
        {
            get { return _pass; }
            set {
                if (value < 0)
                    throw new Exception("Plane: ошибка количества пассажиров"); 
                _pass = value; }
        }


        public Plane((double, double) geo, double price, double speed, int year, double height, int pass): base( geo,  price,  speed,  year) {

            Height = height;
            Pass = pass;

        }


        public override string ToString() {

            StringBuilder result= new StringBuilder();
            result.Append($"*************************************************\n");
            result.Append($"Тип транспорта :                          Самолет\n");
            result.Append($"Географические координаты :     {_geoCoord, 6:f2}\n");
            result.Append($"Цена :                             {_price, 6:f2}\n");
            result.Append($"Скорость :                         {_speed, 6:f2}\n");
            result.Append($"Год выпуска :                      {_year, 6:f2}\n");
            result.Append($"Высота :                           {_height,6:f2}\n");
            result.Append($"Количество пассажиров :            {_pass,6}\n");
            result.Append($"*************************************************\n");

            return result.ToString();


        }



    }
}
