﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AbstractClasses.Models;

namespace AbstractClasses.Tasks
{
    // класс для задания 1
    class Task1
    {
        public Vehicle[] _array { get; private set; }


        // Инициализация массива транспорта
        public void Init() {

             _array = new Vehicle[]{

                new Plane(  (11.756543, 12.734563), 1000d, 300d, 2010, 2000d, 100 ),
                new Plane(  (34.565445, 12.764534), 1200d, 450d, 2016, 2800d, 350 ),
                new Ship(  (56.565235, 58.745534), 10000d, 22d, 2002,10000,"Мурманск" ),
                new Ship(  (63.565335, 45.781534), 9000d, 22d, 2008,4000,"Владивосток" ),
                new Ship(  (56.325335, 23.945534), 500d, 140d, 2012,2000,"Североморск" ),
                new Car(   (74.573435, 93.923134), 300d, 130d, 2018 ),
                new Car(   (82.034535, 43.234134), 700d, 150d, 2010 ),
                new Car(   (23.026435, 72.343234), 300d, 140d, 2020 )
            };


        }


        // Вывод на экран массива транспорта
        public void Show() {

            foreach (Vehicle item in _array)
            {
                Console.WriteLine(item.ToString());
            }


        }


        // самое старое транспортное средство
        public Vehicle FindOldVehicle() {

            int posOldVehicle = 0;
            int year = _array[posOldVehicle].Year;

            for (int i = 0; i < _array.Length; i++)
            {
                if (_array[i].Year < year) { 
                    posOldVehicle = i;
                    year = _array[i].Year;

                }

            }
            return _array[posOldVehicle];
        }

        // самое быстрое и самое медленное транспортные средства (может быть найдено больше 1 транспортного средства) 

        public void LastAndFastVehicle() {

            double maxSpeed=_array[0].Speed;
            double minSpeed = _array[0].Speed;

            for (int i = 1; i < _array.Length; i++)
            {
                if (_array[i].Speed > maxSpeed)
                    maxSpeed = _array[i].Speed;

                if (_array[i].Speed < minSpeed)
                    minSpeed = _array[i].Speed;

            }

            Console.WriteLine($"\nТранспортные средства с максиамльной скоростью: ");
            foreach (Vehicle item in _array)
            {
                if (item.Speed == maxSpeed)
                    Console.WriteLine(item.ToString());
                
            }

            Console.WriteLine($"\nТранспортные средства с минимальной скоростью: ");
            foreach (Vehicle item in _array)
            {
                if (item.Speed == minSpeed)
                    Console.WriteLine(item.ToString());

            }

        }




    }
}
