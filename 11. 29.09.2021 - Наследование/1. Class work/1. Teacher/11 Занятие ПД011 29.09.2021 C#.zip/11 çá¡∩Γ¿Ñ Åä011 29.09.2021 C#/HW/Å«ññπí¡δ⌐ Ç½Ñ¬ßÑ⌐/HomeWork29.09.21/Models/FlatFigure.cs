﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork29._09._21.Models
{
    //	Интерфейс ПлоскаяФигура с методами для вычисления площади и периметра
    interface FlatFigure
    {

        // Метод для нахождения площади
        double Area();

        // Метод для нахождения периметра
        double Perimetr();



    }
}
