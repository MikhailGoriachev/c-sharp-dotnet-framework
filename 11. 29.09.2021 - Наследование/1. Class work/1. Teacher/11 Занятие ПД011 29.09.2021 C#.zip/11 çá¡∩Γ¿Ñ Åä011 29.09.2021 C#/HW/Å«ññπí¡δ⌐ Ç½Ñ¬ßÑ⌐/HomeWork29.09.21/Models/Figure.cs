﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork29._09._21.Models
{
    abstract class Figure
    {
        public abstract int AreaComparer(Figure p1, Figure p2);

        public abstract double Area();
    }
}
