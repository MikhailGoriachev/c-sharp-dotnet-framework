﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork29._09._21.Models
{
    class Rectangle : Figure, FlatFigure
    {
        private double _a;
        public double A
        {
            get { return _a; }
            set
            {
                if (value <= 0)
                    throw new Exception("Rectangle: сторона прямоугольника не может быть меньше или равна 0");
                _a = value;
            }
        }

        private double _b;
        public double B
        {
            get { return _b; }
            set
            {
                if (value <= 0)
                    throw new Exception("Rectangle: сторона прямоугольника не может быть меньше или равна 0");
                _b = value;
            }
        }

        public Rectangle(double a, double b)
        {

            A = a;
            B = b;
           
        }




        // Метод для нахождения площади
        public override double Area()
        {
            return _a * _b;
        }

        // Метод для нахождения периметра
        public double Perimetr()
        {
            return 2d * (_a + _b);
        }

        // компаратор для сортировки по убыванию площади
        public override int AreaComparer(Figure p1, Figure p2)
        {

           return p2.Area().CompareTo(p1.Area());
        }

        public override string ToString()
        {

            StringBuilder result = new StringBuilder();
            result.Append($"*************************************************\n");
            result.Append($"Тип фигуры :                        Прямоугольник\n");
            result.Append($"Сторона А  :                            {_a,6:f2}\n");
            result.Append($"Сторона B  :                            {_b,6:f2}\n");           
            result.Append($"Периметр   :                    {Perimetr(),6:f2}\n");
            result.Append($"Площадь    :                        {Area(),6:f2}\n");
            result.Append($"*************************************************\n");

            return result.ToString();


        }



    }
}
