﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW10.Task1
{
	class Ship : Vehicle
	{
		// Порт приписки
		private string _seaPort;
		public string SeaPort
		{
			get => _seaPort;
			set => _seaPort = value;
		}

		// Кол-во пассажиров
		private int _passengers;
		public int Passengers
		{
			get => _passengers;
			set => _passengers = value;
		}

		public Ship():this(new Point(14, 30), 35000000, 560, 2000, "Артур", 300)
		{}

		public Ship(Point coords, int price, int speed, int prodYear, string seaPort, int passengers)
			: base(coords, price, speed, prodYear, "Корабль")
		{
			_seaPort = seaPort;
			_passengers = passengers;
		}


		public override string ToString() =>
			base.ToString() + $", порт приписки: {_seaPort}, пассажиров: {_passengers}";

		public override string ToTableRow(int indent) =>
			base.ToTableRow(indent) + $" {_passengers,10} ║ {_seaPort,-7} ║        ║";

		public static Ship Generate(string port)
		{
			var coords = new Point(Utilities.GenerateInt(1, 100), Utilities.GenerateInt(1, 100));
			var price = Utilities.GenerateInt(1000, 99_000_000);
			var speed = Utilities.GenerateInt(350, 917);
			var year = Utilities.GenerateInt(1990, 2021);
			var passengers = Utilities.GenerateInt(50, 500);
			return new Ship(coords, price, speed, year, port, passengers);
		}
	}
}
