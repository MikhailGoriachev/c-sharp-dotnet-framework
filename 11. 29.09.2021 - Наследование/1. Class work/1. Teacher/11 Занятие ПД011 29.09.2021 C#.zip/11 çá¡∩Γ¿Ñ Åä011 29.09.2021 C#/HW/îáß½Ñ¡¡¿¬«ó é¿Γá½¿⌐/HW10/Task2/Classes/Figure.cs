﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace HW10.Task2.Classes
{
	// Бызовый класс фигуры
	abstract class Figure
	{
		// поля, используемые наследуемыми классами
		protected double _a;

		protected double _b;

		protected double _c;

		protected double _r;

		protected double _h;

		//  Площадь фигуры
		virtual public double Area { get; }
		
		// Компаратор по уменьшению площади
		public static int CompareByAreaDesc(Figure f1, Figure f2) => f2.Area.CompareTo(f1.Area);

		// Строковое представление
		public override string ToString() => "Геометрическая Фигура ";

		// Шапка таблицы
		public static string Header(int n)
		{
			string spaces = " ".PadRight(n);

			return
				$"{spaces}╔═══════════════╦═════════╦═════════╦═════════╦══════════╦══════════╦══════════╦══════════╦══════════╗\n" +
				$"{spaces}║  Тип фигуры   ║ Сторона ║ Сторона ║ Сторона ║  Радиус  ║  Высота  ║ Периметр ║  Площадь ║  Объем   ║\n" +
				$"{spaces}║               ║    a    ║    b    ║    c    ║    R     ║     H    ║    P     ║    S     ║    V     ║\n" +
				$"{spaces}╠═══════════════╬═════════╬═════════╬═════════╬══════════╬══════════╬══════════╬══════════╬══════════╣\n";
		}

		// Подвал таблицы
		public static string Footer(int n) =>
			$" ".PadRight(n) +
			"╚═══════════════╩═════════╩═════════╩═════════╩══════════╩══════════╩══════════╩══════════╩══════════╝\n";

		// Абстрактный метод представление в виде строки таблицы
		abstract public string ToTableRow(int n);

		// Метод, используемый фигурами для создания табличной строки в зависимости от своих параметров
		protected string MakeTableString(string name, params (string, double)[] args)
		{
			// Строки для всех параметров в таблице, по умолчанию пусты
			string a, b, c, R, H, P, S, V;
			a = b = c = R = H = P = S = V = " ";

			// Усечение строки до двух знаков после запятой
			string makeStr(double x) => x.ToString().Remove(x.ToString().IndexOf(',') + 3);

			// Заполнение переменных данными из переданных параметров
			foreach (var arg in args)
			{
				switch (arg.Item1)
				{
					case "a":			a = makeStr(arg.Item2); break;
					case "b":			b = makeStr(arg.Item2); break;
					case "c":			c = makeStr(arg.Item2); break;
					case "r":			R = makeStr(arg.Item2); break;
					case "h":			H = makeStr(arg.Item2); break;
					case "Perimeter":   P = makeStr(arg.Item2); break;
					case "Area":        S = makeStr(arg.Item2); break;
					case "Volume":      V = makeStr(arg.Item2); break;
				}
			}

			return $"║ {name,-13} ║ {a,7} ║ {b,7} ║ {c,7} ║ {R,8} ║ {H,8} ║ {P,8} ║ {S,8} ║ {V,8} ║";
		}

	}
}
