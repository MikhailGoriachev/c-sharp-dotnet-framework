﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW10.Task2.Classes;

namespace HW10.Task2
{
	// Массив фигур
	class ArrayFigures
	{
		private Figure[] _figures;

		public bool EmptyArray() => _figures is null || _figures.Length == 0;

		public void Show(string title)
		{
			Console.WriteLine(title);

			Console.Write(Figure.Header(4));

			foreach (var elem in _figures)
				Console.WriteLine(elem.ToTableRow(4));

			Console.Write(Figure.Footer(4));
		}

		public void Show(string title, Figure[] figures)
		{
			Console.WriteLine(title);

			Console.Write(Figure.Header(4));

			foreach (var elem in figures)
				Console.WriteLine(elem.ToTableRow(4));

			Console.Write(Figure.Footer(4));
		}

		public void OrderByAreaDesc() => Array.Sort(_figures, Figure.CompareByAreaDesc);

		// фигуры с максимальнаой площадью
		public Figure[] FindMaxArea()
		{
			Figure[] find = new Figure[1] { _figures[0] };
			double maxArea = _figures[0].Area;

			for (int i = 1; i < _figures.Length; i++)
			{
				double area = _figures[i].Area;
				if (area > maxArea)
				{
					find = new Figure[1] { _figures[i] };
					maxArea = area;
				}
				else if (Math.Abs(area - maxArea) < Math.E)
				{
					Array.Resize(ref find, find.Length + 1);
					find[find.Length - 1] = _figures[i];
				}
			}

			return find;
		}

		// фигуры с минимальной площадью
		public Figure[] FindMinArea()
		{
			Figure[] find = new Figure[1] { _figures[0] };
			double minArea = _figures[0].Area;

			for (int i = 1; i < _figures.Length; i++)
			{
				double area = _figures[i].Area;
				if (area < minArea)
				{
					find = new Figure[1] { _figures[i] };
					minArea = area;
				}
				else if (Math.Abs(area - minArea) < Math.E)
				{
					Array.Resize(ref find, find.Length + 1);
					find[find.Length - 1] = _figures[i];
				}
			}

			return find;
		}

		public void Initialize()
		{
			_figures = new Figure[]
			{
				Triangle.Generate(),
				Triangle.Generate(),
				Rectangle.Generate(),
				Rectangle.Generate(),
				Cone.Generate(),
				Cone.Generate(),
				Cylinder.Generate(),
				Cylinder.Generate()
			};
		}

	}
}
