﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW10.Task2.Interfaces;

namespace HW10.Task2.Classes
{
	// Класс определения прямоугольника
	class Rectangle : Figure, IFlateFigure
	{
		public double A
		{
			get => _a;
			private set {
				if (value <= 0)
					throw new ArgumentException(
					"Стороны прямоугольника должны иметь положительное значение");
				_a = value;
			}
		}

		public double B
		{
			get => _b;
			private set {
				if (value <= 0)
					throw new ArgumentException(
						"Стороны прямоугольника должны иметь положительное значение");
				_b = value;
			}
		}

		public override double Area => CalcArea();
		public double Perimeter => CalcPerimeter();

		public Rectangle():this(1d,1d) {}

		Rectangle(double a, double b)
		{
			A = a;
			B = b;
		}


		public double CalcPerimeter() => 2 * (_a + _b);

		public double CalcArea() => _a * _b;


		public override string ToString() => 
			base.ToString() + $"Прямоугольник, a: {_a,6:f2}; b: {_b,6:f2};" +
			$" S = {CalcArea(),8:f2}; P = {CalcPerimeter(),8:f2}";

		public override string ToTableRow(int n) => 
			" ".PadRight(n) + 
			MakeTableString("Прямоугольник", ("a", _a),("b", _b), ("Area", Area),("Perimeter", Perimeter));


		public static Rectangle Generate()
		{
			double a, b;
			a = Utilities.GenerateDouble(1d, 20d);
			b = Utilities.GenerateDouble(1d, 20d);

			return new Rectangle(a, b);
		}

	}
}
