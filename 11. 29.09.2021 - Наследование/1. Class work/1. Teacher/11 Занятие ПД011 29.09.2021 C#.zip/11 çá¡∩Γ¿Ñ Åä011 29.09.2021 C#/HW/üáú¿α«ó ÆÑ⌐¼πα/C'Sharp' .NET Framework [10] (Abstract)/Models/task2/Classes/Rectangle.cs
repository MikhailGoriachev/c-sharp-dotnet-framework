﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Interfaces;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Classes
{
    class Rectangle : Figure,FlatShape{

        private double _b;
        public double B{
            get => _b;
            set => _b = value > 0 ? value : throw new Exception($"Неверные данные для стороны b [ {value} ]");
        }

        public Rectangle() : this(1d, 1d) { }
        public Rectangle(double a, double b) : base(a) => B = b;

        public override double Area() => A * B;
        public override double Perimeter() => (A + B) * 2d;
        public override double Volume() => 0.001d;
        public override double SurfaceAreas() => 0.001d;

        public override string ToString() => base.ToString() + $", b = {B}";

        public override string GetFigure() => "Прямоугольник";

        public override string ToTableRow(string type) =>
              $"\t| {type,-15} │ {A,9:f2} │ {B,9:f2} " +
            $"│ {"─",9:f2} │ {Perimeter(),10:f2} " +
            $"│ {Area(),9:f2} │ {"─",11:f2} " +
            $"│ {"─",8:f2} │";

    }
}
