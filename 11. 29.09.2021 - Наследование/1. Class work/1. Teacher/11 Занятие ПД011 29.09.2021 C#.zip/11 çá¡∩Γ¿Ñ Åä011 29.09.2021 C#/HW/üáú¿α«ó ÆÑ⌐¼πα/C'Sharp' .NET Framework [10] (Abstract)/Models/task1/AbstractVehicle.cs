﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task1
{
    abstract class Vehicle {

        //    Правильно ли задавать конс1танты в абстрактном классе? 
        protected double MinSpeed = 80d,                     // Минимальное значение показателя максимальная скорость
                                                            //        https://5koleso.ru/articles/obzory/samye-medlennye-sovr/
                         MaxSpeed = 2650d,                 //   Максимальная скорость (данные беруться по самолету)
                                                          //          https://hi-news.ru/technology/samyj-bystryj-samolet-v-mire-i-ego-konkurenty-s-kakoj-skorostyu-oni-letayut.html#:~:text=Максимальная%20скорость%20самолета%20составляет%202650,час.%20МиГ-31%20—%20двухместный%20истребитель
                         MinPrice = 1000,                //     Минимальная цена 
                         MinYear = 1960,                //      Минимальный год выпуска 
                         MaxYear = DateTime.Now.Year;  //       Максимальный год выпуска ТС (нынешний год)



        protected CoordXY _coord;  // Координаты транспортного средаства (x,y)
        protected double _speed;   // Скорость (км/ч)
        protected double _price;   // Цена ($)
        protected int _year;       // Год выпуска 

        public double Price
        {
            get => _price;
            set => _price = value >= MinPrice ? value : throw new Exception($"\nТранспортное средство не может стоить меньше{MinPrice}\n");
        } // Price


        public double Speed
        {
            get => _speed;
            set => _speed = value >= MinSpeed && value <= MaxSpeed ? value : throw new Exception($"\nТранспортное средство не может быть медленне,{MinSpeed} или быстрее {MaxSpeed}\n");
        } // Speed


        public int Year
        {
            get => _year;
            set => _year = value >= MinYear && value <= MaxYear ? value : throw new Exception($"\nТранспортное средство не может быть старше {MaxYear}\n");
        } // Year

        // Свойство координат 
        public CoordXY Coord
        {
            get => _coord;
            set => _coord = value;
        }

        // Конструктор по умолчанию 
        public Vehicle() : this(new CoordXY((short)Utils.GetRandom(0,100),(short)Utils.GetRandom(0,100)), 120d, 1300, 2002) { }

        // Конструктор с парамметрами
        public Vehicle(CoordXY coord, double speed, double price, int year) {
            Coord = coord;
            Speed = speed;
            Price = price;
            Year = year;
        } // Vehicle

        // !!   как лучше ? !!
        //public (short x, short y) Coord
        //{
        //    get => _coord.XY;
        //    set => _coord.XY = value;
        //}

        //// Конструктор по умолчанию 
        //public Vehicle() : this((0, 0), 120d, 1300, 1988) { }

        //// Конструктор с парамметрами
        //public Vehicle((short x, short y) coord, double speed, double price, int year)
        //{
        //    Coord = coord;
        //    Speed = speed;
        //    Price = price;
        //    Year = year;
        //} // Vehicle

        public virtual string GetType() => "TC";

        public virtual string ToTableRow(string type) =>
            $"\t| {type,-9} │ {Coord,10} │ {Speed,8:f2} " +
            $"│ {Price,11:n2} │ {Year,10} " + 
            $"│ {"─",8} │ {"─",10} " +
            $"| {"─",-12} |";
                

        public static string Header() =>
                "\t┌───────────┬────────────┬──────────┬─────────────┬────────────┬──────────┬────────────┬──────────────┐\n" +
                "\t│    Тип    │ Координаты │ Скорость │    Цена     │    Год     │  Высота  │ Количество │   Приписка   │\n" +
                "\t│    ТС     │   ( x;y)   │  (км/ч)  │  валюта($)  │  выпуска   │  полета  │ пассажиров │    порта     │\n" +
                "\t├───────────┼────────────┼──────────┼─────────────┼────────────┼──────────┼────────────┼──────────────┤\n";
           
        public static string Footer() => "\t└───────────┴────────────┴──────────┴─────────────┴────────────┴──────────┴────────────┴──────────────┘";

 
        public override string ToString() => $"\n    Координаты: {Coord}\n    Скорость: {Speed}\n" +
                                             $"    Цена: {Price}\n    Год: {Year}";

    }


}
