﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task1
{
    class Car : Vehicle
    {
        public Car() { }
        
        public Car(CoordXY coord, double speed, double price, int year) : base(coord, speed, price, year)
        { }
 
        public override string ToString() => base.ToString();

        public override string GetType() => "Машина";

    } // Car
}
