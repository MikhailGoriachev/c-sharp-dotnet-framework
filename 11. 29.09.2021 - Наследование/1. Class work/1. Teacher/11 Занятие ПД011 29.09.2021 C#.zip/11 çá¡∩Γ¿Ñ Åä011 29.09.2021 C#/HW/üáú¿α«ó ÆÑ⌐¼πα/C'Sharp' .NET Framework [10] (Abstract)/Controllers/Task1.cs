﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp_.NET_Framework__10___Abstract_.Models.task1;

namespace C_Sharp_.NET_Framework__10___Abstract_.Controllers
{
    class Task1
    {       // Набор констант 
        private const int n = 10;              // Количество элементов в массиве
        private const int MinYear = 1998;      // Минимальный год при генерации коллекции         ТС
        private const int MaxYear = 2003;      // Максимальный год при генерации коллекции        ТС
        private const int MinSalary = 5000;    // Минимальная стоимость при генерации коллекции   ТС  => Транспортное средство
        private const int MaxSalary = 100000;  // Максимальная стоимость при генерации коллекции  ТС
        private const double MinSpeed = 120;   // Минимальная скорость при генерации коллекции    ТС
        private const double MaxSpeed = 160;   // Максмимальная скорость при генерации коллекции  ТС

        private Vehicle[] _vehicles;

        public Vehicle[] Vehicles
        {
            get => _vehicles;
            set => _vehicles = value;
        }

        public Task1() : this(new Vehicle[n]) { Initialize(); }

        public Task1(Vehicle[] vehicles)
        {
            _vehicles = vehicles;
        } // Task1

        public void Initialize()
        {               // Никакой читабильности, и неправдоподобные данные
            int i = 0;
            _vehicles[i++] = new Plane();
            _vehicles[i++] = new Plane(new CoordXY(22, 30), Utils.GetRandom(MinSpeed, MaxSpeed), Utils.GetRandom(MinSalary, MaxSalary), Utils.GetRandom(MinYear, MaxYear), 3000,345);
            _vehicles[i++] = new Ship();
            _vehicles[i++] = new Ship(new CoordXY(23, 43), Utils.GetRandom(MinSpeed, MaxSpeed), Utils.GetRandom(MinSalary, MaxSalary), Utils.GetRandom(MinYear, MaxYear), "Нагоя",555);
            _vehicles[i++] = new Ship(new CoordXY(63, 23), 155d, Utils.GetRandom(MinSalary, MaxSalary), Utils.GetRandom(MinYear, MaxYear), "Кобе", 444);
            _vehicles[i++] = new Car();
            _vehicles[i++] = new Car(new CoordXY(35, 15), Utils.GetRandom(MinSpeed, MaxSpeed), Utils.GetRandom(MinSalary, MaxSalary), Utils.GetRandom(MinYear, MaxYear));
            _vehicles[i++] = new Car(new CoordXY(72, 18), 155d, Utils.GetRandom(MinSalary, MaxSalary), Utils.GetRandom(MinYear, MaxYear));
            _vehicles[i++] = new Car(new CoordXY(63, 14), Utils.GetRandom(MinSpeed, MaxSpeed), Utils.GetRandom(MinSalary, MaxSalary), Utils.GetRandom(MinYear, MaxYear));
            _vehicles[i++] = new Car(new CoordXY(38, 36), Utils.GetRandom(MinSpeed, MaxSpeed), Utils.GetRandom(MinSalary, MaxSalary), Utils.GetRandom(MinYear, MaxYear));
        } // Initialize

        #region Различные выводы
        // В парамметры метода был добавлен 1 парамметр, чтобы лишний раз не перегружать метод
        public void Show(Vehicle[] vehic,string title = "")
        {
            Console.Write($"\n\n\t {title}\n" +
                              $"{Vehicle.Header() }");


            void OutItem(Vehicle p) => Console.WriteLine($"{p.ToTableRow(p.GetType())}");
            Array.ForEach(vehic, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Vehicle.Footer());

        } // Show

        // Вывод с выделением цвета самых старых транспортных средств
        public void ShowColorOldTC(Vehicle[] vehic, string title = "")
        {
            Console.Write($"\n\n\t {title}\n" +
                              $"{Vehicle.Header() }");
 
            int oldVehicle = OldTC();
  
            // Сохранение цвета фона 
            ConsoleColor oldFgColor = Console.ForegroundColor;
            ConsoleColor oldBgColor = Console.BackgroundColor;

            void OutItem(Vehicle vehicl)
            {
 
                if (vehicl.Year == oldVehicle)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                }
                else
                {
                    Console.ForegroundColor = oldFgColor;
                    Console.BackgroundColor = oldBgColor;
                } // if else 

                Console.WriteLine($" {vehicl.ToTableRow(vehicl.GetType())}");
            };

            Array.ForEach(_vehicles, OutItem);
 
            // Необходимо на случай если последний элемент выделеться цветом
            Console.ForegroundColor = oldFgColor;
            Console.BackgroundColor = oldBgColor;
            
            // вывод подвала таблицы
            Console.WriteLine(Vehicle.Footer());

        } // ShowColorOldTC

        // Вывод с выделением цвета самых быстрых и самых медленных транспортных средств
        public void ShowColorFastSlowTC(Vehicle[] vehic, string title = "")
        {
            Console.Write($"\n\n\t {title}\n" +
                              $"{Vehicle.Header() }");

            double fastVehicle = FastTC();
            double slowVehicle = SlowTC();

            // Сохранение цвета фона 
            ConsoleColor oldFgColor = Console.ForegroundColor;
            ConsoleColor oldBgColor = Console.BackgroundColor;

            void OutItem(Vehicle vehicl)
            {

                if (vehicl.Speed == fastVehicle)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                }
                else if (vehicl.Speed == slowVehicle)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                }
                else
                {
                    Console.ForegroundColor = oldFgColor;
                    Console.BackgroundColor = oldBgColor;
                } // if else 
                
                Console.WriteLine($" {vehicl.ToTableRow(vehicl.GetType())}");
            };

            Array.ForEach(vehic, OutItem);

            // Необходимо на случай если последний элемент выделеться цветом
            Console.ForegroundColor = oldFgColor;
            Console.BackgroundColor = oldBgColor;

            // вывод подвала таблицы
            Console.WriteLine(Vehicle.Footer());

        } // ShowColorFastSlowTC
        #endregion
        
        #region Методы находящие значения для различных поисков по коллекции
        public int OldTC(){
            int old = Vehicles[0].Year;
            for (int i = 1; i < Vehicles.Length; i++){
                int year = Vehicles[i].Year;
                if (year < old)
                    old = year;
            } // for
            return old;
        } // OldTC

        public double FastTC()
        {
            double speed = Vehicles[0].Speed;
            for (int i = 1; i < Vehicles.Length; i++)
            {
                double tempSpeed = Vehicles[i].Speed;
                if (tempSpeed > speed)
                    speed = tempSpeed;
            } // for
            return speed;
        } // FastTC

        public double SlowTC()
        {
            double speed = Vehicles[0].Speed;
            for (int i = 1; i < Vehicles.Length; i++)
            {
                double tempSpeed = Vehicles[i].Speed;
                if (tempSpeed < speed)
                    speed = tempSpeed;
            } // for
            return speed;
        } // SlowTC
        #endregion

        #region Методы с различными поисками по коллекции
        public Vehicle[] FindOldTC(){
            int oldYear = OldTC();
            bool IsMaxYear(Vehicle veh) => veh.Year == oldYear;

            Vehicle[] vehiclesFind = Array.FindAll(Vehicles, IsMaxYear);
            return vehiclesFind;

        }//FindOldTC

        public Vehicle[] FindFastTC()
        {
            double fastTC = FastTC();
            bool IsFastTC(Vehicle veh) => veh.Speed == fastTC;

            Vehicle[] vehiclesFind = Array.FindAll(Vehicles, IsFastTC);
            return vehiclesFind;

        }//FindFastTC
        public Vehicle[] FindSlowTC()
        {
            double slowTC = SlowTC();
            bool IsSlowTC(Vehicle veh) => veh.Speed == slowTC;

            Vehicle[] vehiclesFind = Array.FindAll(Vehicles, IsSlowTC);
            return vehiclesFind;

        }//FindSlowTC
        #endregion

    } // Task1
}
