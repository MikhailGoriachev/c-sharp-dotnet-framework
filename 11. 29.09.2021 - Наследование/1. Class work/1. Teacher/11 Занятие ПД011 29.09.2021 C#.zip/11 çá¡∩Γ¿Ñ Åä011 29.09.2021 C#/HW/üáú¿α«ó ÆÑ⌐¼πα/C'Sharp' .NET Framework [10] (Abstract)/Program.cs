﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp_.NET_Framework__10___Abstract_.Application;


namespace C_Sharp_.NET_Framework__10___Abstract_
{
    class Program
    {
        static void Main(string[] args)
        {

            App app = new App();
            Console.SetWindowSize(130, 40);
            while (true)
            {
                try
                {

                    int y = 4;
                    int x = 17;
                    int choi;
                    bool flu = true;
                    do
                    {
                        y = 4;
                        if (!flu) Console.Clear();
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|                       MENU                    |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   №   >|<             Задания                 |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   1   >|<   Демонстрация генерации коллекции  |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |         транспортных средств         |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   2   >|<        Демонстрация вывода          |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |         транспортных средств         |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   3   >|<    Демонстрация поиска и вывода     |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |  самые старых транспортных средств   |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   4   >|<    Демонстрация поиска и вывода     |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |  самых быстрых и самых медленных ТС  |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.DarkRed, ConsoleColor./*Black*/DarkGray);
                        Utils.WriteXY(x, y++, "<|xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx|>", ConsoleColor.DarkRed, ConsoleColor./*Black*/DarkGray);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.DarkRed, ConsoleColor./*Black*/DarkGray);
                        Utils.WriteXY(x, y++, "<|   5   >|<       Демонстрация генерации        |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |           коллекции фигур            |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   6   >|<        Демонстрация вывода          |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |               фигур                  |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   7   >|<    Демонстрация поиска и вывода     |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |     фигур с макс. и мин. площадью    |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   8   >|<        Сортировка коллекции         |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |         по убыванию площадей         |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   0   >|<               EXIT                  |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);

                        Console.CursorVisible = false;

                        Console.Write("\n\n\t    Введите пункт: ");

                        choi = 0;
                        flu = int.TryParse(Console.ReadLine(), out choi);

                    } while (!flu);
                    Console.Clear();
                    Console.CursorVisible = true;

                    switch (choi)
                    {
                        // ------------Демонстрация работы над рядом классов [ Базовый(абстрактный) Vehicle ]------------
                        case 1: app.DemoInitialize();           break;     // Демонстрация генерации коллекции транспортных средств
                        case 2: app.DemoShow();                 break;    //  Демонстрация вывода транспортных средств
                        case 3: app.DemoFindOldTC();            break;   //   Демонстрация поиска и вывода самых старых транспортных средств
                        case 4: app.DemoFindFastSlowSpeed();    break;  //    Демонстрация поиска и вывода самых быстрых и самых медленных ТС
                        //// ------------Демонстрация работы над рядом классов [ Базовый(абстрактный) Figure  ]------------
                        case 5: app.DemoInitializeFigure();     break;     // Демонстрация генерации коллекции фигур
                        case 6: app.DemoShowFigure();           break;    //  Демонстрация вывода коллекции фигур
                        case 7: app.DemoFindMaxMinArea();       break;   //   Демонстрация поиска и вывода элементов с максимальной и минимальной площадью
                        case 8: app.DemoSortByDecreasingArea(); break;  //    Демонстрация сортировки коллекции по убыванию площади
    
                        case 0: Console.Write("\n\n\tДо свидания\n"); return;
                    } // switch



                    
                   
                } // try
                
                catch (Exception ex)
                {
                    Console.Clear();
                    Utils.WriteXY(45, 15, "**********************************************", ConsoleColor.White, ConsoleColor.Red);

                    Utils.WriteXY(45, 16, "                     Error                    ", ConsoleColor.DarkRed);
                    Utils.WriteXY(45, 17, "   " + ex.Message, ConsoleColor.Red);

                    Utils.WriteXY(45, 16, "*", ConsoleColor.White, ConsoleColor.Red);
                    Utils.WriteXY(90, 16, "*", ConsoleColor.White, ConsoleColor.Red);
                    Utils.WriteXY(45, 17, "*", ConsoleColor.White, ConsoleColor.Red);
                    Utils.WriteXY(90, 17, "*", ConsoleColor.White, ConsoleColor.Red);

                    Utils.WriteXY(45, 18, "**********************************************", ConsoleColor.White, ConsoleColor.Red);
                } // try-catch
            
                Console.ReadKey(false);
                Console.Clear();
            }// while
 
        } // Main

    } // Program
} // C_Sharp_.NET_Framework__10___Abstract_
