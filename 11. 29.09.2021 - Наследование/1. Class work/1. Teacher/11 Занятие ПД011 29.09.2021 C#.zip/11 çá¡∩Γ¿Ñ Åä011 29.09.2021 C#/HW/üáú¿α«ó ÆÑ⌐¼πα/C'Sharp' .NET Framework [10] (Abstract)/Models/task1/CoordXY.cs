﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task1
{
    public class CoordXY {
        private short _x;
        private short _y;

        // Конструктор по умолчанию, базавое значение координат
        public CoordXY() : this(0, 0) { }

        // Конструктор с парамметрами
        public CoordXY (short x, short y){
            XY = (x, y);
        } 
        
        // Свойства ( я подумал, что делать отдельно свойства для x и для y неправильно)
        public (short x,short y) XY{
            get => (_x,_y);
            set {
                _x = value.x; 
                _y = value.y; 
            } // set
        } // XY

 

        public override string ToString() => $"( {XY.x};{XY.y} )";

    } // CoordXY
}
