﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp_.NET_Framework__10___Abstract_.Controllers;
using C_Sharp_.NET_Framework__10___Abstract_.Models.task1;

namespace C_Sharp_.NET_Framework__10___Abstract_.Application
{
    partial class App{
            

        public void DemoInitialize(){
            _task1.Initialize();
            _task1.Show(_task1.Vehicles, "Сгенерирована новая коллекция транспортных средств");

        } // DemoInitialize

        public void DemoShow() => _task1.Show(_task1.Vehicles,"Коллекция транспортных средств");  
          // ^ DemoShow ^

        public void DemoFindOldTC()
        {
            Vehicle[] vehiclesFind =  _task1.FindOldTC();
            // Вывод всей коллекции с выделением цветом определенных элементов
            _task1.ShowColorOldTC(_task1.Vehicles, "Цветом выделенны самые старые транспортные средства");
            
            // Вывод новой коллекции состоящей из найденных элементов (самые старые авто)
            _task1.Show(vehiclesFind,"Выведена коллекция самых старых транспортных средств");

        } // DemoFindOldTC

        public void DemoFindFastSlowSpeed(){
            Vehicle[] vehiclesFindFastSpeed = _task1.FindFastTC();
            Vehicle[] vehiclesFindSlowSpeed = _task1.FindSlowTC();

            // Вывод всей коллекции с выделением цветом определенных элементов
            _task1.ShowColorFastSlowTC(_task1.Vehicles, "Цветом выделенны самые быстрые(голубой) и медленные(зеленый) транспортные средства");
            
            // Вывод новой коллекции состоящей из найденных элементов (самые быстрые авто)
            _task1.Show(vehiclesFindFastSpeed, "Выведена коллекция самых быстрых транспортных средств");
            // Вывод новой коллекции состоящей из найденных элементов (самые медленные авто)
            _task1.Show(vehiclesFindSlowSpeed, "Выведена коллекция самых медленных транспортных средств");

        } // DemoFindFastSlowSpeed 

    }
}
