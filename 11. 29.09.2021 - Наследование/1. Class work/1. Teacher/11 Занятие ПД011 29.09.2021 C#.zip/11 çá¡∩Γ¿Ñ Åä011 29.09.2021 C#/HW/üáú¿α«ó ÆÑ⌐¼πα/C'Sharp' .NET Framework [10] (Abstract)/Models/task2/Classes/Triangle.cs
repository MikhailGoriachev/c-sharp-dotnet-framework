﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Interfaces;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Classes
{
    class Triangle : Figure,FlatShape{
        private double _b;
        private double _c;

        // конструкторы
        public Triangle() : this(1d) { }

        // равносторонние
        public Triangle(double a) : this(a, a, a) { }

        // равнобедренные треугольники
        public Triangle(double a, double b) : this(a, b, b) { }

        // разносторонние треугольники
        public Triangle(double a, double b, double c)
        {
            if (!isCorrect(a, b, c))
                throw new Exception($"Невозможно создать треугольник со сторонами [ {(a,b,c)} ]");

            TriangleSidess = (a, b, c);
        } // Triangle


        public (double a, double b, double c) TriangleSidess
        {
            get => (_a, _b, _c);
            set
            {
                if (!isCorrect(value.a, value.b, value.c))
                    throw new Exception("Некорректные параметры для сторон треугольника");

                _a = value.a; _b = value.b; _c = value.c;
            } // set

        } // TriangleSidess
        
        // Проверка на возможность создания треугольника
        static public bool isCorrect(double a, double b, double c) =>
             a + b > c && a + c > b && c + b > a;

        // Вывод строкового представления объекта
        public override string ToString() => $"a: {_a:f3}; b: {_b:f3}; c: {_c:f3}";

        // Нахождение площади треугольника (неправильный вариант, скорее всего медленный)
        public override double Area() {
            double per = Perimeter()/2;
            return Math.Sqrt(per * (per - _a) * (per - _b) * (per - _c));
         }
        // Нахождение периметра треугольника
        public override double Perimeter() => _a + _b + _c;
        public override double Volume() => 0.001d;
        public override double SurfaceAreas() => 0.001d;


        public override string GetFigure() => "Треугольник";

        public override string ToTableRow(string type) =>
              $"\t| {type,-15} │ {TriangleSidess.a,9:f2} │ {TriangleSidess.b,9:f2} " +
            $"│ {TriangleSidess.c,9:f2} │ {Perimeter(),10:f2} " +
            $"│ {Area(),9:f2} │ {"─",11:f2} " +
            $"│ {"─",8:f2} │";


    }
}
