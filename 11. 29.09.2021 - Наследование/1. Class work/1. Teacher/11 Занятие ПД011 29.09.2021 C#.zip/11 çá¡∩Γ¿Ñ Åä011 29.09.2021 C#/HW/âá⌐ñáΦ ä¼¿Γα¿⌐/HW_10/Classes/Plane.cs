﻿using System;

namespace HW_10.Classes{
    class Plane : Vehicle{
        private const double MaxFlight = 13_000;
        private const int MinPas = 4, MaxPas = 1_000;

        private double _height;
        public double Height{
            get => _height;
            set => _height = value <= MaxFlight ||value>0? value : throw new Exception($"\nСамолет не может лететь выше {MaxFlight}\n");
        } // Height

        private int _countPas;
        public int CountPas{
            get => _countPas;
            set=>_countPas = value>=MinPas||value<=MinPas?value: throw new Exception($"\nНедопустимое кол-во пассажиров!\n");
        } // CountPas

        public Plane():this(6000, 50, 5919, 233.1, 2001, new CoordXY(3, 1)) {}

        public Plane(double height, int countPas,double price, double speed, int year, CoordXY coord) : base(price, speed, year, coord){
            Height = height;
            CountPas = countPas;
        } // Plane

        public override string ToString() => base.ToString() + $"{Height, 9} |{CountPas, 10} |";
        public override string GetType() => "Самолет";

        public override string ToTableRow(string type) =>
        $"\t| {type,-9} │ {Coord,10} │ {Speed,8:f2} " +
        $"│ {Price,11:n2} │ {Year,10} " +
        $"│ {Height,8} │ {CountPas,10} " +
        $"| {"─",-12} |";
    } // Plane
}
