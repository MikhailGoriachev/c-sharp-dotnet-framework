﻿using System;

namespace HW_10.Controllers{
    internal class Task2{

    } // Task2
}
