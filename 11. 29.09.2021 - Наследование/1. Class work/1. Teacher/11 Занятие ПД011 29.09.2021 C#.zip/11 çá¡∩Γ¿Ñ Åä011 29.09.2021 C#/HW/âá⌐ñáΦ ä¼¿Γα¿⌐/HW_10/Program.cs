﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

using HW_10.Application;
using HW_10.Classes;

namespace HW_10{
    class Program{

        static void Main(string[] args){
            Console.Title = "HW";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Вывести транспортные средства" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Найти среди них самое старое" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Найти само быстрое и самое медленное" },
                //----------------------------------------------------------------------------------------------

                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();
            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();

                    switch (key)
                    {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1
                        #region Задача 1
                        // Вывести транспортные средства
                        case ConsoleKey.Q:
                            app.ShowTask1();
                            break;

                        // Найти среди них самое старое
                        case ConsoleKey.W:
                            app.task1_1();
                            break;

                        // Найти само быстрое и самое медленное
                        case ConsoleKey.E:
                            app.task1_2();
                            break;
                        #endregion
                        #region Задача 2
                        case ConsoleKey.P:

                            break;
                        #endregion

                        // Выход из приложения назначен на клавишу F10 или клавишу Z или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Black);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch


            } // while
        } // main

    } // Program
}
