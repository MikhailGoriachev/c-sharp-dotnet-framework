﻿using System;

namespace HW_10.Classes{
    abstract class Vehicle{
        protected const double MinSpeed = 20, MinPrice = 1835.1, MinYear = 1985, SOL = 1_079_252_848.8;

        protected CoordXY _coord;
        public CoordXY Coord{
            get => _coord;
            set => _coord = value;
        } // Coord

        protected double _price;
        public double Price{ 
            get => _price;
            set => _price = value >= MinPrice ? value : throw new Exception($"\nТранспортное средство не может стоить меньше{MinPrice}\n");
        } // Price

        protected double _speed;
        public double Speed { 
            get => _speed;
            set=>_speed = value>MinSpeed||value>=SOL?value: throw new Exception($"\nТранспортное средство не может быть медленне, чем{MinSpeed}\n");
        } // Speed

        protected int _year;
        public int Year { 
            get => _year;
            set=>_year = value>=MinYear||value>2021?value : throw new Exception($"\nТранспортное средство не может быть старше {MinYear}\n");
        } // Year

        public Vehicle() : this(9_000, 150.3, 1998, new CoordXY(0, 0)) { }

        public Vehicle(double price, double speed, int year, CoordXY coord){
            Price = price;
            Speed = speed;
            Year = year;
            Coord = coord;
        } // vehicle

        public override string ToString() => $"{Speed,8}  | {Price,5}  | {Coord,10} | {Year, 6}  |";
        public virtual string GetType() => "TC";

        public virtual string ToTableRow(string type) =>
            $"\t| {type,-9} │ {Coord,10} │ {Speed,8:f2} " +
            $"│ {Price,11:n2} │ {Year,10} " +
            $"│ {"─",8} │ {"─",10} " +
            $"| {"─",-12} |";


        public static string Header() =>
                "\t┌───────────┬────────────┬──────────┬─────────────┬────────────┬──────────┬────────────┬──────────────┐\n" +
                "\t│    Тип    │ Координаты │ Скорость │    Цена     │    Год     │  Высота  │ Количество │   Приписка   │\n" +
                "\t│    ТС     │     x;y    │  (км/ч)  │     ($)     │  выпуска   │  полета  │ пассажиров │    порта     │\n" +
                "\t├───────────┼────────────┼──────────┼─────────────┼────────────┼──────────┼────────────┼──────────────┤\n";

        public static string Footer() => "\t└───────────┴────────────┴──────────┴─────────────┴────────────┴──────────┴────────────┴──────────────┘";
    } // Vehicle
}
