﻿using System;
using HW_10.Controllers;

namespace HW_10.Application{
    internal partial class App{
        Task1 _task1; // объект для задачи 1

        public App() : this(new Task1()) { }
        public App(Task1 task1){
            _task1 = task1;
        } // App

    } // App
}
