﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_10.Classes{
    public class CoordXY{
        private int _x;
        private int _y;

        public CoordXY(int x = 1, int y = 1){
            XY = (x, y);
        } // CoordXY

        public (int x, int y) XY{
            get => (_x, _y);
            set{
                _x = value.x;
                _y = value.y;
            } // set
        } // XY

        public override string ToString() => $"{XY.x};{XY.y}";

    } // CoordXY
}
