﻿using System;
using HW_10.Classes;

namespace HW_10.Application{
    internal partial class App{

        public void ShowTask1(){
            _task1.Show();
        } // ShowTask1

        public void task1_1(){
            Console.Write($"{Vehicle.Header()}");
            Console.Write($"{_task1.OldVehicle()}\n");
            Console.WriteLine(Vehicle.Footer());
        } // task1_1

        public void task1_2(){
            Console.Write($"\n\n\t1 - самое быстрое, 2 - самое медленное\n{Vehicle.Header()}");
            Console.Write($"{_task1.FastVehicle()}\n");
            Console.Write($"{_task1.SlowVehicle()}\n");
            Console.WriteLine(Vehicle.Footer());
        } // task1_2

    } // App
}
