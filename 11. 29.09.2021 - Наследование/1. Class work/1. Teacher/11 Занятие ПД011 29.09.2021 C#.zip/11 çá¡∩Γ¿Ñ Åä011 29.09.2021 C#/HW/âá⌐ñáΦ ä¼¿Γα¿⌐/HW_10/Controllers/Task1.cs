﻿using System;
using HW_10.Classes;

namespace HW_10.Controllers{
    internal class Task1{
        private const int n = 10;

        private Vehicle[] _vehicles;

        public Task1():this(new Vehicle[n]){ Init(); }

        public Task1(Vehicle[] vehicles){
            _vehicles = vehicles;
        } // Task1

        public Vehicle[] Vehicles{
            get;set;
        } // Vehicles

        public void Init(){
            _vehicles[0] = new Plane();
            _vehicles[1] = new Plane(3000, 22, 7000, 300, 1999, new CoordXY(22, 30));
            _vehicles[2] = new Ship();
            _vehicles[3] = new Ship("Московский", 56, 2500, 60, 2004, new CoordXY(9, 1));
            _vehicles[4] = new Ship("Махачкала", 70, 3000, 65, 2005, new CoordXY(1, 7));
            _vehicles[5] = new Car();
            _vehicles[6] = new Car(8_000, 220, 2003, new CoordXY(6,0));
            _vehicles[7] = new Car(3_000, 200, 2011, new CoordXY(100,255));
            _vehicles[8] = new Car(9_500, 280, 2016, new CoordXY(84,13));
            _vehicles[9] = new Car(9_700, 160, 1986, new CoordXY(62,78));
        } // Init

        public void Show(){
            Console.Write($"\n");

            Console.Write($"{Vehicle.Header() }");


            void OutItem(Vehicle p) => Console.WriteLine($"{p.ToTableRow(p.GetType())}");
            Array.ForEach(_vehicles, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Vehicle.Footer());

            Console.Write($"\n");
        } // Show

        public string OldVehicle(){
            int index = 0;
            for(int i = 0; i < n; i++)
                if (_vehicles[i].Year < _vehicles[index].Year)
                    index = i;

            return _vehicles[index].ToTableRow(_vehicles[index].GetType());
        } // OldVehicle

        public string FastVehicle(){
            int index = 0;
            for (int i = 0; i < n; i++)
                if (_vehicles[i].Speed > _vehicles[index].Speed)
                    index = i;

            return _vehicles[index].ToTableRow(_vehicles[index].GetType());
        } // FastVehicle
        public string SlowVehicle(){
            int index = 0;
            for (int i = 0; i < n; i++)
                if (_vehicles[i].Speed < _vehicles[index].Speed)
                    index = i;
            return _vehicles[index].ToTableRow(_vehicles[index].GetType());
        } // SlowVehicle

    } // Task1
}
