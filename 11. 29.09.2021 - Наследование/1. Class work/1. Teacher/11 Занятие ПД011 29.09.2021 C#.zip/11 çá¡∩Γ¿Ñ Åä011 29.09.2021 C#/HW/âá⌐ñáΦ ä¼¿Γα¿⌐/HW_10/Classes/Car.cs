﻿using System;

namespace HW_10.Classes{
    class Car : Vehicle{
        public Car() { }
        public Car(double price, double speed, int year, CoordXY coord):base(price, speed, year, coord)
        { }
        public override string GetType() => "Машина";
        public override string ToString() =>$"{base.Speed, 8}  |  {base.Price, 5}  | {base.Coord, 10} | {base.Year, 6}  |";
    } // Car
}
