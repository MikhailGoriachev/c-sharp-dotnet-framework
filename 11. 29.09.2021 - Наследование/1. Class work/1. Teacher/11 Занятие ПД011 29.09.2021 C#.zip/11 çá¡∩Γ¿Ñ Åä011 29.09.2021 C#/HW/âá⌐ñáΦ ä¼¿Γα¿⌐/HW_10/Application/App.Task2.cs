﻿using System;

namespace HW_10.Application{
    internal partial class App{

    } // App
}
