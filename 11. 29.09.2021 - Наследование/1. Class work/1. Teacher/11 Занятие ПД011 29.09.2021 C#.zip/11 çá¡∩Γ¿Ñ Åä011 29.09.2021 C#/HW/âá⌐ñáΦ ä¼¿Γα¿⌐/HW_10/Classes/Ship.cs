﻿using System;

namespace HW_10.Classes{
    class Ship : Vehicle{
        private const int MinPas = 1, MaxPas = 15_000;

        private int _countPas;
        public int CountPas{
            get => _countPas;
            set => _countPas = value >= MinPas || value <= MinPas ? value : throw new Exception($"\nНедопустимое кол-во пассажиров!\n");
        } // CountPas

        private string _port;
        public string Port{
            get => _port;
            set=>_port = !string.IsNullOrWhiteSpace(value)?value : throw new Exception($"\nНедопустимое порт приписки!\n");
        } // Port
        public Ship() : this("Питерский", 50, 5919, 70, 2001, new CoordXY(8, 1)) { }

        public Ship(string port, int countPas, double price, double speed, int year, CoordXY coord) : base(price, speed, year, coord){
            Port = port;
            CountPas = countPas;
        } // Ship

        public override string ToString() =>base.ToString() + $"{Port,17} | {CountPas,9} |\n";


        public override string GetType() => "Корабль";

        public override string ToTableRow(string type) =>
        $"\t| {type,-9} │ {Coord,10} │ {Speed,8:f2} " +
        $"│ {Price,11:n2} │ {Year,10} " +
        $"│ {"─",8} " +
        $"│ {_countPas,10} │ {Port,-12} │";
    } // Ship
}
