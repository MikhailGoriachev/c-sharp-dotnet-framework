﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInheritance
{
    public class Rectangular: Figure, IFlatfigure
    {
        public override string Name => "Прямоугольник";
        private double _b;

        public double B
        {
            get=> _b; 
            set {
                if (value < 0) throw new Exception("Недопустимое значение для стороны прямоугольника");
                _b = value;
            }
        }

        public double A
        {
            get => _a;
            set { 
                if (value < 0) throw new Exception("Недопустимое значение для стороны прямоугольника");
                _a = value;
            }
        }

        public override double Area => AreA();
        public double Perimetr()
        {
            return 2 * (A + B);
        }

        public double AreA()
        {
            return A * B; 
        }

        public override string ToTableRow() => $"| {Name, -18} |{A,5},{B, 5} | {Perimetr(), 18} | {AreA(), 9} |";
    }
}
