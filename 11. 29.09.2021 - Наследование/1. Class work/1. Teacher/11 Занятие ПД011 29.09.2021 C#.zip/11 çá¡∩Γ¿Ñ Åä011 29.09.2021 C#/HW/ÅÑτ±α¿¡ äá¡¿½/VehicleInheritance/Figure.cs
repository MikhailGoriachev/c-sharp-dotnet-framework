﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInheritance
{
    public abstract class Figure
    {
        protected double _a;
        public abstract string Name { get; }

        public abstract string ToTableRow();

        public abstract double Area { get; }

        public static int CompareByArea(Figure f1, Figure f2) => f2.Area.CompareTo(f1.Area);
    }
}
