﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VehicleInheritance.Modules;

namespace VehicleInheritance.AppSpace
{
    internal partial class App
    {
        Task2 task2 = new Task2();
        public void Task2Point2()
        {
            Utils.ShowNavBarTask("Фигуры ");

            task2.ShowTable();
            Console.ReadKey();
            
            Console.ReadKey();
        }

        public void Task2Point3()
        {
            Utils.ShowNavBarTask(" Упорядочить фигуры по убыванию площадей");

            Console.WriteLine("\n\n");
            Console.WriteLine("Массив упорядочен по убыванию площадей");
            task2.SortbyArea();
            task2.ShowTable();

            Console.WriteLine($" Фигура с минимальной площадью {task2.MinArea()}"); 
            Console.WriteLine($" Фигура с максимальной площадью {task2.MaxArea()}"); 

            Console.ReadKey(); 
        }
    }

}
