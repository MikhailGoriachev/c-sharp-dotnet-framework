﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInheritance.Modules
{
    class Task2
    {
        Figure[] array = new Figure[]
        {
            new Triangle {Sides=(3, 4, 5) },
            new Triangle {Sides=(4, 5, 6) },
            new Rectangular{A = 4, B =7},
            new Rectangular{A = 8, B =10},
            new Conoid{Height = 12, Radius= 3},
            new Conoid{Height = 5, Radius = 7.6},
            new Cylinder{Height = 5.5, Radius = 3.4},
            new Cylinder{Height = 7.5, Radius = 4.4}

        };

        public void ShowTable ()
        {

            Console.WriteLine("\n\n");

            Console.WriteLine($"\t\t ");
            Console.WriteLine("┌────────────────────┬────────────┬────────────────────┬───────────┐");
            Console.WriteLine("│   Название фигуры  │  Параметры │     Периметр/Объем |  Площадь  |");
            Console.WriteLine("├────────────────────┼────────────┼────────────────────┼───────────┤");
            foreach(var item in array)
            {
                Console.WriteLine(item.ToTableRow()); 
            }
            Console.WriteLine("└────────────────────┴────────────┴────────────────────┴───────────┘"); 
        }

        public void SortbyArea() => Array.Sort(array, Figure.CompareByArea);

        public double MinArea()
        {
            double minarea = double.MaxValue; 
            foreach(var item in array)
            {
                if(item.Area < minarea)
                {
                    minarea = item.Area;
                }
            }
            return minarea; 
        }

        public double MaxArea()
        {
            double maxarea = double.MinValue;
            foreach(var item in array)
            {
                if(item.Area >maxarea)
                {
                    maxarea = item.Area;
                }
            }
            return maxarea; 
        }
    }
}
