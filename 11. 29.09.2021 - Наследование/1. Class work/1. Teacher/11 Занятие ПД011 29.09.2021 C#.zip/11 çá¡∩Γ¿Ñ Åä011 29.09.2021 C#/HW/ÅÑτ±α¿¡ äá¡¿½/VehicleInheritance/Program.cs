﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VehicleInheritance.AppSpace;

namespace VehicleInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 30.09.2021. Наследование. Абстрактные классы. Интерфейсы.";

            // меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Вывести масив Vechicles в консоль" },
           //------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 2. Фигуры" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 2. Упорядочить массив по убыванию площади" },
            };

            //создание экземпляра класса приложения
            App app = new App();
            
            while(true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - Абстрактные классы. Интерфейсы. Наследование");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с абстрактными классами и интерфесами", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch(key)
                    {
                        // пункты меню, относящиеся к Задаче 1
                        #region Задача 1
                        case ConsoleKey.Q:
                            app.Task1Point1();
                            break;
                        #endregion
                        // пункты меню, относящиеся к Задаче 2
                        #region Задача 2
                        case ConsoleKey.R:
                            app.Task2Point2();
                            break;
                        case ConsoleKey.T:
                            app.Task2Point3();
                            break;
                        #endregion

                    }// switch

                }// try 
                catch
                {

                }

            }// while

        }
    }
}
