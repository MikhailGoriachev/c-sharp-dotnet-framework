﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInheritance
{
    public class Plane:Vehicle
    {
        private int _height;

        public int Height
        {
            get => _height;
            set
            {
                if (value < 0) throw new Exception("Недопустимы значения для координат");
                _height = value;
            }
        }
    }
}
