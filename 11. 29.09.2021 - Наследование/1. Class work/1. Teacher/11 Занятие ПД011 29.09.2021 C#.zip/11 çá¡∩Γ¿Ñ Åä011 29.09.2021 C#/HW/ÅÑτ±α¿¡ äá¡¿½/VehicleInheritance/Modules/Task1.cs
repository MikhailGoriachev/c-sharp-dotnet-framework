﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInheritance.Modules
{
    class Task1
    {
        Vehicle[] array = new Vehicle[]
        {
            new Plane { CoordX = 25, CoordY = 25, Height = 7000, Price = 20000000, ProductionYear = 2001, Speed = 700},
            new Plane { CoordX = 55, CoordY = 67, Height = 6000, Price = 10000000, ProductionYear = 2003, Speed = 600},
            new Ship { CoordX = 76, CoordY = 54, Price = 5400000, HomePort = "Мариуполь", Speed = 120, Paxes = 100, ProductionYear = 1999},
            new Ship { CoordX = 45, CoordY = 67, Price = 7800000, HomePort = "Таганрог", Speed = 178, Paxes = 90, ProductionYear = 1996},
            new Ship { CoordX = 90, CoordY = 98, Price = 9000000, HomePort = "Бердянск", Speed = 145, Paxes = 78, ProductionYear = 1998},
            new Car { CoordX = 120, CoordY = 87, Price = 80000, Speed =200, ProductionYear = 2007 }, 
            new Car { CoordX = 54, CoordY = 78, Price = 70000, Speed =200, ProductionYear = 2009 }, 
            new Car { CoordX = 92, CoordY = 73, Price = 60000, Speed =190, ProductionYear = 2004 }, 
            new Car { CoordX = 34, CoordY = 84, Price = 50000, Speed =156, ProductionYear = 2005 }, 
            new Car { CoordX = 56, CoordY = 57, Price = 30000, Speed =210, ProductionYear = 2004 } 
            
        };

        public void ShowTable()
        {
            Console.WriteLine("\n\n");

            Console.WriteLine($"\t\t ");
            Console.WriteLine("┌────────────┬─────────┬──────────────────┬───────────┬─────────────────┐");
            Console.WriteLine("│   CoordX   │  CoordY │        Цена      |  Скорость |    Год выпуска  |");
            Console.WriteLine("├────────────┼─────────┼──────────────────┼───────────┼─────────────────┤");
            foreach(var item in array)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine("└────────────┴─────────┴──────────────────┴───────────┴─────────────────┘");

        }

        public int EarlyYear()
        {
            int earlyyear = 2021; 
            foreach(var item in array)
            {
                if (item.ProductionYear < earlyyear)
                    earlyyear = item.ProductionYear;
            }

            return earlyyear; 
        }

        public int MaxSpeed()
        {
            int maxspeed = int.MinValue; 
            foreach(var item in array)
            {
                if (item.Speed > maxspeed)
                    maxspeed = item.Speed;
            }
            return maxspeed;
        }

        public int MinSpeed()
        {
            int minspeed = int.MaxValue; 
            foreach(var item in array)
            {
                if (item.Speed < minspeed)
                    minspeed = item.Speed;
            }
            return minspeed;   
        }
    }
}
