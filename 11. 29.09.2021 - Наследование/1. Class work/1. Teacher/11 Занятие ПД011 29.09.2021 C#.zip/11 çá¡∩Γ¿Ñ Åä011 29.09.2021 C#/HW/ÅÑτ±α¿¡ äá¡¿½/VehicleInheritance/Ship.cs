﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInheritance
{
    public class Ship : Vehicle
    {
        private string _homePort;

        public string HomePort
        {
            get => _homePort; 
            set =>_homePort = value; 
        }

        private int _paxes;

        public int Paxes
        {
            get => _paxes; 
            set {
                if (value < 0) throw new Exception("Недопустимы значения для координат");
                _paxes = value; }
        }


    }
}
