﻿using System;
using Main.Utilities.Menu;


namespace Main.Models
{


public class FirstTask : MenuWrapper
{
	private readonly string _originalString = "  Кот   ломом   колол   слона   ";


	public FirstTask() =>
		Menu = new Menu($"Cтрока для обработки: {_originalString}",
			new[]
			{
				new MenuItem("Удалить из строки S все подстроки, совпадающие с S0",
					RemoveAllSubstringOccurrences),
				new MenuItem("Заменить в строке S все вхождения строки S1 на строку S2",
					ReplaceAllOccurrences),
				new MenuItem("Заменить пробелы на одиночные точки. В конце троки точку не ставить",
					ReplaceWhitespacesWithDot),
				new MenuItem("Заменить пробелы на одиночные пробелы. Реверсировать строку",
					SingleWhitespacesAndReverse),
				new MenuItem("Заменить пробелы на одиночные пробелы. Сортировать строку. перевести в нижний регистр.",
					SingleWhitespacesSortAndToLower)
			});


	/// Удалить из строки S все подстроки, совпадающие с S0.
	/// Если совпадающих подстрок нет, то вывести строку S без изменений.
	private void RemoveAllSubstringOccurrences()
	{
		string toProcess = string.Copy(_originalString);

		string substringToRemove = "ло";

		Console.WriteLine($"Исходная строка: \"{toProcess}\"\n\n");
		Console.WriteLine($"Подстрока для удаления: \"{substringToRemove}\"\n\n");

		toProcess = toProcess.Replace(substringToRemove, string.Empty);

		Console.WriteLine($"Измененная строка: \"{toProcess}\"");
	}


	/// Заменить в строке S все вхождения строки S1 на строку S2
	private void ReplaceAllOccurrences()
	{
		string toProcess = string.Copy(_originalString);

		string substringToRemove = "ло";
		string newString = "но";

		Console.WriteLine($"Исходная строка: \"{toProcess}\"\n\n");
		Console.WriteLine($"Подстрока для удаления: \"{substringToRemove}\"\n\n");
		Console.WriteLine($"Строка для замены: \"{newString}\"\n\n");

		toProcess = toProcess.Replace(substringToRemove, newString);

		Console.WriteLine($"Измененная строка: \"{toProcess}\"");
	}


	/// Заменить пробелы на одиночные точки. В конце троки точку не ставить
	private void ReplaceWhitespacesWithDot()
	{
		string toProcess = string.Copy(_originalString);

		string splitBy = " ";
		string delimBy = ".";

		Console.WriteLine($"Исходная строка: \'{toProcess}\'\n\n");
		Console.WriteLine($"Разделители для удаления: \'{splitBy}\'\n\n");
		Console.WriteLine($"Новые разделители: \'{delimBy}\'\n\n");

		var words = toProcess.Split(splitBy.ToCharArray(),
			StringSplitOptions.RemoveEmptyEntries);
		toProcess = string.Join(delimBy, words);

		Console.WriteLine($"Измененная строка: \'{toProcess}\'");
	}


	/// Заменить пробелы на одиночные пробелы. Реверсировать строку
	private void SingleWhitespacesAndReverse()
	{
		string toProcess = string.Copy(_originalString);

		string splitBy = " ";
		string delimBy = " ";

		Console.WriteLine($"Исходная строка: \'{toProcess}\'\n\n");
		Console.WriteLine($"Разделители для удаления: \'{splitBy}\'\n\n");
		Console.WriteLine($"Новые разделители: \'{delimBy}\'\n\n");

		var words = toProcess.Split(splitBy.ToCharArray(),
			StringSplitOptions.RemoveEmptyEntries);
		Array.Reverse(words);
		toProcess = string.Join(delimBy, words);

		Console.WriteLine($"Измененная строка: \'{toProcess}\'");
	}


	/// Заменить пробелы на одиночные пробелы. Сортировать строку. перевести в нижний регистр.
	private void SingleWhitespacesSortAndToLower()
	{
		string toProcess = _originalString.ToUpper();

		string splitBy = " ";
		string delimBy = " ";

		Console.WriteLine($"Исходная строка: \'{toProcess}\'\n\n");
		Console.WriteLine($"Разделители для удаления: \'{splitBy}\'\n\n");
		Console.WriteLine($"Новые разделители: \'{delimBy}\'\n\n");

		var words = toProcess.Split(splitBy.ToCharArray(),
			StringSplitOptions.RemoveEmptyEntries);
		Array.Sort(words);
		toProcess = string.Join(delimBy, words)
						  .ToLower();

		Console.WriteLine($"Измененная строка: \'{toProcess}\'");
	}
}


}
