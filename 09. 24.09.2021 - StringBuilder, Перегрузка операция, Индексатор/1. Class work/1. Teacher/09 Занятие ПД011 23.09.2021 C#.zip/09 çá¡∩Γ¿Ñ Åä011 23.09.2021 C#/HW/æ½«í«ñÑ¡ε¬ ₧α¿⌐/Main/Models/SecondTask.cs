﻿using System;
using System.Globalization;
using Main.Utilities.Menu;


namespace Main.Models
{


public class SecondTask : MenuWrapper
{
	private readonly string _originalString = "  Утка  ломом  кололо   яблоко  ";
	private static readonly char[] SplitBy = " ".ToCharArray();
	private static readonly string JoinBy = " ";


	public SecondTask() =>
		Menu = new Menu($"Cтрока для обработки: {_originalString}",
			new[]
			{
				new MenuItem("Поменять местами каждые два соседних слова",
					SwapEachTwoWordsTask),
				new MenuItem("Удалить все слова, начинающиеся и заканчивающиеся гласными буквами",
					RemoveWordsTartsWithVowels),
				new MenuItem("Поменять местами первое слово максимальной длины и первое слово минимальной длины",
					SwapLongestWithSmallestWord),
				new MenuItem("В каждом слове строки установить верхний регистр первой буквы",
					ToUpperAllFirstLetters)
			});


	/// Поменять местами каждые два соседних слова
	private void SwapEachTwoWordsTask()
	{
		string evenLength = string.Copy(_originalString);
		string oddLength = evenLength.Insert(evenLength.Length, "  место   ");

		Console.WriteLine($"Строка с четным количеством чисел: \"{evenLength}\"\n");
		Console.WriteLine($"Строка с не четным количеством чисел: \"{oddLength}\"\n\n\n");

		evenLength = SwapEachTwoWords(evenLength);
		oddLength = SwapEachTwoWords(oddLength);

		Console.WriteLine($"Строка с четным количеством чисел: \"{evenLength}\"\n");
		Console.WriteLine($"Строка с не четным количеством чисел: \"{oddLength}\"");
	}


	private static string SwapEachTwoWords(string toProcess)
	{
		var words = toProcess.Split(SplitBy,
			StringSplitOptions.RemoveEmptyEntries);

		for (int i = 0; i < words.Length - 1; i += 2)
			(words[i], words[i + 1]) = (words[i + 1], words[i]);

		return string.Join(JoinBy, words);
	}


	/// Удалить все слова, начинающиеся и заканчивающиеся гласными буквами
	private void RemoveWordsTartsWithVowels()
	{
		string toProcess = string.Copy(_originalString);

		Console.WriteLine($"Исходная строка: \"{toProcess}\"\n\n");

		var words = toProcess.Split(SplitBy,
			StringSplitOptions.RemoveEmptyEntries);

		var vowels = "аоэеиыуёюя";
		var upperVowels = vowels.ToUpper();

		bool IsVowel(string letter) => vowels.Contains(letter) || upperVowels.Contains(letter);

		for (int i = 0; i < words.Length; i++)
			if (IsVowel(words[i][0].ToString()) && 
				IsVowel(words[i][words[i].Length - 1].ToString()))
				words[i] = string.Empty;

		toProcess = string.Join(JoinBy, words).Trim(JoinBy.ToCharArray());

		Console.WriteLine($"Измененная строка: \"{toProcess}\"");
	}


	/// Поменять местами первое слово максимальной длины и первое слово минимальной длины
	private void SwapLongestWithSmallestWord()
	{
		string toProcess = string.Copy(_originalString);

		Console.WriteLine($"Исходная строка: \"{toProcess}\"\n\n");

		var words = toProcess.Split(SplitBy,
			StringSplitOptions.RemoveEmptyEntries);

		var maxLength = FindWordWithMaxLength(words);
		var minLength = FindWordWithMinLength(words);

		Console.WriteLine(
			$"Слово максимальной длины имеет номер {maxLength.index + 1} и длину в {maxLength.length} символов");
		Console.WriteLine(
			$"Слово минимальной длины имеет номер {minLength.index + 1} и длину в {minLength.length} символов\n\n");

		ref var maxWord = ref words[maxLength.index];
		ref var minWord = ref words[minLength.index];
		(maxWord, minWord) = (minWord, maxWord);

		toProcess = string.Join(JoinBy, words).Trim(JoinBy.ToCharArray());

		Console.WriteLine($"Измененная строка: \"{toProcess}\"");
	}


	private static (int index, int length) FindWordWithMaxLength(string[] targets)
	{
		(int index, int length) = (0, int.MinValue);

		for (int i = 0; i < targets.Length; i++)
			if (targets[i].Length > length)
			{
				length = targets[i].Length;
				index = i;
			}

		return (index, length);
	}


	private static (int index, int length) FindWordWithMinLength(string[] targets)
	{
		(int index, int length) = (0, int.MaxValue);

		for (int i = 0; i < targets.Length; i++)
			if (targets[i].Length < length)
			{
				length = targets[i].Length;
				index = i;
			}

		return (index, length);
	}


	/// В каждом слове строки установить верхний регистр первой буквы
	private void ToUpperAllFirstLetters()
	{
		string toProcess = string.Copy(_originalString);

		Console.WriteLine($"Исходная строка: \"{toProcess}\"\n\n");

		var words = toProcess.Split(SplitBy,
			StringSplitOptions.RemoveEmptyEntries);

		for (int i = 0; i < words.Length; i++)
			words[i] = $"{char.ToUpper(words[i][0])}{words[i].Substring(1)}";

		toProcess = string.Join(JoinBy, words).Trim(JoinBy.ToCharArray());

		// Более элегантное решение
		// TextInfo textInfo = CultureInfo.CurrentCulture.TextInfo;
		// toProcess = textInfo.ToTitleCase(toProcess);

		Console.WriteLine($"Измененная строка: \"{toProcess}\"");
	}
}


}
