﻿using Main.Models;
using Main.Utilities.Menu;


namespace Main
{


public class App : MenuWrapper
{
	private readonly FirstTask _firstTask = new FirstTask();
	private readonly SecondTask _secondTask = new SecondTask();


	public App() =>
		Menu = new Menu("Главное меню приложения", new[]
		{
			new MenuItem("Первая задача", _firstTask.Run) { IsSimpleInvoke = true },
			new MenuItem("Вторая задача", _secondTask.Run) { IsSimpleInvoke = true }
		});
}


}
