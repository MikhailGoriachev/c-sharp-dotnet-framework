﻿namespace Main
{


public sealed class Program
{
	public static void Main(string[] args)
	{
		App app = new App();

		app.Run();
	}
}


}
