﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_8.Model
{
    //Дана строка S (класс string). В строке слова разделяются одним или несколькими пробелами,
    //в результирующей строке слова должны разделяться одним пробелом:
    public static class Task2
    {
        //В строке поменять местами каждые два соседних слова.
        public static string Task2_1(string str) 
        {
            string[] s = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < s.Length; i += 2)
                (s[i], s[i + 1]) = (s[i + 1], s[i]);

            return string.Join(" ", s);
        }//Task2_1

        //Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами
        public static string Task2_2(string str) 
        {
            string[] s = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < s.Length; i++)
            {
                if (s[i].IndexOfAny("аеёиоуыэюяАЕЁИОУЫЭЮЯ".ToCharArray()) == 0 &&
                    s[i].LastIndexOfAny("аеёиоуыэюяАЕЁИОУЫЭЮЯ".ToCharArray()) == s[i].Length - 1)
                {
                    s[i] = "";
                }
            }
            return string.Join(" ", s);

        }//Task2_2

        //Поменять местами первое слово максимальной длины и первое слово минимальной
        //длины в строке
        public static string Task2_3(string str) 
        {
            string[] s = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            int iMin = 0, iMax = 0;

            for(int i = 1; i < s.Length; i++) 
            {
                if (s[i].Length < s[iMin].Length) iMin = i;
                if (s[i].Length > s[iMax].Length) iMax = i;
            }//for

            (s[iMin], s[iMax]) = (s[iMax], s[iMin]);


            return string.Join(" ", s);
        }//Task2_3

        //В каждом слове строки установить верхний регистр первой буквы
        public static string Task2_4(string str) 
        {
            string[] s = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < s.Length; i++)
                s[i] = s[i].Substring(0, 1).ToUpper() + s[i].Substring(1);

            return string.Join(" ", s);
        }//Task2_4

    }//Task2
}
