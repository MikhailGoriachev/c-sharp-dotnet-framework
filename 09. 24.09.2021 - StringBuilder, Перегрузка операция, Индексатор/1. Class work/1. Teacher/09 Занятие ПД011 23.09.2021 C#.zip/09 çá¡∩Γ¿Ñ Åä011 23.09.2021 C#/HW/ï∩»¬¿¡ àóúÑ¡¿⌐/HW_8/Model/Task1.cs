﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_8.Model
{
    public static class Task1
    {

        //Даны строки S и S0. Удалить из строки S все подстроки, совпадающие с S0.
        //Если совпадающих подстрок нет, то вывести строку S без изменений.
        public static string Task1_1(string s, string s0) 
        {
            int n;

            while ((n = s.IndexOf(s0)) != -1)
                s = s.Remove(n, s0.Length);

            return s;
        }//Task1_1

        //Даны строки S, S1 и S2. Заменить в строке S все вхождения строки S1 на строку S2
        public static string Task1_2(string s, string s1, string s2) => s.Replace(s1, s2);

        //Дана строка, состоящая из слов, разделенных пробелами (одним или
        //несколькими). Вывести строку, содержащую эти же слова, разделенные
        //одним символом «.» (точка). В конце строки точку не ставить.
        public static string Task1_3(string str) =>
            string.Join(".", str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));

        //Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими).
        //Вывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные
        //в обратном порядке.
        public static string Task1_4(string str) 
        {
            string[] sw = str.Split(new char[' '], StringSplitOptions.RemoveEmptyEntries);

            Array.Reverse(sw);

            return string.Join(" ", sw);
        }//Task1_4

        //Дана строка, состоящая из слов, набранных заглавными буквами и разделенных пробелами
        //(одним или несколькими). Вывести строку, содержащую эти же слова, разделенные одним
        //пробелом и расположенные в алфавитном порядке строчным буквами.
        public static string Task1_5(string str) 
        {
            string[] sw = str.ToLower().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            Array.Sort(sw);

            return string.Join(" ", sw);
        }//Task1_5

    }//Task1
}
