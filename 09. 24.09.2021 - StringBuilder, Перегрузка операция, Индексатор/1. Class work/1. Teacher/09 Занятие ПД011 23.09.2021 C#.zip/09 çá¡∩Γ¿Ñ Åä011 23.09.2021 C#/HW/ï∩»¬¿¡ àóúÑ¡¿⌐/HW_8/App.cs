﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW_8.Model;

namespace HW_8
{
    class App
    {
        private string _str1 = "Кот ломом колол слона";
        private string _str2 = "Кот   ломом       колол   слона";


        #region Task1
        public void Part1()
        {
            Utils.ShowNavBarTask("    Задание 1.1");

            Console.WriteLine("\n\n\n Даны строки S и S0. Удалить из строки S все подстроки, совпадающие с S0." +
                " \nЕсли совпадающих подстрок нет, то вывести строку S без изменений.\n\n\n");

            string delete = "ло";

            Console.WriteLine($"     Исходная строка:\n" + $"    {_str1}\n\n\n" +
                              $"     Строка после обработки, удалена подстрока \"{ delete }\" :\n" +
                              $"     { Task1.Task1_1(_str1, delete)}");
        }//Part1

        public void Part2()
        {
            Utils.ShowNavBarTask("    Задание 1.2");

            Console.WriteLine("\n\n\n Даны строки S, S1 и S2. Заменить в строке S все вхождения строки S1 на строку S2\n\n\n");

            string replace = "ло", substr = "^^^";

            Console.WriteLine($"     Исходная строка:\n" + $"    {_str1}\n\n\n" +
                              $"     Строка после обработки, замена \"{ replace }\", на \"{ substr }\" :\n" +
                              $"     { Task1.Task1_2(_str1, replace, substr)}");
        }//Part2

        public void Part3()
        {
            Utils.ShowNavBarTask("    Задание 1.3");

            Console.WriteLine("\n\n\n Дана строка, состоящая из слов, разделенных пробелами (одним или" +
                              "несколькими). \n Вывести строку, содержащую эти же слова, разделенные\n" +
                              " одним символом «.» (точка). В конце строки точку не ставить.\n\n");

            Console.WriteLine($"     Исходная строка:\n" + $"    {_str1}\n\n\n" +
                              $"     Строка после обработки:\n" +
                              $"     { Task1.Task1_3(_str2)}");
        }//Part3

        public void Part4()
        {
            Utils.ShowNavBarTask("    Задание 1.4");

            Console.WriteLine("\n\n\n Дана строка, состоящая из слов, разделенных пробелами (одним или " +
                              "несколькими). \n Вывести строку, содержащую эти же слова, разделенные\n" +
                              " одним пробелом и расположенные в обратном порядке.\n\n");

            Console.WriteLine($"     Исходная строка:\n" + $"    {_str1}\n\n\n" +
                              $"     Строка после обработки:\n" +
                              $"     { Task1.Task1_4(_str2)}");
        }//Part4

        public void Part5()
        {
            Utils.ShowNavBarTask("    Задание 1.5");

            Console.WriteLine("\n\n\n Дана строка, состоящая из слов, разделенных пробелами (одним или " +
                              "несколькими). \n Вывести строку, содержащую эти же слова, разделенные\n" +
                              " одним пробелом и расположенные в в алфавитном порядке строчным буквами.\n\n");

            Console.WriteLine($"     Исходная строка:\n" + $"    {_str1}\n\n\n" +
                              $"     Строка после обработки:\n" +
                              $"     { Task1.Task1_5(_str1)}");
        }//Part5

        #endregion

        #region Task2
        public void Part6()
        {
            Utils.ShowNavBarTask("    Задание 2.1");

            Console.WriteLine(
                "\n\n\n    Дана строка S (класс string). В строке слова разделяются одним или несколькими пробелами,\n" +
                "    в результирующей строке слова должны разделяться одним пробелом:\n" +
                "    В строке поменять местами каждые два соседних слова.");

            Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
                              $"    {_str2}\n\n" +
                              $"    Строка после обработки:\n\n" +
                              $"    {Task2.Task2_1(_str2)}");

        }

        public void Part7()
        {
            Utils.ShowNavBarTask("    Задание 2.2");

            Console.WriteLine(
                "\n\n\n    Дана строка S (класс string). В строке слова разделяются одним или несколькими пробелами,\n" +
                "    в результирующей строке слова должны разделяться одним пробелом:\n" +
                "    Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами.");

            string source = "Око слона увидело кота с ломом";

            Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
                              $"    {source}\n\n" +
                              $"    Строка после обработки:\n\n" +
                              $"    {Task2.Task2_2(source)}");

        }

        public void Part8()
        {
            Utils.ShowNavBarTask("    Задание 2.3");

            Console.WriteLine(
                "\n\n\n    Дана строка S (класс string). В строке слова разделяются одним или несколькими пробелами,\n" +
                "    в результирующей строке слова должны разделяться одним пробелом:\n" +
                "    Поменять местами первое слово максимальной длины и первое слово минимальной длины в строке.");


            Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
                              $"    {_str2}\n\n" +
                              $"    Строка после обработки:\n\n" +
                              $"    {Task2.Task2_3(_str2)}");
        }

        public void Part9()
        {
            Utils.ShowNavBarTask("    Задание 2.4");

            Console.WriteLine(
                "\n\n\n    Дана строка S (класс string). В строке слова разделяются одним или несколькими пробелами,\n" +
                "    в результирующей строке слова должны разделяться одним пробелом:\n" +
                "    В каждом слове строки установить верхний регистр первой буквы.");

            Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
                              $"    {_str2}\n\n" +
                              $"    Строка после обработки:\n\n" +
                              $"    {Task2.Task2_4(_str2)}");

        }
        #endregion

    }//App



}
