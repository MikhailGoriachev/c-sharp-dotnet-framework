﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_8
{
    class Program
    {
        static void Main(string[] args)
        {

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задание 1.1" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задание 1.2" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задание 1.3" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задание 1.4" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задание 1.5" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задание 2.1" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задание 2.2" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задание 2.3" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задание 2.4" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true)
            {
                // настройка цветового оформления
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Clear();
                Console.CursorVisible = false;

                Utils.ShowNavBarTask("  Введение в ООП C# - классы, свойства, массивы объектов");
                Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                Console.Clear();

                switch (key)
                {
                    case ConsoleKey.Q:
                        app.Part1();
                        break;

                    case ConsoleKey.W:
                        app.Part2();
                        break;

                    case ConsoleKey.E:
                        app.Part3();
                        break;

                    case ConsoleKey.R:
                        app.Part4();
                        break;

                    case ConsoleKey.T:
                        app.Part5();
                        break;

                    case ConsoleKey.A:
                        app.Part6();
                        break;

                    case ConsoleKey.S:
                        app.Part7();
                        break;

                    case ConsoleKey.D:
                        app.Part8();
                        break;

                    case ConsoleKey.F:
                        app.Part9();
                        break;

                    // выход из приложения назначен на клавишу F10 или кавишу Z
                    case ConsoleKey.F10:
                    case ConsoleKey.Z:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                        Console.CursorVisible = true;
                        return;

                    default:
                        continue;
                } // switch

                // Ожидать нажатия любой клавиши по окончании работы пункта меню
                Console.CursorVisible = true;
                Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                Console.ReadKey(true);
            } // while
        } // Main
    }//Program
}
