﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomeWork23._09._21.Models;


namespace HomeWork23._09._21
{
    class App
    {
        // Задача 1
        
        string S = " кот    ломом    колол    слона ";
        string SO = "ло";
        string S2 = "ка";



        public void DemoTask1() {

             
            Console.WriteLine($"Задача 1.\nРешение задачи разместите в классе, класс расположите во вложенном пространстве \nимен Models Вашего проекта.\nВыполнить обработку строк – используйте класс string.");
            Console.WriteLine($"\nСтрока для обработки: ");
            Console.WriteLine(S);


            Console.WriteLine(Task1.RemoveSubstrings(S, SO));
            Console.WriteLine(Task1.RemoveAllInclude(S, SO, S2));
            Console.WriteLine(Task1.DelimiterDot(S));
            Console.WriteLine(Task1.DelimiterSpaceReverse(S));
            Console.WriteLine(Task1.DelimiterSpaceSortLittle(S));

        }

        public void DemoTask2()
        {


            Console.WriteLine($"Задача 2.\nДана строка S(класс string).В строке слова разделяются одним или несколькими пробелами, \nв результирующей строке слова должны разделяться одним пробелом.");
            Console.WriteLine($"\nСтрока для обработки: ");
            Console.WriteLine(S);
             

            Console.WriteLine(Task2.SwapNeighboringWords(S));
            Console.WriteLine(Task2.DeleteStartVowelsWords(S));
            Console.WriteLine(Task2.SwapMinMaxLeghtWords(S));
            Console.WriteLine(Task2.ToUpperEveryWords(S));
            

        }






    }
}
