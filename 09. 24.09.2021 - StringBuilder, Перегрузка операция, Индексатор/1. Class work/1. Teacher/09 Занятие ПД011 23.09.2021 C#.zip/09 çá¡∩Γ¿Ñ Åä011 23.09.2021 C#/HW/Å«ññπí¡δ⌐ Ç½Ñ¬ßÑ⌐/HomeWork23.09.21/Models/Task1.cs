﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork23._09._21.Models
{
    class Task1
    {
       

        // Даны строки S и S0.Удалить из строки S все подстроки, совпадающие с S0.Если совпадающих подстрок нет, то вывести строку S без изменений.
        public static string RemoveSubstrings(string S, string SO) {


            
            Console.WriteLine($"\n\nЗадание 1\n\tДаны строки S и S0.Удалить из строки S все подстроки, совпадающие с S0.\n\tЕсли совпадающих подстрок нет, то вывести строку S без изменений.");
            Console.WriteLine($"Результат:");
      
            S = S.Replace(SO, "");            
            return S;

        }

        // Даны строки S, S1 и S2. Заменить в строке S все вхождения строки S1 на строку S2
        public static string RemoveAllInclude(string S, string S1, string S2)
        {

            Console.WriteLine($"\n\nЗадание 2\n\tДаны строки S, S1 и S2. Заменить в строке S все вхождения строки S1 на строку S2");
            Console.WriteLine($"Результат:");

            S = S.Replace(S1, S2);
            return S;

        }

        // Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). 
        // Вывести строку, содержащую эти же слова, разделенные одним символом «.» (точка). В конце строки точку не ставить.
        public static string DelimiterDot(string S)
        {

            Console.WriteLine($"\n\nЗадание 3\n\tДана строка, состоящая из слов, разделенных пробелами (одним или несколькими).\n\tВывести строку, содержащую эти же слова, разделенные одним символом «.» (точка).\n\tВ конце строки точку не ставить.");
            Console.WriteLine($"Результат:");

            char[] sep = " ,.:".ToCharArray();                                   // массив разделителей
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);  // массив слов    
            S = string.Join(".", sw);                                          // склеивание массива
           

            return S;

        }

        // Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). 
        // Вывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные в обратном порядке.
        public static string DelimiterSpaceReverse(string S)
        {

            Console.WriteLine($"\n\nЗадание 4\n\tДана строка, состоящая из слов, разделенных пробелами (одним или несколькими).\n\tВывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные \n\tв обратном порядке.");
            Console.WriteLine($"Результат:");

            char[] sep = " ,.:".ToCharArray();                                   // массив разделителей
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);  // массив слов    
            Array.Reverse(sw);                                                  // обратный порядок слов
            S = string.Join(" ", sw);                                          // склеивание массива


            return S;

        }


        // Дана строка, состоящая из слов, набранных заглавными буквами и разделенных пробелами (одним или несколькими). 
        // Вывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные в алфавитном порядке строчным буквами.
        public static string DelimiterSpaceSortLittle(string S)
        {

            Console.WriteLine($"\n\nЗадание 5\n\tДана строка, состоящая из слов, набранных заглавными буквами и разделенных пробелами \n\t(одним или несколькими). \n\tВывести строку, содержащую эти же слова, разделенные одним пробелом \n\tи расположенные в алфавитном порядке строчным буквами.");
            Console.WriteLine($"Результат:");

            char[] sep = " ,.:".ToCharArray();                                   // массив разделителей
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);  // массив слов    
            S = S.ToLower();                                                    // перевод символов в нижний регистр
            Array.Sort(sw);                                                     // сортировка слов в массиве
            S = string.Join(" ", sw);                                          // склеивание массива


            return S;

        }

    }
}
