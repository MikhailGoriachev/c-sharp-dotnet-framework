﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork23._09._21.Models
{
    class Task2
    {

        public static string SwapNeighboringWords(string S)
        {

            Console.WriteLine($"\n\nЗадание 1\n\tВ строке поменять местами каждые два соседних слова.");
            Console.WriteLine($"Результат:");

            char[] sep = " ,.:".ToCharArray();                                   // массив разделителей
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);  // массив слов    

            // замена соседних слов
            for (int i = 0; i < sw.Length;i++ )
            {
                if (i > sw.Length) break;

                swap(ref sw[i], ref sw[i + 1]);
                i++;
            }            
            
           
            S = string.Join(" ", sw);                                          // склеивание массива


            return S;

        }


        public static string DeleteStartVowelsWords(string S)
        {

            Console.WriteLine($"\n\nЗадание 2\n\tИз строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами");
            Console.WriteLine($"Результат:");

            char[] sep = " ,.:".ToCharArray();                                   // массив разделителей
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);  // массив слов    

            char[] vowels = "аеёиоуыэюяАЕЁИОУЫЭЮЯ".ToCharArray();

            S = string.Join(" ", sw);                                          // склеивание массива


            for (int i = 0; i < sw.Length; i++)
            {
                for (int k = 0; k < vowels.Length; k++)
                {

                    if (sw[i].StartsWith(vowels[k].ToString()))
                    {

                        S = S.Replace(sw[i], "");
                        break;
                    }
                    else if(sw[i].EndsWith(vowels[k].ToString()))
                    {
                        S = S.Replace(sw[i], "");
                        break;
                    }
                        

                }
                


            }
            


            return S;

        }

        public static string SwapMinMaxLeghtWords(string S)
        {

            Console.WriteLine($"\n\nЗадание 2\n\tПоменять местами первое слово максимальной длины и первое слово минимальной длины в строке");
            Console.WriteLine($"Результат:");

            char[] sep = " ,.:".ToCharArray();                                   // массив разделителей
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);  // массив слов    

            int maxWordIndex = 0;
            int minWordIndex = 0;
            string maxWord = sw[0];
            string minWord = sw[0];

            for (int i = 1; i < sw.Length; i++)
            {
                if (sw[i].Length < minWord.Length) {

                    minWord = sw[i];
                    minWordIndex = i;

                }
                if (sw[i].Length > maxWord.Length)
                {

                    maxWord = sw[i];
                    maxWordIndex = i;

                }


            }

            swap(ref sw[minWordIndex], ref sw[maxWordIndex]);
                       

            S = string.Join(" ", sw);                                          // склеивание массива


            return S;

        }


        public static string ToUpperEveryWords(string S)
        {

            Console.WriteLine($"\n\nЗадание 2\n\tВ каждом слове строки установить верхний регистр первой буквы.");
            Console.WriteLine($"Результат:");

            char[] sep = " ,.:".ToCharArray();                                   // массив разделителей
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);  // массив слов    

            

            for (int i = 0; i < sw.Length; i++)
            {

                sw[i] = sw[i].Substring(0, 1).ToUpper() + sw[i].Substring(1);

            }

            


            S = string.Join(" ", sw);                                          // склеивание массива


            return S;

        }

        public static void swap(ref string a,ref string b)
        {
            string c;
            c = a;
            a = b;
            b = c;

        }


    }
}
