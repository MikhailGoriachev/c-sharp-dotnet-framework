﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork23._09._21.Models;

namespace HomeWork23._09._21
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Домашние задание на 23.09.21";
            Console.SetWindowSize(120, 35);

            App app = new App();


            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 2" },
                
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };



            // главный цикл приложения
            while (true)
            {
                // настройка цветового оформления
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.Clear();
                Console.CursorVisible = false;

                Utils.ShowNavBarTask(" Работа со строками");
                Utils.ShowMenu(12, 5, "Домашние задание на 23.09.21", menu);

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                Console.Clear();

                switch (key)
                {
                    // ------------------------------------------------------------
                    // пункты меню, относящиеся к задаче 1
                    // Вывод массива работников на экран
                    case ConsoleKey.Q:
                        app.DemoTask1();
                        break;

                    // Упорядочивание работников по алфавиту
                    case ConsoleKey.W:
                        app.DemoTask2();                        
                        break;

                    

                    // выход из приложения назначен на клавишу F10 или кавишу Z
                    case ConsoleKey.F10:
                    case ConsoleKey.Z:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                        Console.CursorVisible = true;
                        return;

                    default:
                        continue;
                } // switch

                // Ожидать нажатия любой клавиши по окончании работы пункта меню
                Console.CursorVisible = true;
                Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                Console.ReadKey(true);
            } // while
           // App app = new App();
                  



           


        }






    }
}
