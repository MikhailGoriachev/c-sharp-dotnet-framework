﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringIntro.Models
{
    // Обработка строк при помощи класса string - задача 2
    internal class Task2
    {
        // строка для обработки
        private string _str;
        public string Str {
            get => _str;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Task2. Задана пустая строка");

                _str = value;
            }
        } // Str

        // Конструкторы класса
        public Task2():this("Строка для обработки в задачае 2") { }
        public Task2(string str) { Str = str; }

        // В строке _str слова разделяются одним или несколькими пробелами,
        // в результирующей строке слова должны разделяться  одним пробелом.
        // В строке поменять местами каждые два соседних слова
        public string Point1() {
            // разбить строку на слова - получить массив слов
            string[] words = _str.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

            // поменять местами каждые два соседних слова - т.е. два
            // соседних элемента в массиве
            int n = words.Length;
            for (int i = 0; i < n-1; i += 2) {
                (words[i], words[i + 1]) = (words[i + 1], words[i]);
            } // for i

            // собрать новую строку с использованием разделителя - символа " "
            // (пробел)
            return string.Join(" ", words);
        } // Point1

        // В строке _str слова разделяются одним или несколькими пробелами,
        // в результирующей строке слова должны разделяться  одним пробелом.
        // Из строки удалить все слова, начинающиеся и заканчивающиеся 
        // гласными буквами
        public string Point2() {
            // разбить строку на слова - получить массив слов
            string[] words = _str.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            
            // эта переменная будет использоваться в IndexOfAny() => нужен массив символов 
            char[] vowels = "aeiouyаеёиоуыэюя".ToCharArray();

            // Для удаления слов, начинающихся и заканчивающихся на гласные 
            // буквы заменяем такое слово пустой строкой
            int n = words.Length;
            for (int i = 0; i < n; ++i) {
                // если первый и последний символы строки - гласные буквы, заменить
                // слово пустой строкой
                string w = words[i];
                if (w.IndexOfAny(vowels) == 0 && w.LastIndexOfAny(vowels) == w.Length - 1) 
                    words[i] = "";
            } // for i

            // собрать новую строку с использованием разделителя - символа " "
            // (пробел) - после первой сборки еще раз разбиваем и собираем строку
            // чтобы убрать два и более подряд идущих пробела, образующихся после
            // склейки пустых строк
            words = string
                .Join(" ", words)
                .Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            return string.Join(" ", words);
        } // Point2

        // В строке _str слова разделяются одним или несколькими пробелами,
        // в результирующей строке слова должны разделяться  одним пробелом.
        // Поменять местами первое слово максимальной длины и первое слово 
        // минимальной длины  в строке
        public string Point3() {
            // разбить строку на слова - получить массив слов
            string[] words = _str.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

            // По заданию требуется найти индексы первого слова максимальной длины
            // и первого слова минимальной длины - ведем поиск в одном цикле, пока
            // еще не изучили LINQ
            int n = words.Length;
            int imin = 0, imax = 0;
            for (int i = 1; i < n; ++i) {
                int len = words[i].Length;

                if (len < words[imin].Length) {
                    imin = i;
                } // if

                if (len > words[imax].Length) {
                    imax = i;
                } // if
            } // for i

            // меняем местами слова
            (words[imin], words[imax]) = (words[imax], words[imin]);

            // собрать новую строку с использованием разделителя - символа " "
            // (пробел)
            return string.Join(" ", words);
        } // Point3

        // В строке _str слова разделяются одним или несколькими пробелами,
        // в результирующей строке слова должны разделяться  одним пробелом.
        // В каждом слове строки установить верхний регистр первой буквы
        public string Point4() {
            // разбить строку на слова - получить массив слов
            string[] words = _str.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

            int n = words.Length;
            for (int i = 0; i < n; ++i) {
                words[i] = words[i].Substring(0, 1).ToUpper() + words[i].Substring(1);
            } // for i

            // собрать новую строку с использованием разделителя - символа " "
            // (пробел)
            return string.Join(" ", words);
        } // Point4
    } // class Task2
}
