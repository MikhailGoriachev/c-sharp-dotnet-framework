﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using StringIntro.Models;

namespace StringIntro
{
    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App
    {
        Task1 _task1;  // объект для решения задачи 1
        Task2 _task2;  // объект для решения задачи 2

        // конструктор по умолчанию
        public App():this(new Task1(), new Task2()) { }
       
        // конструктор с внедрением зависимостей
        public App(Task1 task1, Task2 task2) {
            _task1 = task1;
            _task2 = task2;
        } // App
       
    } // class App
}
