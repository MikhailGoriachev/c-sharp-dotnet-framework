﻿using System;
using Microsoft.VisualBasic;  // для класса Interaction

/* 
 * Задача 1. 
 * Решение задачи разместите в классе, класс расположите во вложенном 
 * пространстве имен Models Вашего проекта. Выполнить обработку строк – 
 * используйте класс string:
 *     • Даны строки S и S0. Удалить из строки S все подстроки, совпадающие
 *       с S0. Если совпадающих подстрок нет, то вывести строку S без изменений.
 *     • Даны строки S, S1 и S2. Заменить в строке S все вхождения строки S1 на 
 *       строку S2
 *     • Дана строка, состоящая из слов, разделенных пробелами (одним или 
 *       несколькими). Вывести строку, содержащую эти же слова, разделенные 
 *       одним символом «.» (точка). В конце строки точку не ставить.
 *     • Дана строка, состоящая из слов, разделенных пробелами (одним или 
 *       несколькими). Вывести строку, содержащую эти же слова, разделенные 
 *       одним пробелом и расположенные в обратном порядке.
 *     • Дана строка, состоящая из слов, набранных заглавными буквами и 
 *       разделенных пробелами (одним или несколькими). Вывести строку, 
 *       содержащую эти же слова, разделенные одним пробелом и расположенные 
 *       в алфавитном порядке строчным буквами.
 * 
 * Задача 2. 
 * Дана строка S (класс string). В строке слова разделяются одним или 
 * несколькими пробелами, в результирующей строке слова должны разделяться 
 * одним пробелом:
 *     • В строке поменять местами каждые два соседних слова.
 *     • Из строки удалить все слова, начинающиеся и заканчивающиеся 
 *       гласными буквами
 *     • Поменять местами первое слово максимальной длины и первое слово 
 *       минимальной длины  в строке
 *     • В каждом слове строки установить верхний регистр первой буквы
 *
 */

namespace StringIntro
{
    class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 23.09.2021 - введение в обработку строк, класс string";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Удалить из строки все подстроки, совпадающие с заданной" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Заменить в строке все вхождения одной подстроки на другую" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Переформатировать строку так, чтобы слова в ней разделялись точкой" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Изменить порядок слов в строке на обратный и разделить их одном пробелом" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Упорядочить слова в строке по алфавиту и разделить одним пробелом" },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "В строке поменять местами каждые два соседних слова" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "В строке поменять местами первые слова минимальной и максимальной длины" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "В каждом слове строки установить верхний регистр первой буквы" },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - исключения, классы, свойства, массивы объектов");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1
                        #region Задача 1
                        // Удалить из строки S все подстроки, совпадающие с S1
                        case ConsoleKey.Q:
                            app.Task1Point1();
                            break;

                        // Заменить в строке все вхождения одной подстроки на другую
                        case ConsoleKey.W:
                            app.Task1Point2();
                            break;


                        // Переформатировать строку так, чтобы слова в ней разделялись точкой
                        case ConsoleKey.E:
                            app.Task1Point3();
                            break;

                        // Изменить порядок слов в строке на обратный и разделить их одном пробелом
                        case ConsoleKey.R:
                            app.Task1Point4();
                            break;

                        // Упорядочить слова в строке по алфавиту и разделить одним пробелом
                        case ConsoleKey.T:
                            app.Task1Point5();
                            break;
                        #endregion


                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 2
                        #region Задача 2

                        // В строке поменять местами каждые два соседних слова
                        case ConsoleKey.A:
                            app.Task2Point1();
                            break;

                        // Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами
                        case ConsoleKey.S:
                            app.Task2Point2();
                            break;

                        // В строке поменять местами первые слова минимальной и максимальной длины
                        case ConsoleKey.D:
                            app.Task2Point3();
                            break;

                        // В каждом слове строки установить верхний регистр первой буквы
                        case ConsoleKey.F:
                            app.Task2Point4();
                            break;
                        #endregion

                        // Выход из приложения назначен на клавишу F10 или клавишу Z или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch


            } // while
        } // Main
    } // class Program
}
