﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringIntro.Models
{
    // Обработка строк при помощи класса string - задача 1
    internal class Task1
    {
        // строка для обработки
        private string _str;
        public string Str {
            get => _str;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Task1. Задана пустая строка");
                
                _str = value; }
        } // Str

        // Конструкторы класса
        public Task1() : this("Строка для обработки в задачае 1") { }
        public Task1(string str) { Str = str; }

        // Удалить из строки Str все подстроки, совпадающие с s0
        public string Point1(string s0) {
            _str = _str.Replace(s0, "");
            return _str;
        }

        // Заменить в строке Str все вхождения строки s1 на строку s2
        public string Point2(string s1, string s2) {
            _str = _str.Replace(s1, s2);
            return _str;
        }

        // Дана строка, состоящая из слов, разделенных пробелами (одним или 
        // несколькими). Сформировать строку, содержащую эти же слова, разделенные 
        // одним символом «.» (точка). В конце строки точку не ставить
        public string Point3() { 
            // разбить строку на слова - получить массив слов
            string[] words = _str.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            
            // собрать строку из массива слов, разделитель между словами - символ "."
            // (точка)
            return string.Join(".", words);
            // => string.Join(".", _str.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries));
        } // Point3

        // Дана строка, состоящая из слов, разделенных пробелами (одним или 
        // несколькими). Вывести строку, содержащую эти же слова, разделенные 
        // одним пробелом и расположенные в обратном порядке.
        public string Point4() {
            // разбить строку на слова - получить массив слов
            string[] words = _str.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

            // поменять порядок следования элементов массива (слов) на обратный
            Array.Reverse(words);

            // собрать новую строку с использованием разделителя - символа " "
            // (пробел)
            return string.Join(" ", words);
        } // Point4

        // Дана строка, состоящая из слов, набранных заглавными буквами и 
        // разделенных пробелами (одним или несколькими). Вывести строку, 
        // содержащую эти же слова, разделенные одним пробелом и расположенные 
        // в алфавитном порядке строчным буквами.
        public string Point5() {
            // перевести строку в строчные буквы, разбить строку на слова - получить массив слов
            string[] words = _str
                .ToLower()
                .Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

            // упорядочить элементы массива (слова) 
            Array.Sort(words);

            // собрать новую строку с использованием разделителя - символа " "
            // (пробел)
            return string.Join(" ", words);
        } // Point5

    } // class Task1
}
