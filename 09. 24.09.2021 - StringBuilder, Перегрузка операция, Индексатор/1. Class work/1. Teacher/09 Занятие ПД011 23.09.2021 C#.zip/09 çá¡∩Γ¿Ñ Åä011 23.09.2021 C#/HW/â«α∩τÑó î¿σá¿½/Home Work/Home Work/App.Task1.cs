﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

using Home_Work.Models;

namespace Application
{
    public partial class App
    {
        #region Задание 1. Название задания

        /*
          * Задача 1. Решение задачи разместите в классе, класс расположите во вложенном пространстве имен 
          * Models Вашего проекта. Выполнить обработку строк – используйте класс string:
          *     •	Даны строки S и S0. Удалить из строки S все подстроки, совпадающие с S0. Если совпадающих
          *         подстрок нет, то вывести строку S без изменений.
          *     •	Даны строки S, S1 и S2. Заменить в строке S все вхождения строки S1 на строку S2
          *     •	Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). Вывести 
          *         строку, содержащую эти же слова, разделенные одним символом «.» (точка). В конце строки точку
          *         не ставить.
          *     •	Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). Вывести 
          *         строку, содержащую эти же слова, разделенные одним пробелом и расположенные в обратном порядке.
         */

        // Задание 1. Мианипуляция со строками
        public void Task1()
        {
            #region Меню

            // вывод меню
            while (true)
            {
                // отчистка консоли
                Console.Clear();

                // цвет 
                Console.ForegroundColor = ConsoleColor.Cyan;

                int x = 5, y = Console.CursorTop + 3;

                // заголовок
                Console.SetCursorPosition(x + 3, y); WriteColor($"{"    Задание 1. Мианипуляция со строками"}", ConsoleColor.Blue);

                y += 2;

                // пукты меню
                Console.SetCursorPosition(x, y++); Console.WriteLine("1. Удаление подстроки");
                Console.SetCursorPosition(x, y++); Console.WriteLine("2. Замена подстрок");
                Console.SetCursorPosition(x, y++); Console.WriteLine("3. Замена разделителя слов ' ' на '.'");
                Console.SetCursorPosition(x, y++); Console.WriteLine("4. Изменение порядка слов на обратный и с разделителем ' '");
                Console.SetCursorPosition(x, y++); Console.WriteLine("0. Выход");

                y += 4;

                // ввод номера задания
                Console.SetCursorPosition(x, y); Console.Write("Введите номер задания: ");
                if (!int.TryParse(Console.ReadLine(), out int n))
                    continue;

                try
                {

                    // обработка ввода 
                    switch (n)
                    {
                        // выход
                        case (int)Cmd.pointExit:
                            // позициониаровние курсора 
                            Console.SetCursorPosition(2, y + 5);
                            return;

                        // 1. Удаление подстроки
                        case (int)Cmd.pointOne:
                            Console.Clear();
                            // запуск задания 
                            Point1();
                            break;

                        // 2. Замена подстрок
                        case (int)Cmd.pointTwo:
                            Console.Clear();
                            // запуск задания 
                            Point2();
                            break;

                        // 3. Замена разделителя слов ' ' на '.'
                        case (int)Cmd.pointThree:
                            Console.Clear();
                            // запуск задания 
                            Point3();
                            break;

                        // 4. Изменение порядка слов на обратный и с разделителем ' '
                        case (int)Cmd.pointFour:
                            Console.Clear();
                            // запуск задания 
                            Point4();
                            break;

                        // если номер задания невалиден
                        default:

                            // установка цвета
                            Console.BackgroundColor = ConsoleColor.DarkRed;
                            Console.ForegroundColor = ConsoleColor.Black;

                            // позиционирование курсора
                            Console.SetCursorPosition(x, y); Console.WriteLine("         Номер задания невалиден!         ");

                            // выключение курсора
                            Console.CursorVisible = false;

                            // задержка времени
                            Thread.Sleep(1000);

                            // возвращение цвета
                            Console.ResetColor();

                            // включение курсора
                            Console.CursorVisible = true;

                            break;
                    } // switch
                } // try

                // стандартное исключение
                catch (Exception ex)
                {
                    Console.Clear();

                    // вывод сообщения об ошибке 
                    WriteColor(ex.Message, ConsoleColor.Red);
                    Console.WriteLine();
                    WriteColor(ex.StackTrace, ConsoleColor.Red);
                    Console.WriteLine();
                } // catch

                // обязательная часть
                finally
                {
                    // ввод клавиши для продолжения 
                    WriteColor("\n\n\tНажмите на [Enter] для продолжения...", ConsoleColor.Cyan);
                    Console.CursorVisible = false;
                    while (Console.ReadKey(true).Key != ConsoleKey.Enter) ;
                    Console.CursorVisible = true;
                } // finally
            }

            #endregion

            #region 1. Удаление подстроки

            // 1. Удаление подстроки
            void Point1()
            {
                ShowNavBarMessage("1. Удаление подстроки");

                // основная строка 
                string line = "кот ломом колол слона";

                // подстрока 
                string substring = "ол";

                // вывод строки до удаления 
                ShowLine(line, "Исходная строка", "Строка до удаления подстроки");

                // удаление подстроки из основной строки
                StringManip.RemoveSubstring(line, substring, out line);

                // вывод строки после удаления 
                ShowLine(line, "Исходная строка", "Строка после удаления подстроки");
            }

            #endregion

            #region 2. Замена подстрок

            // 2. Замена подстрок
            void Point2()
            {
                ShowNavBarMessage("2. Замена подстрок");
            }

            #endregion

            #region 3. Замена разделителя слов ' ' на '.'

            // 3. Пункт меню
            void Point3()
            {
                ShowNavBarMessage("3. Замена разделителя слов ' ' на '.'");
            }

            #endregion

            #region 4. Изменение порядка слов на обратный и с разделителем ' '

            // 4. Пункт меню
            void Point4()
            {
                ShowNavBarMessage("4. Изменение порядка слов на обратный и с разделителем ' '");

            }

            #endregion


        }

        #endregion

    }
}
