﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*
 *      •	Даны строки S и S0. Удалить из строки S все подстроки, совпадающие с S0. Если совпадающих
 *          подстрок нет, то вывести строку S без изменений.
 *      •	Даны строки S, S1 и S2. Заменить в строке S все вхождения строки S1 на строку S2
 *      •	Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). Вывести 
 *          строку, содержащую эти же слова, разделенные одним символом «.» (точка). В конце строки точку
 *          не ставить.
 *      •	Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). Вывести 
 *          строку, содержащую эти же слова, разделенные одним пробелом и расположенные в обратном порядке.
 *      •	В строке поменять местами каждые два соседних слова.
 *      •	Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами
 *      •	Поменять местами первое слово максимальной длины и первое слово минимальной длины в строке
 *      •	В каждом слове строки установить верхний регистр первой буквы
 */

namespace Home_Work.Models
{
    // Класс Манипуляции со строками
    internal class StringManip
    {
        #region Методы


        // Удаление подстроки
        /// <returns>Если было произведено удаление то true, иначе false</returns>
        static public bool RemoveSubstring(string line, string substring, out string result)
        {
            // удаление подстрок из строки
            result = line.Replace(substring, "");

            // поиск подстрок в исходной строке
            return line.IndexOf(substring) != -1;
        }


        // Замена подстрок
        /// <returns>Если была произведена замена то true, иначе false</returns>
        static public bool Replace(string line, string substring, string stringReplace, out string result)
        {
            // замена подстрок
            result = line.Replace(substring, stringReplace);

            // поиск подстрок в исходной строке
            return line.IndexOf(substring) != -1;
        }

        // Замена разделителя слов ' ' на '.'
        /// <returns>Если была произведена замена то true, иначе false</returns>
        static public bool ReplaceSeparator(string line, out string result)
        {
            // замена разделителя слов ' ' на '.'
            result = string.Join(".", line.Split(new char[] {' '} , StringSplitOptions.RemoveEmptyEntries));

            // поиск разделителей в исходной строке
            return line.IndexOf(' ') != -1;
        }

        // изменение порядка слов на обратный и с разделителем ' '
        static public void ReversReplaceSeparator(string line, out string result)
        {
            // получение массива слов без разделителя
            string[] split = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            // изменение порядка слов 
            Array.Reverse(split);

            // объединение слов в строку с разделителем ' '
            result = string.Join(" ", split);
        }

        // поменять местами каждые два соседних слова 
        static public void SwapEveryTwoWords(string line, out string result)
        {
            // получение массива слов без разделителя
            string[] split = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            // размер массива строк
            int length = split.Length;

            // изменение позиций слов 
            for (int i = 0; i < length; i += 2) 
            {
                SwapLines(split, i, i + 1);
            }

            // объединение строки
            result = string.Join(" ", split);
        }

        // удаление из строки всех слов начинающихся или заканчивающихся гласной буквой
        static public void RemoveWordsStartEndVowel(string line, out string result)
        {
            // разделение строки на слова
            string[] split = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            // массив с гласными буквами
            string vowel = "уеыаоэиюё";

            // предикатор 
            bool pred(string str) 
            {
                // перевод строки в нижний регистр
                string strLow = str.ToLower();

                // проверка строки
                return strLow.StartsWith(vowel) || strLow.EndsWith(vowel);
            }

            // строки для удаления 
            string[] delStr = Array.FindAll(split, pred);

            // размер массива строк для удаления 
            int length = delStr.Length;

            // удаление всех слов начинающихся или заканчивающихся гласной буквой
            for (int i = 0; i < length; i++)
            {
                delStr[i] = "";
            }

            // объединение строк 
            result = string.Join(" ", split);
        }

        // поменять местами первое слово масимальной длины и первой слово минимальной длины
        static public void SwapLongShortWords(string line, out string result)
        {
            // разделение строки на слова 
            string[] split = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            // размер массива слов
            int length = split.Length;

            // минимальная и максимальная длина строки
            int min, max;

            min = max = split[0].Length;

            // индексы минимального и максимального элементов 
            int iMin, iMax;

            iMin = iMax = 0;

            // поиск самого длинного и самого короткого слова
            for (int i = 1; i < length; i++)
            {
                // размер строки 
                int lengthLine = split[i].Length;

                // если размер больше max
                if (lengthLine > max) { max = lengthLine; iMax = i; }

                // если размер меньше min
                else if (lengthLine < min) { min = lengthLine; iMin = i; }
            }

            // поменять местами первое слово масимальной длины и первой слово минимальной длины
            SwapLines(split, iMax, iMin);

            // объединение строк
            result = string.Join(" ", split);
        }

        // в каждом слове строки установить верхний регистр первой буквы
        static public  void ToUpperFirstLetterWords(string line, out string result)
        {
            // разделение строки
            string[] split = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            // размер массива строк 
            int length = split.Length;

            // установить верхний регистр для первой буквы услова 
            for (int i = 0; i < length; i++)
                // установка верхнего регистра первой буквы
                split[i] = split[i].Substring(0, 1).ToUpper() + split[i].Substring(1);

            // объединение строки
            result = String.Join(" ", split);
        }

        // поменять местами два слова 
        static private void SwapLines(string[] lines, int i1, int i2)
        {
            string temp = lines[i1];
            lines[i1] = lines[i2];
            lines[i2] = temp;
        }

        #endregion
    }
}
