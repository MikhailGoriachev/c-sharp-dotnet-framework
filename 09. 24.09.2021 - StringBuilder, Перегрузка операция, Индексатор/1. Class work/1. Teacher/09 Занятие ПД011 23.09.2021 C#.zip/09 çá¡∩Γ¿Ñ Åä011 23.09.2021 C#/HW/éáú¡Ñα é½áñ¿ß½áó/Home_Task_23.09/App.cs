﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using Home_Task_23_09.Utilities;
using Home_Task_23_09.Models;
namespace Home_Task_23_09
{
    public class App
    {
        public void Menu()
        {
            #region Главное меню
            /*Console.ForegroundColor = Utils._SymbolsColor;
            Console.BackgroundColor = Utils._MainColor;*/
            Palette.MainColor.EstablishColor();
            string MainTitle = "Домашнее задание на 23.09";

            //Массивы пунктов меню. 
            MenuItem[] baseMenu = new[] {
                new MenuItem {key = " 1 ",Text = " - Задача 1: работа со строками"},
                new MenuItem {key = " 2 ",Text = " - Задача 2: работа со строками"},
                new MenuItem {key = "ESC",Text = " - выход из программы"}
            };

            while (true)
            {
                Console.Clear();
                Utils.ShowBarMessage(" ".PadRight(Console.WindowWidth/2-MainTitle.Length/2)+MainTitle);
                Console.CursorVisible = false;
                Utils.ShowMenu(3, 3, "Выберете задание", baseMenu);

                //Если задание сделано не до конца

                Console.ForegroundColor = Utils.colors.W;
                Console.BackgroundColor = Utils.colors.R;
                Console.SetCursorPosition(3, 14);
                Console.Write("Ps.Задание выполнено на 50%!");
                Palette.MainColor.EstablishColor();

                ConsoleKey key = Console.ReadKey().Key;

                try
                {
                    switch (key)
                    {
                        case ConsoleKey.D1:
                            {
                                Console.Clear();
                                Task1Menu();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.D2:
                            {
                                Console.Clear();
                                Task2Menu();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.Escape:
                            {
                                Console.Clear();
                                return;
                            }
                        default:
                            throw new Exception($"Клавиша {key.ToString()} не поддерживается");
                    }

                }
                //Обрабатываем общее исключение
                catch (Exception ex)
                {
                    Console.Clear();
                    Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);

                    Console.ReadKey();
                }//catch
            }

            #endregion

            #region Подменю
            //Меню задания 1
            void Task1Menu()
            {
                //Console.SetWindowSize(60, 50);
                //Массивы пунктов меню 
                MenuItem[] FirstTaskMenu = new[] {
                new MenuItem {key = " Q ",Text = " - Удалить из строки S все подстроки, совпадающие с S0"},
                new MenuItem {key = " W ",Text = " - Заменить в строке S все вхождения строки S1 на строку S2"},
                new MenuItem {key = " E ",Text = " - Заменить разделительные пробелы на точки в строке"},
                new MenuItem {key = " R ",Text = " - Сократить кол-во пробелов между строками до 1-го."},
                new MenuItem {key = " T ",Text = " - Сократить кол-во пробелов + вывести строку в алфавитном порядке"},
                new MenuItem {key = " Y ",Text = " - Показать полный список задач"},
                new MenuItem {key = "ESC",Text = " - Выход"}
            };
                Task1 task1 = new Task1();
                //App app = new App();
                try
                {

                    while (true)
                    {
                        Console.Clear();
                        Utils.ShowBarMessage($"Задание 1: ");
                        Console.CursorVisible = false;
                        Utils.ShowMenu(3, 3, "Выберете действие", FirstTaskMenu);
                        ConsoleKey key = Console.ReadKey().Key;

                        switch (key)
                        {
                            case ConsoleKey.Q:
                                {
                                    Console.Clear();
                                    task1.FindSubStr();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.W:
                                {
                                    Console.Clear();
                                    task1.ReplaceSubStr();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.E:
                                {
                                    Console.Clear();
                                    task1.SpaceOnDot();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.R:
                                {
                                    Console.Clear();
                                    task1.DelAndReverse();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.T:
                                {
                                    Console.Clear();
                                    task1.DelAndDecrease();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.Y:
                                {
                                    Console.Clear();
                                    task1.ShowTasks();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.Escape:
                                {

                                    return;
                                }
                            default:
                                throw new Exception($"Клавиша {key.ToString()} не поддерживается");
                        }//Switch

                    }//While

                }//Try
                 //Catсh блок
                 //Обрабатываем исключение, касающееся треугольника
                

                //Обрабатываем общее исключение
                catch (Exception ex)
                {
                    Console.Clear();
                    Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);
                    //Console.Write($"{ ex.Message}\n {ex.StackTrace}");

                }//catch

            } //Task 1

            //Меню задания 2
             void Task2Menu()
            {
                //Массивы пунктов меню 
                MenuItem[] FirstTaskMenu = new[] {
                new MenuItem {key = " Q ",Text = " - Поменять местами каждые два соседних слова строки"},
                new MenuItem {key = " W ",Text = " - Удалить все слова, начинающиеся и заканчивающиеся гласными буквами"},
                new MenuItem {key = " E ",Text = " - Поменять местами первое слово максимальной длины и первое слово минимальной длины"},
                new MenuItem {key = " R ",Text = " - В каждом слове строки установить верхний регистр первой буквы"},
                new MenuItem {key = " T ",Text = " - Показать полный список задач"},
                new MenuItem {key = "ESC",Text = " - Выход"}
            };
                Task2 task2 = new Task2();
                try
                {
                    while (true)
                    {
                        Console.Clear();
                        //Полное заполнение строки вычисляется путём нахождения оставшегося пространства после строки до края
                        Utils.ShowBarMessage($"Задание 2:");
                        Console.CursorVisible = false;
                        Utils.ShowMenu(3, 3, "Выберете действие", FirstTaskMenu);

                        //Если задание сделано не до конца

                        Console.ForegroundColor = Utils.colors.W;
                        Console.BackgroundColor = Utils.colors.R;
                        Console.SetCursorPosition(3, 18);
                        Console.Write(" Ps.задание не выполнено! ");
                        Palette.MainColor.EstablishColor();

                        ConsoleKey key = Console.ReadKey().Key;

                        

                        switch (key)
                        {
                            case ConsoleKey.Q:
                                {
                                    Console.Clear();
                                    Utils.ShowFrameMessage("Метод в разработке!","INFO_Task2", 3, 5);
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.W:
                                {
                                    Console.Clear();
                                    Utils.ShowFrameMessage("Метод в разработке!", "INFO_Task2", 3, 5);
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.E:
                                {
                                    Console.Clear();
                                    Utils.ShowFrameMessage("Метод в разработке!", "INFO_Task2", 3, 5);
                                    Console.ReadKey();
                                    break;
                                }
                            
                            case ConsoleKey.R:
                                {
                                    Console.Clear();
                                    Utils.ShowFrameMessage("Метод в разработке!", "INFO_Task2", 3, 5);
                                    Console.ReadKey();
                                    break;
                                }
                            
                            case ConsoleKey.T:
                                {
                                    Console.Clear();
                                    task2.ShowTasks();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.Escape:
                                {

                                    return;
                                }
                            default:
                                throw new Exception($"Клавиша {key.ToString()} не поддерживается");
                        }

                    }//While
                }//try
                 //Catсh блок

               
                //Обрабатываем общее исключение
                catch (Exception ex)
                {
                    Console.Clear();
                    Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);
                }//catch
            } //Task 2

            #endregion
        }
    }
}
