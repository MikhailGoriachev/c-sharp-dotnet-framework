﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Task_23_09.Utilities
{
    public static class Palette
    {

         static ConsoleColor MainBackColor = ConsoleColor.Cyan;
        //Базовый цвет символов 
         static ConsoleColor MainFontColor = ConsoleColor.Black;

        //Создаём объект базового цвета
        public static Color MainColor = new Color { BackGround = MainBackColor, Foreground = MainFontColor }; //Устанавливаем занчения цвета через default C_TOR

        //Цввета для выделения заголовков
        public static Color TitleColor = new Color { BackGround = ConsoleColor.White, Foreground = MainFontColor };


    }
}
