﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassString.Models;

namespace ClassString
{
    class App
    {
        private MenuItem[] _items;
        public App(MenuItem[] items)
        {
            _items = items;
        }

        public void Start()
        {
            Task1 task1 = new Task1();
            Task2 task2 = new Task2();
            while (true)
            {
                // настройка цветового оформления
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.Clear();
                Console.CursorVisible = false;

                Utils.ShowNavBarTask("  Введение в ООП C# - Работа со строками");
                Utils.ShowMenu(12, 5, "Меню приложения для работы со строками", _items);

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                Console.Clear();

                switch (key)
                {
                    //Удалить из строки S все подстроки, совпадающие с S0
                    case ConsoleKey.Q:
                        task1.DeleteSubstring();
                        break;

                    //Заменить в строке S все вхождения строки S1 на строку S2
                    case ConsoleKey.E:
                        task1.SubstituteString();
                        break;

                    //Вывести строку, содержащую эти же слова, разделенные одним символом «.» 
                    case ConsoleKey.R:
                        task1.ReplaceSpacesWithFullStop();
                        break;

                    //Вывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные в обратном порядке

                    case ConsoleKey.T:
                        task1.ReverseString();
                        break;

                    //Вывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные в алфавитном порядке строчным буквами
                    case ConsoleKey.Y:
                        task1.AlphabetOrder();
                        break;
                    // В строке поменять местами каждые два соседних слова.
                    case ConsoleKey.A:
                        task2.ExchangeEveryTwoWords();
                        break;

                    // Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами
                    case ConsoleKey.S:
                        task2.DeleteVowels();
                        break;




                }


            }// while  
        }
    }
}
