﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassString
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 23.09.2021 - введение в ООП на C#: Работа со строками.";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Пункт 1" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1. Пункт 2" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 1. Пункт 3" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 1. Пункт 4" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Задача 1. Пункт 5" },
                // ---------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Пункт 1" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Пункт 2" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2. Пункт 3" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2. Пункт 4" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App(menu);

            app.Start();

           

        }
    }
}
