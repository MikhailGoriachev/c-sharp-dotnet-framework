﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassString.Models
{
    class Task2
    {
        public void ExchangeEveryTwoWords()
        {
            Utils.ShowNavBarTask("Задача 2. Пункт 1. •	В строке поменять местами каждые два соседних слова.");
            ShowTask();

            string S = "При хорошем кнуте  и  пряники не  нужны";
            Console.WriteLine("\n");
            Console.WriteLine($"Строка S  :  {S}");
            char[] sep = " ".ToCharArray();
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);
            for(int i = 0; i<sw.Length-1; i+=2)
            {
                string temp;
                temp = sw[i];
                sw[i] = sw[i + 1];
                sw[i + 1] = temp;
            }
            S = string.Join(" ", sw);
            Console.WriteLine($"Строка S  :  {S}");
            Console.ReadKey();
        }

        public void DeleteVowels()
        {
            Utils.ShowNavBarTask(" Задача 2.  Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами");
            ShowTask1();

            string S = "При хорошем кнуте  и  пряники не  нужны";
            Console.WriteLine("\n");
            Console.WriteLine($"Строка S  :  {S}");
            char[] sep = " ".ToCharArray();
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);
            string vowels = "ауоыиэяюёе";
            


            Console.ReadKey(); 
        }

        private static void ShowTask()
        {
            string text = @" •	В строке поменять местами каждые два соседних слова.";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        } 

        private static void ShowTask1()
        {
            string text = @" Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        }

    }
}
