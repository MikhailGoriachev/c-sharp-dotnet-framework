﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassString.Models
{
    class Task1
    {
        public void DeleteSubstring()
        {
            Utils.ShowNavBarTask("Задача 1 . Пункт1. Удалить из строки S все подстроки, совпадающие с S0");
            ShowTask1();
            string S = "От топота копыт пыль по полю летит";
            string SO = "ы";
            Console.WriteLine("\n");
            Console.WriteLine($"     Строка S  : {S}") ;
            Console.WriteLine($"  Подстрока SO : {SO}");
            while(true)
            {
            int index = S.IndexOf(SO);
                if (index == -1) break;
                S = S.Remove(index,SO.Length);

            }
           
            Console.WriteLine($"После удаления : {S}");


            Console.ReadKey();
        }

        public void SubstituteString()
        {
            Utils.ShowNavBarTask(" Задача 1. Пункт 2. Заменить в строке S все вхождения строки S1 на строку S2");
            ShowTask2();
            string S = "Скороговорун скороговорил скоровыговаривал";
            string S1 = "оро";
            string S2 = "оло";
            Console.WriteLine("\n");
            Console.WriteLine($"Строка S  :  {S}");
            Console.WriteLine($"Строка S1 :  {S1}");
            Console.WriteLine($"Строка S2 :  {S2}");
            S = S.Replace(S1, S2);
            Console.WriteLine($"Строка S  :  {S}");
            


            Console.ReadKey();

        }

        public void ReplaceSpacesWithFullStop()
        {
            Utils.ShowNavBarTask(" Задача 1. Пункт 3. Вывести строку, содержащую слова, разделенные одним символом «.» ");

            ShowTask3();
            string S = "При хорошем кнуте  и пряники не нужны";
            Console.WriteLine("\n");
            Console.WriteLine($"Строка S  :  {S}");
            char[] sep = " ".ToCharArray();
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);
            S = string.Join(".", sw);
            Console.WriteLine($"Строка S  :  {S}");
            Console.ReadKey();

        }

        public void ReverseString()
        {
            Utils.ShowNavBarTask(" Задача 1. Пункт 4. Вывести строку, содержащую слова, разделенные одним пробелом и расположенные в обратном порядке");

            ShowTask4();
            string S = "При хорошем кнуте  и  пряники не  нужны";
            Console.WriteLine("\n");
            Console.WriteLine($"Строка S  :  {S}");
            char[] sep = " ".ToCharArray();
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);
            Array.Reverse(sw);
            S = string.Join(" ", sw);
            Console.WriteLine($"Строка S  :  {S}");
            Console.ReadKey();
        }

        public void AlphabetOrder()
        {
            Utils.ShowNavBarTask(" Задача 1. Пункт 5. Вывести строку,разделенную одним пробелом и расположенную в алфавитном порядке строчным буквами");

            ShowTask5();
            string S = "При хорошем кнуте  и  пряники не  нужны";
            Console.WriteLine("\n");
            Console.WriteLine($"Строка S  :  {S}");
            char[] sep = " ".ToCharArray();
            string[] sw = S.Split(sep, StringSplitOptions.RemoveEmptyEntries);
            Array.Sort(sw);
            S = string.Join(" ", sw).ToLower();
            Console.WriteLine($"Строка S  :  {S}");
            Console.ReadKey();
        }

        private static void ShowTask1()
        {
            string text = @"       1.   Даны строки S и S0. Удалить из строки S все подстроки, совпадающие с S0. 
            Если совпадающих подстрок нет, то вывести строку S без изменений";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);

        }

        private static void ShowTask2()
        {
            string text = @" •	Даны строки S, S1 и S2. Заменить в строке S все вхождения строки S1 на строку S2";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        }

        private static void ShowTask3()
        {
            string text = @" •	    Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). 
            Вывести строку, содержащую эти же слова, разделенные одним символом «.» (точка). 
            В конце строки точку не ставить.";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        }

        private static void ShowTask4()
        {
            string text = @" •	    Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). 
            Вывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные в обратном порядке.";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        }

        private static void ShowTask5()
        {
            string text = @" •	    Дана строка, состоящая из слов, набранных заглавными буквами и разделенных пробелами 
            (одним или несколькими). Вывести строку, содержащую эти же слова, разделенные одним пробелом и 
            расположенные в алфавитном порядке строчным буквами.";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        }

    }
}
