﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW8.Models
{
	// Решение задания 1
	public static class Task1
	{
		// Даны строки S и S0.Удалить из строки S все подстроки, совпадающие с S0.Если совпадающих подстрок нет,
		// то вывести строку S без изменений.
		public static string Subtask1(string s, string s0)
		{
			int n;

			while ((n = s.IndexOf(s0)) != -1)
				s = s.Remove(n, s0.Length);

			return s;
		}

		// Даны строки S, S1 и S2.Заменить в строке S все вхождения строки S1 на строку S2
		public static string Subtask2(string s, string s1, string s2) => 
			s.Replace(s1, s2);


		// Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими).
		// Вывести строку, содержащую эти же слова, разделенные одним символом «.» (точка).
		// В конце строки точку не ставить.
		public static string Subtask3(string str) =>
			string.Join(".", str.Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries));
	

		// Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). Вывести строку,
		// содержащую эти же слова, разделенные одним пробелом и расположенные в обратном порядке.
		public static string Subtask4(string str)
		{
			string[] sw = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

			Array.Reverse(sw);

			return string.Join(" ", sw); 
		}


		// Дана строка, состоящая из слов, набранных заглавными буквами и разделенных пробелами (одним или несколькими).
		// Вывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные в
		// алфавитном порядке строчным буквами.
		public static string Subtask5(string str)
		{
			string[] sw = str.ToLower().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

			Array.Sort(sw);

			return string.Join(" ", sw);
		}


	}
}
