﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using HW8.Models;

namespace HW5
{
	// Класс, обеспечивающий работу приложения
	class App
	{
				
		public App() {}

		private string _source1 = "Кот ломом колол слона";
		private string _source2 = "Кот   ломом колол     слона";

		// Метод запуска работы меню приложения
		public void Run()
		{
			Console.ForegroundColor = ConsoleColor.Green;
			Console.BackgroundColor = ConsoleColor.Black;

			Menu menu = new Menu(new[]
				{
					new Menu.MenuItem() {Text = "Задание 1.1", Callback = MenuItem1},
					new Menu.MenuItem() {Text = "Задание 1.2", Callback = MenuItem2},
					new Menu.MenuItem() {Text = "Задание 1.3", Callback = MenuItem3},
					new Menu.MenuItem() {Text = "Задание 1.4", Callback = MenuItem4},
					new Menu.MenuItem() {Text = "Задание 1.5", Callback = MenuItem5},
					new Menu.MenuItem() {Text = "Задание 2.1", Callback = MenuItem6},
					new Menu.MenuItem() {Text = "Задание 2.2", Callback = MenuItem7},
					new Menu.MenuItem() {Text = "Задание 2.3", Callback = MenuItem8},
					new Menu.MenuItem() {Text = "Задание 2.4", Callback = MenuItem9},
					new Menu.MenuItem() {Text = "Выход"}
				}, new Point(5, 5),
				"Меню приложения");

			menu.Run();
		}

		#region  Задача 1
		private void MenuItem1()
		{
			Utilities.ShowNavBar("    Задание 1.1");
			
			Console.WriteLine(
				"\n\n\n    Даны строки S и S0. Удалить из строки S все подстроки, совпадающие с S0.\n" +
				"    Если совпадающих подстрок нет, то вывести строку S без изменений.");

			string deleting = "ло";

			Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
			                  $"    {_source1}\n\n" +
			                  $"    Строка после обработки (удаления подстроки \"{deleting}\"):\n\n" +
			                  $"    {Task1.Subtask1(_source1, deleting)}");
		}

		
		private void MenuItem2()
		{
			Utilities.ShowNavBar("    Задание 1.2");

			Console.WriteLine(
				"\n\n\n    Даны строки S, S1 и S2. Заменить в строке S все вхождения строки S1 на строку S2");

			string replaceable = "ло", substr= "###";

			Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
			                  $"    {_source1}\n\n" +
			                  $"    Строка после обработки (замена \"{replaceable}\" на \"{substr}\"):\n\n" +
			                  $"    {Task1.Subtask2(_source1, replaceable, substr)}");
		}
		
		private void MenuItem3()
		{
			Utilities.ShowNavBar("    Задание 1.3");

			Console.WriteLine(
				"\n\n\n    Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). Вывести строку, \n" +
				"    содержащую эти же слова, разделенные одним символом «.» (точка). В конце строки точку не ставить.");

			Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
			                  $"    {_source2}\n\n" +
			                  $"    Строка после обработки:\n\n" +
			                  $"    {Task1.Subtask3(_source2)}");

		}

		
		private void MenuItem4()
		{
			Utilities.ShowNavBar("    Задание 1.4");

			Console.WriteLine(
				"\n\n\n    Дана строка, состоящая из слов, разделенных пробелами (одним или несколькими). Вывести строку,\n" +
				"    содержащую эти же слова, разделенные одним пробелом и расположенные в обратном порядке.");

			Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
			                  $"    {_source2}\n\n" +
			                  $"    Строка после обработки:\n\n" +
			                  $"    {Task1.Subtask4(_source2)}");


		}


		private void MenuItem5()
		{
			Utilities.ShowNavBar("    Задание 1.5");

			Console.WriteLine(
				"\n\n\n    Дана строка, состоящая из слов, набранных заглавными буквами и разделенных пробелами \n" +
				"    (одним или несколькими). Вывести строку, содержащую эти же слова, разделенные одним пробелом\n" +
				"     и расположенные в алфавитном порядке строчным буквами.");

			string source = "КОТ   ЛОМОМ КОЛОЛ     СЛОНА";


			Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
							  $"    {source}\n\n" +
							  $"    Строка после обработки:\n\n" +
							  $"    {Task1.Subtask5(source)}");

		}

		#endregion

		#region Задача 2

		private void MenuItem6()
		{
			Utilities.ShowNavBar("    Задание 2.1");

			Console.WriteLine(
				"\n\n\n    Дана строка S (класс string). В строке слова разделяются одним или несколькими пробелами,\n" +
				"    в результирующей строке слова должны разделяться одним пробелом:\n" +
				"    В строке поменять местами каждые два соседних слова.");

			Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
			                  $"    {_source2}\n\n" +
			                  $"    Строка после обработки:\n\n" +
			                  $"    {Task2.Subtask1(_source2)}");

		}

		private void MenuItem7()
		{
			Utilities.ShowNavBar("    Задание 2.2");

			Console.WriteLine(
				"\n\n\n    Дана строка S (класс string). В строке слова разделяются одним или несколькими пробелами,\n" +
				"    в результирующей строке слова должны разделяться одним пробелом:\n" +
				"    Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами.");

			string source = "Око слона увидело кота с ломом";

			Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
			                  $"    {source}\n\n" +
			                  $"    Строка после обработки:\n\n" +
			                  $"    {Task2.Subtask2(source)}");

		}

		private void MenuItem8()
		{
			Utilities.ShowNavBar("    Задание 2.3");

			Console.WriteLine(
				"\n\n\n    Дана строка S (класс string). В строке слова разделяются одним или несколькими пробелами,\n" +
				"    в результирующей строке слова должны разделяться одним пробелом:\n" +
				"    Поменять местами первое слово максимальной длины и первое слово минимальной длины в строке.");


			Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
			                  $"    {_source2}\n\n" +
			                  $"    Строка после обработки:\n\n" +
			                  $"    {Task2.Subtask3(_source2)}");
		}

		private void MenuItem9()
		{
			Utilities.ShowNavBar("    Задание 2.4");

			Console.WriteLine(
				"\n\n\n    Дана строка S (класс string). В строке слова разделяются одним или несколькими пробелами,\n" +
				"    в результирующей строке слова должны разделяться одним пробелом:\n" +
				"    В каждом слове строки установить верхний регистр первой буквы.");

			Console.WriteLine($"\n\n\n    Исходная строка:\n\n" +
			                  $"    {_source2}\n\n" +
			                  $"    Строка после обработки:\n\n" +
			                  $"    {Task2.Subtask4(_source2)}");

		}
		#endregion

	}
}
