﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW8.Models
{
	// Решение задания 2
	public static class Task2
	{
		// Дана строка S(класс string). В строке слова разделяются одним или несколькими пробелами,
		// в результирующей строке слова должны разделяться одним пробелом:

		// В строке поменять местами каждые два соседних слова.
		public static string Subtask1(string str)
		{
			string[] sw = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

			for (int i = 0; i < sw.Length; i += 2)
				(sw[i], sw[i + 1]) = (sw[i + 1], sw[i]);

			return string.Join(" ", sw);
		}

		// Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами
		public static string Subtask2(string str)
		{
			string[] sw = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

			for (int i = 0; i < sw.Length; i++)
			{
				if (sw[i].IndexOfAny("аеёиоуыэюяАЕЁИОУЫЭЮЯ".ToCharArray()) == 0 &&
				    sw[i].LastIndexOfAny("аеёиоуыэюяАЕЁИОУЫЭЮЯ".ToCharArray()) == sw[i].Length - 1)
				{
					sw[i] = "";
				}
			}
			return string.Join(" ", sw);
		}

		// Поменять местами первое слово максимальной длины и первое слово минимальной длины в строке
		public static string Subtask3(string str)
		{
			string[] sw = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

			int iMin = 0, iMax = 0;

			for (int i = 1; i < sw.Length; i++)
			{
				if (sw[i].Length < sw[iMin].Length) iMin = i;
				if (sw[i].Length > sw[iMax].Length) iMax = i;
			}

			(sw[iMin], sw[iMax]) = (sw[iMax], sw[iMin]);


			return string.Join(" ", sw);
		}

		// В каждом слове строки установить верхний регистр первой буквы
		public static string Subtask4(string str)
		{
			string[] sw = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

			for (int i = 0; i < sw.Length; i++)
	            sw[i] = sw[i] .Substring(0, 1).ToUpper() + sw[i].Substring(1);

			return string.Join(" ", sw);
		}
	}
}
