﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction

namespace Задание
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 23.09.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Удалить из строки S все подстроки, совпадающие с S0" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Заменить в строке S все вхождения строки S1 на строку S2" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1. Разделить слова строки символом «.»" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 1. Разделить слова строки одним пробелом и расположить в обратном порядке" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 1. Разделить слова строки одним пробелом и расположить в алфавитном порядке строчным буквами" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. В строке поменять местами каждые два соседних слова" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2. Поменять местами первое слово максимальной длины и первое слово минимальной длины в строке" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2. В каждом слове строки установить верхний регистр первой буквы" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 23.09.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Удалить из строки S все подстроки, совпадающие с S0
                        case ConsoleKey.Q:
                            app.Task1Part1();
                            break;

                        // Заменить в строке S все вхождения строки S1 на строку S2
                        case ConsoleKey.W:
                            app.Task1Part2();
                            break;


                        // Разделить слова строки символом «.»
                        case ConsoleKey.E:
                            app.Task1Part3();
                            break;

                        // Разделить слова строки одним пробелом и расположить в обратном порядке
                        case ConsoleKey.R:
                            app.Task1Part4();
                            break;

                        // Разделить слова строки одним пробелом и расположить в алфавитном порядке строчным буквами
                        case ConsoleKey.T:
                            app.Task1Part5();
                            break;

                        // ------------------------------------------------------------

                        // В строке поменять местами каждые два соседних слова
                        case ConsoleKey.A:
                            app.Task2Part1();
                            break;

                        // Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами
                        case ConsoleKey.S:
                            app.Task2Part2();
                            break;

                        // Поменять местами первое слово максимальной длины и первое слово минимальной длины в строке
                        case ConsoleKey.D:
                            app.Task2Part3();
                            break;

                        // В каждом слове строки установить верхний регистр первой буквы
                        case ConsoleKey.F:
                            app.Task2Part4();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
