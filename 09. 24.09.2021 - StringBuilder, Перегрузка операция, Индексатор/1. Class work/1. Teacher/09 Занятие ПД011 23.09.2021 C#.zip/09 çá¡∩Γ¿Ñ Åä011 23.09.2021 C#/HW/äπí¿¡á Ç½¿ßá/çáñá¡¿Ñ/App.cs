﻿using System;
using Задание.Models;

namespace Задание
{
    
    // Объекты и методы для обработки по заданию
    public class App {


        // Удалить из строки S все подстроки, совпадающие с S0
        public void Task1Part1(string s = "пудель пуделя потчевал пудингом", string s0 = "пу") {
            Utils.ShowNavBarTask("    Удалить из строки S все подстроки, совпадающие с S0");

            Console.WriteLine($"\n    Строка S до изменений   : \"{s}\"");
            Console.WriteLine($"\n    Строка S0               : \"{s0}\"");

            Task1.Part1( ref s, s0);
            Console.WriteLine($"\n\n    Строка S после изменений: \"{s}\"");
        } // Task1Part1

        // Заменить в строке S все вхождения строки S1 на строку S2
        public void Task1Part2(string s = "перепёлка перепелят прятала от ребят", string s1 = "ре", string s2 = "пе")
        {
            Utils.ShowNavBarTask("    Заменить в строке S все вхождения строки S1 на строку S2");

            Console.WriteLine($"\n    Строка S до изменений   : \"{s}\"");
            Console.WriteLine($"\n    Строка S1               : \"{s1}\"");
            Console.WriteLine($"\n    Строка S2               : \"{s2}\"");

            Task1.Part2(ref s, s1, s2);
            Console.WriteLine($"\n\n    Строка S после изменений: \"{s}\"");
        } // Task1Part2

        // Разделить слова строки символом «.»
        public void Task1Part3(string s = "белые бараны били в барабаны")
        {
            Utils.ShowNavBarTask("    Разделить слова строки символом «.»");

            Console.WriteLine($"\n    Строка до изменений   : \"{s}\"");

            Task1.Part3(ref s);
            Console.WriteLine($"\n\n    Строка после изменений: \"{s}\"");
        } // Task1Part3

        // Разделить слова строки одним пробелом и расположить в обратном порядке
        public void Task1Part4(string s = "   вымыли    мышки    миску    для    мишки   ") {
            Utils.ShowNavBarTask("    Разделить слова строки одним пробелом и расположить в обратном порядке");

            Console.WriteLine($"\n    Строка до изменений   : \"{s}\"");

            Task1.Part4(ref s);
            Console.WriteLine($"\n\n    Строка после изменений: \"{s}\"");
        } // Task1Part4

        // Разделить слова строки одним пробелом и расположить в алфавитном порядке строчным буквами
        public void Task1Part5(string s = "ПЕРЕПЁЛКА     ПОПАЛА   В    ПЕРЕПЛЁТ")
        {
            Utils.ShowNavBarTask("    Разделить слова строки одним пробелом и расположить в алфавитном порядке строчным буквами");

            Console.WriteLine($"\n    Строка до изменений   : \"{s}\"");

            Task1.Part5(ref s);
            Console.WriteLine($"\n\n    Строка после изменений: \"{s}\"");
        } // Task1Part5

        // ----------------------------------------------------------------------------------------------------------------------

        // В строке поменять местами каждые два соседних слова
        public void Task2Part1(string s = "бобры берут для бобрят бобы")
        {
            Utils.ShowNavBarTask("    В строке поменять местами каждые два соседних слова");

            Console.WriteLine($"\n    Строка до изменений   : \"{s}\"");

            Task2.Part1(ref s);
            Console.WriteLine($"\n\n    Строка после изменений: \"{s}\"");
        } // Task2Part1

        // Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами
        public void Task2Part2(string s = "оплошала кошка Нюшка")
        {
            Utils.ShowNavBarTask("    Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами");

            Console.WriteLine($"\n    Строка до изменений   : \"{s}\"");

            Task2.Part2(ref s);
            Console.WriteLine($"\n\n    Строка после изменений: \"{s}\"");
        } // Task2Part2

        // Поменять местами первое слово максимальной длины и первое слово минимальной длины в строке
        public void Task2Part3(string s = "Деликатный кот не доел деликатес")
        {
            Utils.ShowNavBarTask("    Поменять местами первое слово максимальной длины и первое слово минимальной длины в строке");

            Console.WriteLine($"\n    Строка до изменений   : \"{s}\"");

            Task2.Part3(ref s);
            Console.WriteLine($"\n\n    Строка после изменений: \"{s}\"");
        } // Task2Part3


        // В каждом слове строки установить верхний регистр первой буквы
        public void Task2Part4(string s = "кот Василий перед мышами хвалился силой своей и усами")
        {
            Utils.ShowNavBarTask("    В каждом слове строки установить верхний регистр первой буквы");

            Console.WriteLine($"\n    Строка до изменений   : \"{s}\"");

            Task2.Part4(ref s);
            Console.WriteLine($"\n\n    Строка после изменений: \"{s}\"");
        } // Task2Part4
    } // class App
}