﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models
{
    static class Task1 {

        // Удалить из строки S все подстроки, совпадающие с S0
        static public void Part1(ref string s, string s0) {
            s = s.Replace(s0, "");
        } // Part1

        // Заменить в строке S все вхождения строки S1 на строку S2
        static public void Part2(ref string s, string s1, string s2) {
            s = s.Replace(s1, s2);
        } // Part2

        // Разделить слова строки символом «.»
        static public void Part3(ref string s) {
            string[] sw = s.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);  // массив слов

            s = string.Join(".", sw);
        } // Part3

        // Разделить слова строки одним пробелом и расположить в обратном порядке
        static public void Part4(ref string s) {
            string[] sw = s.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);  // массив слов
            Array.Reverse(sw);
            s = string.Join(" ", sw);
        } // Part4

        // Разделить слова строки одним пробелом и расположить в алфавитном порядке строчным буквами
        static public void Part5(ref string s)
        {
            string[] sw = s.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);  // массив слов
            Array.Sort(sw);
            s = string.Join(" ", sw).ToLower();
        } // Part4
    } // Task1
}
