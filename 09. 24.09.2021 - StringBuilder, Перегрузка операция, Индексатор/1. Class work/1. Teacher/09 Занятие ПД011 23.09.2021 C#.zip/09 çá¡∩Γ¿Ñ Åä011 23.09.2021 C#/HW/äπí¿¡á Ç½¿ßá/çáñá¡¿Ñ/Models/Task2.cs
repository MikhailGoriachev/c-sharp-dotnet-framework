﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models
{
    class Task2 {
        // В строке поменять местами каждые два соседних слова
        static public void Part1(ref string s) {
            string[] sw = s.Split(" ,.:".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);  // массив слов

            for(int i = 0; i < sw.Length - 1; i += 2) {
                (sw[i], sw[i + 1]) = (sw[i + 1], sw[i]);
            } // for i

            s = string.Join(" ", sw);
        } // Part1

          // Из строки удалить все слова, начинающиеся и заканчивающиеся гласными буквами
        static public void Part2(ref string s) {
            string[] sw = s.Split(" ,.:".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);  // массив слов
            s = "";
            char[] vowels = "аеёиоуыэюя".ToCharArray();
            for (int i = 0; i < sw.Length; i++) {
                if (sw[i].LastIndexOfAny(vowels) != sw[i].Length - 1 || sw[i].IndexOfAny(vowels) != 0)
                    s += sw[i] + " ";
            } // for i
            s = s.Trim();
        } // Part2

        // Поменять местами первое слово максимальной длины и первое слово минимальной длины в строке
        static public void Part3(ref string s) {
            string[] sw = s.Split(" ,.:".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);  // массив слов

            (int iMin, int iMax) = (MinLenght(sw), MaxLenght(sw));

            (sw[iMin], sw[iMax]) = (sw[iMax], sw[iMin]);

            s = string.Join(" ", sw);
        } // Part3

        static public void Part4(ref string s) {
            string[] sw = s.Split(" ,.:".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);  // массив слов

            for (int i = 0; i < sw.Length; i++)
                sw[i] = sw[i].Substring(0, 1).ToUpper() + sw[i].Substring(1);

            s = string.Join(" ", sw);
        } // Part4


        // индекс слова минимальной длины
        static private int MinLenght(string[] sw) {
            int iMin = 0;
            for (int i = 1; i < sw.Length; i++) {
                if (sw[i].Length < sw[iMin].Length)
                    iMin = i;
            } // for i
            return iMin;
        } // MinLenght

        // индекс слова максимальной длины
        static private int MaxLenght(string[] sw)
        {
            int iMax = 0;
            for (int i = 1; i < sw.Length; i++)
            {
                if (sw[i].Length > sw[iMax].Length)
                    iMax = i;
            } // for i
            return iMax;
        } // MinLenght
    }
}
