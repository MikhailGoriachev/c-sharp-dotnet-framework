﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_3
{
    class Program
    {
        static private Random rand = new Random();

        #region Metods
        //заполнения массива случайными значениями
        static void Fill(int[] arr, int lo, int hi) 
        {
            for(int i = 0; i < arr.Length; i++) 
            {
                arr[i] = rand.Next(lo, hi + 1);
            }//for
        }//Fill

        //вывод массива
        static void ShowArr(int[] arr) 
        {
            Console.Write("\t\t\t\t\nПолученный массив: \n\t\t");
            Console.ForegroundColor = ConsoleColor.Red;
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($" {arr[i]} ");
            }//for
            Console.Write("\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
        }//ShowArr
        //вывод с выделением цвета
        static void ShowArrMin(int[] arr, int minEl)
        {
            Console.Write("\t\t\t\t\nМассив с выделением цвета минимального элемента: \n\t\t");
            Console.ForegroundColor = ConsoleColor.Red;

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == minEl)
                    Console.ForegroundColor = ConsoleColor.Yellow;

                Console.Write($" {arr[i]} ");

                Console.ForegroundColor = ConsoleColor.Red;
            }//for
            Console.Write("\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
        }//ShowArr
        static void ShowSumElems(int[] arr, int iF, int iL, int sum)
        {
            Console.Write("\t\t\t\t\nМассив с выделением цвета между первым и последним положительными элементами: \n\t\t");
            Console.ForegroundColor = ConsoleColor.Red;

            for (int i = 0; i < arr.Length; i++)
            {
                if (i == iF + 1)
                    Console.ForegroundColor = ConsoleColor.Yellow;
                if(i == iL)
                    Console.ForegroundColor = ConsoleColor.Red;

                Console.Write($" {arr[i]} ");


            }//for
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write($"\n\nСумма элементов данного массива равна: {sum}\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
        }//ShowSumElems

        //предикат для метода FindIndex
        static bool Predicate(int x) { return x > 0; }

        //компаратор для сортировки
        static int ComareTo(int x, int y) { return (x == 0 && y != 0) ? -1 : (x != 0 && y == 0) ? 1 : 0; }

        //метод поиска минимального элемента массива 
        static int MinElem(int[] arr)
        {
            int minEl = int.MaxValue;

            for (int i = 0; i < arr.Length; i++)
            {
                if (minEl > arr[i]) minEl = arr[i];
            }//for

            return minEl;
        }//MinElem

        //метод вычисления суммы элементов массива в пределах
        static int SumElems(int[] arr, int iF, int iL)
        {
            int sum = 0;

            for (int i = iF + 1; i < iL; i++)
                sum += arr[i];

            return sum;
        }//SumElems


        // ----------------------------- double -----------------------
        static void ShowArrDouble(double[] arr)
        {
            Console.Write("\t\t\t\t\nПолученный массив: \n\t\t");
            Console.ForegroundColor = ConsoleColor.Red;
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($" {arr[i]:n2} ");
            }//for
            Console.Write("\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
        }//ShowArr

        static void ShowSumElems(double[] arr, double iF, double sum)
        {
            Console.Write("\t\t\t\t\nМассив с выделением цвета после первого отрицательного элемента: \n\t\t");
            Console.ForegroundColor = ConsoleColor.Red;

            for (int i = 0; i < arr.Length; i++)
            {
                if (i == iF + 1)
                    Console.ForegroundColor = ConsoleColor.Yellow;

                Console.Write($" {arr[i]:n2} ");


            }//for
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write($"\n\nСумма элементов данного массива равна: {sum:n2}\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
        }//ShowSumElems

        static void ShowArrMinDouble(double[] arr, double minEl)
        {
            Console.Write("\t\t\t\t\nМассив с выделением цвета минимального по модулю элемента: \n\t\t");
            Console.ForegroundColor = ConsoleColor.Red;

            for (int i = 0; i < arr.Length; i++)
            {
                if (Math.Abs(Math.Abs(arr[i]) - Math.Abs(minEl)) < 1E-3)
                    Console.ForegroundColor = ConsoleColor.Yellow;

                Console.Write($" {arr[i]:n2} ");

                Console.ForegroundColor = ConsoleColor.Red;
            }//for
            Console.Write("\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
        }//ShowArr

        static void FillDouble(double[] arr, double lo, double hi)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = lo + (hi - lo) * rand.NextDouble();
            }//for
        }//Fill

        static bool PredicateDouble(double x) { return x < 0; }

        static double SumElems(double[] arr, int iF)
        {
            double sum = 0;

            for (int i = iF + 1; i < arr.Length; i++)
                sum += arr[i];

            return sum;
        }//SumElems

        static double MinElemDouble(double[] arr)
        {
            double minEl = double.MaxValue;

            for (int i = 0; i < arr.Length; i++)
            {
                if (Math.Abs(minEl) > Math.Abs(arr[i])) minEl = arr[i];
            }//for

            return minEl;
        }//MinElemDouble

        #endregion

        static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // выводим верхнюю строку
        private static void ShowNavBar()
        {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст с функциональными клавишами в верхнюю строку
            WriteXY(2, 0, "F5", ConsoleColor.Red);
            WriteXY(5, 0, "Задача 1", ConsoleColor.Black);

            WriteXY(16, 0, "F6", ConsoleColor.Red);
            WriteXY(19, 0, "Задача 2", ConsoleColor.Black);

            WriteXY(30, 0, "F7", ConsoleColor.Red);
            WriteXY(33, 0, "Задача 3", ConsoleColor.Black);

            WriteXY(45, 0, "F10", ConsoleColor.Red);
            WriteXY(49, 0, "Выход", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBar

        private static void ShowText()
        {
            string text = @"
             Задача 1. Методы класса Math. Для значений, вводимых с клавиатуры
                рассчитайте значение выражений. (напоминаю, что при правильном 
                кодировании выражений их значения совпадают примерно до 10го знака 
                после запятой). Выражения взяты из учебника Павловской Т.А.

             Задача 2. Одномерный массив. В одномерном массиве, состоящем из n целых элементов:
                Заполнить массив случайными числами
                Вычислить минимальный элемент массива, вывести массив с выделением таких элементов цветом
                Вычислить сумму элементов массива, расположенных между первым и последним положительными элементами, 
                вывести массив с выделением цветом таких элементов
                Упорядочить массив так, чтобы элементы, равные нулю были в начале массива

             
             Задача 3. Одномерный массив. В одномерном массиве, состоящем из n вещественных элементов:
                Заполнить массив случайными числами
                Вычислить индекс минимального по модулю элемента массива, вывести массив с 
                выделением цветом найденного элемента
                Вычислить сумму модулей элементов массива, расположенных после первого 
                отрицательного элемента, вывести массив с выделением цветом слагаемых
                Упорядочить массив так, чтобы переместить в начало массива все элементы, 
                значение которых находится в диапазоне [a, b]. При помощи метода Array.Resize() удалить
                все элементы, не входящие в этот диапазон
   
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowText

        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.CursorVisible = false;

            // главный цикл работы приложения 
            while (true)
            {
                ShowNavBar();
                ShowText();

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                switch (key)
                {
                    // решение задачи 1 назначено на клавишу F5
                    case ConsoleKey.F5:
                        Task1();
                        break;

                    // решение задачи 1 назначено на клавишу F6
                    case ConsoleKey.F6:
                        Task2();
                        break;

                    // решение задачи 1 назначено на клавишу F7
                    case ConsoleKey.F7:
                        Task3();
                        break;

                    // выход из приложения назначен на клавишу F10
                    case ConsoleKey.F10:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Console.SetCursorPosition(0, Console.WindowHeight - 1);
                        Console.CursorVisible = true;
                        return;
                } // switch
            } // while
        }

        //Задание номер 1. Методы класса Math
        static void Task1() 
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\t\t\t\tЗадание №1. Методы класса Math. \n\n");
            string str;

            //ввод данных с клавиатуры для alpha
            Console.Write("Введите значение alpha: ");
            str = Console.ReadLine();
            double.TryParse(str, out double alpha);

            //ввод данных с клавиатуры для beta
            Console.Write("Введите значение beta: ");
            str = Console.ReadLine();
            double.TryParse(str, out double beta);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("-------------------------------------------------------------------\n");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\t\t\t\tВариант №7\n");

            //вычисления по первой формуле
            double z1 = (Math.Pow((Math.Cos(alpha) - Math.Cos(beta)), 2)) - 
                        (Math.Pow((Math.Sin(alpha) - Math.Sin(beta)), 2));

            //вычисления по второй формуле
            double z2 = -4 * Math.Pow(Math.Sin((alpha - beta) / 2), 2) * Math.Cos(alpha + beta);

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\nРезультаты вычислений: \nz1 = {z1:n10}\nz2 = {z2:n10}\n");

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("-------------------------------------------------------------------\n");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\t\t\t\tВариант №11\n");

            //вычисления по первой формуле
            z1 = (1 - (2 * Math.Pow(Math.Sin(alpha), 2))) / (1 + Math.Sin(2 * alpha));
            //вычисления по второй формуле
            z2 = (1 - Math.Tan(alpha)) / (1 + Math.Tan(alpha));

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\nРезультаты вычислений: \nz1 = {z1:n10}\nz2 = {z2:n10}\n");


            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.ReadKey();
            Console.Clear();
        }//Task1

        //Задание номер 2. Одномерный массив(int)
        static void Task2() 
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\t\t\t\tЗадание №2. Одномерный массив(int)");
            Console.ForegroundColor = ConsoleColor.Cyan;

            //генерация колличества элементов в массиве
            int n = rand.Next(10, 20);
            int[] arr = new int[n];

            //заполнение массива случайными элементами
            Fill(arr, -5, 5);
            //вывод массива
            ShowArr(arr);

            //находим минимальный элемент
            int minEl = MinElem(arr);
            ShowArrMin(arr, minEl);

            //нахождение первого и последнего индекса положительного числа
            int iFirst = Array.FindIndex(arr, Predicate);
            int iLast = Array.FindLastIndex(arr, Predicate);
            //нахождение суммы
            int sum = SumElems(arr, iFirst, iLast);
            ShowSumElems(arr, iFirst, iLast, sum);

            //сортировка
            Array.Sort(arr, ComareTo);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("\n\nСортировка массива, нули в начало:");
            Console.ForegroundColor = ConsoleColor.Cyan;
            //вывод массива
            ShowArr(arr);
            Console.ReadKey();
            Console.Clear();
        }//Task2

        //Задание номер 3. Одномерный массив(double)
        static void Task3()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\t\t\t\tЗадание №3. Одномерный массив(double)");
            Console.ForegroundColor = ConsoleColor.Cyan;
          
            //генерация колличества элементов в массиве
            int n = 13;
            double[] arr = new double[n];

            //заполнение массива случайными элементами
            FillDouble(arr, -5d, 5d);
            //вывод массива
            ShowArrDouble(arr);

            //находим минимальный по модулю элемент
            double minEl = MinElemDouble(arr);
            ShowArrMinDouble(arr, minEl);

            //нахождение первого индекса отрицательного числа
            int iFirst = Array.FindIndex(arr, PredicateDouble);
            //нахождение суммы
            double sum = SumElems(arr, iFirst);
            ShowSumElems(arr, iFirst, sum);

            //диапазон для задания
            double a = 3d;
            double b = 7d;

            int CompareDouble(double lhs, double rhs)
            {
                if (Math.Abs(lhs - rhs) < 0.1)
                    return 0;

                if (lhs >= a && lhs <= b
                &&
                (rhs < a || rhs > b))
                    return -1;

                return 1;
            }//CompareDouble

            //сортировка
            Array.Sort(arr, CompareDouble);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("\n\nСортировка массива:");
            Console.ForegroundColor = ConsoleColor.Cyan;
            //вывод массива
            ShowArrDouble(arr);

            int counter = 0;
            foreach (double d in arr)
                if (d >= a && d <= b)
                    counter++;

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("\n\nУдаление элементов вне диапазона:");
            Array.Resize(ref arr, counter);
            Console.ForegroundColor = ConsoleColor.Cyan;
            //вывод массива
            ShowArrDouble(arr);
            Console.ReadKey();
            Console.Clear();
        }//Task3

        //Задание номер 4

    }
}
