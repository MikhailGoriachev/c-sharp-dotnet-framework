﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathArrays
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 13.09.2021 -  Математические операции и массивы";
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.CursorVisible = false; 


            // цикл работы приложения 
            while(true)
            {
                Console.Clear();
                ShowNavBar();
                ShowText();

                //получить код клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                switch(key)
                {
                    // решение задачи 1 назначено на клавишу F5
                    case ConsoleKey.F5:
                        Task1();
                        break;
                    // решение задачи 2 назначено на клавишу F6 
                    case ConsoleKey.F6:
                        Task2();
                        break;

                    // решение задачи 3 назначено на клавишу F7
                    case ConsoleKey.F7:
                        Task3();
                        break;

                    //решение задачи 4 назначено на клавишу F7
                    case ConsoleKey.F8:
                        Task4();
                        break;
                }
            }

        }// Main

        // вывод верхней строки
        private static void ShowNavBar()
        {
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // выводим текст   в верхнюю строку
            WriteXY(2, 0, "F5", ConsoleColor.Red);
            WriteXY(5, 0, "Задача1", ConsoleColor.Black);

            WriteXY(16, 0, "F6", ConsoleColor.Red);
            WriteXY(19, 0, "Задача 2", ConsoleColor.Black);

            WriteXY(30, 0, "F7", ConsoleColor.Red);
            WriteXY(33, 0, "Задача 3", ConsoleColor.Black);

            WriteXY(45, 0, "F8", ConsoleColor.Red);
            WriteXY(49, 0, "Задача 4", ConsoleColor.Black);

            WriteXY(65, 0, "F10", ConsoleColor.Red);
            WriteXY(64, 0, "Выход", ConsoleColor.Black);

            //восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        }// ShowNavBar

        //

        private static void ShowText()
        {
            string text = @" 
            Задача 1. Методы класса Math. Для значений, вводимых с клавиатуры рассчитайте значение выражений. 
                  (напоминаю, что при правильном кодировании выражений их значения совпадают примерно до 10го знака 
                  после запятой). 
                  Выражения взяты из учебника Павловской Т.А.:

            Вариант 9.     z_1=〖(cosα-cosβ)〗^2-〖(sinα-sinβ)〗^2;     z_2=-4〖sin〗^2  (α-β)/2∙cos⁡(α+β);

            Вариант 11.    z_1=(1-2∙〖sin〗^2 α)/(1+sin2α);            z_2=(1-tgα)/(1+tgα);

            Задача 2.Одномерный массив. В одномерном массиве, состоящем из n целых элементов:
                     Заполнить массив случайными числами. Вычислить минимальный элемент массива, 
                     вывести массив с выделением таких элементов цветом.  
                     Вычислить сумму элементов массива, расположенных между первым и последним 
                     положительными элементами, вывести массив с выделением цветом таких элементов. 
                     Упорядочить массив так, чтобы элементы, равные нулю были в начале массива. 

            Задача 3.Одномерный массив. В одномерном массиве, состоящем из n вещественных элементов:
                     Заполнить массив случайными числами. Вычислить индекс минимального по модулю элемента массива, 
                     вывести массив с выделением цветом найденного элемента. Вычислить сумму модулей элементов 
                     массива, расположенных после первого отрицательного элемента, вывести массив с выделением цветом 
                     слагаемых. Упорядочить массив так, чтобы переместить в начало массива все элементы, значение 
                     которых находится в диапазоне [a, b]. При помощи метода Array.Resize() удалить все элементы, 
                     не входящие в этот диапазон.

            Задача 4.Прямоугольный массив. В матрице целых чисел размера M x N:
                     Заполнить матрицу случайными числами. Поменять местами столбец с заданным номером 
                     и первый из столбцов, содержащих только отрицательные элементы. Если требуемых столбцов 
                     нет – вывести сообщение, не менять матрицу Поменять местами строки матрицы так, чтобы 
                     первые элементы матрицы были упорядочены по убыванию ";
            WriteXY(0, 2, text, ConsoleColor.Gray); 
        }

        static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текцщий цвет консоли и установить заданнный 
            ConsoleColor oldcolor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            //восстановить цвет консоли
            Console.ForegroundColor = oldcolor;

        }

        private static void ShowTextTask1()
        {
            string text = @" 
                Задача 1. Методы класса Math. Для значений, вводимых с клавиатуры рассчитайте значение выражений. 
                  (напоминаю, что при правильном кодировании выражений их значения совпадают примерно до 10го знака 
                  после запятой). 
                  Выражения взяты из учебника Павловской Т.А.:

            Вариант 9.  z_1=〖(cosα-cosβ)〗^2-〖(sinα-sinβ)〗^2;   z_2=-4〖sin〗^2  (α-β)/2∙cos⁡(α+β);

            Вариант 11. z_1=(1-2∙〖sin〗^2 α)/(1+sin2α);  z_2=(1-tgα)/(1+tgα);
                 ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask1

        private static void ShowNavTask1()
        {
            //сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            //Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 1", ConsoleColor.Red);
            WriteXY(11, 0, "Методы класса Math, 0 - для выходы", ConsoleColor.Black);

            //восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        }

        private static void Task1()
        {

            // оформление экрана вывода
            Console.Clear();
            ShowNavTask1();
            ShowTextTask1();

            Console.WriteLine("\nРешение Варианта 9");
            double a, b; 
            Console.WriteLine("\nВведите значение угла в радианах через Enter от 0,017 до 6,28319");
            a = double.Parse(Console.ReadLine());
            b = double.Parse(Console.ReadLine());

            double z1 = Math.Pow((Math.Cos(a) - Math.Cos(b)), 2) - Math.Pow((Math.Sin(a) - Math.Sin(b)), 2);

            double z2 = -4 * Math.Pow(Math.Sin((a - b) / 2),2) * Math.Cos(a + b);

            Console.WriteLine($"\n Значение z1 : {z1} \n Значение z2 : {z2} ");
            

            Console.WriteLine("\nРешение Варианта 11");
            double d, c;
            Console.WriteLine("\nВведите значение угла в радианах через Enter от 0,017 до 6,28319");
            d = double.Parse(Console.ReadLine());
            c = double.Parse(Console.ReadLine());

            double Z1 = (1-2*(Math.Pow(Math.Sin(d),2))) /(1+Math.Sin(2*d));
            double Z2 = (1 - Math.Tan(d)) / (1 + Math.Tan(c));

            Console.WriteLine($"\n Значение z1 : {Z1} \n Значение z2 : {Z2} ");
            Console.ReadKey();

        }

        private static void ShowTextTask2()
        {
            string text = @"
              Задача 2   Одномерный массив. В одномерном массиве, состоящем из n целых элементов:
                 ";

            WriteXY(0, 3, text, ConsoleColor.Gray);
        }

        private static void ShowNavTask2()
        {

            //сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            //Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 2", ConsoleColor.Red);
            WriteXY(11, 0, "Одномерный массив", ConsoleColor.Black);

            //восстановить цвет фона
            Console.BackgroundColor = oldBkColor;

        }

        private static void Task2()
        {
            // оформление экрана вывода
            Console.Clear();
            ShowNavTask2();
            ShowTextTask2();

            // заполнение массива случайными числами с выводом в консоль 

            const int low = -5;
            const int high = 5;
            const int size = 10;
            int[] arr = new int[size]; // создаем массив
            Fill(arr, low, high); // заполняем его 
            Console.WriteLine("\nЗаполнить массив случайными числами");
            Console.WriteLine("\n");
            foreach(var item in arr ) {
                Console.Write($"{item,7} "); // выводим в консоль
            }
            // находим минимальные элементы 
            Console.WriteLine("\n");
            Console.WriteLine("\nМинимальные элементы в массиве");
            int min = FindMin(arr); 
            // красим в красный цвет
            foreach (var item in arr)
            {
                if (item == min) {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
                Console.Write($"{item, 7}  ");
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            // находим  сумму между первым и последним положительными элементами 
            Console.WriteLine("\n");
            int first = FindFirstPositive(arr);
            int last = FindLastPositive(arr);
            int sum = FindSum(arr, first, last);
            Console.WriteLine($"\nСумма между первым и послежним положительным элементом в массиве {sum}");
            for(int i =0; i< arr.Length; ++i)
            {
                if (i > first && i < last)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
                    Console.Write($"{arr[i],7}");
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            Console.WriteLine($"\nСортировка нулевых элементов вперед");
            int ComparatorZero(int x, int y) =>
                x == 0 && y != 0 ? -1 : x != 0 && y == 0 ? 1 : 0;
            Array.Sort(arr, ComparatorZero);
            foreach(var item in arr){ Console.Write($"{item,7}");}

            Console.ReadLine();

        }

        private static void ShowTextTask3()
        {
            string text = @"
              Задача 3   Одномерный массив. В одномерном массиве, состоящем из n вещественных элементов:
                 ";

            WriteXY(0, 3, text, ConsoleColor.Gray);
        }

        private static void ShowNavTask3()
        {

            //сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            //Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 3", ConsoleColor.Red);
            WriteXY(11, 0, "Одномерный массив", ConsoleColor.Black);

            //восстановить цвет фона
            Console.BackgroundColor = oldBkColor;

        }

        private static void Task3()
        {
            // оформление экрана вывода
            Console.Clear();
            ShowNavTask3();
            ShowTextTask3();


            const double low = -5.5;
            const double high = 5.5;
            const int size = 12;

            // создание массива и вывод его в консоль
            double[] arr = new double[size];
            // заполнение массива
            FillDbl(arr, low, high);
            Console.WriteLine("\nЗаполнить массив случайными числами");
            Console.WriteLine("\n");
            
            foreach (var item in arr)
            {
                Console.Write($"{item,7:n2} "); // выводим в консоль
            }
            //Нахождение индекса минимального 
            int index = FindMinAbs(arr);
            
             //красим в красный цвет и выводим
            Console.WriteLine("\n");
            Console.WriteLine($"\nИндекс минимального по модулю значения равен {index}  ");
            for(int i=0; i< arr.Length; ++i)
            {
                if(i == index)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
                Console.Write($"{arr[i],7:n2} ");
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            // сумма модулей после первого отрицательного
            int indexnegative = FindFirstNegative(arr);
            double sum = FindSumAbs(arr, index);
            Console.WriteLine("\n");
            Console.WriteLine($"\nИндекс первого отрицательного {indexnegative} ");
            Console.WriteLine($"\nСумма модулей после первого отрицательного равна :{sum, 1:n2}");

            // упорядочивание и удаление с попощью методу Array.Resize() в диапазоне [a, b]
            // генерация значений [a,b];
            int a = 3;
            int b = 5;
            Console.WriteLine("\n");
            Console.Write($"Диапазон от {a} до {b} "); 

            //компаратор для заданного диапазона
            int CompareDiapasone(double x, double y)
            {
                if (Math.Abs(x - y) < 0.1) return 0;
                if (x >= a && x <= b && (y < a || y > b)) return -1;
                return 1;
            }
                

            Array.Sort(arr, CompareDiapasone);
            Show($"\nСортировка в диапазоне от {a} до {b}\n", arr);

            Console.ReadLine();
        }

        private static void Task4()
        {
            // оформление экрана вывода
            Console.Clear();
            ShowNavTask4();
            ShowTextTask4();

            // создаем и заполняем матрицу случайными целыми числами
            Console.WriteLine("\n Заполняем матрицу случайными числами\n");
            

            const int m = 5;
            const int n = 10;
            int[,] matrix = new int [m, n]; 
            const int low = -5;
            const int high = 15;
            FillMatrix(matrix, low, high);
            ShowMatrix("Матрица со случаными значениями", matrix); 


            Console.ReadLine();

        }

        private static void ShowTextTask4()
        {
            string text = @"
              Задача 4   Прямоугольный массив. В матрице целых чисел размер M x N:
                 ";

            WriteXY(0, 3, text, ConsoleColor.Gray);
        }

        private static void ShowNavTask4()
        {

            //сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            //Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 4", ConsoleColor.Red);
            WriteXY(11, 0, "Прямоугольный массив", ConsoleColor.Black);

            //восстановить цвет фона
            Console.BackgroundColor = oldBkColor;

        }

        private static void Fill (int[] arr, int low, int high)
        {
            for(int i =0; i< arr.Length; ++i)
            {
                arr[i] = rand.Next(low, high);  
            }
        }

        private static void FillDbl(double[] arr, double lo, double hi)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = lo + (hi - lo) * rand.NextDouble();
            } // for i
        } // Fill
        static Random rand = new Random();

        private static int FindMin(int[] arr)
        {
            int min = int.MaxValue; 
            for(int i =0; i< arr.Length; ++i)
            {
                if(arr[i] < min)
                {
                    min = arr[i];
                    
                }
                
            }

            return min;
        }

        private static int FindMinAbs(double[] arr)
        {
            double minabs = double.MaxValue;
            int minindex = 0;
            for(int i =0; i< arr.Length; ++i)
            {
                double current =Math.Abs(arr[i]);
                if(current < minabs)
                {
                    minindex = i;
                    minabs = current;
                }
            }
            return minindex;
        }

        private static double FindSumAbs(double[] arr, int index)
        {
            double sum = 0; 
            for(int i =index; i<arr.Length;++i)
            {
                sum += arr[i]; 
            }
            return sum;
        }

        private static int FindFirstNegative(double[] arr)
        {
            int index = 0; 
            for(int i =0; i< arr.Length; ++i)
            {
                if(arr[i] <0)
                {
                    index = i;
                    break;
                }
            }
            return index;
        }

        private static int FindFirstPositive(int [] arr)
        {
            int pos =0;
            for(int i =0; i< arr.Length; ++i)
            {
                if(arr[i] > 0)
                {
                    pos = i;
                    break;
                }
            }

            return pos; 
        }

        private static int FindLastPositive(int [] arr)
        {
            int pos = 0; 
            for(int i =0; i< arr.Length; ++i)
            {
                if(arr[i]> 0)
                {
                    pos = i;
                }
            }
            return pos;
        }

        private static int FindSum(int [] arr, int first, int last)
        {
            int sum = 0;
            for(int i =first+1; i< last; ++i)
            {
                sum += arr[i];
            }
            return sum; 
        }

        private static void Show(string title, double[] arr)
        {
            Console.WriteLine(title);

            foreach(double item in arr)
            {
                Console.Write($"{item,7:n2}");
            }
        }

        private static void FillMatrix(int [,] mrt, int low, int high)
        {
            int rows = mrt.GetLength(0);
            int cols = mrt.GetLength(1);

            for (int i = 0; i < rows; ++i)
                for (int j = 0; j < cols; ++j)
                    mrt[i, j] = rand.Next(low, high + 1);

        }

        private static void ShowMatrix(string title, int[,] matr)
        {
            Console.WriteLine(title);

            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);

            for (int i = 0; i < rows; ++i)
            {
                for (int j = 0; j < cols; ++j)
                    Console.Write("{0, 10}", matr[i, j]);
                Console.WriteLine();
            }
        }

    }// class Program
}
