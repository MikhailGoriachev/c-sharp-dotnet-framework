﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Задача 1. Методы класса Math.
 * Для значений, вводимых с клавиатуры, рассчитайте значение выражений (при
 * правильном кодировании выражений их значения совпадают примерно до 10го
 * знака после запятой). Выражения взяты из учебника Павловской Т.А.:
 *     Вариант 9.
 *     z_1 = (cos(a) - cos(b))^2 - (sin(a) - sin(b))^2;  
 *     z_2 = -4*sin^2((a - b/2))*cos⁡(a + b));
 *     
 *     Вариант 11.
 *     z_1 = (1 - 2*sin^2(a)) / (1 + sin(2a));          
 *     z_2 = (1 - tg(a)) / (1 + tg(a));
 *
 * Задача 2. Одномерный массив.
 * В одномерном массиве, состоящем из n целых элементов:
 *     • Заполнить массив случайными числами
 *     • Вычислить минимальный элемент массива, вывести массив с выделением
 *       таких элементов цветом
 *     • Вычислить сумму элементов массива, расположенных между первым и
 *       последним положительными элементами, вывести массив с выделением
 *       цветом таких элементов
 *     • Упорядочить массив так, чтобы элементы, равные нулю были в начале
 *       массива
 *
 * Задача 3. Одномерный массив.
 * В одномерном массиве, состоящем из n вещественных элементов:
 * 	   • Заполнить массив случайными числами
 * 	   • Вычислить индекс минимального по модулю элемента массива, вывести
 *       массив с выделением цветом найденного элемента
 * 	   • Вычислить сумму модулей элементов массива, расположенных после первого
 *       отрицательного элемента, вывести массив с выделением цветом слагаемых
 * 	   • Упорядочить массив так, чтобы переместить в начало массива все
 *       элементы, значение которых находится в диапазоне [a, b]. При помощи
 *       метода Array.Resize() удалить все элементы, не входящие в этот
 *       диапазон
 *
 * Задача 4. Прямоугольный массив.
 * В матрице целых чисел размера M x N:
 * 	   • Заполнить матрицу случайными числами
 * 	   • Поменять местами столбец с заданным номером и первый из столбцов,
 *       содержащих только отрицательные элементы. Если требуемых столбцов
 *       нет – вывести сообщение, не менять матрицу
 *     • Поменять местами строки матрицы так, чтобы первые элементы матрицы
 *       были упорядочены по убыванию
 * 
 */

namespace MathArray
{
    class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 13.09.2021 - методы и константы класса Math, массивы - класс Array";
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.CursorVisible = false;

            // главный цикл работы приложения 
            while (true) {
                ShowNavBar();
                ShowText();

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                switch (key) {
                    // решение задачи 1 назначено на клавишу F5
                    case ConsoleKey.F5:
                        Task1();
                        break;

                    // решение задачи 2 назначено на клавишу F6
                    case ConsoleKey.F6:
                        Task2();
                        break;

                    // решение задачи 3 назначено на клавишу F7
                    case ConsoleKey.F7:
                        Task3();
                        break;

                    // решение задачи 4 назначено на клавишу F8
                    case ConsoleKey.F8:
                        Task4();
                        break;

                    // выход из приложения назначен на клавишу F10
                    case ConsoleKey.F10:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Console.SetCursorPosition(0, Console.WindowHeight - 1);
                        Console.CursorVisible = true;
                        return;
                } // switch
            } // while
        } // Main


        #region Вспомогательные методы
        // формирует и выводит верхнюю строку окна консоли для метода Main
        private static void ShowNavBar() {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string[] hotKeys = {"F5",       "F6",       "F7",       "F8",       "F10"};
            string[] descs   = {"Задача 1", "Задача 2", "Задача 3", "Задача 4", "Выход" };

            // при выводе немного используем методы класса strring :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, " ".PadRight(Console.WindowWidth), Console.ForegroundColor);

            // Выводим текст с функциональными клавишами в верхнюю строку
            for (int i = 0, x = 2; i < hotKeys.Length; i++) {
                WriteXY(x, 0, hotKeys[i], ConsoleColor.Red);
                
                // позиция вывода описания - к позиции аваод хот-кея добавить
                // длину строки-хоткея и учесть пробел
                int descPos = x + hotKeys[i].Length + 1;
                WriteXY(descPos, 0, descs[i], ConsoleColor.Black);

                // вычисление следующей позиции вывода:
                // к позиции вывода описания добавить ее длину и промежуток до следующего вывода
                x = descPos + descs[i].Length + 3;
            } // for i

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBar

        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line) {
            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;
            ConsoleColor oldFgColor = Console.ForegroundColor;

            // при выводе немного используем методы класса strring :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
            Console.ForegroundColor = oldFgColor;
        } // ShowNavBarTask


        // вывод текста задания в консоль
        private static void ShowText(int taskNumber = -1) {
            string[] text = {@"
             Задача 1. Методы класса Math.
             Для значений, вводимых с клавиатуры, рассчитайте значение выражений

             Вариант 9.
             z_1 = (cos(a) - cos(b))^2 - (sin(a) - sin(b))^2;  
             z_2 = -4*sin^2((a - b/2))*cos⁡(a + b));

             Вариант 11.
             z_1 = (1 - 2*sin^2(a)) / (1 + sin(2a));          
             z_2 = (1 - tg(a)) / (1 + tg(a));
             ",
             @"
             Задача 2. Одномерный массив.
             Заполнить одномерный массив, состоящий из n целых элементов случайными 
             числами, выполнить обработки, упорядочить массив по правилу ""нули впереди""
             ",
             @"
             Задача 3. Одномерный массив.
             Заполнить одномерный массив, состоящем из n вещественных элементов случайными
             числами, выполнить обработки, упорядочить массив по правилу ""числа из [a, b]
             в конец массива"", удалить такие числа при помощи Array.Resize()
             ",
             @"
             Задача 4. Прямоугольный массив.
             Заполнить матрицу целых чисел размера M x N случайными числами, поменять 
             местами столбцы по заданному правилу, переставить строки так, чтобы их  
             первые элементы были упорядочены по убыванию
            "};

            WriteXY(0, 3, taskNumber < 1?string.Join("\n", text):text[taskNumber-1], ConsoleColor.Gray);
        } // ShowText

        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // вывод строки приглашения и ввод вещественного числа
        public static double InputDouble(int x, int y, string prompt) {
            // сохранить цвета консоли
            ConsoleColor bgColor = Console.BackgroundColor; 
            ConsoleColor fgColor = Console.ForegroundColor;
            bool result;
            double value = 0;

            // отобразить курсор для удобства ввода 
            Console.CursorVisible = true;

            do {
                // вывод подсказки
                Console.BackgroundColor = bgColor;
                WriteXY(x, y, prompt, fgColor);

                // вывод имитации строки ввода 
                Console.BackgroundColor = ConsoleColor.Cyan;
                WriteXY(x + prompt.Length + 1, y, " ".PadRight(20), Console.ForegroundColor);

                // собственно ввод
                Console.ForegroundColor = ConsoleColor.Black;
                Console.SetCursorPosition(x + prompt.Length + 2, y);
                result = double.TryParse(Console.ReadLine(), out value);
            } while (!result);

            // восстановить цвет консоли, спрятать текстовый курсор
            Console.ForegroundColor = fgColor;
            Console.BackgroundColor = bgColor;
            Console.CursorVisible = false;
            return value;
        } // InputDouble
        #endregion


        #region Одномерный массив
        // заполнение массив случайными числами
        private static Random _rand = new Random();
        private static void Fill(double[] arr, double lo, double hi) {
            for (int i = 0; i < arr.Length; i++) {
                arr[i] = lo + (hi - lo) * _rand.NextDouble();
            } // for i
        } // Fill

        private static void Fill(int[] arr, int lo, int hi) {
            for (int i = 0; i < arr.Length; i++) {
                arr[i] = _rand.Next(lo, hi+1);
            } // for i
        } // Fill

        // вывод массива double в консоль
        private static void Show(string title, double[] arr) {
            Console.Write(title + "\t");
            for (int i = 0; i < arr.Length; ++i) {
                Console.Write($"{arr[i], 8:f2}   ");
                if ((i + 1) % 10 == 0) Console.Write("\n\t");
            } // foreach
            Console.WriteLine();
        } // Show

        // вывод массива int в консоль
        private static void Show(string title, int[] arr) {
            Console.Write(title + "\t");
            for (int i = 0; i < arr.Length; ++i) {
                Console.Write($"{arr[i], 8:f0}   ");
                if ((i + 1) % 10 == 0) Console.Write("\n\t");
            } // foreach
            Console.WriteLine();
        } // Show

        // Поиск минимального элемента в массиве - классика, но в C# избыточная...
        private static int Min(int[] data) {
            int min = data[0];
            foreach (var datum in data) {
                if (datum < min) min = datum;
            } // foreach datum

            return min;
        } // Min

        // Поиск индекса минимального по модулю элемента в массиве - классика
        private static int MinAbsIndex(double[] data) {
            double minAbs = Math.Abs(data[0]);
            int imin = 0;

            for (int i = 1; i < data.Length; ++i) {
                var temp = Math.Abs(data[i]);
                if (temp < minAbs) {
                    minAbs = temp;
                    imin = i;
                } // if
            } // foreach datum

            return imin;
        } // MinAbsIndex

        // Вывод массива int с выделением цветом элементов с заданным значением
        private static void Show(string title, int[] arr, int value) {
            Console.Write(title + "\t");
            for (int i = 0; i < arr.Length; ++i) {
                // задать цвет элементу с заданным значением
                if (arr[i] == value) {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.Black;
                } // if

                Console.Write($"{arr[i], 8:f0}  ");
                
                // восстановить цвет
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write(" ");
                if ((i + 1) % 10 == 0) Console.Write("\n\t");
            } // foreach
            Console.WriteLine();
        } // Show

        // Вывод массива double с выделением цветом элементов с заданным значением
        private static void Show(string title, double[] arr, double value) {
            Console.Write(title + "\t");
            for (int i = 0; i < arr.Length; ++i) {
                // задать цвет элементу с заданным значением
                if (Math.Abs(arr[i] - value) < 1e-6) {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                } // if

                Console.Write($"{arr[i],8:f2}  ");

                // восстановить цвет
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write(" ");
                if ((i + 1) % 10 == 0) Console.Write("\n\t");
            } // foreach
            Console.WriteLine();
        } // Show

        // Вывод массива с выделением цветом элементов между заданными индексами
        private static void Show(string title, int[] arr, int firstIndex, int lastIndex) {
            Console.Write(title + "\t");
            for (int i = 0; i < arr.Length; ++i) {
                // задать цвет элементу по заданному правилу
                if (i == firstIndex) {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                } else if (i == lastIndex) {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                } else if (firstIndex < i && i < lastIndex) {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                } // if

                Console.Write($"{arr[i],8:f0}  ");

                // восстановить цвет
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write(" ");
                if ((i + 1) % 10 == 0) Console.Write("\n\t");
            } // foreach
            Console.WriteLine();
        } // Show

        // Вывод массива double с выделением цветом элементов после элемента с заданным индексом
        private static void Show(string title, double[] arr, int index) {
            Console.Write(title + "\t");
            for (int i = 0; i < arr.Length; ++i) {
                // задать цвет элементу по заданному правилу
                if (i > index) {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                } // if

                Console.Write($"{arr[i],8:f2}  ");

                // восстановить цвет
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write(" ");
                if ((i + 1) % 10 == 0) Console.Write("\n\t");
            } // foreach
            Console.WriteLine();
        } // Show

        // Вывод массива double с выделением цветом элементов принадлежащих интервалу [lo, hi]
        private static void Show(string title, double[] arr, double lo, double hi) {
            Console.Write(title + "\t");
            for (int i = 0; i < arr.Length; ++i) {
                // задать цвет элементу по заданному правилу
                if (lo <= arr[i] && arr[i] <= hi) {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                } // if

                Console.Write($"{arr[i],8:f2}  ");

                // восстановить цвет
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write(" ");
                if ((i + 1) % 10 == 0) Console.Write("\n\t");
            } // foreach
            Console.WriteLine();
        } // Show
        #endregion


        #region Прямоугольный массив

        // заполнение прямоугольного массива
        private static void Fill(int[,] matr, int lo, int hi) {
            // matr.GetLength(0) - количество строк
            // matr.GetLength(1) - количество столбцов
            int rows = matr.GetLength(0); // строки
            int cols = matr.GetLength(1); // столбцы
           
            for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                matr[i, j] = _rand.Next(lo, hi+1);
        } // Fill


        // вывод прямоугольного массива, выделяя цветом столбцы col1, col2
        private static void Show(string title, int[,] matr, int col1, int col2) {
            // Вывод заголовка
            Console.Write(title + "\t");

            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);

            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    if (j == col1 || j == col2) {
                        Console.ForegroundColor = ConsoleColor.DarkBlue;
                        Console.BackgroundColor = ConsoleColor.Gray;
                    } // if

                    Console.Write($"{matr[i, j], 8}  ");
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Write(" ");
                } // for j

                Console.Write("\n\t");
            } // for i
        } // Show

                
        // вывод прямоугольного массива с выделением цветом первого элемента каждой строки
        private static void Show(string title, int[,] matr) {
            // Вывод заголовка
            Console.Write(title + "\t");

            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);

            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    // первый элемент каждой строки выделим цветом
                    if (j == 0) {
                        Console.ForegroundColor = ConsoleColor.DarkBlue;
                        Console.BackgroundColor = ConsoleColor.Gray;
                    } // if

                    Console.Write($"{matr[i, j],8}  ");

                    // отключение цвета - только для первого элемента каждой строки
                    if (j == 0) {
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.BackgroundColor = ConsoleColor.DarkGray;
                    } // if
                    Console.Write(" ");
                } // for j

                Console.Write("\n\t");
            } // for i
        } // Show

        // возвращает индекс первого столбца прямоугольного массива matrix,
        // содержащего только отрицательные элементы 
        private static int ColNegativesOnly(int[,] matrix) {
            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);
            int col = -1;

            // перебираем матрицу по столбцам
            for (int j = 0; j < cols; j++) {
                col = j;  // предполагаем в данном столбце все элементы отрицательные
                for (int i = 0; i < rows; i++) {
                    if (matrix[i, j] >= 0) {
                        col = -1;
                        break;
                    } // if
                } // for j

                // нашли и тут же вышли из цикла - нам нужен первый столбец
                if (col >= 0) break;
            } // for i

            return col;
        } // ColNegativesOnly

        // меняет местами столбцы col1, col2 - если столбцы указаны 
        // некорректно, ничего не делает, просто возвращает управление
        private static void SwapCols(int[,] matrix, int col1, int col2) {
            int cols = matrix.GetLength(1);
            if (col1 < 0 || col1 >= cols || col2 < 0 || col2 >= cols) return;

            int rows = matrix.GetLength(0);
            for (int i = 0; i < rows; i++) {
                // (matrix[i, col1], matrix[i, col2]) = (matrix[i, col2], matrix[i, col1]);
                int t = matrix[i, col1];
                matrix[i, col1] = matrix[i, col2];
                matrix[i, col2] = t;
            } // for i
        } // SwapCols

        // поменять местами строки row1 и row2 
        private static void SwapRows(int[,] matrix, int row1, int row2) {
            int rows = matrix.GetLength(0);
            if (row1 < 0 || row1 >= rows || row2 < 0 || row2 >= rows) return;

            int cols = matrix.GetLength(1);
            for (int j = 0; j < cols; j++) {
                // (matrix[row1, j], matrix[row2, j]) = (matrix[row2, j], matrix[row1, j]);
                int t = matrix[row1, j];
                matrix[row1, j] = matrix[row2, j];
                matrix[row2, j] = t;
            } // for i
        } // SwapCols

        // Поменять местами строки матрицы так, чтобы первые элементы матрицы были
        // упорядочены по убыванию 
        public static void SortRows(int[,] matrix) {
            int rows = matrix.GetLength(0);
            for (int i = 0; i < rows; i++) {
                for (int k = 0; k < rows - 1; k++) { 
                    if (matrix[k, 0] < matrix[k + 1, 0])
                        SwapRows(matrix, k, k + 1);
                } // for k
            } // for i
        } // SortRows

        #endregion


        #region Task1 - решение задачи 1
        /*
         * Задача 1. Методы класса Math.
         * Для значений, вводимых с клавиатуры, рассчитайте значение выражений (при
         * правильном кодировании выражений их значения совпадают примерно до 10го
         * знака после запятой). Выражения взяты из учебника Павловской Т.А.:
         *     Вариант 9.
         *     z_1 = (cos(a) - cos(b))^2 - (sin(a) - sin(b))^2;  
         *     z_2 = -4*sin^2((a - b/2))*cos⁡(a + b));
         *     
         *     Вариант 11.
         *     z_1 = (1 - 2*sin^2(a)) / (1 + sin(2a));          
         *     z_2 = (1 - tg(a)) / (1 + tg(a));
         */
        public static void Task1() {
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 1. Расчет выражений с использованием класса Math");
            ShowText(1);

            // Ввод исходных данных для расчета
            double a = InputDouble(12, 16, "Введите значение a: ");
            double b = InputDouble(12, 16, "Введите значение b: ");

            // Расчет и вывод результатов
            Console.SetCursorPosition(4, 16);
            Console.WriteLine(
                "\t    ┌────────┬─────────────────┬─────────────────┐\n" +
                "\t    │ Вариант│        9        │        11       │\n" +
                "\t    ├────────┼─────────────────┼─────────────────┤\n" +
                $"\t    │    a   │ {a, 15:f10} │ {a, 15:f10} │\n" +
                $"\t    │    b   │ {b, 15:f10} │                 │");
            
            // расчет по варианту 9
            double z1a = Math.Pow(Math.Cos(a) - Math.Cos(b), 2) - Math.Pow(Math.Sin(a) - Math.Sin(b), 2);
            double z2a = -4d * Math.Pow(Math.Sin((a - b) / 2d), 2)*Math.Cos(a + b);
            
            // расчет по варианту 11
            double z1b = (1d - 2d*Math.Pow(Math.Sin(a), 2)) / (1 + Math.Sin(2d*a));
            double z2b = (1d - Math.Tan(a)) / (1d + Math.Tan(a));
            
            Console.Write($"\t    │   z1   │ {z1a,15:f10} │ {z1b,15:f10} │\n");
            Console.Write($"\t    │   z2   │ {z2a,15:f10} │ {z2b,15:f10} │\n");

            Console.WriteLine("\t    └────────┴─────────────────┴─────────────────┘");

            // ожидать нажатия любой клавиши, не отображать нажатую клавишу
            // в окне консоли
            WriteXY(4, Console.WindowHeight-1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
            Console.ReadKey(true);
            Console.Clear();
        } // Task1
        #endregion


        #region Task2 - решение задачи 2
        /*
         * Задача 2. Одномерный массив.
         * В одномерном массиве, состоящем из n целых элементов:
         *     • Заполнить массив случайными числами
         *     • Вычислить минимальный элемент массива, вывести массив с выделением
         *       таких элементов цветом
         *     • Вычислить сумму элементов массива, расположенных между первым и
         *       последним положительными элементами, вывести массив с выделением
         *       цветом таких элементов
         *     • Упорядочить массив так, чтобы элементы, равные нулю были в начале
         *       массива
         */
        public static void Task2() {
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 2. Обработка одномерного целочисленного массива");
            ShowText(2);

            int n = _rand.Next(8, 16);
            int[] data = new int[n];

            // Заполнить массив случайными числами
            Fill(data, -5, 5);
            Show("\n\n\t    Массив для обработки:\n", data);

            // Вычислить минимальный элемент массива, вывести массив с выделением
            // таких элементов цветом
            int min = Min(data);
            // int min = data.Min();   // с использованием расширяющего метода
            Show("\n\n\t    В массиве цветом выделены минимальные элементы:\n", data, min);

            // Вычислить сумму элементов массива, расположенных между первым и
            // последним положительными элементами, вывести массив с выделением
            // цветом таких элементов
            bool IsPositive(int datum) => datum >= 0;
            int iFirstPositive = Array.FindIndex(data, IsPositive);
            int iLastPositive = Array.FindLastIndex(data, IsPositive);
            int sum = 0;
            for (int i = iFirstPositive+1; i < iLastPositive; i++) {
                sum += data[i];
            } // for i

            Console.Write("\n\t    Сумма элементов масссива, расположенных между первым и\n" +
                              "\t    последним положительными элементами: ");
            if (iFirstPositive < 0 || iLastPositive < 0)
                Console.WriteLine("\n\t    В массиве меньше двух положительных элементов - расчет невозможен");
            else 
                Show($"{sum}\n", data, iFirstPositive, iLastPositive);

            // Упорядочить массив так, чтобы элементы, равные нулю были в начале массива
            int ZeroFirstComparator(int x, int y) =>
                x == 0 && y != 0 ? -1 : x != 0 && y == 0 ? 1 : 0;
            Array.Sort(data, ZeroFirstComparator);
            Show("\n\n\t    Массив упорядочен по правилу \"Нули вперед\":\n", data, 0);

            // ожидать нажатия любой клавиши, не отображать нажатую клавишу
            // в окне консоли
            WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
            Console.ReadKey(true);
            Console.Clear();
        } // Task2
        #endregion


        #region Task3 - решение задачи 3
        /*
        * Задача 3. Одномерный массив.
        * В одномерном массиве, состоящем из n вещественных элементов:
        *     • Заполнить массив случайными числами
        *     • Вычислить индекс минимального по модулю элемента массива, вывести
        *       массив с выделением цветом найденного элемента
        *     • Вычислить сумму модулей элементов массива, расположенных после первого
        *       отрицательного элемента, вывести массив с выделением цветом слагаемых
        *     • Упорядочить массив так, чтобы переместить в начало массива все
        *       элементы, значение которых находится в диапазоне [a, b]. При помощи
        *       метода Array.Resize() удалить все элементы, не входящие в этот
        *       диапазон
         */
        public static void Task3() {
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 3. Обработка одномерного вещественного массива");
            ShowText(3);

            int n = _rand.Next(8, 16);
            double[] data = new double[n];

            // Заполнить массив случайными числами
            Fill(data, -5d, 5d);
            Show("\n\n\t    Массив для обработки:\n", data);

            // Вычислить индекс минимального по модулю элемента массива, вывести
            // массив с выделением цветом найденного элемента
            int minAbsIndex = MinAbsIndex(data);
            // int min = data.Min(a => Math.Abs(a));   // с использованием расширяющего метода
            Show("\n\n\t    В массиве цветом выделены минимальные по модулю элементы:\n", data, 
                data[minAbsIndex]);

            // Вычислить сумму модулей элементов массива, расположенных после первого
            // отрицательного элемента, вывести массив с выделением цветом слагаемых
            bool IsNegative(double datum) => datum < 0;
            int iFirstNegative = Array.FindIndex(data, IsNegative);
            double sum = 0;

            Console.Write("\n\t    Сумма модулей элементов масссива, расположенных после \n" +
                          "\t    первого отрицательного элемента: ");
            if (iFirstNegative >= 0) {
                for (int i = iFirstNegative + 1; i < data.Length; i++) {
                    sum += Math.Abs(data[i]);
                } // for i
                Show($"{sum:f2}\n", data, iFirstNegative);
            } else 
                Console.WriteLine("\n\t    В массиве нет отрицательных элементов - расчет невозможен");
            // if

            // Упорядочить массив так, чтобы переместить в начало массива все
            // элементы, значение которых находится в диапазоне [a, b].
            double a = -3d, b = 2d;
            bool InRange(double x) => a <= x && x <= b;   // проверка принадлежности интервалу [a, b]
            int RangeComparator(double x, double y) =>
                InRange(x) && !InRange(y) ? -1 : !InRange(x) && InRange(y) ? 1 : 0;
            Array.Sort(data, RangeComparator);
            Show($"\n\n\t    Массив упорядочен по правилу \"Элементы со значениями [{a}, {b}] в начало массива\":\n", 
                data, a, b);

            // для удаления - перевернем массив, разместив все удаляемые элементы в конце массива
            Array.Reverse(data);

            // вычисление нового размера массива 
            int newSize = data.Length - Array.FindAll(data, InRange).Length;

            // собственно удаление - сокращение размера массива
            Array.Resize(ref data, newSize);

            // перевернем массив в исходное состояние
            Array.Reverse(data);

            // и покажем окончательный вариант массива
            Show($"\n\n\t    Из массива удалены элементы со значениями [{a}, {b}]:\n",
                data, a, b);

            // ожидать нажатия любой клавиши, не отображать нажатую клавишу
            // в окне консоли
            WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
            Console.ReadKey(true);
            Console.Clear();
        } // Task3
        #endregion


        #region Task4 - решение задачи 4
        /*
         * Задача 4. Прямоугольный массив.
         * В матрице целых чисел размера M x N:
         * 	   • Заполнить матрицу случайными числами
         * 	   • Поменять местами столбец с заданным номером и первый из столбцов,
         *       содержащих только отрицательные элементы. Если требуемых столбцов
         *       нет – вывести сообщение, не менять матрицу
         *     • Поменять местами строки матрицы так, чтобы первые элементы матрицы
         *       были упорядочены по убыванию
         */
        public static void Task4() {
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 4. Обработка прямоугольного целочисленного массива");
            ShowText(4);

            int m = 5, n = 7;
            int[,] matrix = new int[m, n];

            Fill(matrix, -10, 10);

            #region только для отладки
            // формирование столбца с отрицательными элементами
            int rows = matrix.GetLength(0);
            int nc = _rand.Next(0, matrix.GetLength(1));
            for (int i = 0; i < rows; ++i)
                matrix[i, nc] = _rand.Next(-10, -1);
            #endregion

            // получить индекс первого столбца, содержащий только отрицательные элементы
            int col = ColNegativesOnly(matrix);
            if (col < 0) {
                Show("\n\n\t    В матрице нет столбца без положительных элементов:\n\n", matrix);
            } else {
                Show($"\n\n\t   Меняем местами столбцы {n - 1} и {col}:\n\n", matrix, n - 1, col);

                SwapCols(matrix, matrix.GetLength(1) - 1, col);
                Show($"\n\t    После обмена столбцов {n - 1} и {col}:\n\n", matrix, n - 1, col);
            } // if

            SortRows(matrix);
            Show("\n\t    После сортировки строк по убыванию первых элементов:\n\n", matrix);

            // ожидать нажатия любой клавиши, не отображать нажатую клавишу
            // в окне консоли
            WriteXY(4, Console.WindowHeight - 1, "Нажмите любую клавишу для продолжения...", Console.ForegroundColor);
            Console.ReadKey(true);
            Console.Clear();
        } // Task4
        #endregion

    } // class Program
}
