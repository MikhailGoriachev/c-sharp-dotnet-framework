﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction

namespace Задание
{
    class Program
    {
        private static Random rand = new Random();
        static void Main(string[] args)
        {
            Console.Title = "Задание на 13.09.2021";
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.CursorVisible = false;

            // главный цикл работы приложения 
            while (true)
            {
                ShowNavBar();
                ShowText();

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                switch (key)
                {
                    // решение задачи 1 назначено на клавишу F5
                    case ConsoleKey.F5:
                        Task1();
                        break;

                    // решение задачи 2 назначено на клавишу F6
                    case ConsoleKey.F6:
                        Task2();
                        break;

                    // решение задачи 3 назначено на клавишу F7
                    case ConsoleKey.F7:
                        Task3();
                        break;

                    // решение задачи 4 назначено на клавишу F8
                    case ConsoleKey.F8:
                        Task4();
                        break;

                    // выход из приложения назначен на клавишу F10
                    case ConsoleKey.F10:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Console.SetCursorPosition(0, Console.WindowHeight - 1);
                        Console.CursorVisible = true;
                        return;
                } // switch
            } // while
        } // Main


        // выводим верхнюю строку
        private static void ShowNavBar()
        {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст с функциональными клавишами в верхнюю строку
            WriteXY(2, 0, "F5", ConsoleColor.Red);
            WriteXY(5, 0, "Задача 1", ConsoleColor.Black);

            WriteXY(16, 0, "F6", ConsoleColor.Red);
            WriteXY(19, 0, "Задача 2", ConsoleColor.Black);

            WriteXY(30, 0, "F7", ConsoleColor.Red);
            WriteXY(33, 0, "Задача 3", ConsoleColor.Black);

            WriteXY(45, 0, "F8", ConsoleColor.Red);
            WriteXY(48, 0, "Задача 4", ConsoleColor.Black);

            WriteXY(60, 0, "F10", ConsoleColor.Red);
            WriteXY(64, 0, "Выход", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBar

        private static void ShowText()
        {
            string text = @"
             Задача 1.
             Методы класса Math. Для значений, вводимых с клавиатуры рассчитайте значение выражений. 
             (напоминаю, что при правильном кодировании выражений их значения совпадают примерно до 
             10го знака после запятой). Выражения взяты из учебника Павловской Т.А.
             
             Задача 2.
             В одномерном массиве, состоящем из n целых элементов:
             -  Заполнить массив случайными числами
             -  Вычислить минимальный элемент массива, вывести массив с выделением таких элементов цветом
             -  Вычислить сумму элементов массива, расположенных между первым и последним положительными 
                элементами, вывести массив с выделением цветом таких элементов
             -  Упорядочить массив так, чтобы элементы, равные нулю были в начале массива

             Задача 3.
             В одномерном массиве, состоящем из n вещественных элементов:
             -  Заполнить массив случайными числами
             -  Вычислить индекс минимального по модулю элемента массива, вывести массив с выделением цветом 
                найденного элемента
             -	Вычислить сумму модулей элементов массива, расположенных после первого отрицательного элемента,
                вывести массив с выделением цветом слагаемых
             -	Упорядочить массив так, чтобы переместить в начало массива все элементы, значение которых находится
                в диапазоне [a, b]. При помощи метода Array.Resize() удалить все элементы, не входящие в этот диапазон
    
            Задача 4.
             В матрице целых чисел размера M x N:
             -	Заполнить матрицу случайными числами
             -	Поменять местами столбец с заданным номером и первый из столбцов, содержащих только отрицательные элементы.
                Если требуемых столбцов нет – вывести сообщение, не менять матрицу
             -	Поменять местами строки матрицы так, чтобы первые элементы матрицы были упорядочены по убыванию 

            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowText



        #region Решение задачи 1
        // Вывод текста задания в консоль
        private static void ShowTextTask1()
        {
            string text = @"
             Задача 1.
             Методы класса Math. Для значений, вводимых с клавиатуры рассчитайте значение выражений. 
             (напоминаю, что при правильном кодировании выражений их значения совпадают примерно до 
             10го знака после запятой). Выражения взяты из учебника Павловской Т.А.
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask1

        // Вывод информационного сообщения в верхнюю строку экрана
        private static void ShowNavBarTask1()
        {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 1", ConsoleColor.Red);
            WriteXY(11, 0, "Методы класса Math", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask1

        /// <summary>
        /// Задача 1.
        /// Методы класса Math.Для значений, вводимых с клавиатуры рассчитайте значение выражений.
        /// (напоминаю, что при правильном кодировании выражений их значения совпадают примерно до 
        /// 10го знака после запятой). Выражения взяты из учебника Павловской Т.А.
        /// </summary>
        private static void Task1()
        {

            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask1();
            ShowTextTask1();

            string prompt, title;

            #region Вариант 9

            string response = Interaction.InputBox("Аргумент для вычислений:", "Вариант 9    (1/2)");

            // выходной параметр - переменная объявляется в момент вызова
            bool convertResult = double.TryParse(response, out double a);

            string response2 = Interaction.InputBox("Аргумент для вычислений:", "Вариант 9    (2/2)");
            bool convertResult2 = double.TryParse(response2, out double b);
            if (convertResult && convertResult2)
            {

                // вычисления по варианту
                double z1 = Math.Pow((Math.Cos(a) - Math.Cos(b)), 2) -
                            Math.Pow((Math.Sin(a) - Math.Sin(b)), 2);
                double z2 = -4d* Math.Pow(Math.Sin((a - b)/2d), 2) * Math.Cos(a + b);

                // формирование параметров для выводa результата 
                title = "Вариант 9 - результат :";
                prompt = $"\n             Вычисления выполнены:\n             z1 = {z1:n10}\n             z2 = {z2:n10}\n";
            }
            else
            {
                // формирование параметров для выводa результата 
                title = "Вариант 9 - ошибка";
                prompt = "\n             Введено не число";
            } // if

            // вывод результата

            // сохранить цвет фона
            ConsoleColor oldColor = Console.ForegroundColor;

            Console.ForegroundColor = ConsoleColor.DarkRed;

            Console.Write($"\n\n\n             {title}");
            Console.ForegroundColor = oldColor;
            Console.WriteLine(prompt);
            #endregion


            #region Вариант 11

            response = Interaction.InputBox("Аргумент для вычислений:", "Вариант 11");

            // выходной параметр - переменная объявляется в момент вызова
            convertResult = double.TryParse(response, out double c);
            if (convertResult){

                // вычисления по варианту
                double z1 = (1d - 2d * Math.Pow(Math.Sin(c), 2)) / (1d + Math.Sin(2d * c));
                double z2 = (1d - Math.Tan(c)) / (1 + Math.Tan(c));

                // формирование параметров для выводa результата 
                title = "Вариант 11 - результат :";
                prompt = $"\n             Вычисления выполнены:\n             z1 = {z1:n10}\n             z2 = {z2:n10}\n";
                Console.ReadKey(true);
            }
            else
            {
                // формирование параметров для выводa результата 
                title = "Вариант 11 - ошибка";
                prompt = "\n             Введено не число";
                Console.ReadKey(true);
            } // if

            // вывод результата
            Console.ForegroundColor = ConsoleColor.DarkRed;

            Console.Write($"\n\n             {title}");
            Console.ForegroundColor = oldColor;
            Console.WriteLine(prompt);

            #endregion


            // выводим финишное сообщение задачи, ждем нажатия любой клавиши
            // и чистим экран перед выходом и выключаем курсор
            WriteXY(12, Console.WindowHeight - 1,
                "Нажмите любую клавишу для продолжения...",
                ConsoleColor.Gray
            );
            Console.ReadKey(true);  // ожидать код клавиши, не отображать символ клавиши
            Console.Clear();
            Console.CursorVisible = false;
        } // Task1
        #endregion

        #region Решение задачи 2
        // Вывод текста задания в консоль
        private static void ShowTextTask2()
        {
            string text = @"
             Задача 2.
             В одномерном массиве, состоящем из n целых элементов:
             1.  Заполнить массив случайными числами
             2.  Вычислить минимальный элемент массива, вывести массив с выделением таких элементов цветом
             3.  Вычислить сумму элементов массива, расположенных между первым и последним положительными 
                 элементами, вывести массив с выделением цветом таких элементов
             4.  Упорядочить массив так, чтобы элементы, равные нулю были в начале массива
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask2

        // Вывод информационного сообщения в верхнюю строку экрана
        private static void ShowNavBarTask2()
        {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 2", ConsoleColor.Red);
            WriteXY(11, 0, "Одномерный массив", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask2

        /// <summary>
        /// Задача 2.
        /// В одномерном массиве, состоящем из n целых элементов:
        ///      -  Заполнить массив случайными числами
        ///      -  Вычислить минимальный элемент массива, вывести массив с выделением таких элементов цветом
        ///      -  Вычислить сумму элементов массива, расположенных между первым и последним положительными
        ///         элементами, вывести массив с выделением цветом таких элементов
        ///      -  Упорядочить массив так, чтобы элементы, равные нулю были в начале массива
        /// </summary>
        private static void Task2()
        {

            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask2();
            ShowTextTask2();

            int n = 10;       // размер массива
            int[] arr;
            arr = new int[n]; // выделение памяти, создание массива

            // Заполнить массив случайными числами
            Fill(arr, -10, 10);


            WriteXY(12, 13, "1. Массив запонен                           : ", ConsoleColor.DarkRed);
            Show(arr);

            // Вычислить минимальный элемент массива, вывести массив с выделением таких элементов цветом
            WriteXY(12, 15, "2. Минимальные элементы                     : ", ConsoleColor.DarkRed);
            ShowMin(arr, ConsoleColor.DarkRed);

            WriteXY(12, 17, "3. Первый и последний положительные элементы: ", ConsoleColor.DarkRed);
            ShowFirstLastPos(arr, ConsoleColor.DarkRed, ConsoleColor.Green);
            int last = LastPos(arr);
            int first = FirstPos(arr);

            WriteXY(12, 18, "   Cумма элементов между ними               : ", ConsoleColor.DarkRed);
            int sum = SumBetween(arr, first, last);
            Console.WriteLine($"{sum, 7}");

            // Упорядочить массив так, чтобы элементы, равные нулю были в начале массива

            // сортировка элементы, равные нулю впереди
            int SpecialComparator(int x, int y) =>
                x == 0 && y != 0 ? -1 : x != 0 && y == 0 ? 1 : 0;
            Array.Sort(arr, SpecialComparator);

            WriteXY(12, 20, "4. Массив упорядочен                        : ", ConsoleColor.DarkRed);
            Show(arr);

            // выводим финишное сообщение задачи, ждем нажатия любой клавиши
            // и чистим экран перед выходом и выключаем курсор
            WriteXY(12, Console.WindowHeight - 1,
                "Нажмите любую клавишу для продолжения...",
                ConsoleColor.Gray
            );
            Console.ReadKey(true);  // ожидать код клавиши, не отображать символ клавиши
            Console.Clear();
            Console.CursorVisible = false;
        } // Task2

        // поиск индекса минимального элемента
        private static int Min(int[] arr) {
            int iMin = 0;
            for (int i = 1; i < arr.Length; i++){
                if (arr[i] < arr[iMin]) iMin = i;
            } // for i
            return iMin;
        } // Min

        // поиск индекса первого положительного элемента
        private static int FirstPos(int[] arr) {
            for (int i = 0; i < arr.Length; i++) {
                if (arr[i] > 0) return i;
            } // for i
            return -1;
        } // FirstPos

        // поиск индекса последнего положительного элемента
        private static int LastPos(int[] arr){
            int iPos = -1;
            for (int i = 0; i < arr.Length; i++) {
                if (arr[i] > 0) iPos = i;
            } // for i
            return iPos;
        } // LastPos


        // вывод массива в консоль(Выделение цветом минимального элемента)
        private static void ShowMin(int[] arr, ConsoleColor color)
        {
            int iMin = Min(arr);

            ConsoleColor oldColor = Console.ForegroundColor;

            void ShowItem(int item)
            {
                if (item == arr[iMin]) Console.ForegroundColor = color;

                Console.Write($"{item,7}");
                Console.ForegroundColor = oldColor;
            } // ShowItem

            Array.ForEach(arr, ShowItem);

            Console.WriteLine();
        } // ShowMin


        // вывод массива в консоль(Выделение цветом первого и последнего положительных элементов)
        private static void ShowFirstLastPos(int[] arr, ConsoleColor colorPos, ConsoleColor colorBetween)
        {
            int iFirst = FirstPos(arr);
            int iLast = LastPos(arr);

            ConsoleColor oldColor = Console.ForegroundColor;

            for (int i = 0; i < arr.Length; i++)
            {
                if (i == iFirst || i == iLast) Console.ForegroundColor = colorPos;
                if (i > iFirst && i < iLast) Console.ForegroundColor = colorBetween;

                Console.Write($"{arr[i],7}");

                Console.ForegroundColor = oldColor;
            } // for i

            Console.WriteLine();
        } // ShowFirstLastPos

        // сумма элементов, расположенных между указанными элементами
        private static int SumBetween(int[] arr, int from, int to)
        {
            int sum = 0;
            for (int i = from + 1; i < to; i++)
            {
                sum += arr[i];
            } // for i
            return sum;
        } // SumBetween

        // вывод массива в консоль
        private static void Show(int[] arr)
        {
            void LocalShowItem1(int item) =>
               Console.Write($"{item,7}");

            Array.ForEach(arr, LocalShowItem1);

            Console.WriteLine();
        } // Show

        // заполнение массивa случайными числами
        private static void Fill(int[] arr, int lo, int hi)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rand.Next(lo, hi + 1);
            } // for i
        } // Fill


        #endregion

        #region Решение задачи 3
        // Вывод текста задания в консоль
        private static void ShowTextTask3()
        {
            string text = @"
             Задача 3.
             В одномерном массиве, состоящем из n вещественных элементов:
             1. Заполнить массив случайными числами
             2. Вычислить индекс минимального по модулю элемента массива, вывести массив с выделением цветом 
                найденного элемента
             3. Вычислить сумму модулей элементов массива, расположенных после первого отрицательного элемента,
                вывести массив с выделением цветом слагаемых
             4. Упорядочить массив так, чтобы переместить в начало массива все элементы, значение которых находится
                в диапазоне [a, b]. При помощи метода Array.Resize() удалить все элементы, не входящие в этот диапазон
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask2

        // Вывод информационного сообщения в верхнюю строку экрана
        private static void ShowNavBarTask3()
        {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 3", ConsoleColor.Red);
            WriteXY(11, 0, "Одномерный массив", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask3

        /// <summary>
        ///Задача 3.
        ///В одномерном массиве, состоящем из n вещественных элементов:
        ///1. Заполнить массив случайными числами
        ///2. Вычислить индекс минимального по модулю элемента массива, вывести массив с выделением цветом
        ///   найденного элемента
        ///3. Вычислить сумму модулей элементов массива, расположенных после первого отрицательного элемента,
        ///   вывести массив с выделением цветом слагаемых
        ///4. Упорядочить массив так, чтобы переместить в начало массива все элементы, значение которых находится
        ///   в диапазоне[a, b]. При помощи метода Array.Resize() удалить все элементы, не входящие в этот диапазон
        /// </summary>
        private static void Task3() {

            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask3();
            ShowTextTask3();

            double lo = -10d;
            double hi = 10d;

            int n = 8;       // размер массива
            double[] arr;
            arr = new double[n]; // выделение памяти, создание массива

            // Заполнить массив случайными числами
            Fill(arr, lo, hi);


            WriteXY(13, 15, "1. Массив запонен                             : ", ConsoleColor.DarkRed);
            Show(arr);

            // Вычислить индекс минимального по модулю элемента массива, вывести массив с выделением цветом
            // найденного элемента
            WriteXY(13, 17, "2. Минимальный по модулю элемент              : ", ConsoleColor.DarkRed);
            ShowMinAbs(arr, ConsoleColor.DarkRed);

            //  Вычислить сумму модулей элементов массива, расположенных после первого отрицательного элемента,
            //  вывести массив с выделением цветом слагаемых
            WriteXY(13, 19, "3. Первый отрицательный элемент               : ", ConsoleColor.DarkRed);
            ShowFirstNeg(arr, ConsoleColor.DarkRed, ConsoleColor.Green);
            WriteXY(16, 20, "Сумма модулей элементов                    : ", ConsoleColor.DarkRed);
            Console.WriteLine($"{SumAfterFirstNeg(arr), 8:f2}");

            // Упорядочить массив так, чтобы переместить в начало массива все элементы, значение которых находится
            // в диапазоне[a, b]. При помощи метода Array.Resize() удалить все элементы, не входящие в этот диапазон

            // диапазон
            double a = lo + (hi - lo) * rand.NextDouble();
            double b = a + (hi - a) * rand.NextDouble();

            // сортировка элементы, равные нулю впереди
            int SpecialComparator(double x, double y) =>
                (x >= a && x <= b) && (y < a || y > b) ? -1 : (x < a || x > b) && (y >= a && y <= b) ? 1 : 0;

            Array.Sort(arr, SpecialComparator);

            WriteXY(13, 22, $"4. Массив упорядочен (диапазон[{a, 5:f2}, {b, 5:f2}]) : ", ConsoleColor.DarkRed);
            Show(arr);

            Array.Resize(ref arr, Count(arr, a, b));
            WriteXY(16, 23, $"Элементы удалены                           : ", ConsoleColor.DarkRed);
            Show(arr);


            Console.ReadKey(true);  // ожидать код клавиши, не отображать символ клавиши
            Console.Clear();
            Console.CursorVisible = false;
        } // Task3


        private static int Count(double[] arr, double lo, double hi){
            int count = 0;
            for (int i = 1; i < arr.Length; i++) {
                if (arr[i] >= lo && arr[i] <= hi) count++;
            } // for i
            return count;
        } // Count

        // поиск индекса минимального по модулю элемента
        private static int MinAbs(double[] arr){
            int iMin = 0;
            for (int i = 1; i < arr.Length; i++){
                if (Math.Abs(arr[i]) < Math.Abs(arr[iMin])) iMin = i;
            } // for i
            return iMin;
        } // MinAbs

        // поиск индекса первого отрицательного элемента
        private static int FirstNeg(double[] arr){
            for (int i = 0; i < arr.Length; i++) {
                if (arr[i] < 0) return i;
            } // for i
            return -1;
        } // MinAbs


        private static double SumAfterFirstNeg(double[] arr){
            double sum = 0d;
            int iFirst = FirstNeg(arr);

            for (int i = iFirst + 1; i < arr.Length; i++) {
                sum += Math.Abs(arr[i]);
            } // for i

            return sum;
        } // SumAfterFirstNeg

        // вывод массива в консоль(Выделение цветом первого отрицательного элементa)
        private static void ShowFirstNeg(double[] arr, ConsoleColor colorPos, ConsoleColor colorBetween)
        {
            int iFirst = FirstNeg(arr);

            ConsoleColor oldColor = Console.ForegroundColor;

            for (int i = 0; i < arr.Length; i++)
            {
                if (i == iFirst) Console.ForegroundColor = colorPos;
                if (i > iFirst && iFirst != -1) Console.ForegroundColor = colorBetween;

                Console.Write($"{arr[i], 8:f2}");

                Console.ForegroundColor = oldColor;
            } // for i

            Console.WriteLine();
        } // ShowFirstNeg



        // заполнение массивa случайными числами
        private static void Fill(double[] arr, double lo, double hi)
        {
            for (int i = 0; i < arr.Length; i++){
                arr[i] = lo + (hi - lo) * rand.NextDouble();
            } // for i
        } // Fill

        // вывод массива в консоль(Выделение цветом минимального по модулю элемента)
        private static void ShowMinAbs(double[] arr, ConsoleColor color)        {
            int iMin = MinAbs(arr);

            ConsoleColor oldColor = Console.ForegroundColor;

            void ShowItem(double item)            {
                if (item == arr[iMin]) Console.ForegroundColor = color;

                Console.Write($"{item,8:f2}");
                Console.ForegroundColor = oldColor;
            } // ShowItem

            Array.ForEach(arr, ShowItem);

            Console.WriteLine();
        } // ShowMinAbs


        // вывод массива в консоль
        private static void Show(double[] arr)
        {
            void LocalShowItem(double item) =>
               Console.Write($"{item, 8:f2}");

            Array.ForEach(arr, LocalShowItem);

            Console.WriteLine();
        } // Show

        #endregion

        #region Решение задачи 4
        // Вывод текста задания в консоль
        private static void ShowTextTask4()
        {
            string text = @"
             Задача 4.
             В матрице целых чисел размера M x N:
             1.	Заполнить матрицу случайными числами
             2.	Поменять местами столбец с заданным номером и первый из столбцов, содержащих только отрицательные элементы.
                Если требуемых столбцов нет – вывести сообщение, не менять матрицу
             3.	Поменять местами строки матрицы так, чтобы первые элементы матрицы были упорядочены по убыванию 
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask4


        // Вывод информационного сообщения в верхнюю строку экрана
        private static void ShowNavBarTask4()
        {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 4", ConsoleColor.Red);
            WriteXY(11, 0, "Прямоугольный массив", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask4

        /// <summary>
        /// Задача 4.
        /// В матрице целых чисел размера M x N:
        /// 1.	Заполнить матрицу случайными числами
        /// 2.	Поменять местами столбец с заданным номером и первый из столбцов, содержащих только отрицательные элементы.
        ///     Если требуемых столбцов нет – вывести сообщение, не менять матрицу
        /// 3.	Поменять местами строки матрицы так, чтобы первые элементы матрицы были упорядочены по убыванию
        /// </summary>
        private static void Task4(){
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask4();
            ShowTextTask4();

            int m = 3; // строки
            int n = 5; // столбцы
            int[,] matr = new int[m, n];

            // Заполнить матрицу случайными числами
            Fill(matr, -10, 2);


            WriteXY(13, 12, "1. Матрица запонена: ", ConsoleColor.DarkRed);
            Show(matr);

            int row = rand.Next(1, n + 1);
            WriteXY(13, 12 + m + 2, "2. Поменять местами столбцы: ", ConsoleColor.DarkRed);

            // Поменять местами столбец с заданным номером и первый из столбцов, содержащих только отрицательные элементы.
            // Если требуемых столбцов нет – вывести сообщение, не менять матрицу
            int negRow = FirstNegRow(matr);
            int r = 0;
            if(negRow == -1) Console.Write(" требуемых столбцов нет :( ");
            else {
                WriteXY(16, 12 + m + 3, $"Номер первого столбца = {row} ", ConsoleColor.Green);
                ChangeRows(ref matr, row-1, negRow);
                ShowRows(matr, row - 1, negRow, ConsoleColor.DarkRed);
                r += m + 1;
            } // if

            WriteXY(13, 12 + m + 2 + r + 2, "3. Поменять местами строки: ", ConsoleColor.DarkRed);
            // Поменять местами строки матрицы так, чтобы первые элементы матрицы были упорядочены по убыванию
            sortMatr(ref matr);
            Show(matr);

            Console.ReadKey(true);  // ожидать код клавиши, не отображать символ клавиши
            Console.Clear();
            Console.CursorVisible = false;
        } // Task4

        private static int FirstNegRow(int[,] matr)
        {
            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);

            bool isNeg = true;

            for (int j = 0; j < rows; j++) {
                isNeg = true;

                for (int i = 0; i < cols; i++){
                    if (matr[j, i] >= 0) isNeg = false;
                } // for j

                if (isNeg) return j;
            } // for i
            return -1;
        } // FirstNegRow

        private static void sortMatr(ref int[,] matr) {
            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            for (int i = 0; i < rows - 1; i++)
            {
                if (matr[i, 0] < matr[i + 1, 0]) ChangeCols(ref matr, i, i + 1);
            } // for i
        } // sortMatr

        private static void ChangeCols(ref int[,] matr, int col1, int col2)
        {
            int cols = matr.GetLength(1);

            for (int j = 0; j < cols; j++) {
                int temp = matr[col1, j];
                matr[col1, j] = matr[col2, j];
                matr[col2, j] = temp;
            } // for i
        } // ChangeCols

        private static void ChangeRows(ref int[,] matr, int row1, int row2)
        {
            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);

            for (int j = 0; j < rows; j++)
            {
                int temp = matr[j, row1];
                matr[j, row1] = matr[j, row2];
                matr[j, row2] = temp;
            } // for i
        } // Show

        // вывод прямоугольного массива
        private static void ShowRows(int[,] matr, int row1, int row2, ConsoleColor color)
        {
            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);

            ConsoleColor oldColor = Console.ForegroundColor;

            for (int i = 0; i < rows; i++) {
                Console.Write("\n            ");

                for (int j = 0; j < cols; j++)
                {
                    if(j == row1 || j == row2)  Console.ForegroundColor = color;

                    Console.Write($"{matr[i, j],7}");

                    Console.ForegroundColor = oldColor;
                } // for j
            } // for i
        } // ShowNegRow

        // вывод прямоугольного массива
        private static void Show(int[,] matr)
        {
            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);
            for (int i = 0; i < rows; i++){
                Console.Write("\n            ");
                for (int j = 0; j < cols; j++)
                    Console.Write($"{matr[i, j], 7}");
            } // for i
        } // Show

        private static void Fill(int[,] matr, int lo, int hi) {
            int rows = matr.GetLength(0); // строки
            int cols = matr.GetLength(1); // столбцы

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    matr[i, j] = rand.Next(lo, hi + 1);
        } // Fill


        #endregion


        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY
    }
}
