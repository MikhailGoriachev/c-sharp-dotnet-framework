﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.VisualBasic;   // для работы с классом Interaction

namespace C_Sharp_.NET_Framework__3___Massive_and_Math_
{
    class Program
    {
        private static Random rand = new Random();
        static void Main(string[] args)
        {
            int y = 4;
            int x = 10;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            WriteXY(x,y,   "<|------------------------------------|>");
            WriteXY(x,y+1, "<|                 MENU               |>");
            WriteXY(x,y+2, "<|------------------------------------|>");
            WriteXY(x,y+3, "<|   №   >|<         Задания          |>");
            WriteXY(x,y+4, "<|------------------------------------|>");
            WriteXY(x,y+5, "<|   1   >|<      Библиотека Math     |>");
            WriteXY(x,y+6, "<|------------------------------------|>");
            WriteXY(x,y+7, "<|   2   >|<  Одномерный массив int   |>");
            WriteXY(x,y+8, "<|------------------------------------|>");
            WriteXY(x,y+9, "<|   3   >|< Одномерный массив doublе |>");
            WriteXY(x,y+10,"<|------------------------------------|>");
            WriteXY(x,y+11,"<|   4   >|<  Прямоугольная матрица   |>");
            WriteXY(x,y+12,"<|------------------------------------|>");
            WriteXY(x,y+13,"<|   0   >|<           EXIT           |>");
            WriteXY(x,y+14,"<|------------------------------------|>\n\n");

            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Black;

            Console.CursorVisible = false;
            Console.Write("\tВведите пункт: ");
            int choi;
            choi = int.Parse(Console.ReadLine());
            Console.Clear();
            Console.CursorVisible = true;
            switch (choi){
                case 1: task1(); break;
                case 2: task2(); break;
                case 3: task3(); break;
                case 4: task4(); break;
                case 0: Console.Write("\n\n\tДо свидания\n");return;
            }

            Console.ReadKey(false);
        } // main

        #region task1 Math
        static void task1(){

            WriteXY(25, 2, "Пример №9");
            WriteXY(7, 5, "Введите значение аргумента(a) для примера:");
            bool result = double.TryParse(Console.ReadLine(), out double a);
            if (!result) { WriteXY(15, 10, "Введены некорректные данные");return; }

            WriteXY(7,7, "Введите значение аргумента(b) для примера:");
            result = double.TryParse(Console.ReadLine(), out double b);
            if (!result) { WriteXY(15, 10, "Введены некорректные данные");return; }

            double z1 = Math.Pow(Math.Cos(a) - Math.Cos(b), 2) - Math.Pow(Math.Sin(a) - Math.Sin(b), 2);
            double z2 = -4d * Math.Pow(Math.Sin((a - b) / 2), 2) * Math.Cos(a+b);

            Console.WriteLine($"\n\t\tРезультат вычисления:\n\t z1 = {z1:n10}\n\t z2 = {z2:n10}");

            Console.ReadKey();
            Console.Clear();

            WriteXY(25, 2, "Пример №11");
 
            WriteXY(7, 5, "Введите значение аргумента(a) для примера:");
             result = double.TryParse(Console.ReadLine(), out a);
            if (!result) { WriteXY(15, 10, "Введены некорректные данные"); return; }
               
              z1 = (1d - 2d * Math.Pow(Math.Sin(a),2)) / (1d + Math.Sin(a*2d));
            
              z2 =  (1d - Math.Tan(a)) / (1d + Math.Tan(a));

            Console.WriteLine($"\n\t\tРезультат вычисления:\n\t z1 = {z1:n10}\n\t z2 = {z2:n10}");
 
        }// task1 
        #endregion
       

        #region task2 Одномерный массив int
        static void task2(){

            Console.Write("\n\n\tВведите желаемый размер массива:");
            bool res = int.TryParse(Console.ReadLine(), out int n);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }
            int[] arr = new int[n];

            Console.Write ("\n\tВведите минимальное значение для генерации массива:");
            res = int.TryParse(Console.ReadLine(),out int lo);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }

            Console.Write("\tВведите максимальное значение для генерации массива:");
            res = int.TryParse(Console.ReadLine(), out int hi);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }

            // Заполнение массива
            Fill(arr, lo, hi);
            // Вывод массива
            Show(arr,4,"Исходный массив:");

            int min = MinMassive(arr);
            ShowMin(arr, 4, min,"Вывод с выдилением минимальных элементов:");
            
            Console.Write("\n\n");
            int sum = SumFirstLastPositiveElem(arr);
            ShowFirLasPositiveElem(arr, 4, "Вывод массива с выделением цвета элементов от первого до последнего положительного:");
            Console.WriteLine($"\nСумма элементов массива между 1 и последнием положительным элементом = {sum}");

            // Компаратор для сортировки
            int SpecialComparator(int x, int y) =>
             x == 0 && y != 0 ? -1 : x != 0 && y == 0 ? 1 : 0;
            Array.Sort(arr, SpecialComparator);
            Console.Write("\n\n");
            Show(arr, 4, "Исходный массив отсортированный по правилу нулевые элементы в начале:");

        }// task2
        #endregion

        #region Методы для решения задач в task2
        // Заполнение массива
        static void Fill(int[] arr, int lo, int hi){
            for (int i = 0; i < arr.Length; i++)
                arr[i] = rand.Next(lo, hi+1);
        } // Fill
        
        // Вывод массива
        static void Show(int[] arr, int couStr,string title = "" )
        {
            Console.WriteLine("\n\t" + title);
            //ConsoleColor color = Console.ForegroundColor; 
            for (int i = 0; i < arr.Length; i++) {
                Console.Write($"{arr[i],8}");
            if((i+1) % couStr == 0 && i != 0) { Console.WriteLine(); }
            } // if
           // Console.ForegroundColor = color;
        } // Show

        // Вывод массива с выделением минимальных элементов
        static void ShowMin(int[] arr, int couStr,int min ,string title = "")
        {
            Console.WriteLine("\n\t" + title);
            ConsoleColor color = Console.ForegroundColor;
            for (int i = 0; i < arr.Length; i++)
            {
                Console.ForegroundColor = (arr[i] == min) ? ConsoleColor.Yellow : color;
                Console.Write($"{arr[i],8}");
                if ((i + 1) % couStr == 0 && i != 0) { Console.WriteLine(); }
            } // if
            Console.ForegroundColor = color;
        } // ShowMin

        // Вывод массива с выделением цвета элементов от первого до последнего положительного
        static void ShowFirLasPositiveElem(int[] arr, int couStr, string title = "")
        {
            Console.WriteLine("\n\t" + title);
            ConsoleColor color = Console.ForegroundColor;
            int first = FirstPositivElem(arr);
            int last = LastPositivElem(arr);
            for (int i = 0; i < arr.Length; i++)
            {
                Console.ForegroundColor = (i>=first && i <= last) ? ConsoleColor.Yellow : color;
                Console.Write($"{arr[i],8}");
                if ((i + 1) % couStr == 0 && i != 0) { Console.WriteLine(); }
            } // if
            Console.ForegroundColor = color;
        } // ShowFirLasPositiveElem

        // Вычисление минимального элемента массива
        static int MinMassive(int[] arr) {
            int min = int.MaxValue;
            for (int i = 0; i < arr.Length; i++){
                if (min > arr[i]) min = arr[i];
            } // for
            return min;
        }// MinMassive

        // Первый положительный элемент в массиву (возвращает индекс элемента)
        static int FirstPositivElem(int [] arr){
            for (int i = 0; i < arr.Length; i++)
                if (arr[i] >= 0) return i;
            // *Отсутствует положительный элемент*
            return -1;
        }// FirstPositivElem

        // Последний положительный элемент в массиву (возвращает индекс элемента)
        static int LastPositivElem(int[] arr)
        {
            for (int i = arr.Length-1; i >= 0; i--)
                if (arr[i] >= 0) return i;
            // *Отсутствует положительный элемент*
            return -1;
        }// LastPositivElem

        // Сумма между первым и последним положительным элементов
        static int SumFirstLastPositiveElem(int[] arr){
            int first = FirstPositivElem(arr);
            int last = LastPositivElem(arr);
            int sum = 0;
            for (int i = first; i <= last; i++){
                sum += arr[i];
            }
            return sum;
        }// SumFirstLastPositiveElem
        #endregion

        #region task3 Одномерный массив double
        static void task3(){
            Console.Write("\n\n\tВведите желаемый размер массива:");
            bool res = int.TryParse(Console.ReadLine(), out int n);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }
            double[] arr = new double[n];

            Console.Write("\n\tВведите минимальное значение для генерации массива:");
            res = double.TryParse(Console.ReadLine(), out double lo);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }

            Console.Write("\tВведите максимальное значение для генерации массива:");
            res = double.TryParse(Console.ReadLine(), out double hi);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }

            // Заполнение массива
            Fill(arr, lo, hi);
            // Вывод массива
            Show(arr, 4, "Исходный массив:");
            
            int imin = MinABSMassive(arr);
            Console.Write($"\n\n Индекс минимального по модулю элемента: {imin}");
            ShowABSMin(arr, 4, imin, "Вывод массива с выдилением минимального по модулю элемента:");

            Console.Write("\n");
            int firstNegative = FirstNegativeElem(arr);
            double sum = SumAfterFirstNegative(arr, firstNegative+1);
            ShowAfterFirstNegative(arr, 4, firstNegative+1,"Элементы стоящие после первого отрицательного выделены цветом");
            Console.WriteLine($"\nСумма элементов по модулю расположенных после первого отрицательного элемента = {sum}");
 
        } // task3
        #endregion
       
        #region Методы для решения задач в task3
        // Заполнение массива
        static void Fill(double[] arr, double lo, double hi)
        {
            for (int i = 0; i < arr.Length; i++)
                arr[i] = lo + (hi - lo) * rand.NextDouble();
        } // Fill

        // Вывод массива
        static void Show(double[] arr, int couStr, string title = "")
        {
            Console.WriteLine("\n\t" + title);
           // ConsoleColor color = Console.ForegroundColor;
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"{arr[i],8:f2}");
                if ((i + 1) % couStr == 0 && i != 0) { Console.WriteLine(); }
            } // if
           // Console.ForegroundColor = color;
        } // Show

        // Вывод массива с выделением минимального по модулю элемента
        static void ShowABSMin(double[] arr, int couStr,int imin, string title = "")
        {
            Console.WriteLine("\n\t" + title);
            ConsoleColor color = Console.ForegroundColor;
            for (int i = 0; i < arr.Length; i++)
            {
                Console.ForegroundColor = (i == imin) ? ConsoleColor.Yellow : color;
                Console.Write($"{arr[i],8:f2}");
                if ((i + 1) % couStr == 0 && i != 0) { Console.WriteLine(); }
            } // if
            Console.ForegroundColor = color;
        } // ShowABSMin

        // Вывод массива с выделением элементов после первого минимального
        static void ShowAfterFirstNegative(double[] arr, int couStr, int first, string title = "")
        {
            Console.WriteLine("\n\t" + title);
            ConsoleColor color = Console.ForegroundColor;
            for (int i = 0; i < arr.Length; i++)
            {
                // Выделение собственно самого 1 отрицательного
                Console.ForegroundColor = (i == first-1) ? ConsoleColor.Green : color;
                // Выделение Элементов после 1 отрицательного 
                // *если не выделять сам отрицательный элемент условие выглядит так: (i == first)*
                if (i >= first) Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write($"{arr[i],8:f2}");
                if ((i + 1) % couStr == 0 && i != 0) { Console.WriteLine(); }
            } // if
            Console.ForegroundColor = color;
        } // ShowAfterFirstNegative

        // Минимальный по модулю элемент
        static int MinABSMassive(double[] arr)
        {
            double min = double.MaxValue;
            int imin = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (Math.Abs(min) > Math.Abs(arr[i])){
                    min = arr[i];
                    imin = i;
                }
            } // for
            return imin;
        }// MinMassive

        // Вычисление первого отрицательного элемента (возвращает индекс)
        static int FirstNegativeElem(double[] arr)
        {
            for (int i = 0; i < arr.Length; i++){
                if (arr[i] < 0d) return i;
            }
            // отрицательного элемента нет
            return -1;
        } // FirstNegativeElem

        // Сумма модулей элементов расположенный после первого отрицательного элемента
        static double SumAfterFirstNegative(double[] arr, int first){
            double sum = 0d;
            for (int i = first; i < arr.Length; i++){
                sum += Math.Abs(arr[i]);
            } // for
            return sum;
        } // SumAfterFirstNegative
        #endregion

        #region task4 Прямоугольный массив
        static void task4(){

            Console.Write("\n\n\tВведите желаемый размер матрицы (кол-во строк \"M\"):");
            bool res = int.TryParse(Console.ReadLine(), out int M);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }
            
            Console.Write("\n\n\tВведите желаемый размер матрицы (кол-во столбцов \"N\"):");
            res = int.TryParse(Console.ReadLine(), out int N);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }

            int [,] matr = new int[M, N];

            Console.Write("\n\tВведите минимальное значение для генерации массива:");
            res = int.TryParse(Console.ReadLine(), out int lo);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }

            Console.Write("\tВведите максимальное значение для генерации массива:");
            res = int.TryParse(Console.ReadLine(), out int hi);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }

            // Заполнение массива
            Fill(matr, lo, hi);
            // Вывод массива
            Show(matr, 4, "Исходный матрица:");

            int couNegative = OnlyNegativeCols(matr);
            if(couNegative == -1)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("\n\t\t**************************************\n"); 
                Console.Write("\t\t   Подходящий столбец не обнаружен!   \n"); 
                Console.Write("\t\t   Будет произведен выход в гл.меню   \n"); 
                Console.Write("\t\t**************************************\n");
                Console.ForegroundColor = ConsoleColor.White;
                return;
            }
            Console.WriteLine($"\tСтолбец содержащий только отрицательные элементы: {couNegative}\n");


            Console.Write($"\tВведите номер стобца который хотите поменять местами с столбцом под номером {couNegative+1}, всего столбцов {N} |>:");
            res = int.TryParse(Console.ReadLine(), out int colsUser);
            if (!res) { WriteXY(15, 15, "Введенны некорректные данные"); return; }
            SwapCols(matr, colsUser - 1, couNegative);
            // Вывод массива
            Show(matr, 4, "\nМатрица после замены:");
        }// task4
        #endregion

        #region Методы для решения задач в task44

        
        // Заполнение матрицы
        static void Fill(int[,] matr, int lo, int hi){
            int M = matr.GetLength(0);
            int N = matr.GetLength(1);
        
            for (int i = 0; i < M; i++) {
                for (int j = 0; j <N; j++){
                    matr[i, j] = rand.Next(lo, hi + 1);

                }// for N
            }// for M
        } // Fill

        // Вывод матрицы
        static void Show(int[,] matr, int couStr, string title = "")
        {
            int M = matr.GetLength(0);
            int N = matr.GetLength(1);

            Console.WriteLine("\n\t" + title);

            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                    Console.Write("{0, 10}", matr[i, j]);
                Console.WriteLine();
            } // for i
       
        } // Show

        // Поиск столбца с отрицательными элементами
        static int OnlyNegativeCols(int[,] matr){
            int M = matr.GetLength(0);
            int N = matr.GetLength(1);

            for (int j = 0; j < N; j++){
                for (int i = 0; i < M; i++){
                    if (matr[i, j] >= 0) break;
                    if (i + 1 == M) return j;
                }// for N
            }// for M
            // Столбца только с отрицательными элементаи нет
            return -1; 
        } // OnlyNegativeCols
       
        // Обмен местами столбца которого выбрал user и столбца только с негативными элементами
        static void SwapCols (int[,]matr,int colsUser,int colsNegative){
            int temp;
            int M = matr.GetLength(0);
            for (int i = 0; i < M; i++)
            {
                temp = matr[i, colsUser];
                matr[i, colsUser] = matr[i, colsNegative];
                matr[i, colsNegative] = temp;
            } // for i
        } // SwapCols


        #endregion

        //static void sort(double[] arr, double to,double from)
        //{
        //    for (int i = 0; i < n; i++)
        //    {
        //        int imax = 0;
        //        for (int j = 0; j < n - i; j++)
        //        {
        //            if (x[j] > x[imax])
        //                imax = j;
        //        } // for j
        //        swap(x[imax], x[n - i - 1]);
        //    } // for i

        //} // sort

        #region Вспомогательные методы
        // Вспомогательный метод для вывода в заданных координатах окна консоли 
        static void WriteXY(int x, int y, string s)
        {
            Console.SetCursorPosition(x, y);
            Console.Write(s);
        } // WriteXY
        #endregion
    }
}


