﻿using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

//using Microsoft.VisualBasic;   // для работы с классом Interaction

//using static System.Console;

namespace HomeWork13._09._21
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.Clear();
                ConsoleColor foreColor = Console.ForegroundColor;
                ConsoleColor backColor = Console.BackgroundColor;


                Console.SetWindowSize(100, 35);

                WriteXY(0, 0, $"▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓\n");
                Console.BackgroundColor = ConsoleColor.Red;

                WriteXY(46, 0, $"0 - ВЫХОД\n");

                Console.Title = "Домашние задание на 12.09.21";
                Console.BackgroundColor = ConsoleColor.DarkCyan;

                WriteXY(30, 2, $"░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\n");
                WriteXY(35, 2, "Домашние задание на 12.09.21\n");

                Console.ForegroundColor = ConsoleColor.Black;

                WriteXY(5, 6, $"1 - Задача 1. Методы класса Math.\n");

                WriteXY(5, 8, $"2 - Задача 2. Одномерный массив.\n");
                WriteXY(5, 10, $"3 - Задача 3. Одномерный массив.\n");
                WriteXY(5, 12, $"4 - Задача 4. Прямоугольный массив. \n");

                WriteXY(4, 14, $"Сделайте Ваш выбор: \n");

                // ввод выбора меню
                string res = Console.ReadLine();
                bool flag = int.TryParse(res,out int a);

                if (!flag) continue;

                // обработка команды
                switch (a)
                {
                    case 1:
                        Task1();
                        break;

                    case 2:
                        Task2();

                        break;

                    case 3:
                        Task3();
                        break;

                    case 4:
                        Task4();
                        break;

                    case 0:
                        return;

                    default:
                        //Console.Clear();
                        Console.BackgroundColor = ConsoleColor.Red;
                        Console.ForegroundColor = ConsoleColor.Black;
                        WriteXY(38, 17, $"Такого пункта меню нет!\n");
                        Thread.Sleep(1_000);
                        break;
                        

                } // switch


                Console.ForegroundColor = foreColor;
                Console.BackgroundColor = backColor;
            }
        }

        #region Задание 1
        static void Task1() {

            Console.Clear();

            // ввод значения альфа
            Console.WriteLine($"Введите значения α:");
            int α = int.Parse(Console.ReadLine());

            // ввод значения бета
            Console.WriteLine($"Введите значения β:");
            int β = int.Parse(Console.ReadLine());

            Console.WriteLine($"\nВариант 9.\n");
            Console.WriteLine(@"z_1=〖(cosα-cosβ)〗^2-〖(sinα-sinβ)〗^2;   z_2=-4〖sin〗^2  (α-β)/2∙cos⁡(α+β)");


            

            double z1 = Math.Pow(Math.Cos(α) - Math.Cos(β), 2) - Math.Pow(Math.Sin(α) - Math.Sin(β), 2);
            double z2 = -4 * Math.Pow(Math.Sin((α - β) / 2), 2) * Math.Cos(α + β);
            Console.WriteLine($"\nZ1 = {z1}\n");
            Console.WriteLine($"Z2 = {z2}\n");


            Console.WriteLine($"Z1 == Z2 = {(z1-z2<1e-10)} \n");

            //Console.ReadKey(false);


            Console.WriteLine($"Вариант 11.\n");
            Console.WriteLine(@"z_1 = (1 - 2∙〖sin〗^2 α)/ (1 + sin2α); z_2 = (1 - tgα) / (1 + tgα)");

            z1 = (1 - 2 * Math.Pow(Math.Sin(α), 2)) / (1 + Math.Sin(2 * α));
            z2 = (1 - Math.Tan(α)) / (1 + Math.Tan(α));

            Console.WriteLine($"\nZ1 = {z1}\n");
            Console.WriteLine($"Z2 = {z2}\n");
            Console.WriteLine($"Z1 == Z2 = {(z1 - z2 < 1e-10)} ");

            Console.ReadKey(false);

        }




        #endregion

        #region Задание 2
        static void Task2() {

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.Clear();

            int n = rand.Next(10, 50);

            int[] arr;         // создание ссылки 
            arr = new int[n]; // выделение памяти, создание массива

            // заполнение массива случайными числами
            Fill(arr, -50, 50);

            // выведем этот массив
            Show($"\nМассив заполнен {n} случайными числами:\n", arr);


            int minValue;

           SearchMin(arr,out minValue);


            ShowMinColor($"\nВ массиве выделны цветом минимальные элементы\n", arr, minValue);

            int first;
            int last;
            bool flag = FirstLastPositivElem(arr, out first, out last);
            if (flag) {

                ShowArrFirstLastPositiv($"\nВ массиве выделны цветом первый и последний положительные элементы.\nСумма элементов между первым и последним положительным равна {SumArrFirstLastPositiv(arr, first, last)} \n", arr, first, last);
            }else
                Show($"\nВ массиве один или менее положительных элементов:\n", arr);



            // компаратор для сортировки нулевых значений впереди
            int Comparator(int x, int y) =>
                x == 0 && y != 0 ? -1 : x != 0 && y == 0 ? 1 : 0;
            Array.Sort(arr, Comparator);
            Show("\nМассив отсортирован по правилу \"Нулевые значения впереди\":\n", arr);



            


            Console.ReadKey(false);


        }

        // поиск минимального значения в массиве
        private static void SearchMin(int[] arr, out int minValue) {

            minValue = arr[0];

            foreach (int item in arr)
            {
                if (item < minValue) {
                    minValue = item;
                }
            } // foreach

        }

        // вывод массива с подсветкой минимального значения
        private static void ShowMinColor(string title, int[] arr, int value)
        {
            Console.Write(title);

            ConsoleColor backgrounddefaultcolor = Console.BackgroundColor;
            ConsoleColor foregrounddefaultcolor = Console.ForegroundColor;

            int count = 0;

            void LocalShowItem(int item)
            {           
                if (item== value) {

                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.ForegroundColor = ConsoleColor.Black;

                }
                Console.Write($"  {item,3}  ");
                Console.BackgroundColor = backgrounddefaultcolor;
                Console.ForegroundColor = foregrounddefaultcolor;
                count++;
                if (count % 6 == 0) Console.WriteLine();

            } // LocalShowItem

            Array.ForEach(arr, LocalShowItem);

            

            Console.WriteLine();
        } // Show


        // поиск первого и последнего положительного элементов в массиве
        private static bool FirstLastPositivElem(int[] arr, out int firstPosIndex, out int lastPosIndex) {

            firstPosIndex = -1;
            lastPosIndex = -1;


            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] > 0)
                {
                    firstPosIndex = i;
                    break;
                }

            }

            for (int i = arr.Length-1; i >= 0 ; i--)
            {
                if (arr[i] > 0)
                {
                    lastPosIndex = i;
                    break;
                }

            }


            // проверка на наличие двух элементов 
            return firstPosIndex!= lastPosIndex;       
        
        }

        // сумма между первым и последним положительным элементами
        private static int SumArrFirstLastPositiv( int[] arr, int first, int last) {

            int sum = 0;

            for (int i = first+1; i < last; i++)
            {
                sum += arr[i];

            }

            return sum;
        }


        // вывод массива с подсветко элемнтов между первым и последним положительным
        private static void ShowArrFirstLastPositiv(string title, int[] arr, int first, int last) {

            Console.Write(title);

            int count = 0;

            ConsoleColor backgrounddefaultcolor = Console.BackgroundColor;
            ConsoleColor foregrounddefaultcolor = Console.ForegroundColor;

            for (int i = 0; i < arr.Length; i++)
            {
                if (i == first)
                {  
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.ForegroundColor = ConsoleColor.White;
                }

                if (i == last)
                {
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.ForegroundColor = ConsoleColor.White;
                }

                Console.Write($"  {arr[i],3}  ");

                Console.BackgroundColor = backgrounddefaultcolor;
                Console.ForegroundColor = foregrounddefaultcolor;

                count++;
                if (count % 6 == 0) Console.WriteLine();

                


            }

            Console.WriteLine();
        }

        #endregion

        #region Задание 3

        static void Task3() {

            Console.BackgroundColor = ConsoleColor.Cyan;
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.Clear();

            int n = rand.Next(10, 50);

            int[] arr;         // создание ссылки 
            arr = new int[n]; // выделение памяти, создание массива

            // заполнение массива случайными числами
            Fill(arr, -50, 50);

            // выведем этот массив
            Show($"\nМассив заполнен {n} случайными числами:\n", arr);

            // поиск минимального модулю и вывод в цвете
            int pos = MinAbs(arr);
            ShowArrMinAbs($"\nВывод массива с подсветкой минимального по модулю элемента:\n", arr, pos);

            int firstNegativ;
            bool flag = FirstNegativElem(arr, out firstNegativ);
            if (flag)
            {

                ShowAfterFirstNegativ($"\nВ массиве выделны цветом элементы после первого отрицательного.\nСумма модулей элементов после первого отрицательного равна {SumAfterFirstNegativ(arr, firstNegativ)} \n", arr, firstNegativ);
            }
            else
                Show($"\nВ массиве нет отрицательных элементов:\n", arr);


            int a= rand.Next(0, arr.Length/2);
            int b= rand.Next(a, arr.Length -1);

            SpecialSort($"\nМассив отсортирован по правилу - числа в диапазоне от {a} до {b} в начале", arr, a, b);
            

            Console.ReadKey(false);

        }


        // поиск индекса минимального элемета по модулю
        private static int MinAbs(int[] arr) {

            int result = 0;
            int abs = Math.Abs(arr[0]);

            for (int i = 1; i < arr.Length; i++)
            {
                if (Math.Abs(arr[i]) < abs) {

                    abs = Math.Abs(arr[i]);
                    result = i;

                }
            }

            return result;        
        }



        // вывод массива с подсветкой минимального по модулю элемента
        private static void ShowArrMinAbs(string title, int[] arr, int pos)
        {

            Console.Write(title);

            int count = 0;

            ConsoleColor backgrounddefaultcolor = Console.BackgroundColor;
            ConsoleColor foregrounddefaultcolor = Console.ForegroundColor;

            for (int i = 0; i < arr.Length; i++)
            {
                if (i == pos)
                {
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.ForegroundColor = ConsoleColor.White;
                }
                         
                Console.Write($"  {arr[i],3}  ");

                Console.BackgroundColor = backgrounddefaultcolor;
                Console.ForegroundColor = foregrounddefaultcolor;

                count++;
                if (count % 6 == 0) Console.WriteLine();

            }

            Console.WriteLine();
        }

        // поиск первого минимального элемента в массиве
        private static bool FirstNegativElem(int[] arr, out int pos) {

            pos = -1;           
            bool flag = false;


            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] < 0) {
                    pos = i;
                    flag = true;
                    break;
                }

            }

            return flag;        
        }


        //сумма модулей элементов массива полсе первого отрицательного
        private static int SumAfterFirstNegativ(int[] arr,int pos) {

            int sum = 0;

            for (int i = pos+1; i < arr.Length; i++)
            {
                sum += Math.Abs(arr[i]);
            }

            return sum;
        }


        // вывод массива с элементов, после минимального
        private static void ShowAfterFirstNegativ(string title, int[] arr, int pos)
        {

            Console.Write(title);

            int count = 0;

            ConsoleColor backgrounddefaultcolor = Console.BackgroundColor;
            ConsoleColor foregrounddefaultcolor = Console.ForegroundColor;
            
            for (int i = 0; i < arr.Length; i++)
            {
                if (i == pos + 1) {

                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.ForegroundColor = ConsoleColor.White;

                }


                Console.Write($"  {arr[i],3}  ");
                count++;
                if (count % 6 == 0) Console.WriteLine();

            }

            Console.BackgroundColor = backgrounddefaultcolor;
            Console.ForegroundColor = foregrounddefaultcolor;

            Console.WriteLine();
        }


        // Сортировка массива по правилу, чтобы переместить в начало массива все элементы, значение которых находится в диапазоне [a, b].
        private static void SpecialSort(string title, int[] arr, int a, int b) {

            Console.WriteLine($" {title}");

            int count = 0;

            for (int i = 0; i < arr.Length; i++)
            {


                if (arr[i] < a || arr[i] > b)
                {

                    for (int k = i + 1; k < arr.Length; k++)
                    {

                        if (arr[k] >= a && arr[k] <= b)
                        {

                            int temp = arr[k];
                            arr[k] = arr[i];
                            arr[i] = temp;

                            count++;
                            break;
                        }


                    }

                }
                else
                    count++;




            }


            if (count > 0)
            {
                Show($"\nМассив отсортирован:\n", arr);

                Console.WriteLine($" Всего элементов в диапазоне - {count}");

                Array.Resize(ref arr, count);

                Show($"\nРазмер массива изменен:\n", arr);
            }
            else
                Console.WriteLine($"\nВ массиве нет элементов в заданном диапазоне!\n");
            
        }



        #endregion

        #region Задание 4
        static void Task4() {

            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Clear();

            int m = rand.Next(5, 9);
            int n = rand.Next(6, 10);
            int lo = rand.Next(-20, 0);
            int hi = rand.Next(0, 20);

            int[,] matrix;         // создание ссылки 
            matrix = new int[m,n]; // выделение памяти, создание массива

            Fill(matrix, lo, hi);
            Show($"\nСоздана матрица размером {m} на {n} элементов.\nЗаполнена значениями от {lo} до {hi}\n\n", matrix );


            int x = rand.Next(0, n);

            bool flag=SwapColsNegativ(matrix, x);

            if(flag)
                Show($"Номер столбеца, который будет меняться {x};\nПосле перестановки.  \n\n", matrix);
            else
                Show($"\nНет подходящих елементов для перестановки\n\n", matrix);

            Sort(matrix);

            Console.ReadKey(false);

        }


        private static bool SwapColsNegativ(int[,] matr, int x) {

            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);
            bool flag = false;

            for (int i = 0; i < cols; i++)
            {
                for (int k = 0; k < rows; k++)
                {
                    if (matr[k,i] < 0)
                    {

                        flag = true;

                    }
                    else {

                        flag = false;
                        break;
                    
                    }

                }


                if (flag) {

                    Console.WriteLine($"Номер стобца, в котором только отрицательные элементы {i}");

                    for (int j = 0; j < rows; j++)
                    {
                        int temp = matr[j,i];
                        matr[j, i] = matr[j,x];
                        matr[j, x] = temp;


                    }

                        return true;
                }

            }

            return false;
        }


        private static void Sort(int[,] matr)
        {

            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);

            int[,] newMatrix;         // создание ссылки 
            newMatrix = new int[rows, cols]; // выделение памяти, создание массива

            int[] arr;         // создание ссылки 
            arr = new int[rows]; // выделение памяти, создание массива



            for (int i = 0 ; i < rows; i++)
            {
                
                arr[i]=matr[i, 0];

            }

            // краткая форма записи метода
            // Массив отсортирован по убыванию
            int Descend(int x, int y) => y.CompareTo(x);
            Array.Sort(arr, Descend);

            

           // Show($"\nМассив ", arr);


            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < arr.Length; j++)
                {
                    if (matr[i, 0] == arr[j])
                    {

                        newMatrix[j, 0] = arr[j];

                        for (int n = 1; n < cols; n++)
                        {
                            newMatrix[j, n] = matr[i, n];


                        }


                        j++;


                    }
                }
                



            }



            Show($"\nНет подходящих елементов для перестановки\n\n", newMatrix);

        }

        #endregion

        #region Дополнительные методы
        // заполнение массива случайными числами
        private static void Fill(int[] arr, int lo, int hi)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rand.Next(lo,hi);
            } // for i
        } // Fill
        private static void Fill(int[,] matr, int lo, int hi)
        {
            // matr.GetLength(0) - количество строк
            // matr.GetLength(1) - количество столбцов
            int rows = matr.GetLength(0); // строки
            int cols = matr.GetLength(1); // столбцы

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    matr[i, j] = rand.Next(lo, hi + 1);
        } // Fill

        private static void Show(string title, int[] arr)
        {
            Console.Write(title);

            int count = 0;
            
            void LocalShowItem(int item)
            {
                Console.Write($"  {item,3}  ");
                count++;
                if(count%6==0) Console.WriteLine();
            } // LocalShowItem

            Array.ForEach(arr, LocalShowItem);
          
            Console.WriteLine();
        } // Show
        // вывод прямоугольного массива
        private static void Show(string title, int[,] matr)
        {
            // Вывод заголовка
            Console.Write(title);

            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                    Console.Write("{0, 10}", matr[i, j]);
                Console.WriteLine();
            } // for i
        } // Show

        // Класс имяОбъекта = new Класс(параметры);
        static private Random rand = new Random();

        // Вспомогательный метод для вывода в заданных координатах окна консоли 
        static void WriteXY(int x, int y, string s)
        {
            Console.SetCursorPosition(x, y);
            Console.Write(s);
        } // WriteXY



        #endregion






    }
}
