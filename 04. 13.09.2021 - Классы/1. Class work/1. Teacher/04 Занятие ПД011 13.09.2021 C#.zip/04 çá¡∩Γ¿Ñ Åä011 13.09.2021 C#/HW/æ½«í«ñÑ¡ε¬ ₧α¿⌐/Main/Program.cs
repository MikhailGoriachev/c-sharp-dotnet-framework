﻿using System;


namespace Main
{
	internal class Program
	{
		private static readonly Random Rand = new Random();


		private static void ShowHomeworkInfo()
		{
			const string info = @"
Задача 1. Методы класса Math. Для значений, вводимых с клавиатуры рассчитайте значение выражений. 
(напоминаю, что при правильном кодировании выражений их значения совпадают примерно до 10го знака после запятой). 
Выражения взяты из учебника Павловской Т.А.:
	Вариант 9.
		См. формулу
	Вариант 11.
		См. формулу
Задача 2. Одномерный массив. В одномерном массиве, состоящем из n целых элементов:
	1 - Заполнить массив случайными числами
	2 - Вычислить минимальный элемент массива, вывести массив с выделением таких элементов цветом
	3 - Вычислить сумму элементов массива, расположенных между первым и последним положительными элементами, 
		вывести массив с выделением цветом таких элементов
	4 - Упорядочить массив так, чтобы элементы, равные нулю были в начале массива
Задача 3. Одномерный массив. В одномерном массиве, состоящем из n вещественных элементов:
	1 - Заполнить массив случайными числами
	2 - Вычислить индекс минимального по модулю элемента массива, вывести массив с выделением цветом найденного 
		элемента
	3 - Вычислить сумму модулей элементов массива, расположенных после первого отрицательного элемента, вывести 
		массив с выделением цветом слагаемых
	4 - Упорядочить массив так, чтобы переместить в начало массива все элементы, значение которых находится в 
		диапазоне [a, b]. При помощи метода Array.Resize() удалить все элементы, не входящие в этот диапазон
Задача 4. Прямоугольный массив. В матрице целых чисел размера M x N:
	1 - Заполнить матрицу случайными числами
	2 - Поменять местами столбец с заданным номером и первый из столбцов, содержащих только отрицательные элементы. 
		Если требуемых столбцов нет – вывести сообщение, не менять матрицу
	3 - Поменять местами строки матрицы так, чтобы первые элементы матрицы были упорядочены по убыванию 
";
			Console.WriteLine(info);
		}


		public static void Main(string[] args)
		{
			while (true)
			{
				Console.BackgroundColor = ConsoleColor.Gray;
				Console.ForegroundColor = ConsoleColor.Black;
				Console.Clear();
				Console.CursorVisible = false;

				ShowHomeworkInfo();

				Console.WriteLine("Нажмите соответствующую задаче цифру на клавиатуре(обычный ряд цифр, 0 для выхода) ");
				ConsoleKey key = Console.ReadKey(true).Key;
				switch (key)
				{
					case ConsoleKey.Escape:
					case ConsoleKey.NumPad0:
					case ConsoleKey.D0:
						Environment.Exit(0);
						break;

					case ConsoleKey.NumPad1:
					case ConsoleKey.D1:
						Task_1();
						break;

					case ConsoleKey.NumPad2:
					case ConsoleKey.D2:
						Task_2();
						break;

					case ConsoleKey.NumPad3:
					case ConsoleKey.D3:
						Task_3();
						break;

					case ConsoleKey.NumPad4:
					case ConsoleKey.D4:
						Task_4();
						break;
				}
			}
		}


#region Задача 1


		private static void Task_1()
		{
			Console.Clear();

			double maxValue = 20;
			double minValue = -20;

			Console.CursorVisible = true;
			Console.Write("Введите alpha: ");
			double alpha = double.Parse(Console.ReadLine());
			Console.Write("Введите beta: ");
			double beta = double.Parse(Console.ReadLine());
			Console.CursorVisible = false;

			Console.WriteLine("\n\n\n");

			(double z1, double z2) first = CalculateFirst(alpha, beta);
			Console.WriteLine("Решение Варианта 9:");
			Console.WriteLine($"\tz1 = {first.z1}, z2 = {first.z2}");

			(double z1, double z2) second = CalculateSecond(alpha, beta);
			Console.WriteLine("\n\nРешение Варианта 11:");
			Console.WriteLine($"\tz1 = {first.z1}, z2 = {first.z2}");

			Console.Write("\n\n\nНажмите любую клавишу для продолжения...");
			Console.ReadKey(false);
		}


		private static (double z1, double z2) CalculateFirst(double alpha, double beta)
		{
			double z1 =
				Math.Pow(Math.Cos(alpha) - Math.Cos(beta), 2) -
				Math.Pow(Math.Sin(alpha) - Math.Sin(beta), 2);

			double z2 =
				-4 * Math.Pow(Math.Sin((alpha - beta) / 2), 2) *
				Math.Cos(alpha + beta);

			return (z1, z2);
		}


		private static (double z1, double z2) CalculateSecond(double alpha, double beta)
		{
			double z1 =
				(1 - 2 * Math.Pow(Math.Sin(alpha), 2)) /
				(1 + Math.Sin(alpha * 2));

			double z2 =
				(1 - Math.Tan(alpha)) /
				(1 + Math.Tan(alpha));

			return (z1, z2);
		}


#endregion


#region Задача 2


		private static readonly (int min, int max) Task2RandomRanges = (-5, 5);
		private static readonly (int min, int max) Task2LengthRanges = (15, 30);
		private static readonly int                Task2ElemsInRow   = 8;


		/*
			Задача 2. Одномерный массив. В одномерном массиве, состоящем из n целых элементов:
				1 - Заполнить массив случайными числами
				2 - Вычислить минимальный элемент массива, вывести массив с выделением таких 
					элементов цветом
				3 - Вычислить сумму элементов массива, расположенных между первым и последним 
					положительными элементами, 
					вывести массив с выделением цветом таких элементов
				4 - Упорядочить массив так, чтобы элементы, равные нулю были в начале массива
		*/
		private static void Task_2()
		{
			Console.Clear();

			int   length = Rand.Next(Task2LengthRanges.min, Task2LengthRanges.max);
			int[] array  = new int[length];

			GenerateArray(array);

			FindMinAndShow(array);

			SumBetweenPositives(array);

			ZerosFirstSort(array);

			Console.Write("\n\n\nНажмите любую клавишу для продолжения...");
			Console.ReadKey(false);
		}


		/// 1 - Заполнить массив случайными числами
		private static void GenerateArray(int[] array)
		{
			int RandomGenerator() => Rand.Next(Task2RandomRanges.min, Task2RandomRanges.max);
			Fill(array, RandomGenerator);

			Console.WriteLine($"Сгенерированный массив (размер: {array.Length}):");
			Show(array, Task2ElemsInRow, SimpleShow);
		}


		/// 2 - Вычислить минимальный элемент массива, вывести массив с 
		/// выделением таких элементов цветом
		private static void FindMinAndShow(int[] array)
		{
			int min = Min(array);

			Console.WriteLine($"Минимальные элементы({min}) выделены цветом");

			string ColorMins(int elem, int _)
			{
				if (elem == min)
					Console.ForegroundColor = ConsoleColor.Red;

				return $"{elem}";
			}

			Show(array, Task2ElemsInRow, ColorMins);
		}


		/// Поиск минимума в массиве
		private static int Min(int[] array)
		{
			int returned = int.MaxValue;

			foreach (int i in array)
				if (i < returned)
					returned = i;

			return returned;
		}


		/// 3 - Вычислить сумму элементов массива, расположенных между 
		/// первым и последним  положительными элементами, 
		/// вывести массив с выделением цветом таких элементов
		private static void SumBetweenPositives(int[] array)
		{
			bool IsPositive(int elem) => elem > 0;

			int first = Array.FindIndex(array, IsPositive);
			int last  = Array.FindLastIndex(array, IsPositive);

			if (first == -1 || last == -1)
			{
				Console.WriteLine("В массиве нет положительных элементов\n\n");
				return;
			}

			int sum = Aggregate(array, first + 1, last);

			Console.WriteLine($"Первый положительный элемент имеет индекс {first} и значение {array[first]}");
			Console.WriteLine($"Последний положительный элемент имеет индекс {last} и значение {array[last]}");
			Console.WriteLine($"Сумма элементов между ними: {sum}\n");
			Console.WriteLine("Элементы соответствующие им по значениям, выделены цветом");

			string ColorPositives(int elem, int _)
			{
				if (elem == array[first] || elem == array[last])
					Console.ForegroundColor = ConsoleColor.Red;

				return $"{elem}";
			}

			Show(array, Task2ElemsInRow, ColorPositives);
		}


		/// Подсчет суммы элементов между begin и end индексами, [begin, end)
		private static int Aggregate(int[] array, int begin, int end)
		{
			int accumulate = 0;

			for (int i = begin; i < end; i++)
				accumulate += array[i];

			return accumulate;
		}


		/// 4 - Упорядочить массив так, чтобы элементы, равные нулю были в начале массива
		private static void ZerosFirstSort(int[] array)
		{
			int ZerosFirstComparer(int lhs, int rhs)
				=> lhs == 0 && rhs != 0 ? -1 :
				   lhs != 0 && rhs == 0 ? 1 : 0;

			Array.Sort(array, ZerosFirstComparer);

			Console.WriteLine("Массив отсортирован по правилу: нули впереди");
			Show(array, Task2ElemsInRow, SimpleShow);
		}


#endregion


#region Задача 3


		private static readonly (double min, double max) Task3RandomRanges = (-5, 5);
		private static readonly (int min, int max)       Task3LengthRanges = (15, 30);
		private static readonly int                      Task3ElemsInRow   = 8;
		private static readonly double                   Task3Tolerance    = 0.3;


		/*
		Задача 3. Одномерный массив. В одномерном массиве, состоящем из n вещественных элементов:
			1 - Заполнить массив случайными числами
			2 - Вычислить индекс минимального по модулю элемента массива, вывести массив с выделением 
				цветом найденного элемента
			3 - Вычислить сумму модулей элементов массива, расположенных после первого отрицательного 
				элемента, вывести массив с выделением цветом слагаемых
			4 - Упорядочить массив так, чтобы переместить в начало массива все элементы, значение 
				которых находится в диапазоне [a, b]. При помощи метода Array.Resize() удалить все элементы, 
				не входящие в этот диапазон 
		*/
		private static void Task_3()
		{
			Console.Clear();

			int      length = Rand.Next(Task3LengthRanges.min, Task3LengthRanges.max);
			double[] array  = new double[length];

			GenerateArray(array);

			FindMinAndShow(array);

			AbsSumAfterFirstNegative(array);

			SortByRangeAndRemoveOthers(array);

			Console.Write("\n\n\nНажмите любую клавишу для продолжения...");
			Console.ReadKey(false);
		}


		/// 1 - Заполнить массив случайными числами
		private static void GenerateArray(double[] array)
		{
			double RandomGenerator() => Rand.NextDouble() * (Task3RandomRanges.max - Task3RandomRanges.min) +
										Task3RandomRanges.min;

			Fill(array, RandomGenerator);

			Console.WriteLine($"Сгенерированный массив (размер: {array.Length}):");
			Show(array, Task3ElemsInRow, SimpleShow);
		}


		/// 2 - Вычислить индекс минимального по модулю элемента массива, 
		/// вывести массив с выделением цветом найденного элемента
		private static void FindMinAndShow(double[] array)
		{
			var min = Min(array);

			Console.WriteLine($"Минимальный элемент имеет индекс {min.index}, и значение {min.value:F}, он выделен цветом");

			string ColorMins(double elem, int index)
			{
				if (index == min.index)
					Console.ForegroundColor = ConsoleColor.Red;

				return $"{elem:F}";
			}

			Show(array, Task3ElemsInRow, ColorMins);
		}


		/// Поиск минимального вещественного числа
		private static (int index, double value) Min(double[] array)
		{
			(int index, double value) returned = (0, double.MaxValue);

			for (int i = 0; i < array.Length; i++)
			{
				double absValue = Math.Abs(array[i]);
				
				if (absValue < returned.value)
				{
					returned.value = absValue;
					returned.index = i;
				}
			}

			return returned;
		}


		/// 3 - Вычислить сумму модулей элементов массива, расположенных после первого 
		/// отрицательного элемента, вывести массив с выделением цветом слагаемых
		private static void AbsSumAfterFirstNegative(double[] array)
		{
			bool IsNegative(double value) => value < 0;

			int firstNegative = Array.FindIndex(array, IsNegative);
			if (firstNegative == -1)
			{
				Console.WriteLine("В массиве нет отрицательных элементов\n\n");
				return;
			}

			double sum = 0;
			for (int i = firstNegative + 1; i < array.Length; i++)
				sum += Math.Abs(array[i]);

			string MakeOutString(double value, int index)
			{
				if (index > firstNegative)
					Console.ForegroundColor = ConsoleColor.Red;

				return $"{value:F}";
			}

			Console.WriteLine($"Первый отрицательный элемент имеет индекс {firstNegative}");
			Console.WriteLine($"Со значением {array[firstNegative]:F}");
			Console.WriteLine($"Сумма модулей элементов после него - {sum:F}, элементы выделены цветом");
			Show(array, Task3ElemsInRow, MakeOutString);
		}


		/// 4 - Упорядочить массив так, чтобы переместить в начало массива все элементы, значение 
		/// которых находится в диапазоне [a, b]. При помощи метода Array.Resize() 
		/// удалить все элементы, не входящие в этот диапазон  
		private static void SortByRangeAndRemoveOthers(double[] array)
		{
			(double min, double max) range = (3, 4);

			int RangeFirstComparer(double lhs, double rhs)
			{
				if (Math.Abs(lhs - rhs) < 0.1)
					return 0;

				if (lhs >= range.min && lhs <= range.max
									  &&
										(rhs < range.min || rhs > range.max))
					return -1;

				return 1;
			}

			Array.Sort(array, RangeFirstComparer);

			int counter = 0;
			foreach (var d in array)
			{
				if (d >= range.min && d <= range.max)
					counter++;
			}

			Console.Write("Массив упорядочен по правилу: значения в диапазоне ");
			Console.WriteLine($"[{range.min:F}, {range.max:F}] в начало массива");
			Show(array, Task3ElemsInRow, SimpleShow);

			Console.WriteLine("Элементы не входящие в диапазон удалены при помощи Array.Resize()");
			Array.Resize(ref array, counter);
			Show(array, Task3ElemsInRow, SimpleShow);
		}


#endregion


#region Общие для Задачи 2 и Задачи 3 методы


		private static string SimpleShow(int elem, int _) => $"{elem}";

		private static string SimpleShow(double elem, int _) => $"{elem:F}";


		/// <summary>
		///     Вывод массива в консоль
		/// </summary>
		/// <param name="array">Массив для вывода</param>
		/// <param name="elemsInRow">Количество элементов массива в одной строке</param>
		/// <param name="makeOutString">
		///     Метод возвращающий строку для вывода,
		///     принимает очередной элемент массива
		/// </param>
		/// <typeparam name="T">Тип массива</typeparam>
		/// <exception cref="ArgumentNullException">Если массив или делегат являются null</exception>
		private static void Show<T>(T[] array, int elemsInRow, Func<T, int, string> makeOutString)
			where T : unmanaged
		{
			ConsoleColor oldColor = Console.ForegroundColor;

			for (int i = 0; i < array.Length; i++)
			{
				Console.Write($"{makeOutString(array[i], i),8} {((i + 1) % elemsInRow == 0 ? "\n" : "")}");
				Console.ForegroundColor = oldColor;
			}

			Console.WriteLine("\n\n");
		}


		/// <summary>
		///     Заполнение массива случайныи значениями
		/// </summary>
		/// <param name="array">Массив для заполнения</param>
		/// <param name="randomGenerator">Метод возвращающий случайный элемент</param>
		/// <typeparam name="T">Тип массива</typeparam>
		/// <exception cref="ArgumentNullException">Если любой из аргументов является null</exception>
		private static void Fill<T>(T[] array, Func<T> randomGenerator)
			where T : unmanaged
		{
			for (int i = 0; i < array.Length; i++) array[i] = randomGenerator();
		}


#endregion


#region Задача 4


		private static readonly (int min, int max) Task4RandomRanges = (-7, 3);
		private static readonly (int min, int max) Task4LengthRanges = (3, 6);


		/* Задача 4. Прямоугольный массив. В матрице целых чисел размера M x N:
		 1 - Заполнить матрицу случайными числами
		 2 - Поменять местами столбец с заданным номером и первый из столбцов, содержащих только
			 отрицательные элементы. Если требуемых столбцов нет – вывести сообщение, не менять матрицу
		 3 - Поменять местами строки матрицы так, чтобы первые элементы матрицы были упорядочены по убыванию 
		*/
		private static void Task_4()
		{
			Console.Clear();

			int    x      = Rand.Next(Task4LengthRanges.min, Task4LengthRanges.max);
			int    y      = Rand.Next(Task4LengthRanges.min, Task4LengthRanges.max);
			int[,] matrix = new int[x, y];

			GenerateMatrix(matrix);

			SwapColWithNegativeCol(matrix);

			SortBySwap(matrix);

			Console.Write("\n\n\nНажмите любую клавишу для продолжения...");
			Console.ReadKey(false);
		}


		/// 1 - Заполнить матрицу случайными числами
		private static void GenerateMatrix(int[,] matrix)
		{
			int rows = matrix.GetUpperBound(0) + 1;
			int cols = matrix.GetUpperBound(1) + 1;

			for (int i = 0; i < rows; i++)
				for (int j = 0; j < cols; j++)
					matrix[i, j] = Rand.Next(Task4RandomRanges.min, Task4RandomRanges.max);

			Console.Write($"Сгенерированная матрица (");
			Console.WriteLine($"общий размер: {matrix.Length}, колонок: {cols}, рядов: {rows}):");
			Show(matrix);
		}


		/// 2 - Поменять местами столбец с заданным номером и первый из столбцов, содержащих только
		/// отрицательные элементы. Если требуемых столбцов нет – вывести сообщение, не менять матрицу
		private static void SwapColWithNegativeCol(int[,] matrix)
		{
			int col = Rand.Next(0, matrix.GetUpperBound(1));

			int negativeCol = FindNegativeCol(matrix);

			if (negativeCol == -1 || col == negativeCol)
			{
				Console.WriteLine("Нет подходящего столбца или выбранный столбец совпадает с столбцом отрицательных чисел\n\n");
				return;
			}

			SwapCols(matrix, col, negativeCol);

			Console.WriteLine($"Сгенерированный индекс столбца для операции: {col}");
			Console.WriteLine($"Первый столбец содержащий только отрицательные элементы имеет индекс: {negativeCol}");
			Show(matrix);
		}


		/// Поиск первой колонки с отрицательными элементами 
		private static int FindNegativeCol(int[,] matrix)
		{
			int rows = matrix.GetUpperBound(0) + 1;
			int cols = matrix.GetUpperBound(1) + 1;

			for (int i = 0; i < cols; i++)
			{
				bool isFullNegative = false;

				for (int j = 0; j < rows; j++)
				{
					if (matrix[j, i] >= 0)
					{
						isFullNegative = false;
						break;
					}

					isFullNegative = true;
				}

				if (isFullNegative)
					return i;
			}

			return -1;
		}


		/// Смена колонок местами 
		private static void SwapCols(int[,] matrix, int lhs, int rhs)
		{
			int rows = matrix.GetUpperBound(0) + 1;

			for (int i = 0; i < rows; i++)
				Swap(ref matrix[i, lhs], ref matrix[i, rhs]);
		}


		/// 3 - Поменять местами строки матрицы так, чтобы первые элементы матрицы были упорядочены по убыванию
		private static void SortBySwap(int[,] matrix)
		{
			int cols = matrix.GetUpperBound(0) + 1;

			for (int i = 0; i < cols; i++)
			{
				bool isSorted = true;

				for (int j = 0; j < cols - i - 1; j++)
					if (matrix[j, 0] < matrix[j + 1, 0])
					{
						SwapRows(matrix, j, j + 1);
						isSorted = false;
					}

				if (isSorted)
					break;
			}

			Console.WriteLine($"Строки матрицы изменены чтобы первые элементы были упорядочены по убыванию");
			Show(matrix);
		}


		/// Смена строк местами
		private static void SwapRows(int[,] matrix, int lhs, int rhs)
		{
			int cols = matrix.GetUpperBound(1) + 1;

			for (int i = 0; i < cols; i++)
				Swap(ref matrix[lhs, i], ref matrix[rhs, i]);
		}


		/// Смена местами двух элементов 
		private static void Swap(ref int lhs, ref int rhs) => (lhs, rhs) = (rhs, lhs);


		/// Вывод матрицы в консоль 
		private static void Show(int[,] matrix)
		{
			int rows = matrix.GetUpperBound(0) + 1;
			int cols = matrix.GetUpperBound(1) + 1;

			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < cols; j++)
					Console.Write($"{matrix[i, j],8}");

				Console.WriteLine();
			}

			Console.WriteLine("\n\n");
		}


#endregion
	}
}
