#pragma once
#include "pch.h"

// ����� Memento - ����� ������� ��������� �� ������ MoneyOrder,
class Memento
{
	string fullName_;                  
	string senderAccountCode_;         
	string beneficiareysAccountCode_;  
	double transferAmount_;

public:
	Memento(string name, string senderAcc, string beneficiareysAcc, double transfermon)
	{
		fullName_ = name;
		senderAccountCode_ = senderAcc;
		beneficiareysAccountCode_ = beneficiareysAcc;
		transferAmount_ = transfermon;
	} 


	string getName() const { return fullName_; }
	void setName(string pName) { fullName_ = pName; }

	string getSenderAccountCode() const { return senderAccountCode_; }
	void setSenderAccountCode(string senderAcc) { senderAccountCode_ = senderAcc; }

	string getBeneficiareysAccountCode() const { return beneficiareysAccountCode_; }
	void setBeneficiareysAccountCode(string beneficiareysAcc) {

		beneficiareysAccountCode_ = beneficiareysAcc;
	}

	double getTransferAmount() const { return transferAmount_; }
	void setTransferAmount(double transfermon) { transferAmount_ = transfermon; }

};
