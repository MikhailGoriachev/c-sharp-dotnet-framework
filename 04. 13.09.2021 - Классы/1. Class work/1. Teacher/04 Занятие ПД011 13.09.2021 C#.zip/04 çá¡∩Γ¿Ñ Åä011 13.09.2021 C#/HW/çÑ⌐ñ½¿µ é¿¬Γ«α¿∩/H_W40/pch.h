﻿
#ifndef PCH_H
#define PCH_H

// TODO: add headers that you want to pre-compile here

#define _CRT_SECURE_NO_WARNINGS

// использование математических констант, современный стиль
#include <corecrt_math_defines.h>

#include <iostream>  // этот файл делает доступными инженерные функции  
#include <iomanip>   // для манипуляторов вывода setw(), setprecision()
#include <Windows.h>
#include <conio.h>

#include <sstream>   // для работы со строковым потоком вывода
#include <fstream>   // для работы со файловыми потоками ввода/вывода

#include <deque>
#include <stack>
#include <list>
#include <queue>
#include <vector>    // подключение класса vector

#include <iterator>    // итераторы
#include <functional>  // стандартные функторы 
#include <algorithm>   // стандартные алгоритмы
#include <numeric>     // некоторые алгоритмы, предназначенные для обработки числовых данных

#include <map>
#include <set>

using namespace std;

// объявление символической константы - кодовой страницы
#define CODE_PAGE 1251

// объявление константы - кода цвета в консоли
const short BLACK = 0b0000;
const short BLUE = 0b0001;
const short GREEN = 0b0010;
const short CYAN = 0b0011;
const short RED = 0b0100;
const short MAGENTA = 0b0101;
const short YELLOW = 0b0110;
const short GRAY = 0b0111;

const short LTBLACK = 0b1000;
const short LTBLUE = 0b1001;
const short LTGREEN = 0b1010;
const short LTCYAN = 0b1011;
const short LTRED = 0b1100;
const short LTMAGENTA = 0b1101;
const short LTYELLOW = 0b1110;
const short WHITE = 0b1111;

const short BLACK_ON_CYAN = BLACK | CYAN << 4;
const short BLUE_ON_CYAN = BLUE | CYAN << 4;
const short GREEN_ON_CYAN = GREEN | CYAN << 4;
const short CYAN_ON_CYAN = CYAN | CYAN << 4;
const short RED_ON_CYAN = RED | CYAN << 4;
const short MAGENTA_ON_CYAN = MAGENTA | CYAN << 4;
const short YELLOW_ON_CYAN = YELLOW | CYAN << 4;
const short GRAY_ON_CYAN = GRAY | CYAN << 4;

const short LTBLACK_ON_CYAN = LTBLACK | CYAN << 4;
const short LTBLUE_ON_CYAN = LTBLUE | CYAN << 4;
const short LTGREEN_ON_CYAN = LTGREEN | CYAN << 4;
const short LTCYAN_ON_CYAN = LTCYAN | CYAN << 4;
const short LTRED_ON_CYAN = LTRED | CYAN << 4;
const short LTMAGENTA_ON_CYAN = LTMAGENTA | CYAN << 4;
const short LTYELLOW_ON_CYAN = LTYELLOW | CYAN << 4;
const short WHITE_ON_CYAN = WHITE | CYAN << 4;

const short GRAY_ON_BLACK = GRAY | BLACK << 4;

const short YELLOW_ON_LTMAGENTA = YELLOW | LTMAGENTA << 4;

const short YELLOW_ON_BLACK = YELLOW | BLACK << 4;
const short CYAN_ON_BLACK = CYAN | BLACK << 4;
const short CYAN_ON_RED = CYAN | RED << 4;
const short YELLOW_ON_RED = YELLOW | RED << 4;
const short YELLOW_ON_MAGENTA = YELLOW | MAGENTA << 4;

const short BLACK_ON_LTYELLOW = LTYELLOW | BLACK << 4;

const short LTYELLOW_ON_LTMAGENTA = LTYELLOW | LTMAGENTA << 4;

const short LTYELLOW_ON_RED = LTYELLOW | RED << 4;

const short GRAY_ON_BLUE = GRAY | BLUE << 4;

const short WHITE_ON_RED = WHITE | RED << 4;

const short WHITE_ON_GREEN = WHITE | GREEN << 4;


const short mainColor = WHITE_ON_CYAN;      // основной цвет вывода
const short infoColor = MAGENTA_ON_CYAN;    // цвет вывода информационных сообщений
const short acctColor = RED_ON_CYAN;        // цвет активных клавиш в навигационной строке
const short hintColor = BLACK_ON_CYAN;      // цвет поясняющего текста в навигационной строке 
const short errColor = CYAN_ON_RED;         // цвет текста сообщения об ошибке
const short resColor = BLUE_ON_CYAN;         // вывод таблицы результатов
const short arrColor = GRAY_ON_CYAN;         // вывод массива 
const short headerColor = GREEN_ON_CYAN;  // вывод заголовков - сообщений перед массивами 

// команда очистки консоли
#define CLEAR "cls"

#endif //PCH_H

