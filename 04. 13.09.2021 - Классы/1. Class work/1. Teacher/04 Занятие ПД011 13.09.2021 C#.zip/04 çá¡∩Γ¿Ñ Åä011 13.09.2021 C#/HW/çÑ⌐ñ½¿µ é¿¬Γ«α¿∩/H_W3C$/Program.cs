﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace H_W3C_
{
    class Program
    {
        static void Main(string[] args)
        {
            // Настройка консоли 
            Console.Title = "Домашнее задание № 3";
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.CursorVisible = false;

            ConsoleKeyInfo cmd;
            // Меню выбора задачи
            do
            {
                Console.Clear();
                Console.SetCursorPosition(0, 3);
                Console.WriteLine("    Выберите пункт меню:\n");
                Console.WriteLine("    F5.Задача 1. Вариант 9 - сложное выражение");
                Console.WriteLine("    F6.Задача 1. Вариант 11 - сложное выражение");
                Console.WriteLine("    F7.Задача 2. Одномерный массив состоящий из целых элементов.");
                Console.WriteLine("    F8.Задача 3. Одномерный массив состоящий из вещественных элементов.");
                Console.WriteLine("    F9.Задача 4. Прямоугольный массив состоящий из целых элементов.");
                Console.WriteLine("    Esc. Выход");

                // Чтение кода клавиши
                cmd = Console.ReadKey(false);

                switch (cmd.Key)
                {
                    case ConsoleKey.F5: Variant9(); break;
                    case ConsoleKey.F6: Variant11(); break;
                    case ConsoleKey.F7: Task_2(); break;
                    case ConsoleKey.F8: Task_3(); break;
                    case ConsoleKey.F9: Task_4(); break;
                }// switch
            } while (cmd.Key != ConsoleKey.Escape);
         
        }// main

        #region Задача 1. Вариант 9
        // Вычисления по задаче Вариант 9
        // z_1=〖(cosα-cosβ)〗^2-〖(sinα-sinβ)〗^2;   z_2=-4〖sin〗^2  (α-β)/2∙cos⁡(α+β);
        private static void Variant9()
        {
            double a;
            Console.CursorVisible = true;
            Console.Write("\n Задача 1.\n\n Введите аргумент для вычисления :");
            double.TryParse(Console.ReadLine(), out a);
            Console.CursorVisible = false;

            double b = 2.4;

            // вычисления по варианту
            double z1 = Math.Pow((Math.Cos(a) - Math.Cos(b)), 2) -
                            Math.Pow((Math.Sin(a) - Math.Sin(b)), 2);

           double z2 = -4 * Math.Pow(Math.Sin((a - b) / 2d), 2) * Math.Cos(a + b);
         
            Console.WriteLine("    Вариант 9 - результат"); 
                Console.Write($"\n   Вычисления выполнены:\n" +
                    $"   z1 = {z1:n10}\n   z2 = {z2:n10}\n");

            Console.WriteLine("\n\n\nНажмите любую клавишу для продолжения.");
            Console.ReadKey(false);
        } // Variant9
        #endregion

        #region Задача 1. Вариант 11
        // Вычисления по задаче Вариант 11
        //z_1=(1-2∙〖sin〗^2 α)/(1+sin2α);  z_2=(1-tgα)/(1+tgα);
        private static void Variant11()
        {
            double a;
            Console.CursorVisible = true;
            Console.Write("\n Задача 1.\n\n Введите аргумент для вычисления :");
            double.TryParse(Console.ReadLine(), out a);
            Console.CursorVisible = false;


            // вычисления по варианту
            double z1 = (1d - 2d * Math.Pow(Math.Sin(a), 2)) / (1d + Math.Sin(2d * a));

            double z2 = (1d - Math.Tan(a)) / (1d + Math.Tan(a));

            Console.WriteLine("    Вариант 11 - результат");
            Console.Write($"\n   Вычисления выполнены:\n" +
                $"   z1 = {z1:n10}\n   z2 = {z2:n10}\n");

            Console.WriteLine("\n\n\nНажмите любую клавишу для продолжения.");
            Console.ReadKey(false);
        } // Variant11
        #endregion


        #region Задача 2
        /// <summary>
        /// Задача 2. Одномерный массив. 
        ///          В одномерном массиве, состоящем из n целых элементов:
        ///    •Заполнить массив случайными числами
        ///    •Вычислить минимальный элемент массива, 
        ///    вывести массив с выделением таких элементов цветом
        ///    •Вычислить сумму элементов массива, расположенных между первым и 
        ///    последним положительными элементами, вывести массив с выделением цветом таких элементов
        ///    •Упорядочить массив так, чтобы элементы, равные нулю были в начале массива
        /// </summary>

        private static void Task_2()
        {
            int n = 10;
            int[] arr = new int[n];
            // заполнение массива случайными числами
            Fill(arr, -5, 10);

            // выведем этот массив
            Show("\nМассив заполнен случайными числами:\n", arr);

            MinElem(arr);

            SumElem(arr);

            SortZeroFirst();

            Console.WriteLine("\n\n\nНажмите любую клавишу для продолжения.");
            Console.ReadKey(false);
        }// Task_2

        // вычислить минимальный элемент массива
        private static void MinElem(int[] arr)
        {
            int min = int.MaxValue;
            int minIndex = 0;
            for (int i = 0; i < arr.Length; i++) {
                if (min > arr[i])
                {
                    min = arr[i];
                    minIndex = i;
                }// if
            }// for i

            ShowArray("\n\nПоиск минимального элемента в массиве:\n", arr, minIndex);

        }// MinElem 

        // вычислить сумму элементов массива
        private static void SumElem(int[] arr)
        {
            int first = -1;
            int last = -1;
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] > 0)
                {
                    first = i;
                    break;
                }// if
            }// for i
            for (int i = arr.Length - 1; i > 0; i--)
            {
                if (arr[i] > 0)
                {
                    last = i;
                    break;
                }// if
            }// for i

            for (int i = first + 1; i <= last - 1; i++)
            {
                sum += arr[i];
            }// for i

            Show("\n\nВычислить сумму элементов массива, расположенных между первым и последним положительными элементами:\n", arr);
            Console.WriteLine($" \n Сумма элементов {sum} \n первый положительный элемент с индексом {first + 1}" +
                $" \n последний положительный элемент с индексом {last + 1} ");
        }// SumElem

        // упорядочить массив так, чтобы элементы, равные нулю были в начале массива
        private static void SortZeroFirst()
        {
            var xarr = new[] { 2, 7, 0, 5, 9, 24, 0, 8, 0, 12 };

            Array.Sort(xarr, SpecialComparator);
            Show("\nМассив отсортирован по правилу \"Нулевые элементы впереди\":\n", xarr);
        }// SortZeroFirst

        // компаратор для сортировки
        private static int SpecialComparator(int x, int y) =>
        x == 0 && y >= 0 ? -1 : x >= 0 && y == 0 ? 1 : 0;

        #endregion

        #region Задача 3
        /// <summary>
        ///Задача 3. Одномерный массив.
        ///       В одномерном массиве, состоящем из n вещественных элементов:
        ///      •Заполнить массив случайными числами
        ///      •Вычислить индекс минимального по модулю элемента массива, 
        ///     вывести массив с выделением цветом найденного элемента
        ///      •Вычислить сумму модулей элементов массива, 
        ///     расположенных после первого отрицательного элемента, 
        ///     вывести массив с выделением цветом слагаемых
        ///      •Упорядочить массив так, чтобы переместить в начало массива все элементы,
        ///      значение которых находится в диапазоне[a, b].
        ///      При помощи метода Array.Resize() удалить все элементы, не входящие в этот диапазон
        /// </summary>
        private static void Task_3()
        {
            int n = 10;
            double[] arr_dbl = new double[n];
            // заполнение массива случайными числами
            Fill_Dbl(arr_dbl, -5d, 10d);

            // выведем этот массив
            Show_Dbl("\nМассив заполнен случайными числами:\n", arr_dbl);

            MinIndex(arr_dbl);

            SumModul(arr_dbl);

            SortDiapazone(arr_dbl);

            Console.WriteLine("\n\n\nНажмите любую клавишу для продолжения.");
            Console.ReadKey(false);
        }// Task_3

        // вычислить индекс минимального по модулю элемента массива
        private static void MinIndex(double[] arr)
        {
            double min = double.MaxValue;
            int minIndex = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (Math.Abs(min) > Math.Abs(arr[i]))
                {
                    min = arr[i];
                    minIndex = i;
                }// if
            }// for i

            ShowArray_Dbl("\n\nВычислить индекс минимального по модулю элемента массива:\n", arr, minIndex);

        }// MinIndex 

        // вычислить сумму модулей элементов массива
        private static void SumModul(double[] arr)
        {
            int first = -1;

            double sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] < 0)
                {
                    first = i;
                    break;
                }// if
            }// for i

            for (int i = first + 1; i < arr.Length; i++)
            {
                sum += Math.Abs(arr[i]);

            }// for i

            Show_Dbl("\n\nВычислить сумму модулей элементов массива, расположенных после первого отрицательного элемента:\n", arr);
            Console.WriteLine($" \n Сумма элементов {sum:n2} \n первый отрицательный элемент с индексом : {first + 1}");
        }// SumModul

        // упорядочить массив так, чтобы переместить в начало массива все элементы,
        // значение которых находится в диапазоне [a, b]
        private static void SortDiapazone(double[] arr)
        {
            double a = -2d;
            double b = 6d;
            double temp;     // переменная для обмена элементов местами

            for (int i = 0; i < arr.Length - 1; i++)
            {
                for (int j= 0; j < arr.Length - i - 1; j++)
                {
                    if (arr[j] < a || arr[j] > b)
                    {
                        temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }// if
                }// for j
            }// for i
                
            Show_Dbl($"\nУпорядоченный массив, в начале массива все элементы в диапазоне от {a,2:n2} ..до {b,2:n2}\n", arr);
        }// SortDiapazone

        #endregion

        #region Задача 4
        /// <summary>
        ///Задача 4. Прямоугольный массив.
        ///      В матрице целых чисел размера M x N:
        ///       •Заполнить матрицу случайными числами
        ///       •Поменять местами столбец с заданным номером и первый из столбцов,
        ///      содержащих только отрицательные элементы.
        ///      Если требуемых столбцов нет – вывести сообщение, не менять матрицу
        ///       •Поменять местами строки матрицы так,
        ///       чтобы первые элементы матрицы были упорядочены по убыванию
        /// </summary>
        private static void Task_4()
        {
            int[,] matrix = new int[5, 7];

            Fill(matrix, -10, 2);
            Show("\nПрямоугольный массив заполнен случайными числами:\n", matrix);

            SwapColp(matrix);

            SwapRowSort(matrix);

            Console.WriteLine("\n\n\nНажмите любую клавишу для продолжения.");
            Console.ReadKey(false);
        }// Task_4

        // поменять местами столбец с заданным номером и первый из столбцов, содержащих только отриц. эл.
        private static void SwapColp(int[,] matr)
        {
            int row = matr.GetLength(0);
            int col = matr.GetLength(1);
            int column = -1;
            int temp = 0;


            for (int j  = 0; j < col; j ++)
            {
                
                for (int i = 0; i < row; i++)
                {
                    if (matr[i, j] > 0) break;
                    if(i == row)
                    {
                        column = j;
                        break;
                    }// if
                }// for i

            }// for j
            
            if(column >= 0)
                for (int i = 0; i < col; i++)
                {
                    temp = matr[i, col - 1];
                    matr[i, col - 1] = matr[i, column];
                    matr[i, column] = temp;
                }// for i
            
            Show("\nПоменять местами столбец с заданным номером и первый из столбцов, содержащих только отрицательные элементы\n", matr);
        }// SwapColp

        // поменять местами строки матрицы, первые элементы матрицы упорядочены по убыванию
        private static void SwapRowSort(int[,] matr)
        {
            int row = matr.GetLength(0);
            int col = matr.GetLength(1);
            bool exit;     // ставим флаг, после каждого обмена строк и продолжаем сортировку по индексу i
            bool change;   // если надо поменять местами строки матрицы
            int temp;

            for (int i = 0; i < row; i++)
            {
                exit = true;
                for (int j = 0; j < row - i- 1; j++)
                {
                    change = false;
                    for (int k = 0; k < col; k++)
                    {
                        if (matr[j, k] < matr[j + 1, k])
                        {
                            change = true;
                            break;
                        }
                        else if (matr[j, k] > matr[j + 1, k]) break;
                    }// for k
                    if (change)
                    {
                        for (int k = 0; k < col; k++)
                        {
                            temp = matr[j, k];
                            matr[j, k] = matr[j + 1, k];
                            matr[j + 1, k] = temp;
                        }// for k
                        exit = false;
                    }// if 

                }// for j

                if (exit)
                    break;
            }// for i

            Show("\nПоменять местами строки матрицы, первые элементы матрицы упорядочены по убыванию\n", matr);
        }// SwapRowSort

        #endregion

        #region Заполнение и вывод массива
        // заполнение массив случайными числами
        private static void Fill(int[] arr, int lo, int hi)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rand.Next(lo, hi);
            } // for i
        } // Fill

        private static void Fill_Dbl(double[] arr, double lo, double hi)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = lo + (hi - lo) * rand.NextDouble();
            } // for i
        } // Fill_Dbl

        // заполнение прямоугольного массива
        private static void Fill(int[,] matr, int lo, int hi)
        {
            int rows = matr.GetLength(0); // строки
            int cols = matr.GetLength(1); // столбцы

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    matr[i, j] = rand.Next(lo, hi + 1);
        } // Fill

        // вывод массива в консоль
        private static void Show(string title, int[] arr)
        {
            Console.Write(title);

            void LocalShowItem(int item) =>
            Console.Write($"{item, 8}");

            Array.ForEach(arr, LocalShowItem);

            Console.WriteLine();
        } // Show

        private static void Show_Dbl(string title, double[] arr)
        {
            Console.Write(title);

            void LocalShowItem(double item) =>
            Console.Write($"{item,10:n2}");

            Array.ForEach(arr, LocalShowItem);

            Console.WriteLine();
        } // Show_Dbl

        // вывод прямоугольного массива
        private static void Show(string title, int[,] matr)
        {
            // Вывод заголовка
            Console.Write(title);

            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                    Console.Write("{0, 10}", matr[i, j]);
                Console.WriteLine();
            } // for i
        } // Show

        private static void ShowArray(string title, int[] arr, int minIndex)
        {
            Console.Write(title);

            for (int i = 0; i < arr.Length; i++)
            {
                if (i == minIndex) Console.ForegroundColor = ConsoleColor.Red;
                else Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"{arr[i],8}");
            }// for i
            Console.ForegroundColor = ConsoleColor.White;
        } // ShowArray

        private static void ShowArray_Dbl(string title, double[] arr, int minIndex)
        {
            Console.Write(title);

            for (int i = 0; i < arr.Length; i++)
            {
                if (i == minIndex) Console.ForegroundColor = ConsoleColor.Red;
                else Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"{arr[i],10:n2}");
            }// for i
            Console.ForegroundColor = ConsoleColor.White;
        } // ShowArray
        #endregion

        private static Random rand = new Random();
    }// class Program
}
