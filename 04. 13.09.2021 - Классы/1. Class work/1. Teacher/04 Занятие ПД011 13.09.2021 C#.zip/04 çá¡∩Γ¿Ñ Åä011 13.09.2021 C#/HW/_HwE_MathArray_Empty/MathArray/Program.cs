﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Задача 1. Методы класса Math.
 * Для значений, вводимых с клавиатуры, рассчитайте значение выражений (при
 * правильном кодировании выражений их значения совпадают примерно до 10го
 * знака после запятой). Выражения взяты из учебника Павловской Т.А.:
 * Вариант 9.
 * z_1=〖(cosα-cosβ)〗^2-〖(sinα-sinβ)〗^2;   z_2=-4〖sin〗^2  (α-β)/2∙cos⁡(α+β);
 * Вариант 11.
 * z_1=(1-2∙〖sin〗^2 α)/(1+sin2α);  z_2=(1-tgα)/(1+tgα);
 *
 * Задача 2. Одномерный массив.
 * В одномерном массиве, состоящем из n целых элементов:
 *     • Заполнить массив случайными числами
 *     • Вычислить минимальный элемент массива, вывести массив с выделением
 *       таких элементов цветом
 *     • Вычислить сумму элементов массива, расположенных между первым и
 *       последним положительными элементами, вывести массив с выделением
 *       цветом таких элементов
 *     • Упорядочить массив так, чтобы элементы, равные нулю были в начале
 *       массива
 *
 * Задача 3. Одномерный массив.
 * В одномерном массиве, состоящем из n вещественных элементов:
 * 	   • Заполнить массив случайными числами
 * 	   • Вычислить индекс минимального по модулю элемента массива, вывести
 *       массив с выделением цветом найденного элемента
 * 	   • Вычислить сумму модулей элементов массива, расположенных после первого
 *       отрицательного элемента, вывести массив с выделением цветом слагаемых
 * 	   • Упорядочить массив так, чтобы переместить в начало массива все
 *       элементы, значение которых находится в диапазоне [a, b]. При помощи
 *       метода Array.Resize() удалить все элементы, не входящие в этот
 *       диапазон
 *
 * Задача 4. Прямоугольный массив.
 * В матрице целых чисел размера M x N:
 * 	   • Заполнить матрицу случайными числами
 * 	   • Поменять местами столбец с заданным номером и первый из столбцов,
 *       содержащих только отрицательные элементы. Если требуемых столбцов
 *       нет – вывести сообщение, не менять матрицу
 *     • Поменять местами строки матрицы так, чтобы первые элементы матрицы
 *       были упорядочены по убыванию
 * 
 */

namespace MathArray
{
    class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 13.09.2021 - методы и константы класса Math, массивы - класс Array";
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.CursorVisible = false;

            // главный цикл работы приложения 
            while (true) {
                ShowNavBar();
                ShowText();

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                switch (key) {
                    // решение задачи 1 назначено на клавишу F5
                    case ConsoleKey.F5:
                        Task1();
                        break;

                    // решение задачи 2 назначено на клавишу F6
                    case ConsoleKey.F6:
                        Task2();
                        break;

                    // решение задачи 3 назначено на клавишу F7
                    case ConsoleKey.F7:
                        Task3();
                        break;

                    // решение задачи 4 назначено на клавишу F8
                    case ConsoleKey.F8:
                        Task4();
                        break;

                    // выход из приложения назначен на клавишу F10
                    case ConsoleKey.F10:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Console.SetCursorPosition(0, Console.WindowHeight - 1);
                        Console.CursorVisible = true;
                        return;
                } // switch
            } // while
        } // Main


        #region Вспомогательные методы
        // формирует и выводит верхнюю строку окна консоли для метода Main
        private static void ShowNavBar() {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string[] hotKeys = {"F5",       "F6",       "F7",       "F8",       "F10"};
            string[] descs   = {"Задача 1", "Задача 2", "Задача 3", "Задача 4", "Выход" };

            // при выводе немного используем методы класса strring :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, " ".PadRight(Console.WindowWidth), Console.ForegroundColor);

            // Выводим текст с функциональными клавишами в верхнюю строку
            for (int i = 0, x = 2; i < hotKeys.Length; i++) {
                WriteXY(x, 0, hotKeys[i], ConsoleColor.Red);
                
                // позиция вывода описания - к позиции аваод хот-кея добавить
                // длину строки-хоткея и учесть пробел
                int descPos = x + hotKeys[i].Length + 1;
                WriteXY(descPos, 0, descs[i], ConsoleColor.Black);

                // вычисление следующей позиции вывода:
                // к позиции вывода описания добавить ее длину и промежуток до следующего вывода
                x = descPos + descs[i].Length + 3;
            } // for i

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBar

        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line) {
            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;
            ConsoleColor oldFgColor = Console.ForegroundColor;

            // при выводе немного используем методы класса strring :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
            Console.ForegroundColor = oldFgColor;
        } // ShowNavBarTask


        // вывод текста задания в консоль
        private static void ShowText(int taskNumber = -1) {
            string[] text = {@"
             Задача 1. Методы класса Math.
             Для значений, вводимых с клавиатуры, рассчитайте значение выражений

             Вариант 9.
             z_1 = (cos(a) - cos(b))^2 - (sin(a) - sin(b))^2;  
             z_2 = -4*sin^2(a - b)/(2*cos⁡(a + b));

             Вариант 11.
             z_1 = (1 - 2*sin^2(a)) / (1 + sin(2a));          
             z_2 = (1 - tg(a)) / (1 + tg(a));
             ",  // 0

             @"
             Задача 2. Одномерный массив.
             Заполнить одномерный массив, состоящий из n целых элементов случайными 
             числами, выполнить обработки, упрядочить массив по правилу ""нули впереди""
             ",  // 1

             @"
             Задача 3. Одномерный массив.
             Заполнить одномерный массив, состоящем из n вещественных элементов случайными
             числами, выполнить обработки, упорядочить массив по правилу ""числа из [a, b]
             в конец массива"", удалить такие числа при помощи Array.Resize()
             ",

             @"
             Задача 4. Прямоугольный массив.
             Заполнить матрицу целых чисел размера M x N случайными числами, поменять 
             местами столбцы по заданному правилу, переставить строки так, чтобы их  
             первые элементы были упорядочены по убыванию
            "};

            WriteXY(0, 3,  taskNumber < 1?string.Join("\n", text):text[taskNumber-1], ConsoleColor.Gray);
        } // ShowText

        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY
        #endregion


        #region Task1 - решение задачи 1
        public static void Task1() {
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 1. Расчет выражений с использованием класса Math");
            ShowText(1);

            // одидать нажатия любой клавиши, не отображать нажатую клавишу
            // в окне консоли
            Console.ReadKey(true);
        } // Task1
        #endregion


        #region Task2 - решение задачи 2
        public static void Task2() {
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 2. Обработка одномерного целочисленного массива");
            ShowText(2);

            // одидать нажатия любой клавиши, не отображать нажатую клавишу
            // в окне консоли
            Console.ReadKey(true);
        } // Task2
        #endregion



        #region Task3 - решение задачи 3
        public static void Task3() {
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 3. Обработка одномерного вещественного массива");
            ShowText(3);

            // одидать нажатия любой клавиши, не отображать нажатую клавишу
            // в окне консоли
            Console.ReadKey(true);
        } // Task3
        #endregion


        #region Task4 - решение задачи 4
        public static void Task4() {
            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask("  Задача 4. Обработка прямоугольного целочисленного массива");
            ShowText(4);

            // одидать нажатия любой клавиши, не отображать нажатую клавишу
            // в окне консоли
            Console.ReadKey(true);
        } // Task4
        #endregion

    } // class Program
}
