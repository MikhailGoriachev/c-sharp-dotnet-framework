﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction

namespace HW_3
{
    class Program
    {
        static void Main(string[] args){
            Console.Title = "HW на 13.09.21";
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.CursorVisible = false;

            // главный цикл работы приложения 
            while (true){
                Console.Clear();
                ShowNavBar();
                ShowText();

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                switch (key)
                {
                    // решение задачи 1 назначено на клавишу F1
                    case ConsoleKey.F1:
                        DoTask1();
                        break;

                    // решение задачи 2 назначено на клавишу F2
                    case ConsoleKey.F2:
                       DoTask2();
                        break;

                    // решение задачи 3 назначено на клавишу F3
                    case ConsoleKey.F3:
                        DoTask3();
                        break;

                    // решение задачи 4 назначено на клавишу F4
                    case ConsoleKey.F4:
                        DoTask4();
                        break;

                    // выход из приложения назначен на клавишу F10
                    case ConsoleKey.F10:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Console.SetCursorPosition(0, Console.WindowHeight - 1);
                        Console.CursorVisible = true;
                        return;
                } // switch
            } // while
        } // Main
        #region Вспомогательные методы
        // выводим верхнюю строку
        private static void ShowNavBar(){
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст с функциональными клавишами в верхнюю строку
            WriteXY(2, 0, "F1", ConsoleColor.Red);
            WriteXY(5, 0, "Задача 1", ConsoleColor.Black);

            WriteXY(16, 0, "F2", ConsoleColor.Red);
            WriteXY(19, 0, "Задача 2", ConsoleColor.Black);

            WriteXY(30, 0, "F3", ConsoleColor.Red);
            WriteXY(33, 0, "Задача 3", ConsoleColor.Black);

            WriteXY(30, 0, "F4", ConsoleColor.Red);
            WriteXY(33, 0, "Задача 4", ConsoleColor.Black);

            WriteXY(45, 0, "F10", ConsoleColor.Red);
            WriteXY(49, 0, "Выход", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBar

        // вывод текста задания в консоль
        private static void ShowText(){
            string text = @"
            Задача 1. Методы класса Math. Для значений, вводимых с клавиатуры рассчитайте значение выражений.
            (напоминаю, что при правильном кодировании выражений их значения совпадают примерно до 10го знака 
            после запятой)

            Задача 2. Одномерный массив. В одномерном массиве, состоящем из n целых элементов:
            •	Заполнить массив случайными числами
            •	Вычислить минимальный элемент массива, вывести массив с выделением таких элементов цветом
            •	Вычислить сумму элементов массива, расположенных между первым и последним положительными элементами,
                вывести массив с выделением цветом таких элементов
            •	Упорядочить массив так, чтобы элементы, равные нулю были в начале массива

            Задача 3. Одномерный массив. В одномерном массиве, состоящем из n вещественных элементов:
            •	Заполнить массив случайными числами
            •	Вычислить индекс минимального по модулю элемента массива, вывести массив с выделением цветом найденного элемента
            •	Вычислить сумму модулей элементов массива, расположенных после первого отрицательного элемента, вывести массив с выделением цветом слагаемых
            •	Упорядочить массив так, чтобы переместить в начало массива все элементы, значение которых находится в диапазоне [a, b].
                При помощи метода Array.Resize() удалить все элементы, не входящие в этот диапазон
               
            Задача 4. Прямоугольный массив. В матрице целых чисел размера M x N:
            •	Заполнить матрицу случайными числами
            •	Поменять местами столбец с заданным номером и первый из столбцов, содержащих только отрицательные элементы. 
                Если требуемых столбцов нет – вывести сообщение, не менять матрицу
            •	Поменять местами строки матрицы так, чтобы первые элементы матрицы были упорядочены по убыванию
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowText

        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY
        #endregion

        #region Описания заданий
        private static void ShowTextTask1(){
            string text = @"
            Задача 1. Методы класса Math. Для значений, вводимых с клавиатуры рассчитайте значение выражений.
            (напоминаю, что при правильном кодировании выражений их значения совпадают примерно до 10го знака 
            после запятой)
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask1
        private static void ShowTextTask2(){
            string text = @"
             Задача 2. Одномерный массив. В одномерном массиве, состоящем из n целых элементов:
            •	Заполнить массив случайными числами
            •	Вычислить минимальный элемент массива, вывести массив с выделением таких элементов цветом
            •	Вычислить сумму элементов массива, расположенных между первым и последним положительными элементами,
                вывести массив с выделением цветом таких элементов
            •	Упорядочить массив так, чтобы элементы, равные нулю были в начале массива
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask2
        private static void ShowTextTask3(){
            string text = @"
            Задача 3.Одномерный массив.В одномерном массиве, состоящем из n вещественных элементов:
            •	Заполнить массив случайными числами
            •	Вычислить индекс минимального по модулю элемента массива, вывести массив с выделением цветом найденного элемента
            •	Вычислить сумму модулей элементов массива, расположенных после первого отрицательного элемента, вывести массив с выделением цветом слагаемых
            •	Упорядочить массив так, чтобы переместить в начало массива все элементы, значение которых находится в диапазоне[a, b].
                При помощи метода Array.Resize() удалить все элементы, не входящие в этот диапазон
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask3
        private static void ShowTextTask4(){
            string text = @"
            Задача 4. Прямоугольный массив. В матрице целых чисел размера M x N:
            •	Заполнить матрицу случайными числами
            •	Поменять местами столбец с заданным номером и первый из столбцов, содержащих только отрицательные элементы. 
                Если требуемых столбцов нет – вывести сообщение, не менять матрицу
            •	Поменять местами строки матрицы так, чтобы первые элементы матрицы были упорядочены по убыванию
            ";
            WriteXY(0, 3, text, ConsoleColor.Gray);
        } // ShowTextTask4
        #endregion

        #region Информационные сообщения
        // Вывод информационного сообщения в верхнюю строку экрана
        private static void ShowNavBarTask1(){
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 1", ConsoleColor.Red);
            WriteXY(11, 0, "Для значений, вводимых с клавиатуры рассчитайте значение выражений, 0 - для выхода", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask1

        private static void ShowNavBarTask2(){
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 2", ConsoleColor.Red);
            WriteXY(11, 0, "Задания для одномерного целого массива, 0 - для выхода", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask2

        private static void ShowNavBarTask3(){
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 2", ConsoleColor.Red);
            WriteXY(11, 0, "Задания для одномерного вещественного массива, 0 - для выхода", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask3

        private static void ShowNavBarTask4(){
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string header = new string(' ', Console.WindowWidth);

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.Write(header);

            // Выводим текст в верхнюю строку
            WriteXY(2, 0, "Задача 2", ConsoleColor.Red);
            WriteXY(11, 0, "Задания для матрицы, 0 - для выхода", ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
        } // ShowNavBarTask4

        #endregion

        #region Задача 1
        private static void DoTask1(){
            string response = "1"; // переменная для получения ввода пользователя

            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask1();
            ShowTextTask1();

            while (true){
                // ввод и парсинг числа
                response = Interaction.InputBox(
                    "Введите 1 число или 0 для выхода",
                    "Задача 1. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                bool succcess = double.TryParse(response, out double number1);
                if (!succcess)
                {
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if
                // проверка условия выхода из цикла
                if (number1 == 0) break;

                response = Interaction.InputBox(
                   "Введите 2 число или 0 для выхода",
                   "Задача 1. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                succcess = double.TryParse(response, out double number2);
                if (!succcess){
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if
                // проверка условия выхода из цикла
                if (number2 == 0) break;

                double res1 = Math.Pow((Math.Cos(number1) - Math.Cos(number2)), 2) - Math.Pow((Math.Sin(number1) - Math.Sin(number2)), 2);

                double res2 = -4*Math.Pow(Math.Sin((number1-number2)/2), 2)*Math.Cos(number1+number2);

                Console.WriteLine("\n\t\tВариант 9.");
                Console.WriteLine("\t\tОтвет 1 = "+res1);
                Console.WriteLine("\t\tОтвет 2 = "+res2);
                res1 = (1 - 2 * Math.Pow(Math.Sin(number1), 2)) / (1 + Math.Sin(2*number1));
                res2 = (1-Math.Tan(number1))/(1+Math.Tan(number1));
                Console.WriteLine("\n\t\tВариант 11.");
                Console.WriteLine("\t\tОтвет 1 = "+ res1);
                Console.WriteLine("\t\tОтвет 2 = "+ res2);
            } // while
        } // DoTask1
        #endregion

        #region Задача 2
        private static void DoTask2(){
            string response = "-10"; // переменная для получения ввода пользователя
                                     // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask2();
            ShowTextTask2();
            while (true){
                // проверка условия выхода из цикла
                response = Interaction.InputBox(
                     "Введите число low или 0 для выхода",
                     "Задача 2. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;
                bool succcess = int.TryParse(response, out int low);
                if (!succcess){
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

                response = Interaction.InputBox(
                    "Введите число high или 0 для выхода",
                    "Задача 2. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;
                succcess = int.TryParse(response, out int high);
                if (!succcess){
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

                int n = 10;
                int[] matr;
                matr = new int[n];
                Fill(matr, low, high);
                Show("\n\n\t\tМассив целых элементов\n", matr);

                Console.Write("\n\n\t\tМассив с выделенными минимальными элементами\n\t\t");

                int iMin = matr[0];

                for(int i = 0; i < matr.Length; i++)
                    if (matr[i] < iMin) iMin = matr[i];
                ConsoleColor oldColor = Console.ForegroundColor;
                for (int i = 0; i < matr.Length; i++){
                    Console.ForegroundColor = matr[i] == iMin ?ConsoleColor.Yellow:oldColor;
                    Console.Write($"{matr[i]} ");
                } // for i
                Console.ForegroundColor = oldColor;

                int summa = 0, iMax;
                // находим первый положительный элемент(его индекс)
                iMin = FirstElem(matr);
                // находим последний положительный элемент(его индекс)
                iMax = LastElem(matr);

                summa = Summa(matr, iMin, iMax);

                Console.Write("\n\n\t\tМассив целых элементов\n\t\t");
                for (int i = 0; i < matr.Length; i++){
                    Console.ForegroundColor = (iMin < i && i < iMax) ? ConsoleColor.Yellow : oldColor;
                    Console.Write($"{matr[i]} ");
                } // for i
                Console.ForegroundColor = oldColor;
                Console.Write("\t\tСумма = " + summa);

                // Компаратор для сортировки
                int SpecialComparator(int x, int y) =>
                 x == 0 && y != 0 ? -1 : x != 0 && y == 0 ? 1 : 0;
                Array.Sort(matr, SpecialComparator);
                Console.Write("\n\n");
                Show("\n\n\t\tМассив целых элементов", matr);

            } // while
        } // DoTask1

        private static int Summa(int []matr, int min, int max){
            int sum = 0;
            for (int i = 0; i < matr.Length; i++)
                if (min < i && i < max)
                    sum += matr[i];
            return sum;
        } // Summa

        private static int FirstElem(int[] matr){
            for (int i = 0; i < matr.Length; i++)
                if (matr[i] >= 0) return i;
            return -1;
        } // FirstElem

        private static int LastElem(int[] matr){
            for (int i = matr.Length-1; i >=0; i--)
                if (matr[i] >= 0) return i;
            return -1;
        } // LastElem

        // заполнение массив случайными числами
        private static void Fill(int[] matr, int lo, int hi){
            for (int i = 0; i < matr.Length; i++)
                matr[i] = lo + rand.Next() % (hi - lo + 1);
        } // Fill
        private static void Show(string title, int[] matr){
            Console.Write(title);
            Console.Write("\n\t\t");
            void LocalShowItem(int item) => Console.Write($"{item}"+ " ");
            Array.ForEach(matr, LocalShowItem);
            Console.WriteLine();
        } // Show
        #endregion

        #region Задача 3
        private static void DoTask3(){
            string response = "-10"; // переменная для получения ввода пользователя

            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask3();
            ShowTextTask3();

            while (true){
                // ввод и парсинг числа
                response = Interaction.InputBox(
                    "Введите число low или 0 для выхода",
                    "Задача 3. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                bool succcess = double.TryParse(response, out double low);
                if (!succcess){
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

                response = Interaction.InputBox(
                   "Введите число high или 0 для выхода",
                   "Задача 3. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                succcess = double.TryParse(response, out double high);
                if (!succcess){
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

                ConsoleColor oldColor = Console.ForegroundColor;

                int n = 10;
                double[] matr;
                matr = new double[n];
                FillDouble(matr, low, high);
                ShowDouble("\n\t\tВещественный массив\n\t\t", matr);

                int ModulMin = MinModulElemIndex(matr);
                Console.Write("\n\t\tВещественный массив, с минимальными по модулю элементом\n\t\t");
                for (int i = 0; i < matr.Length; i++){
                    Console.ForegroundColor = (i == ModulMin) ? ConsoleColor.Yellow : oldColor;
                    Console.Write($"{matr[i],10:f2}");
                } // for i
                Console.ForegroundColor = oldColor;

                int firstNeg = FirstNegElem(matr);
                double summa = SummaModul(matr, firstNeg);

                Console.Write("\n\t\tВещественный массив\n\t\t");
                for (int i = 0; i < matr.Length; i++){
                    Console.ForegroundColor = (i > firstNeg) ? ConsoleColor.Yellow : oldColor;
                    Console.Write($"{matr[i],10:f2}");
                } // for i
                Console.ForegroundColor = oldColor;
                Console.Write("\n\t\tСумма = " + summa);

                response = Interaction.InputBox(
                    "Введите число high или 0 для выхода",
                    "Задача 3. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                succcess = double.TryParse(response, out double a);
                if (!succcess){
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

                response = Interaction.InputBox(
                    "Введите число high или 0 для выхода",
                    "Задача 3. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                succcess = double.TryParse(response, out double b);
                if (!succcess){
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

            } // while
        } // DoTask3

        private static double SummaModul(double[] matr, int firstNeg){
            double sum = 0d;
            for (int i = 0; i < matr.Length; i++)
                if (i > firstNeg) sum += Math.Abs(matr[i]);
            return sum;
        } // SummaModul

        private static int FirstNegElem(double[] matr){
            for (int i = 0; i < matr.Length; i++)
            if(matr[i]<0d)
                    return i;
            return -1;
        } // FirstNegElem

        private static int MinModulElemIndex(double[] matr){
            int index = 0;
            for (int i = 0; i < matr.Length; i++)
                if (Math.Abs(matr[i]) < index) index = i;

            return index;
        } // MinModulElemIndex

        private static void FillDouble(double[] matr, double lo, double hi){
            for (int i = 0; i < matr.Length; i++)
                matr[i] = lo + (hi - lo) * rand.NextDouble();
        } // Fill

        private static void ShowDouble(string title, double[] matr){
            Console.Write(title);
            void LocalShowItem(double item) => Console.Write($"{item,10:f2}");
            Array.ForEach(matr, LocalShowItem);

            Console.WriteLine();
        } // Show
        #endregion

        #region Задача 4
        private static void DoTask4(){
            string response = "-10"; // переменная для получения ввода пользователя

            // оформление экрана вывода
            Console.Clear();
            ShowNavBarTask1();
            ShowTextTask1();

            while (true){
                // ввод и парсинг числа
                response = Interaction.InputBox(
                    "Введите число low",
                    "Задача 4. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                bool succcess = int.TryParse(response, out int low);
                if (!succcess){
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

                response = Interaction.InputBox(
                   "Введите число high",
                   "Задача 4. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                succcess = int.TryParse(response, out int high);
                if (!succcess){
                    Interaction.MsgBox(
                    "Вы ввели не число\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if


                int[,] matr = new int[5, 5];

                FillMatr(matr, low, high);
                Show("\n\t\tПрямоугольный массив:\n", matr);

                response = Interaction.InputBox(
                    "Введите столбец",
                    "Задача 4. Ввод", response);
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (response == "") break;

                succcess = int.TryParse(response, out int num1);
                if (!succcess||num1<0||num1>=matr.GetLength(1)){
                    Interaction.MsgBox(
                    "Вы ввели что-то не то\nПовторите ввод, пожалуйтса",
                    MsgBoxStyle.Critical | MsgBoxStyle.OkOnly,
                    "Ошибка ввода"
                    );
                    continue;
                } // if

                int num2 = ColumnNeg(matr);
                if(num2!=-1)
                    ChangeMatr(matr, num1, num2);

                Show("\n\t\tПрямоугольный массив:\n", matr);

            } // while

            } // DoTask4

        private static int ColumnNeg(int [,] matr){
            int N = matr.GetLength(1);
            int M = matr.GetLength(0);
            for(int j = 0; j < N; j++){
                for (int i = 0; i < N; i++){
                    if (matr[i, j] >= 0) break;
                    if (i + 1 == M) return j;
                } // for i
            } // for j
            return -1;
        } // ColumnNeg

        public static void ChangeMatr(int [,] matr, int num1, int num2){
            int temp;
            for (int i = 0; i < matr.GetLength(0); i++){
                temp = matr[i, num1];
                matr[i, num1] = matr[i, num2];
                matr[i, num2] = temp;
            } // for i
        } // ChangeMatr

        private static void FillMatr(int[,] matr, int lo, int hi){
            int rows = matr.GetLength(0); // строки
            int cols = matr.GetLength(1); // столбцы

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    matr[i, j] = rand.Next(lo, hi + 1);
        } // Fill

        // вывод прямоугольного массива
        private static void Show(string title, int[,] matr){
            // Вывод заголовка
            Console.Write(title);

            // получение количества строк и столбцов прямоугольной матрицы
            int rows = matr.GetLength(0);
            int cols = matr.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                    Console.Write("{0, 10}", matr[i, j]);
                Console.WriteLine();
            } // for i
        } // Show

        #endregion
        private static Random rand = new Random();
    } // class Program 
}
