﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace HW9.Task3
{
	// Класс, определяющий единицу товара
	class Item
	{
		// название товара;
		private string _name;

		public string Name
		{
			get { return _name; }
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException(nameof(Name), "Не указано названия наименования");
				_name = value;
			}
		}


		// количество товара(в условных единицах);
		private int _amount;

		public int Amount
		{
			get { return _amount; }
			set
			{
				if (value < 0)
					throw new ArithmeticException("Недопустимое количество товара");

				_amount = value;
			}
		}

		// стоимость товара в рублях.
		private int _price;

		public int Price
		{
			get { return _price; }
			set
			{
				if (value < 0)
					throw new ArithmeticException("Недопустимая стоимость товара");

				_price = value;
			}
		}

		// стоимость общего количества наименования
		public int Value => _price * _amount;


		// конструкторы
		public Item() : this("Резиновая утка", 12, 75)
		{
		}

		public Item(string name, int amount, int price)
		{
			_name = name;
			_amount = amount;
			_price = price;
		}


		#region Перегруженные операции

		// +: сложения товаров с одинаковыми наименованиями, выполняющую сложение их стоимостей,
		// т.е.цен, умноженных на количество
		public static int operator +(Item it1, Item it2)
		{
			if (it1.Name != it2.Name)
				throw new Exception("Недопустимая операция сложения дла разных наименований");
			return it1.Value + it2.Value;
		}

		// +: сложения товара и целого числа, выполняющего сложение цены и целого числа
		public static Item operator +(Item it1, int value) =>
			new Item {Name = it1.Name, Amount = it1.Amount, Price = it1.Price + value};

		// –: вычитание товара и целого числа, выполняющего вычитание целого числа из цены
		public static Item operator -(Item it1, int value) =>
			new Item {Name = it1.Name, Amount = it1.Amount, Price = it1.Price - value};

		// сравнение товаров по цене: < >
		public static bool operator >(Item it1, Item it2) => it1?.Price > it2?.Price;
		public static bool operator <(Item it1, Item it2) => it1?.Price < it2?.Price;

		// сравнение товаров по цене: <= >=
		public static bool operator >=(Item it1, Item it2) => it1?.Price >= it2?.Price;
		public static bool operator <=(Item it1, Item it2) => it1?.Price <= it2?.Price;


		// сравнение товаров по цене: == !=
		public static bool operator ==(Item it1, Item it2) => it1?.Price == it2?.Price;
		public static bool operator !=(Item it1, Item it2) => it1?.Price != it2?.Price;


		// операция true: стоимость товара в интервале 1, …, 1000
		public static bool operator true(Item it) => it?.Price is >= 1 and <= 1000;

		// операция false: стоимость товара равна 0 или больше 1000
		public static bool operator false(Item it) => it?.Price is <= 0 or > 1000;


		#endregion


		// строковое представление
		public override string ToString()
		{
			return $"Наименование: {_name}, Количество: {_amount}, Цена: {_price}";
		}

		// шапка таблицы
		public static string Header(int indent)
		{
			string spaces = " ".PadRight(indent);
			string str =
			$"{spaces}╔════╦════════════════════════════════════════════╦════════╦════════╦═══════════╗\n" +
			$"{spaces}║ №  ║           Название наименования            ║ Кол-во ║  Цена  ║ Стоимость ║\n" +
			$"{spaces}╠════╬════════════════════════════════════════════╬════════╬════════╬═══════════╣\n";
			return str;
		}

		// формирование строки таблицы для представления объекта 
		public string ToTableRow(int n) =>
			$"║ {n,2} ║ {_name,-42} ║ {_amount,6} ║ {_price,6} ║ {Value,9} ║";
		

		// подвал таблицы
		public static string Footer(int indent) =>
			$"{" ".PadRight(indent)}╠════╩════════════════════════════════════════════╩════════╩════════╬═══════════╣";


		// фабрика, создающая данные об игрушке
		public static Item Create()
		{
			(string, int)[] items =
			{
				("Калейдоскоп новый", 104), ("Счетные палочки", 23), ("Пирамидка", 171), ("Конструктор КД Утро", 279),
				("Конструктор деревянный \"Цифры\"", 933), ("Лабиринт круглый, синий", 299), ("Лабиринт круглый, зеленый", 299),
				("Лабиринт круглый, красный", 299), ("Кубики на палочке Ёжик", 199), ("Кубики на палочке Мишка", 199),
				("Сортер Веселые фигурки", 422), ("Дорожная Дальнобойщик", 225), ("Самосвал", 19), ("Пожарная машина", 326),
				("Машинка Спецтехника", 36), ("Каток дорожный", 33), ("Автокран Арктика", 307), ("Автомобиль Пони-эвакуатор с суперкаром", 386),
				("Набор Техпомощь", 489), ("Пожарная машина Крепыш", 313), ("Трактор с ковшом в кор.", 589),
				("Бетоновоз Констурктор в кор.", 443), ("Автомобиль с платформой Актив", 664), ("Бетономешалка", 275),
				("Автокран", 314), ("Формы для песка Сад", 33), ("Бетономешалка Вжух на стройке", 42), ("Кран Вжух", 42),
				("Машинка пожарная Вжух в городе", 42), ("Кран Вжух в городе", 42), ("Самосвал Актив с прицепом", 617),
				("Самосвал 1/30 ", 175), ("Самосвал в кор.", 397), ("Гонка Молния", 228), ("Спорткар", 162),
				("Набор1 Грузовик с пушкой", 113), ("Танкетка Патриот", 113), ("Ракетовоз Патриот", 134),
				("Танк 2 Патриот", 147), ("Машина военная Малышок", 109), ("Самосвал военный Малышок", 124)
			};

			int choosen = Utilities.GenerateInt(0, items.Length);

			string name = items[choosen].Item1;
			int price = items[choosen].Item2;
			int amount = Utilities.GenerateInt(1, 50);

			return new Item {Name = name, Price = price, Amount = amount};
		}

	}
}