﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW9.Task3
{
	class Shop
	{
		// название магазина
		private string _name;

		public string Name
		{
			get { return _name; }
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Не указано название магазина");
				_name = value;
			}
		}

		// закрытый массив товаров
		private Item[] _items;

		// конструкторы

		public Shop() : this("Магазин игрушек", new Item[Utilities.GenerateInt(10, 20)])
		{
			Initialize();
		}

		public Shop(string name, Item[] items)
		{
			Name = name;
			_items = items;
		}

		public int Length => _items.Length;

		// индексатор с контролем выхода за пределы массива
		public Item this[int index]
		{
			get
			{
				if (index < 0 || index >= Length)
					throw new ArgumentOutOfRangeException(nameof(index), "Попытка обращения за пределы массива.");
				return _items[index];
			}
			set
			{
				if (index < 0 || index >= Length)
					throw new ArgumentOutOfRangeException(nameof(index), "Попытка записи за пределами массива.");
				_items[index] = value;
			}
		}

		// заполнение массива товаров данными
		public void Initialize()
		{
			for (int i = 0; i < Length; i++)
			{
				Item create;
				do create = Item.Create();
				while (Array.Find(_items, it => it is not null && it.Name == create.Name));
				_items[i] = create;
			}
		}

		// вывод товаров в консоль
		public void Show(string caption, int indent, Item item = null)
		{
			string space = " ".PadRight(indent);
			Console.Write($"\n\n\n\n{space}{caption}\n{Item.Header(indent)}");

			int row = 1;

			void OutItem(Item it)
			{
				Console.Write($"{ space}");
				if (it.Equals(item)) Utilities.Palette.TableRow.SetToConsole();
				//Utilities.ColorSet.SetToConsole(it.Equals(item) ? Utilities.Palette.TableRow : Utilities.Palette.Ordinary);
				Console.WriteLine($"{it.ToTableRow(row++)}");
				Utilities.Palette.Ordinary.SetToConsole();
			}
			Array.ForEach(_items, OutItem);

			Console.WriteLine(Item.Footer(indent));
			Console.WriteLine($"{space}║ Итого:                                                            ║ {SumValues(),9} ║");
			Console.WriteLine($"{space}╚═══════════════════════════════════════════════════════════════════╩═══════════╝");
		}

		// суммирование цен товаров
		int SumValues()
		{
			int sum = 0;
			Array.ForEach(_items, it => sum += it.Value);
			return sum;
		}


	}
}
