﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW9
{
	class Program
	{
		static void Main(string[] args)
		{
			new Utilities.ColorSet() { Foreground = ConsoleColor.Green, Background = ConsoleColor.Black }
				.SetToConsole();

			App app = new App();
			app.Run();
		}
	}
}
