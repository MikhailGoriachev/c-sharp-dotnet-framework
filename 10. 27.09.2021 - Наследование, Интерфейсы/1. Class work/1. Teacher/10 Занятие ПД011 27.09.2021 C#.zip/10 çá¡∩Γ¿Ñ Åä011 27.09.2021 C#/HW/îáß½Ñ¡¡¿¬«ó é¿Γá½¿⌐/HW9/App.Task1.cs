﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW9
{
	internal partial class App
	{
		// произведение элементов массива с четными номерами,
		// вывести массив с выделением цветом элементов с четными номерами 
		private void Task1MenuItem1()
		{
			Utilities.ShowNavBar("    Задание 1-1");

			_task1.Initialize();
			
			Utilities.WriteColored("\n\n    Произведение элементов массива с четными номерами:  ",
				Utilities.Palette.Notice);
			
			Utilities.WriteColored($"{_task1.MultiplyEvenPositions()}", Utilities.Palette.Ordinary);

			Utilities.WriteColored($"\n\n    Элементы  с чётными номерами выделены цветом:\n\n    ",
				Utilities.Palette.Notice);

			_task1.ShowEvenPositionsHighlighted();
		}

		// сумму элементов массива, расположенных между первым и последним нулевыми элементами,
		// вывести диапазон суммирования с выделением цветом: границ и слагаемых
		private void Task1MenuItem2()
		{
			Utilities.ShowNavBar("   Задание 1-2");

			_task1.Initialize(0,4);

			Utilities.WriteColored("\n\n    Сумма элементов массива, расположенных между первым и последним" +
			                        " нулевыми элементами:  ", Utilities.Palette.Notice);

			Utilities.WriteColored($"{_task1.SumBetweenFirstLastZero()}", Utilities.Palette.Ordinary);

			Utilities.WriteColored("\n\n    Диапазон суммирования с выделением цветом границ и слагаемых:\n\n    ",
				Utilities.Palette.Notice);

			_task1.ShowRangeHighlighted();

		}

		// отрицательным элементам массива поменять знак, сортировать массив по убыванию.
		// Метод сортировки – сортировка вставками
		private void Task1MenuItem3()
		{
			Utilities.ShowNavBar("    Задание 1-3");

			_task1.Initialize();

			Utilities.WriteColored($"\n\n    Исходный массив:\n\n    ", Utilities.Palette.Notice);

			_task1.ShowArray();

			Utilities.WriteColored($"\n\n    Отрицательным элементам массива изменён знак:\n\n    ", Utilities.Palette.Notice);
			
			_task1.ReverseNegativeSignes();
			_task1.ShowArray();

			Utilities.WriteColored($"\n\n    Массив отсортирован по убыванию:\n\n    ", Utilities.Palette.Notice);
			_task1.InsertSort();
			_task1.ShowArray();
		}


	}
}
