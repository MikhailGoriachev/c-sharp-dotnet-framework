﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW9.Task1
{
	// класс для хранения одномерного массива 
	class IntArray
	{
		// контейнер данных
		private int[] _array;

		// получение длины массива
		public int Length => _array.Length;
		
		public IntArray(int length = 0)
		{
			if (length < 0)
				throw new ArgumentException("Значение длины массива не может быть отрицательным");
			_array = new int[length];
		}

		// индексатор
		public int this[int index]
		{
			get
			{
				if (index < 0 || index >= Length)
					throw new ArgumentOutOfRangeException(nameof(index), "Попытка обращения за пределы массива.");
				return _array[index];
			}
			set
			{
				if (index < 0 || index >= Length)
					throw new ArgumentOutOfRangeException(nameof(index), "Попытка записи за пределами массива.");
				_array[index] = value;
			}
		}

		// заполнение массива случайными значениями
		public void Fill(int lo, int hi)
		{
			for (int i = 0; i < Length; i++)
			{
				_array[i] = Utilities.GenerateInt(lo, hi);
			}
		}

		// строковое представление
		public override string ToString()
		{
			StringBuilder returned = new StringBuilder("Значения массива: ");
			Array.ForEach(_array, x => returned.AppendFormat($"{x, 4}"));
			return returned.ToString();
		}
	}
}
