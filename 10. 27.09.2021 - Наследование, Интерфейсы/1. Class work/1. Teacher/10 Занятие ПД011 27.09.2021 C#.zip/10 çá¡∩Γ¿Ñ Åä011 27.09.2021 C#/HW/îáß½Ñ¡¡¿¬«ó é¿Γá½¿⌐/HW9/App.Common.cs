﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW9.Task2;

namespace HW9
{
	internal partial class App
	{
		private Menu _mainMenu;
		private Menu _subMenu1;
		private Menu _subMenu2;
		private Menu _subMenu3;

		private Task1.Task1 _task1;
		private Task2.Task2 _task2;
		private Task3.Task3 _task3;

		public App() : this(new Task1.Task1(), new Task2.Task2(), new Task3.Task3())
		{}

		public App(Task1.Task1 task1, Task2.Task2 task2, Task3.Task3 task3)
		{
			_task1 = task1;
			_task2 = task2;
			_task3 = task3;
			InitMenu();
		}

		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem() {Text = "Задание 1", Callback = MainMenuItem1},
					new Menu.MenuItem() {Text = "Задание 2", Callback = MainMenuItem2},
					new Menu.MenuItem() {Text = "Задание 3", Callback = MainMenuItem3},
					new Menu.MenuItem() {Text = "Выход"}
				}, new Point(5, 5),
				"Меню приложения");

			// Подменю - первое задание
			_subMenu1 = new Menu(new[]
				{
					new Menu.MenuItem {Text = "Пункт 1", Callback = Task1MenuItem1},
					new Menu.MenuItem {Text = "Пункт 2", Callback = Task1MenuItem2},
					new Menu.MenuItem {Text = "Пункт 3", Callback = Task1MenuItem3},
					new Menu.MenuItem {Text = "Назад"}
				}, new Point(5, 5),
				"Задание 1");

			// Подменю - второе задание
			_subMenu2 = new Menu(new[]
				{
					new Menu.MenuItem {Text = "Сложение игрушки с целым числом ", Callback = Task2MenuItem1},
					new Menu.MenuItem {Text = "Вычитание целого числа из игрушки", Callback = Task2MenuItem2},
					new Menu.MenuItem {Text = "Сравнение цен двух игрушек", Callback = Task2MenuItem3},
					new Menu.MenuItem {Text = "Проверка условным оператором true/false", Callback = Task2MenuItem5},
					new Menu.MenuItem {Text = "Назад"}
				}, new Point(5, 5),
				"Задание 2");

			// Подменю - третье задание
			_subMenu3 = new Menu(new[]
				{
					new Menu.MenuItem {Text = "Отобразить список товаров", Callback = Task3MenuItem1},
					new Menu.MenuItem {Text = "Найти товар с минимальной ценой", Callback = Task3MenuItem2},
					new Menu.MenuItem {Text = "Найти товар с максимальной ценой", Callback = Task3MenuItem3},
					new Menu.MenuItem {Text = "Отсортировать список товаров по убыванию количества", Callback = Task3MenuItem4},
					new Menu.MenuItem {Text = "Назад"}
				}, new Point(5, 5),
				"Задание 3");

		}


		public void Run() =>_mainMenu.Run();
		private void MainMenuItem1() => _subMenu1.Run(true);
		private void MainMenuItem2() => _subMenu2.Run(true);
		private void MainMenuItem3() => _subMenu3.Run(true);
		
	}
}
