﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW9.Task3;

namespace HW9
{
	internal partial class App
	{
		// Отображение списка товаров
		private void Task3MenuItem1()
		{
			Utilities.ShowNavBar("    Отображение списка товаров");
			
			_task3.Show();
		}

		// Нахождение товара с минимальной ценой
		private void Task3MenuItem2()
		{
			Utilities.ShowNavBar("    Нахождение товара с минимальной ценой");

			Item minPrice = _task3.FindMinPriceItem();
			_task3.Show(minPrice);

			Console.Write($"\n\n    Товар с минимальной ценой:\n    ");
			Utilities.WriteColored(minPrice.ToString(), Utilities.Palette.Context);
		}

		// Нахождение товара с максимальной ценой
		private void Task3MenuItem3()
		{
			Utilities.ShowNavBar("    Нахождение товара с максимальной ценой");

			Item maxPrice = _task3.FindMaxPriceItem();
			_task3.Show(maxPrice);
			Console.Write($"\n\n    Товар с максимальной ценой:\n    ");
			Utilities.WriteColored(maxPrice.ToString(), Utilities.Palette.Context);
		}

		// Сортировка товаров по уменьшению количества
		private void Task3MenuItem4()
		{
			Utilities.ShowNavBar("    Сортировка товаров по уменьшению количества");

			Console.WriteLine($"\n\n    Список товаров отсортирован по убиыванию количества:\n");
			_task3.SortItemsDescend();
			_task3.Show();

		}
	}
}