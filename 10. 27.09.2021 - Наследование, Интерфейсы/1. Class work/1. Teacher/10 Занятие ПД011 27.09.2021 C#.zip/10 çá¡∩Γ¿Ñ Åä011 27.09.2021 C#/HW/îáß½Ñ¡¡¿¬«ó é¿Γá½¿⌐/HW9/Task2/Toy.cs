﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW9.Task2
{
	// Класс представления игрушки
	class Toy
	{
		// название игрушки 
		public string Name { get; set; }

		// возрастная категория 
		public int Age { get; set; }
		
		// стоимость игрушки 
		public int Price { get; set; }

		// конструкторы
		public Toy():this("не указано", 0, 0)
		{}
		
		public Toy(string name, int age, int price)
		{
			Name = name;
			Age = age;
			Price = price;
		}

		// строковое представление
		public override string ToString() =>
			$"Название: {Name}, Возрастная категория: {Age}, Стоимость: {Price}";


		#region Перегрузки операций

		// сложение игрушки с целым числом – операция выполняет сложение цены и числа
		public static Toy operator +(Toy toy, int value) =>
			new Toy {Age = toy.Age, Name = toy.Name, Price = toy.Price + value};

		// вычитание целого числа из игрушки – операция выполняет вычитание целого числа из цены игрушки
		public static Toy operator -(Toy toy, int value) =>
			new Toy { Age = toy.Age, Name = toy.Name, Price = toy.Price - value };

		// сравнение цен двух игрушек
		public static bool operator >(Toy toy1, Toy toy2) => toy1.Price > toy2.Price;
		public static bool operator <(Toy toy1, Toy toy2) => toy1.Price < toy2.Price;

		// true: если возрастная категория больше 5
		public static bool operator true(Toy toy) => toy.Age > 5;

		// false: если возрастная категория меньше или равна 5 
		public static bool operator false(Toy toy) => toy.Age <= 5;

		#endregion
	}
}
