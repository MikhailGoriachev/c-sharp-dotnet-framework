﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW9.Task3
{
	// Класс, определяющий методы для выполнения третьей задачи
	class Task3
	{
		private Shop _shop;

		public Task3():this(new Shop()) {}
		public Task3(Shop shop)
		{
			_shop = shop;
		}

		// Вывод списка товаров
		public void Show(Item it = null) =>
			_shop.Show($"{_shop.Name}, список товаров:", 4, it);

		// Найти товар с минимальной ценой
		public Item FindMinPriceItem()
		{
			int iMin = 0;
			for (int i = 1; i < _shop.Length; i++)
				if (_shop[i].Price < _shop[iMin].Price) iMin = i;
			return _shop[iMin];
		}

		// Найти товар с максимальной ценой
		public Item FindMaxPriceItem()
		{
			int iMax = 0;
			for (int i = 1; i < _shop.Length; i++)
				if (_shop[i].Price > _shop[iMax].Price) iMax = i;
			return _shop[iMax];
		}

		// Вызов сортировки по уменьшению количества товаров
		public void SortItemsDescend() =>
			QSortItemsDescend(_shop, 0, _shop.Length - 1);

		// Быстрая сортировка по уменьшению количества товаров
		public void QSortItemsDescend(Shop shop, int start, int end)
		{
			if (start >= end) return;

			int i = start, j = end;
			int baseElem = (end - start) / 2 + start;

			while (i < j)
			{
				int value = _shop[baseElem].Amount;

				while (i < baseElem && (shop[i].Amount >= value)) i++;

				while (j > baseElem && (shop[j].Amount <= value)) j--;

				if (i < j)
				{
					(shop[i], shop[j]) = (shop[j], shop[i]);

					if (i == baseElem) baseElem = j;
					else if (j == baseElem) baseElem = i;
				}
			}

			QSortItemsDescend(shop, start, baseElem);
			QSortItemsDescend(shop, baseElem + 1, end);
		}
	}
}
