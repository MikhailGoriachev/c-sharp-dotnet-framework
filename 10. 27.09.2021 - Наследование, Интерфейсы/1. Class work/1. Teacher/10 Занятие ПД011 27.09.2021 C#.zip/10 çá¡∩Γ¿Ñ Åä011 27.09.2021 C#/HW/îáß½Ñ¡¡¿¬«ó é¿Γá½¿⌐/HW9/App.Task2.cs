﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW9
{
	internal partial class App
	{
		// Сложение игрушки с целым числом
		private void Task2MenuItem1()
		{
			Utilities.ShowNavBar("    Сложение игрушки с целым числом");

			Console.Write("\n    ");

			_task2.AddingDemo();
		}

		// Вычитание целого числа из игрушки
		private void Task2MenuItem2()
		{
			Utilities.ShowNavBar("    Вычитание целого числа из игрушки");

			Console.Write("\n    ");
			
			_task2.SubstractionDemo();
		}

		// Сравнение цен двух игрушек
		private void Task2MenuItem3()
		{
			Utilities.ShowNavBar("    Сравнение цен двух игрушек");

			_task2.ComparingDemo();
		}

		// Проверка условным оператором true/false
		private void Task2MenuItem5()
		{
			Utilities.ShowNavBar("    Проверка условным оператором true/false");

			_task2.OperatorTrueFalseDemo();
		}

	}
}