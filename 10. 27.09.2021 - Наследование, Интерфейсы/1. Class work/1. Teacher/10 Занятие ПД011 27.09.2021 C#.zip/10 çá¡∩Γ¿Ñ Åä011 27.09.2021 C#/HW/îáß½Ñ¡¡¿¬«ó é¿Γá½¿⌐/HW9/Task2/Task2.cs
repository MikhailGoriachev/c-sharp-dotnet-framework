﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace HW9.Task2
{
	class Task2
	{
		// Объекты игрушек
		private Toy _toy1;
		private Toy _toy2;

		// Конструкторы
		public Task2(): 
			this(new Toy("Набор кубиков", 3, 400), new Toy("Конструктор LEGO Ninjago", 6 , 2000))
		{}

		public Task2(Toy toy1, Toy toy2)
		{
			_toy1 = toy1;
			_toy2 = toy2;
		}


		// Сложение игрушки c числом
		public void AddingDemo()
		{
			Utilities.WriteColored("Игрушка:\n\n    ", Utilities.Palette.Notice);
			
			Console.Write(_toy1);

			Utilities.WriteColored("\n\n    К игрушке прибавлено 75:\n\n    ", Utilities.Palette.Notice);

			Console.Write(_toy1 += 75);
		}

		// Вычитание числа из игрушки
		public void SubstractionDemo()
		{
			Utilities.WriteColored("Игрушка:\n\n    ", Utilities.Palette.Notice);

			Console.Write(_toy1);

			Utilities.WriteColored("\n\n    Из игрушки вычтено 75:\n\n    ", Utilities.Palette.Notice);

			Console.Write(_toy1 -= 75);
		}


		// Сравнение цен двух игрушек
		public void ComparingDemo()
		{
			Utilities.WriteColored("\n\n    Игрушка 1:\n\n    ", Utilities.Palette.Notice);
			Console.Write(_toy1);

			Utilities.WriteColored("\n\n    Игрушка 2:\n\n    ", Utilities.Palette.Notice);
			
			Console.Write(_toy2);

			Utilities.WriteColored($"\n\n    Игрушка 1 < Игрушка 2: ", Utilities.Palette.Notice);

			Console.Write($"{_toy1 < _toy2}");
		}

		// Проверка условным оператором true/false
		public void OperatorTrueFalseDemo()
		{
			Utilities.WriteColored("\n\n    Игрушка 1:\n\n    ", Utilities.Palette.Notice);

			bool result = _toy1 ? true : false;
			
			Console.Write(_toy1);
			Utilities.WriteColored($"\n\n    Оператор true/false: {result}\n\n    ", Utilities.Palette.Notice);

			result = _toy2 ? true : false;

			Utilities.WriteColored("\n\n    Игрушка 2:\n\n    ", Utilities.Palette.Notice);
			Console.Write(_toy2);
			Utilities.WriteColored($"\n\n    Оператор true/false: {result}\n\n    ", Utilities.Palette.Notice);

		}
	}
}
