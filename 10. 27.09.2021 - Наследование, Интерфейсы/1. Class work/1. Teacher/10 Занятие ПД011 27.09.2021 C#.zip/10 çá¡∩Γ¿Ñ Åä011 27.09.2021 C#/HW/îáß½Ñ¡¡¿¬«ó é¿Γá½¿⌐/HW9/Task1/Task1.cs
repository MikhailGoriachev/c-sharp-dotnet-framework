﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW9.Task1
{
	class Task1
	{

		// Количество элементов массива
		private static int n = 20;


		// массив IntArra
		private IntArray _intArray;

		// Конструктор по умолчанию
		public Task1() : this(new IntArray(n))
		{
			Initialize();
		}

		// Конструктор с внедрением зависимостей
		public Task1(IntArray intArray)
		{
			_intArray = intArray;
		}

		// Заполнение массива
		public void Initialize(int lo = -20, int hi = 20) => _intArray.Fill(lo, hi);

		public void ShowArray() => Console.Write(_intArray);

		// Произведение элементов массива с четными номерами
		public long MultiplyEvenPositions()
		{
			long mult = 1;
			for (int i = 0; i < _intArray.Length; i++)
			{
				if((i & 1) == 0 && _intArray[i] != 0)
					mult *= _intArray[i];
			}
			return mult;
		}

		// Вывести массив с выделением цветом элементов с четными номерами 
		public void ShowEvenPositionsHighlighted()
		{
			Utilities.ColorSet curColors = new Utilities.ColorSet(true);
			Utilities.ColorSet evenColors = new Utilities.ColorSet()
				{Foreground = ConsoleColor.Black, Background = ConsoleColor.DarkCyan};

			for (int i = 0; i < _intArray.Length; i++)
			{
				Utilities.ColorSet.SetToConsole((i & 1) == 0 ? evenColors : curColors);
				Console.Write($"  {_intArray[i]}  ");
			}

			Utilities.ColorSet.SetToConsole(curColors);
		}


		// Найти индексы первого и последнего нуля
		private (int iFirst, int iLast) FindFirstLastZeroes()
		{
			int iFirstZero = -1, iLastZero = -1;

			for (int i = 0; i < _intArray.Length; i++)
			{
				if (_intArray[i] != 0) continue;
				iFirstZero = i;
				break;
			}
			
			for (int i = _intArray.Length - 1; i >= 0; i--)
			{
				if (_intArray[i] != 0) continue;
				iLastZero = i;
				break;
			}

			return (iFirstZero, iLastZero);
		}

		// Сумма между первым и последним нулями
		public int SumBetweenFirstLastZero()
		{
			int sum = 0;
			var indexes = FindFirstLastZeroes();

			if (indexes.iFirst == indexes.iLast)
				return sum;

			for (int i = indexes.iFirst + 1; i < indexes.iLast; i++)
			{
				sum += _intArray[i];
			}

			return sum;
		}

		// Вывести диапазон суммирования с выделением цветом: границ и слагаемых
		public void ShowRangeHighlighted()
		{
			var indexes = FindFirstLastZeroes();

			Utilities.ColorSet curColors = new Utilities.ColorSet(true);
			Utilities.ColorSet rangeColors = new Utilities.ColorSet()
				{ Foreground = ConsoleColor.Black, Background = ConsoleColor.DarkCyan };

			for (int i = 0; i < _intArray.Length; i++)
			{
				if (i == indexes.iFirst)
					Utilities.ColorSet.SetToConsole(rangeColors);
				
				Console.Write($"  {_intArray[i]}  ");
				
				if (i == indexes.iLast)
					Utilities.ColorSet.SetToConsole(curColors);
			}

			Utilities.ColorSet.SetToConsole(curColors);
		}

		// отрицательным элементам массива поменять знак
		public void ReverseNegativeSignes()
		{
			for (int i = 0; i < _intArray.Length; i++)
			{
				if (_intArray[i] < 0) _intArray[i] = -_intArray[i];
			}
		}

		// сортировать массив по убыванию. Метод сортировки – сортировка вставками
		public void InsertSort()
		{
			bool flag;
			int i, j, k;

			for (i = 1; i < _intArray.Length; i++)
			{
				flag = false;
				for (j = 0; j <= i; j++)
				{
					if (_intArray[j] < _intArray[i])
					{
						flag = true;
						break;
					} 
				} 
				if (!flag) continue;

				int temp = _intArray[i];

				for (k = i; k > j; k--)
				{
					_intArray[k] = _intArray[k - 1];
				}

				_intArray[j] = temp;
			}
		}
	}
}
