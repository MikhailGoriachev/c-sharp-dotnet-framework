﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork27._09._21.Models;
using HomeWork27._09._21.HomeWorkException;

namespace HomeWork27._09._21.Tasks
{
    class Task2
    {
        

        private Toy _toy;

        public Toy Toy
        {
            get { return _toy; }
            set { _toy = value; }
        }



        public Task2(string name, int agecat, int price) {
            _toy = new Toy("Машинка на пулте ДУ", 6, 100);           
        }

       



    }
}
