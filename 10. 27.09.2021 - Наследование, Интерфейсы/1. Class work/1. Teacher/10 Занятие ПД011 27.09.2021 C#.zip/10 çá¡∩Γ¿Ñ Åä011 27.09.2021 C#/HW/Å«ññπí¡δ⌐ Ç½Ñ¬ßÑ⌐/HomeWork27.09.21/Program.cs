﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork27._09._21.Tasks;
using HomeWork27._09._21.AppSpace;
using HomeWork27._09._21.Utils;
using HomeWork27._09._21.HomeWorkException;
using HomeWork27._09._21.Models;


namespace HomeWork27._09._21
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Домашние задание на 20.09.21";

            App app1 = new App(40, -20, 30);

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Произведение элементов массива с четными номерами, вывести массив " },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Сумму элементов массива, расположенных между первым и последним нулевыми элементами" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Отрицательным элементам массива поменять знак, сортировать массив по убыванию" },


                new MenuItem { HotKey = ConsoleKey.R, Text = "Сложения игрушки с целым числом" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Вычитания целого числа из игрушки " },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Сравнение цен двух игрушек" },

                new MenuItem { HotKey = ConsoleKey.S, Text = "Демонстрация перегрузки true/fasle" },
                //new MenuItem { HotKey = ConsoleKey.D, Text = "Вывод массива комнат" },
                //new MenuItem { HotKey = ConsoleKey.F, Text = "Сортировка по убыванию площади массива комнат" },
                //new MenuItem { HotKey = ConsoleKey.G, Text = "Сортировка по возрастанию количества окон массива комнат" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };



            // главный цикл приложения
            while (true)
            {
                // настройка цветового оформления
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.Clear();
                Console.CursorVisible = false;

                Utils.Utils.ShowNavBarTask(" Работа с перегрузкой операций");
                Utils.Utils.ShowMenu(12, 5, "Домашние задание на 27.09.21", menu);

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                Console.Clear();

                switch (key)
                {
                    // ------------------------------------------------------------
                    // пункты меню, относящиеся к задаче 1
                    // Произведение элементов массива с четными номерами, вывести массив 
                    case ConsoleKey.Q:
                        try
                        {
                            app1 = new App(25, -10, 10);

                            app1.DemoShowPart1();

                        }
                        catch (IntArrayException ex)
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine($"\n{ex.Message}\n");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                        break;

                    // Сумму элементов массива, расположенных между первым и последним нулевыми элементами
                    case ConsoleKey.W:
                        try
                        {
                            app1 = new App(30, -5, 5);

                            app1.DemoShowPart2();

                        }
                        catch (IntArrayException ex)
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine($"\n{ex.Message}\n");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                        break;


                    // Отрицательным элементам массива поменять знак, сортировать массив по убыванию
                    case ConsoleKey.E:
                        try
                        {
                            app1 = new App(40, -20, 30);

                            app1.DemoShowPart3();
                        }
                        catch (IntArrayException ex)
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine($"\n{ex.Message}\n");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                        break;





                    // пункты меню, относящиеся к задаче 2
                    // Сложения игрушки с целым числом
                    case ConsoleKey.R:
                        try
                        {
                            app1.Task2.Toy = new Toy("Машинка на пулте ДУ", 6, 100); 
                            app1.DemoShowOperatorPlus(Utils.Utils.GetRandom(10, 20));

                        }
                        catch (ToyException ex)
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine($"\n{ex.Message}");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                        break;

                    // Вычитания целого числа из игрушки 
                    case ConsoleKey.T:
                        try
                        {
                            app1.Task2.Toy = new Toy("Машинка на пулте ДУ", 6, 100);
                            app1.DemoShowOperatorMinus(Utils.Utils.GetRandom(10, 20));
                        }
                        catch (ToyException ex)
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine($"\n{ex.Message}");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                        break;



                    // сравнение цен двух игрушек
                    case ConsoleKey.A:
                        try
                        {
                            Toy t1 = new Toy("Конструктор", 6, 150);
                            app1.DemoShowComparisonTwoToys(t1);
                        }
                        catch (ToyException ex)
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine($"\n{ex.Message}");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                        break;


                    // Демонстрация перегрузки true/fasle
                    case ConsoleKey.S:
                        try
                        {
                            Toy t1 = new Toy("Конструктор", 3, 150);
                            app1.DemoShowAgeCat(t1);
                        }
                        catch (ToyException ex)
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine($"\n{ex.Message}");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                        break;


                    //// Инициализация массива комнат
                    //case ConsoleKey.S:
                    //    app.InitArrayRoom();
                    //    break;

                    //// Вывод массива комнат
                    //case ConsoleKey.D:
                    //    try
                    //    {
                    //        app.ShowRoom();
                    //    }
                    //    catch (EmptyArrayException ex)
                    //    {
                    //        Console.ForegroundColor = ConsoleColor.Cyan;
                    //        Console.WriteLine($"\n{ex.Message}");
                    //        Console.ForegroundColor = ConsoleColor.Gray;
                    //    }
                    //    break;


                    //// Сортировка по убыванию площади массива комнат
                    //case ConsoleKey.F:
                    //    try
                    //    {
                    //        app.SortByAreaRoom();
                    //    }
                    //    catch (EmptyArrayException ex)
                    //    {
                    //        Console.ForegroundColor = ConsoleColor.Cyan;
                    //        Console.WriteLine($"\n{ex.Message}");
                    //        Console.ForegroundColor = ConsoleColor.Gray;
                    //    }
                    //    break;

                    //// Сортировка по убыванию площади массива комнат
                    //case ConsoleKey.G:
                    //    try
                    //    {
                    //        app.SortByCountWindowsRoom();
                    //    }
                    //    catch (EmptyArrayException ex)
                    //    {
                    //        Console.ForegroundColor = ConsoleColor.Cyan;
                    //        Console.WriteLine($"\n{ex.Message}");
                    //        Console.ForegroundColor = ConsoleColor.Gray;
                    //    }
                    //    break;


                    // выход из приложения назначен на клавишу F10 или кавишу Z
                    case ConsoleKey.F10:
                    case ConsoleKey.Z:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Utils.Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                        Console.CursorVisible = true;
                        return;

                    default:
                        continue;
                } // switch

                // Ожидать нажатия любой клавиши по окончании работы пункта меню
                Console.CursorVisible = true;
                Utils.Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                Console.ReadKey(true);
            } // while

            

        }
    }
}
