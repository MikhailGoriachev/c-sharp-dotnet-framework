﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork27._09._21.Models;


namespace HomeWork27._09._21.AppSpace
{
    internal partial class App
    {
        public void DemoShowOperatorPlus(int a)
        {

            Console.WriteLine($"Игрушка до изменения:");
            Console.WriteLine($"{_task2.Toy.ToString()}");

            Console.WriteLine($"К стоимости игрушки будет добавлено значение {a,-5}");


            Task2.Toy = Task2.Toy + a;

            Console.WriteLine($"Игрушка после изменения:");
            Console.WriteLine($"{_task2.Toy.ToString()}");




        }

        public void DemoShowOperatorMinus(int a)
        {

            Console.WriteLine($"Игрушка до изменения:");
            Console.WriteLine($"{_task2.Toy.ToString()}");

            Console.WriteLine($"К стоимости игрушки будет добавлено значение {a,-5}");


            Task2.Toy = Task2.Toy - a;

            Console.WriteLine($"Игрушка после изменения:");
            Console.WriteLine($"{_task2.Toy.ToString()}");




        }

        public void DemoShowComparisonTwoToys(Toy t1)
        {

            Console.WriteLine($"Игрушка 1:");
            Console.WriteLine($"{_task2.Toy.ToString()}");
            Console.WriteLine($"Игрушка 2:");
            Console.WriteLine($"{t1.ToString()}");
            Console.WriteLine();

            Console.WriteLine($"Демонстрация операции >");
            Console.WriteLine($"[ {_task2.Toy.Name} ] > [ {t1.Name} ] = {_task2.Toy>t1} ");
            Console.WriteLine($"Демонстрация операции <");

            Console.WriteLine($"[ {_task2.Toy.Name} ] < [ {t1.Name} ] = {_task2.Toy<t1} ");

        }


        public void DemoShowAgeCat(Toy t1)
        {

            Console.WriteLine($"Игрушка 1:");
            Console.WriteLine($"{_task2.Toy.ToString()}");
            Console.WriteLine($"Игрушка 2:");
            Console.WriteLine($"{t1.ToString()}");
            Console.WriteLine();

            Console.WriteLine($"Демонстрация операции true");
            Console.Write($"Возрастная категория больше 5 ");
            if (_task2.Toy)
                Console.WriteLine("True");
            else
                Console.WriteLine("False");


            Console.WriteLine($"Демонстрация операции false");
            Console.Write($"Возрастная категория меньше 5 ");
            if (t1)
                Console.WriteLine("True");
            else
                Console.WriteLine("False");
        }


    }
}
