﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork27._09._21.HomeWorkException
{

    [Serializable]
    public class ToyException : Exception
    {
        public ToyException() { }
        public ToyException(string message) : base(message) { }
        public ToyException(string message, Exception inner) : base(message, inner) { }
        protected ToyException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
