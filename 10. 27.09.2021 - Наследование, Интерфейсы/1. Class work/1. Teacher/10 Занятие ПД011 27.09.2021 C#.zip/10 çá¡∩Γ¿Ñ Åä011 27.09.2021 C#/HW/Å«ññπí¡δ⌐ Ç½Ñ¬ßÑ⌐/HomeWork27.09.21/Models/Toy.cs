﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork27._09._21.HomeWorkException;

namespace HomeWork27._09._21.Models
{
    class Toy
    {
        // имя игрушки
        private string _name;
        public string Name
        {
            get { return _name; }
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ToyException("Toy: ошибка именни игрушки");
                _name = value; 
            }
        }

        // возрастная категория
        private int _ageCat;
        public int AgeCat
        {
            get { return _ageCat; }
            set { if(value<0)
                    throw new ToyException("Toy: ошибка возрастной категории игрушки");
                _ageCat = value; 
            }
        }

        // цена
        private int _price;
        public int Price
        {
            get { return _price; }
            set {
                if (value < 0)
                    throw new ToyException("Toy: ошибка цены игрушки");
                _price = value; 
            
            }
        }

        public Toy(string name, int agecat, int price)
        {
            this.Name = name;
            this.AgeCat = agecat;
            this.Price = price;
        }


        // перегрузка операции + сложение объекта и целого числа
        // сложения игрушки с целым числом – операция выполняет сложение цены и числа
        public static Toy operator +(Toy t1, int number) =>
            new Toy(t1.Name, t1.AgeCat, t1.Price + number);
           // new Toy { Name = t1.Name, AgeCat = t1.AgeCat, Price = t1.Price + number };

        // перегрузка операции - вычитания объекта и целого числа
        // вычитания целого числа из игрушки – операция выполняет вычитание целого числа из цены игрушки
        public static Toy operator -(Toy t1, int number) =>
             new Toy(t1.Name, t1.AgeCat, t1.Price - number);
        //new Toy { Name = t1.Name, AgeCat = t1.AgeCat, Price = t1.Price - number };

        // < и >: сравнение цен двух игрушек
        // операции сравнения перегружаются только попарно - противоположные операции
        public static bool operator >(Toy t1, Toy t2)=>t1.Price > t2.Price;       

        // парная перегрузка оператора >
        public static bool operator <(Toy t1, Toy t2) => t1.Price < t2.Price;


        // true и false тоже можно перегрузить для удобства
        //	true: если возрастная категория больше 5
        //	false: если возрастная категория меньше или равна 5 
        public static bool operator true(Toy t1) => t1.AgeCat > 5;
        public static bool operator false(Toy t1) => t1.AgeCat <= 5; // operator false


        // метод вывода в строку
        public override string ToString()
        {
            return $"[ Имя игрушки : { _name,10 } , возрастная категория : {_ageCat,-3} , цена : {_price, -5} ]";
        }



    }
}
