﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork27._09._21.Tasks;
using HomeWork27._09._21.Models;

namespace HomeWork27._09._21.AppSpace
{
    internal partial class App
    {


        //private Task1 _task1;
        private Task1 _task1;
        public Task1 Task1
        {
            get { return _task1; }
            set { _task1 = value; }
        }

        private Task2 _task2;
        public Task2 Task2
        {
            get { return _task2; }
            set { _task2 = value; }
        }


        //private Task2 _task2;
        //public Task3 task3;


        public App(int size, int lo, int hi) {

            _task1 = new Task1(size,lo,hi);  
            _task2 = new Task2("Игрушка",1,1);

        }



    }
}
