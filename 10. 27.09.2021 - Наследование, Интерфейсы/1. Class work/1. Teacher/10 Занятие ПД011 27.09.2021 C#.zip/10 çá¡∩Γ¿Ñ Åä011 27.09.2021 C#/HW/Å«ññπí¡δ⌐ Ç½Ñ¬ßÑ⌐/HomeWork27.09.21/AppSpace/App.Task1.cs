﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork27._09._21.AppSpace
{
    internal partial class App
    {
        public void DemoShowPart1()
        {


            Console.WriteLine($"Произведение элементов массива с четными номерами равно {_task1.MultiElemEvens()}");
            Console.WriteLine($"Четные номера выведены в цвете.");

            _task1.ShowColorElemEvens();

        }

        public void DemoShowPart2()
        {

            Console.WriteLine($"Cумма элементов массива, расположенных между первым и последним нулевыми элементами {_task1.SumFirstLastNullElem()}");

            _task1.ShowFirstLastNullElem();


        }

        public void DemoShowPart3()
        {

            Console.WriteLine($"Отрицательным элементам массива поменять знак, сортировать массив по убыванию. Метод сортировки – сортировка вставками ");
            Console.WriteLine($"Массив до обработки: ");

            _task1.ShowColorElemEvens();

            _task1.SwapNegativElem();
            _task1.SortArrayDown();
            Console.WriteLine($"Массив после обработки: ");

            _task1.ShowColorElemEvens();


        }

    }
}