﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork27._09._21.Models;
using HomeWork27._09._21.HomeWorkException;


namespace HomeWork27._09._21.Tasks
{
    class Task1
    {
        // массив для обработки
        private IntArray _array;

        // инициализирующий конструктор
        public Task1(int size,int lo, int hi) {

            _array = new IntArray(size);
            _array.FillArrya(lo,hi);
        
        }



        // произведение элементов массива с четными номерами
        public long MultiElemEvens() {

            long result = 1;

            for (int i = 0; i < _array.Length(); i++)
            {
                if ((i & 1) == 0)
                    result *= _array[i];
            }

            return result;               
        
        }


        // вывести массив с выделением цветом элементов с четными номерами 
        public void ShowColorElemEvens()
        {
            ConsoleColor BackColor = Console.BackgroundColor;
            ConsoleColor ForeColor = Console.ForegroundColor;

            for (int i = 0; i < _array.Length(); i++)
            {
                if (i % 7 == 0)
                    Console.WriteLine();

                if ((i & 1) == 0)
                {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.Green;
                }
                Console.Write($"   {_array[i],5}   ");

                Console.BackgroundColor = BackColor;
                Console.ForegroundColor = ForeColor;
                  
            }
            Console.WriteLine();


        }

        // сумму элементов массива, расположенных между первым и последним нулевыми элементами
        public int SumFirstLastNullElem() {

            int firstNullIndex = SearchNullFirstIndex();
            int lastNullIndex = SearchNullLastIndex();

            if (firstNullIndex == lastNullIndex) {
                throw new IntArrayException("IntArray: в массиве меньше двух нулевых елементов");
            }

            int result = 0;

            for (int i = firstNullIndex+1; i < lastNullIndex; i++)
            {
                result += _array[i];
            }

            return result;   
        }

        // поиск индекса первого нулевого элемента
        private int SearchNullFirstIndex() {

            for (int i = 0; i < _array.Length(); i++)
            {
                if (_array[i] == 0)
                    return i;

            }
            return -1;

        }

        // поиск индекса последнего нулевого элемента
        private int SearchNullLastIndex()
        {
            for (int i = _array.Length()-1; i>=0; i--)
            {
                if (_array[i] == 0)
                    return i;

            }
            return -1;           

        }

        // вывести диапазон суммирования с выделением цветом: границ и слагаемых
        public void ShowFirstLastNullElem() {

            ConsoleColor BackColor = Console.BackgroundColor;
            ConsoleColor ForeColor = Console.ForegroundColor;

            int firstNullIndex = SearchNullFirstIndex();
            int lastNullIndex = SearchNullLastIndex();

            for (int i = 0; i < _array.Length(); i++)
            {
                if (i % 7 == 0)
                    Console.WriteLine();

                if (i == firstNullIndex)
                {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.Green;
                }


                if (i == lastNullIndex)
                {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.Green;
                }

                if (i > firstNullIndex && i < lastNullIndex) {

                    Console.BackgroundColor = ConsoleColor.Magenta;
                    Console.ForegroundColor = ConsoleColor.Yellow;


                }


                Console.Write($"  {_array[i],5}  ");

                Console.BackgroundColor = BackColor;
                Console.ForegroundColor = ForeColor;

            }
            Console.WriteLine();






        }//


        // отрицательным элементам массива поменять знак, 
        public void SwapNegativElem() {

            for (int i = 0; i < _array.Length(); i++)
            {
                if (_array[i] < 0) {

                    _array[i] = Math.Abs(_array[i]);
                
                }

            }
                
        }

        // сортировать массив по убыванию. Метод сортировки – сортировка вставками
        public void SortArrayDown() {
           
            for (int i = 0; i < _array.Length()-1; i++)
            {
                    int key = i + 1;
                    int temp = _array[key];
                    for (int j = i + 1; j > 0; j--)
                    {
                        if (temp > _array[j - 1])
                        {
                            _array[j] = _array[j - 1];
                            key = j - 1;
                        }
                    }
                    _array[key] = temp;
            }    
        }





    }
}
