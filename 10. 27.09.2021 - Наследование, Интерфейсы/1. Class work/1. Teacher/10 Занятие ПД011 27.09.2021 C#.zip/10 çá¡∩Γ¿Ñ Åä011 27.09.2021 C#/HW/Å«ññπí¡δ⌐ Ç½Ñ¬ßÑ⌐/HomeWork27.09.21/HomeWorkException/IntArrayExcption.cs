﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork27._09._21.HomeWorkException
{

    [Serializable]
    public class IntArrayException : Exception
    {
        public IntArrayException() { }
        public IntArrayException(string message) : base(message) { }
        public IntArrayException(string message, Exception inner) : base(message, inner) { }


        protected IntArrayException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
