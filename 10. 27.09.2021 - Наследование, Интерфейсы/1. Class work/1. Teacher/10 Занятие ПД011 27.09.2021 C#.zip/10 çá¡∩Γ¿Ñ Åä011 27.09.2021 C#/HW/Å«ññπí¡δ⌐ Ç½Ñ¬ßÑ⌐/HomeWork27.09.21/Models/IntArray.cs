﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork27._09._21.HomeWorkException;
using HomeWork27._09._21.Utils;

namespace HomeWork27._09._21.Models
{
    class IntArray
    {
        // размер массива
       private int _size;
        public int Size
        {
            get { return _size; }
            set {
                if (value <= 0)
                    throw new IntArrayException("IntArray: размер массива не божет быть нулевым или отрицательным");

                _size = value;
            
            }
        }


        // контейнер данных
        private int[] _array;

        // конструктор 
        // инициализация по размеру
        public IntArray(int size)
        {

            _array = new int[size];
            _size = size;

        }
        // инициализация массивом
        public IntArray(int[] array)
        {
            _array = array;
            _size = array.Length;

        }


        // свойство Length - размер массива
        public int Length() => _array.Length;

        // метод заполнения случайными числами
        public void FillArrya(int lo, int hi) {

            for (int i = 0; i < _size; i++) {

                _array[i] = Utils.Utils.GetRandom(lo, hi);

            }
        }

        // метод вывода в строку
        public override string ToString()
        {
            string res ="";

            for (int i = 0; i < _size; i++)
            {
                res += $"  {_array[i]}  ";
                if (i % 7 == 0)
                    res += "\n";
            }            

            return res;
        }



        // Индексатор. 
        public int this[int index]
        {
            get
            {   // Аксессор.
                if (index < 0 || index > _array.Length)
                    throw new IntArrayException("IntArray: ошибка по чтению. Выход за пределы массива");

                return _array[index];
            }

            set
            {   // Мутатор.
                if (index < 0 || index > _array.Length)
                    throw new IntArrayException("IntArray: ошибка по записи. Выход за пределы массива");

                _array[index] = value;

            }
        }

    }
}
