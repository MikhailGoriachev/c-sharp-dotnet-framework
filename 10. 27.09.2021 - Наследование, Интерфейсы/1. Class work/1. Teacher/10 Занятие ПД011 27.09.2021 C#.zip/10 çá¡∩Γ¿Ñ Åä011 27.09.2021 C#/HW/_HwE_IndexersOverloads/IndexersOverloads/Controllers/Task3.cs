﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using IndexersOverloads.Models;

namespace IndexersOverloads.Controllers
{
    /* 
     * При помощи индексатора, реализуйте поиск товаров с минимальной ценой, максимальной
     * ценой, сортировку товара по убыванию количества (метод быстрой сортировки). 
     * 
     */
    internal class Task3
    {
        Shop _shop;


        // Поиск минимальной цены в массиве товаров - при помощи индексатора
        public int MinCost() {
            int imin = 0, n = _shop.Length;
            for (int i = 1; i < n; i++) {
                if (_shop[i].Cost < _shop[imin].Cost) imin = i;
            } // for i

            return _shop[imin].Price;
        } // MinCost

        // Поиск максимальной цены в массиве товаров - при помощи индексатора
        public int MaxCost() {
            int imax = 0, n = _shop.Length;
            for (int i = 1; i < n; i++) {
                if (_shop[i].Cost > _shop[imax].Cost) imax = i;
            } // for i

            return _shop[imax].Price;
        } // MaxCost

        // Выборка товаров с заданной ценой
        Product[] SelectProduct(int value) {
            // Размер массива товаров
            int n = _shop.Length;

            // массив для отобранных товаров
            Product[] data = new Product[n];

            // цикл отбора товаров
            int k = 0;
            for(int i = 0; i < n; ++i)
                if (_shop[i].Cost == value)
                    data[k++] = _shop[i];

            // установить размер массива отобранных товаров по фактическому
            // количеству отобранных товаров :)
            Array.Resize(ref data, k); 
            return data;
        } // SelectProduct

        // Сортировка - рекурсивная быстрая сортировка
        // array - массив для сортировки
        // start - индекс начала части массива
        // end   - индекс конца части массива
        public void QuickSort(int start, int end) {
            // условие завершения рекурсии
            if (start >= end) return;

            // начальные значения переменных на очередном вызове
            int i = start, j = end;                      // для работы алгоритма
            int baseElement = start + (end - start) / 2; // расчет начального индекса середины массива

            // проходим по обрабатываемой части массива, элементы
            // меньшие базового помещаем в первую половину массива 
            // (до базового элемента), элементы бОльшие базового 
            // помещаем во вторую половину массива (после базового)
            while (i < j) {
                // середина - значение элемента в середине интервала
                // (базовый элемент)
                Product value = _shop[baseElement];

                // движение от начала к середине, пока не найдем элемент <= середины 
                // (бОльший базового)
                while (i < baseElement && _shop[i].Number <= value.Number) i++;

                // движение от конца к середине, пока не найдем элемент >= середины
                // меньше базового
                while (j > baseElement && value.Number >= _shop[j].Number) j--;

                // если это возможно, меняем местами найденные элементы
                // бОльший --- базовый --- меньший ###>  меньший --- базовый --- бОльший
                if (i < j) {
                    // меняем местами элементы в половинках массива
                    (_shop[i], _shop[j]) = (_shop[j], _shop[i]);

                    // если слева дошли до середины - нет элементов для обмена
                    // отодвигаем середину вправо, чтобы продолжать движение
                    // по массиву
                    if (i == baseElement) baseElement = j;

                    // если справа дошли до середины - нет элементов для обмена
                    // отодвигаем середину влево для продолжения движения
                    else if (j == baseElement) baseElement = i;
                } // if
            } // while

            // рекурсивный вызов в новых границах поиска
            QuickSort(start, baseElement);      // от начала массива до cur
            QuickSort(baseElement + 1, end);    // от cur+1 до конца массива
        } // quickSort
    } // class Task3
}
