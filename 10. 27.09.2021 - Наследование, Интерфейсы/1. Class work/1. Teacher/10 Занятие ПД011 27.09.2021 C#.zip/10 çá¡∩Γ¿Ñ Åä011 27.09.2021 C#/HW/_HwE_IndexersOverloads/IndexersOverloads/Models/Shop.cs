﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersOverloads.Models
{
    /* 
     * Класс Shop (магазин), хранящий название магазина, закрытый массив 
     * товаров. В классе реализованы методы заполнения массива товаров 
     * данными, вывод товаров в консоль, суммирование стоимостей товаров. 
     * Разработан индексатор с контролем выхода за пределы массива.
     */
    internal class Shop
    {
        // название магазина
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException("Не указано название магазина");
                _name = value;
            }
        } // Name

        // контейнер данных и свойство получения длины массива
        private Product[] _products;
        public int Length => _products.Length;

        // индексатор для массива
        public Product this[int index] {
            // получить элемент с заданным индексом, при выходе
            // индекса за допустимые пределы - выбросить исключение 
            get {
                if (index < 0 || index > _products.Length) {
                    throw new IndexOutOfRangeException(
                        "Выход индекса за пределы массива при чтении");
                } // if

                return _products[index];
            } // get

            // записать элемент с заданным индексом, при выходе
            // индекса за допустимые пределы - выбросить исключение  
            set {
                if (index < 0 || index > _products.Length) {
                    throw new IndexOutOfRangeException(
                        "Выход индекса за пределы массива при записи");
                } // if

                _products[index] = value;
            } // set
        } // indexer


        public Shop() : this("Магазин 'Продадим всё'", new Product[10]) {
            Initialize();
        } // Shop
        public Shop(string name, Product[] products) {
            Name = name;

            // принимаем только не пустой массив товаров
            if (products.Length == 0)
                throw new ArgumentException("Попытка передачи пустого массива товаров в магазин");
            _products = products;
        } // Shop

        // заполнение массива товаров начальными значениямм для обработки
        public void Initialize() {
            (string Name, int Price)[] seeds = { 
                ("ручка гелевая",           35),
                ("галоши резиновые",       230),
                ("пиджак импортный",      1210),
                ("кинокамера",            2800),
                ("маркер спиртовый",        50),
                ("зонтик автоматический",  950),
            };

            // заполнить массив товаров новым набором данных
            int n = _products.Length;
            for (int i = 0; i < n; i++) {
                int k = Utils.Random.Next(0, seeds.Length-1);
                _products[i].Name = seeds[k].Name;
                _products[i].Price = seeds[k].Price;
                _products[i].Number = Utils.Random.Next(1, 5);
            } // for i
        } // Initialize
    } // class Shop
}
