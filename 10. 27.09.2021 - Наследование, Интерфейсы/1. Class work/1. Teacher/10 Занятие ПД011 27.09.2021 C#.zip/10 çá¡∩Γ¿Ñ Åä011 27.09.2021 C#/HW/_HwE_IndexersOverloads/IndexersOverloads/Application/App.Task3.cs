﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersOverloads.Application
{
    /* 
     * Методы для решения задачи 3
     */
    internal partial class App
    {
        // Заполнение магазина начальными данными 
        public void Task3Point1() {
            Utils.ShowNavBarTask("   Заполнение магазина начальными данными");

            Utils.ShowUnderConstruction();
        } // Task3Point1

        // Вывод данных магазина
        public void Task3Point2() {
            Utils.ShowNavBarTask("   Вывод данных магазина");

            Utils.ShowUnderConstruction();
        } // Task3Point2

        // Выборка товаров с минимальной ценой
        public void Task3Point3() {
            Utils.ShowNavBarTask("   Выборка товаров с минимальной ценой");

            Utils.ShowUnderConstruction();
        } // Task3Point3

        // Выборка товаров с максимальной ценой
        public void Task3Point4() {
            Utils.ShowNavBarTask("   Выборка товаров с максимальной ценой");

            Utils.ShowUnderConstruction();
        } // Task3Point4

        // Сортировка товаров по убыванию количества
        public void Task3Point5() {
            Utils.ShowNavBarTask("   Сортировка товаров по убыванию количества");

            Utils.ShowUnderConstruction();
        } // Task3Point5
    } // class App
}
