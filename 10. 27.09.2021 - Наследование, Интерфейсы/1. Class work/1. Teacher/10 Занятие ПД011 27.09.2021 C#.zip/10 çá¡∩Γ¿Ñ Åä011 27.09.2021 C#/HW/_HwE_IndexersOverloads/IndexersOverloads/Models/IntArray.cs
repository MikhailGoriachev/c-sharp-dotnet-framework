﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersOverloads.Models
{
    /* 
     * Класс для хранения одномерного массива из п элементов, 
     * типа int, имя класса IntArray.  В классе реализовать:
     *     • контейнер данных – собственно массив с уровнем доступа private
     *     • индексатор с контролем выхода за допустимые пределы (при выходе 
     *       выбрасывать исключение)      
     *     • свойство Length - размер массива
     *     • метод заполнения случайными числами
     *     • метод вывода в строку
     */
    internal class IntArray
    {
        // контейнер данных и свойство получения длины массива
        private int[] _data;
        public int Length => _data.Length;

        // количество элементов, выводимых в строку
        private int _m;

        public IntArray():this(new int[10]) {
            Fill(-10, 10);
        } // IntArray
        public IntArray(int[] data, int m = 15) {
            _data = data;
            _m = m;
        } // IntArray

        // индексатор для массива
        public int this[int index] {
            // получить элемент с заданным индексом, при выходе
            // индекса за допустимые пределы - выбросить исключение 
            get {
                if (index < 0 || index > _data.Length) {
                    throw new IndexOutOfRangeException(
                        "Выход индекса за пределы массива при чтении");
                } // if

                return _data[index];
            } // get

            // записать элемент с заданным индексом, при выходе
            // индекса за допустимые пределы - выбросить исключение  
            set {
                if (index < 0 || index > _data.Length) {
                    throw new IndexOutOfRangeException(
                        "Выход индекса за пределы массива при записи");
                } // if

                _data[index] = value;
            } // set
        } // indexer

        // заполнение массива случайными числами в диапазоне [lo, hi]
        public void Fill(int lo, int hi) {
            int n = _data.Length;
            for (int i = 0; i < n; i++) {
                _data[i] = Utils.Random.Next(lo, hi);
            } // for i
        } // Fill

        // Вывод массива с выделением цветом отрицательных элементов
        public void Show(string title, int indent = 12, int m = 15) {
            string space = " ".PadRight(indent);
            Console.Write($"{space}{title}\n{space}");

            int n = _data.Length;
            for (int i = 0; i < n; i++) {
                Console.Write($"{_data[i], 7}");
                if (i % _m == 0) Console.Write($"\n{space}");
            } // for i

            Console.WriteLine();
        } // Show

        // Вывод элементов массива в строку
        public override string ToString() {
            StringBuilder sb = new StringBuilder();
            int n = _data.Length; 
            for (int i = 0; i < n; i++) {
                sb.Append($"{_data[i],7}   ");
                if ((i+1) % _m == 0) sb.AppendLine();
            } // for i

            sb.AppendLine();
            return sb.ToString();
        } // ToString
    } // class IntArray 
}
