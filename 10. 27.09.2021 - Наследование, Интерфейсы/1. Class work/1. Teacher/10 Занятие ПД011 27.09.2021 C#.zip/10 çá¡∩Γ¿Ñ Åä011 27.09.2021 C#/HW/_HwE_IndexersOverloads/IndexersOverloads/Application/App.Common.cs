﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using IndexersOverloads.Controllers;

namespace IndexersOverloads.Application
{
    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App
    {
        Task1 _task1;  // объект для решения задачи 1
        Task2 _task2;  // объект для решения задачи 2
        Task3 _task3;  // объект для решения задачи 3

        // конструктор по умолчанию
        public App():this(new Task1(), new Task2(), new Task3()) { }
       
        // конструктор с внедрением зависимостей
        public App(Task1 task1, Task2 task2, Task3 task3) {
            _task1 = task1;
            _task2 = task2;
            _task3 = task3;
        } // App
       
    } // class App
}
