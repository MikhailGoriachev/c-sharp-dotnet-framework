﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersOverloads.Models
{
    /* 
     * Класс Toy для представления игрушки со свойствами – название
     * игрушки (string), возрастная категория (int), цена игрушки (int). 
     * Перегрузите операции для класса Toy:
     *     • +: сложения игрушки с целым числом – операция выполняет сложение 
     *          цены и числа
     *     • –: вычитания целого числа из игрушки – операция выполняет вычитание 
     *          целого числа из цены игрушки
     *     • < и >: сравнение цен двух игрушек
     *     • true: если возрастная категория больше 5
     *     • false: если возрастная категория меньше или равна 5   
     */
    internal class Toy {
        // название игрушки
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException("Не указано название игрушки");
                _name = value;
            }
        } // Name

        // возрастная категория
        private int _age;
        public int Age {
            get => _age;
            set {
                if (value < 0)
                    throw new ArgumentException("Некорректное значение возрастной категории игрушки");
                _age = value;
            } // set
        } // Age

        // цена игрушки
        private int _price;
        public int Price {
            get => _price;
            set {
                if (value < 0)
                    throw new ArgumentException("Некорректное значение цены игрушки");
                _price = value;
            } // set
        } // Price

        // строковое представление игрушки
        public override string ToString() =>
            $"Игрушка '{_name}', категория {_age}+, цена {_price}.00 руб.";

        // вывод в строку таблицы
        public string ToTableRow(int numRow) =>
            $"│ {numRow,3} │ {_name,-18} │ {_age,-12} │ {_price,15:n2}  │";

        // статический метод для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬──────────────────────┬────────────┬───────────────┐\n" +
                $"{spaces}│  №  │ Наименование         │ Возрастная │ Цена игрушки, │\n" +
                $"{spaces}│ п/п │             игрушки  │ категория  │      руб.     │\n" +
                $"{spaces}├─────┼──────────────────────┼────────────┼───────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴──────────────────────┴────────────┴───────────────┘";

        #region перегруженные операции
        // +: сложения игрушки с целым числом – операция выполняет сложение 
        //    цены и числа
        public static Toy operator +(Toy t1, int number) =>
            new Toy {_name = t1._name, _age = t1._age, Price = t1._price + number };

        // –: вычитания целого числа из игрушки – операция выполняет вычитание 
        //    целого числа из цены игрушки
        public static Toy operator -(Toy t1, int number) =>
            new Toy { _name = t1._name, _age = t1._age, Price = t1._price - number };

        // < и >: сравнение цен двух игрушек
        public static bool operator <(Toy t1, Toy t2) => t1._price < t2._price;
        public static bool operator >(Toy t1, Toy t2) => t1._price > t2._price;

        // true: если возрастная категория больше 5
        public static bool operator true(Toy t) => t._age > 5;

        // false: если возрастная категория меньше или равна 5   
        public static bool operator false(Toy t) => t._age <= 5;
        #endregion
    } // class Toy
}
