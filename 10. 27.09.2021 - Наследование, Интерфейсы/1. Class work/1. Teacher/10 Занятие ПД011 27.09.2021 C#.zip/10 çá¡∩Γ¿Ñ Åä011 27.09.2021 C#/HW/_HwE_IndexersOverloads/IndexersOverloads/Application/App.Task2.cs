﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersOverloads.Application
{
    /* 
     * Методы для решения задачи 2
     */
    internal partial class App
    {

        // Демонстрация перегруженных операций класса Toy
        public void Task2Point1() {
            Utils.ShowNavBarTask("   Демонстрация перегруженных операций класса Toy");

            Utils.ShowUnderConstruction();
        } // Task2Point1


    } // class App
}
