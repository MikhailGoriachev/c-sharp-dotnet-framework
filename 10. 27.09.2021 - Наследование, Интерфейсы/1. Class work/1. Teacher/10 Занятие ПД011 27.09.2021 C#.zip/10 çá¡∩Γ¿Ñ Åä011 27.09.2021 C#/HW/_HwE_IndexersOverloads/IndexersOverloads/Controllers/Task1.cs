﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using IndexersOverloads.Models;

namespace IndexersOverloads.Controllers
{
    /* 
     * В классе Task1 с использованием класса одномерного массива и индексатора 
     * реализовать обработки:
     *     • произведение элементов массива с четными номерами, вывести массив 
     *       с выделением цветом элементов с четными номерами 
     *     • сумму элементов массива, расположенных между первым и последним 
     *       нулевыми элементами, вывести диапазон суммирования с выделением 
     *       цветом: границ и слагаемых
     *     • отрицательным элементам массива поменять знак, сортировать массив по 
     *       убыванию. Метод сортировки – сортировка вставками     
     */
    internal class Task1
    {
        // данные для обработки
        private IntArray _data;
        
        // конструкторы класса
        public Task1():this(new IntArray()) {
            Initialize();
        }
        public Task1(IntArray data) {
            _data = data;
        }

        // Заполнение массива данными для обработки
        public void Initialize() => _data.Fill(-10, 10);

        // Вывод массива в консоль
        public void Show(string str) =>
            Console.WriteLine($"{str}\n{_data}\n\n");

        // Произведение элементов массива с четными номерами
        // т.е. с нечетными индексами
        public long Prod() {
            long prod = 1;
            for (int i = 0; i < _data.Length; i++) {
                prod *= _data[i]; 
            } // for i

            return prod;
        } // Prod

        // сумма элементов массива, расположенных между первым и последним
        // нулевыми элементами

        // найти первое вхождение ключа поиска
        int IndexOf(int key) {
            int n = _data.Length;
            for (int i = 0; i < n; i++) {
                if (key == _data[i]) return i;
            } // for i

            return -1;
        } // IndexOf

        // найти последнее вхождение ключа поиска
        int LastIndexOf(int key) {
            int n = _data.Length;
            for (int i = n-1; i >= 0; i--) {
                if (key == _data[i]) return i;
            } // for i

            return -1;
        } // LastIndexOf

        // возвращает сумму элементов массива между первым и последним нулевыми элементами
        public int SummaBetweenFirstLastZero() {
            // индексы первого и последнего элементов, равных 0
            int firstZero = IndexOf(0);
            int lastZero = LastIndexOf(0);

            if (firstZero < 0 || lastZero < 0)
                throw new Exception("В массиве нет двух элементов, равных нулю.");

            int sum = 0;
            for (int i = firstZero+1; i < lastZero; i++) 
                sum += _data[i];

            return sum;
        } // SummaBetweenFirstLastZero

        // Вывод массива с выделением цветом первого и последнего нулевых элементов,
        // и элементов между ними
        public void ShowSum() {
            // индексы первого и последнего элементов, равных 0
            int firstZero = IndexOf(0);
            int lastZero = LastIndexOf(0);

            (ConsoleColor fg, ConsoleColor bg) oldColor = 
                (Console.ForegroundColor, Console.BackgroundColor);

            Console.WriteLine("\n\n\t    Сумма элементов между первым и последним нулями:\n");
            int n = _data.Length;
            for (int i = 0; i < n; i++) {
                (ConsoleColor fg, ConsoleColor bg) color = oldColor;
                if (i == firstZero)
                    color = (fg:ConsoleColor.DarkRed, bg:ConsoleColor.Gray);
                else if (i == lastZero)
                    color = (fg: ConsoleColor.Black, bg: ConsoleColor.Gray);
                else if (firstZero < i && i < lastZero)
                    color = (fg: ConsoleColor.DarkMagenta, bg: ConsoleColor.Gray);

                (Console.ForegroundColor, Console.BackgroundColor) = color;
                Console.Write($"{_data[i], 7}  ");
                (Console.ForegroundColor, Console.BackgroundColor) = oldColor;
                Console.Write(" ");
            } // for i
        } // ShowSum


        // Вывод массива с выделением цветом элементов с четными номерам, т.е.
        // с нечетными индексами
        public void ShowEvenNumbers() {
            (ConsoleColor fg, ConsoleColor bg) oldColor =
                (Console.ForegroundColor, Console.BackgroundColor);

            Console.WriteLine("\n\n\t    Массив для обработки. Элементы с четными номерами выделены цветом:\n");
            int n = _data.Length;
            for (int i = 0; i < n; i++) {
                (ConsoleColor fg, ConsoleColor bg) color = (i & 1) != 0
                    ?(fg: ConsoleColor.Black, bg: ConsoleColor.Gray)
                    :oldColor;

                (Console.ForegroundColor, Console.BackgroundColor) = color;
                Console.Write($"{_data[i], 7}  ");
                (Console.ForegroundColor, Console.BackgroundColor) = oldColor;
                Console.Write(" ");
            } // for i
        } // ShowEvenNumbers


        // Отрицательным элементам массива поменять знак
        public void Transform() {
            int n = _data.Length;
            for (int i = 0; i < n; i++) {
                _data[i] = _data[i] < 0?-_data[i] : _data[i];
            } // for i
        } // Transform

        // Сортировать массив по убыванию. Метод сортировки – сортировка
        // вставками
        public void SortInsertionDesc() {
            int n = _data.Length;
            // Внешний цикл - перебор элементов массива
            for (int i = 1; i < n; ++i) {
                int j;
                // признак необходимости вставки элемента
                bool flag = false;     // предполагаем, что вставка не нужна
                                       // ищем место для вставки очередного проверяемого 
                                       // элемента массива arr[i]
                for (j = 0; j <= i; ++j) {
                    if (_data[i] > _data[j]) { // условие вставки сработало
                        flag = true;           // установить признак вставки
                        break;
                    } // if
                } // for j

                // вставка не нужна - переходим к следующему элементу массива
                if (!flag) continue;

                // сдвиг части массива вправо, вставка кандидата на найденное место
                var t = _data[i];
                for (int k = i; k > j; --k)
                    _data[k] = _data[k - 1];
                _data[j] = t;
            } // for i
        } // SortInsertionDesc
    } // class Task1
}
