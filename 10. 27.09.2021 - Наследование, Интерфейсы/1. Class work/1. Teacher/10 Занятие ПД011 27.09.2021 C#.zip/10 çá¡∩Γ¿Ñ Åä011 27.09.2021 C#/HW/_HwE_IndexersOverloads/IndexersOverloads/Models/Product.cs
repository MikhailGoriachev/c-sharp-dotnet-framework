﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersOverloads.Models
{
    /* 
     * Описать класс «товар», содержащий следующие закрытые поля:
     *     • название товара;
     *     • количество товара (в условных единицах);
     *     • цена единицы товара в рублях.
     * Предусмотреть свойства для задания и получения состояния объекта.
     * Реализовать перегруженные операции:
     *     • +: сложения товаров с одинаковыми наименованиями, выполняющую 
     *             сложение их стоимостей, т.е. цен, умноженных на количество
     *     • +: сложения товара и целого числа, выполняющего сложение цены 
     *             и целого числа
     *     • –: вычитание товара и целого числа, выполняющего вычитание целого
     *             числа из цены
     *     • сравнение товаров по цене: < >, <= >=, == !=
     *     • операция true: стоимость товара в интервале 1, …, 1000
     *     • операция false: стоимость товара равна 0 или больше 1000     
     */
    internal class Product
    {
        // название товара;
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException("Не указано название товара");
                _name = value;
            }
        } // Name

        // количество товара (в условных единицах)
        private int _number;
        public int Number {
            get => _number;
            set {
                if (value < 0)
                    throw new ArgumentException("Некорректное значение количества товара");
                _number = value;
            } // set
        } // Number

        // цена единицы товара в рублях
        private int _price;
        public int Price {
            get => _price;
            set {
                if (value < 0)
                    throw new ArgumentException("Некорректное значение цены товара");
                _price = value;
            } // set
        } // Price

        // Стоимость товара - цена, умноженная на количество
        public int Cost => _price * _number;


        // Перегруженные операции:
        // +: сложения товаров с одинаковыми наименованиями, выполняющую 
        //    сложение их стоимостей, т.е. цен, умноженных на количество
        public static int operator +(Product p1, Product p2) {
            if (p1._name != p2._name)
                throw new InvalidOperationException("Сложение невозможно для товаров с разными наименованиями");

            return p1.Cost + p2.Cost;
        } // operator+

        // +: сложения товара и целого числа, выполняющего сложение цены 
        //       и целого числа
        public static Product operator +(Product p1, int value) =>
            new Product { _name = p1._name, _number = p1._number, Price = p1._price + value};

        // –: вычитание товара и целого числа, выполняющего вычитание целого
        //       числа из цены
        public static Product operator -(Product p1, int value) =>
            new Product { _name = p1._name, _number = p1._number, Price = p1._price - value };

        // сравнение товаров по цене: < >, <= >=, == !=
        public static bool operator <(Product p1, Product p2) => p1._price < p2._price;
        public static bool operator >(Product p1, Product p2) => p1._price > p2._price;

        public static bool operator <=(Product p1, Product p2) => p1._price <= p2._price;
        public static bool operator >=(Product p1, Product p2) => p1._price >= p2._price;

        public static bool operator ==(Product p1, Product p2) => p1._price == p2._price;
        public static bool operator !=(Product p1, Product p2) => p1._price != p2._price;

        // операция true: стоимость товара в интервале 1, …, 1000
        public static bool operator true(Product p) => 1 <= p.Cost && p.Cost <= 1_000;

        // операция false: стоимость товара равна 0 или больше 1000  
        public static bool operator false(Product p) => 0 == p.Cost || p.Cost > 1_000;

        #region Вывод в консоль
        //
        // формирование строкового представления объекта
        public override string ToString() => 
            $"товар '{_name}', с ценой {_price}.00 руб., количество {_number} шт.";

        // формирование строки таблицы для представления объекта 
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_name,-20} │ {_price, 10}.00 │ {_number, 7}    │";

        // статический метод для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬──────────────────────┬───────────────┬────────────┐\n" +
                $"{spaces}│  №  │ Наименование         │ Цена единицы  │ Количество │\n" +
                $"{spaces}│ п/п │              товара  │ товара, руб.  │   товара   │\n" +
                $"{spaces}├─────┼──────────────────────┼───────────────┼────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴──────────────────────┴───────────────┴────────────┘";

        #endregion
    } // class Product
}
