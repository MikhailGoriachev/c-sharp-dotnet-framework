﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersOverloads.Application
{
    /* 
     * Методы для решения задачи 1
     */
    internal partial class App
    {
        // Заполнение массива данными для обработки
        public void Task1Point1() {
            Utils.ShowNavBarTask("   Заполнение массива данными для обработки");

           // Сформировать массив данных, вывести его в консоль
           _task1.Initialize();
           _task1.ShowEvenNumbers();
        } // Task1Point1

        // Произведение элементов с четными номерами
        public void Task1Point2() {
            Utils.ShowNavBarTask("   Произведение элементов с четными номерами");

            long prod = _task1.Prod();
            _task1.ShowEvenNumbers();
            Console.WriteLine($"\n\t    Произведение элементов массива с четными номерами: {prod}"); 
        } // Task1Point2

        // Сумма элементов между первым и последним нулями
        public void Task1Point3() {
            Utils.ShowNavBarTask("   Сумма элементов между первым и последним нулями");

            int sum = _task1.SummaBetweenFirstLastZero();
            _task1.SummaBetweenFirstLastZero();
            Console.WriteLine($"\n\t    Сумма элементов между первым и последним нулями: {sum}");
        } // Task1Point3

        // Преобразование и сортировка массива
        public void Task1Point4() {
            Utils.ShowNavBarTask("   Преобразование и сортировка массива");

            _task1.Show("\n\n\n\n\t    Массив для преобразования и сортировки");
            _task1.Transform();
            _task1.SortInsertionDesc();

            _task1.Show("\n\n\t    Массив после преобразования и сортировки");
        } // Task1Point4

    } // class App
}
