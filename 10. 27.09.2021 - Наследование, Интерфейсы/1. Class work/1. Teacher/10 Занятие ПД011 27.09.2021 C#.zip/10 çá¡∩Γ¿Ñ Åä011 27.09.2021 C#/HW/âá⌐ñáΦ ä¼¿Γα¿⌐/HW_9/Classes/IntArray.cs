﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_9.Classes{
    public class IntArray {
        private const int n = 10, low = -10, high = 10;

        public IntArray():this(new int[n]) { }
        public IntArray(int[] data){
            data = _data;
        } // IntArray

        private int[] _data;
        public int[] Data { get; set; }
        public int this[int index]{
            get{
                if (index < 0)
                    throw new Exception("\nВыход за пределы массива недопутим!\n");
                else if (index >= _data.Length)
                    throw new Exception("\nВыход за пределы массива недопутим!\n");
                return _data[index];
            } // get
            set{
                if (index < 0)
                    throw new Exception("\nВыход за пределы массива недопутим!\n");
                else if (index >= _data.Length)
                    throw new Exception("\nВыход за пределы массива недопутим!\n");
                _data[index] = value;
            } // set
        } // int indexer

        public int Length { get { return _data.Length; } }

        // Заполение элементов массива
        public void Fill(){
            _data = new int[n];
            for (int i = 0; i < _data.Length; i++)
                _data[i] = Utils.Random.Next(low, high);
        } // Fill

        // Вывод элементов массива в строку
        public string Show(){
            string str = "";
            foreach (var i in _data)
                str += ($"{i}   ");
            return str;
        } // Show

    } // IntArray
}
