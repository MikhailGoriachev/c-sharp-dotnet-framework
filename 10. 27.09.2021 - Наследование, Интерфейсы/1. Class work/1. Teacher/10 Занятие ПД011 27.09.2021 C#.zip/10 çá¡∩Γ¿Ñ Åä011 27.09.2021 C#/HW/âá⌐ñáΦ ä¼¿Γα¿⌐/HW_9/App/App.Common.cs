﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW_9.Classes;

namespace HW_9.App{
    public partial class App{

        private IntArray _intArray;

        public App():this(new IntArray()){}

        public App(IntArray intA){
            _intArray = intA;_intArray.Fill();
        } // App
    } // App.Common
}
