﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_9.App{
    partial class App{

        public void task3_1(){

        } // task3_1

    } // App.Task3
}
