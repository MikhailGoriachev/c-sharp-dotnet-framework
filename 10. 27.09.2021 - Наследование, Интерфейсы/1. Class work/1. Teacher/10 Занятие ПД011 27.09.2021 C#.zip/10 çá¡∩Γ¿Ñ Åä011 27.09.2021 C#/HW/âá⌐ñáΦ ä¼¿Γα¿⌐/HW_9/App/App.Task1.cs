﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW_9.Classes;

namespace HW_9.App{
    partial class App{

        // Произведение элементов массива с четными номерами
        public void task1_1(){
            Console.WriteLine("\n\n\t\tМассив целых чисел:\n");
            int n = _intArray.Length;

            Console.Write($"\t{_intArray.Show()}\n\t");

            // умножаем каждый четный элемент самового на себя
            for(int i = 0; i < n; i++)
                if ((_intArray[i] % 2) == 0) _intArray[i] *= _intArray[i];

            ConsoleColor oldClr = Console.ForegroundColor;

            // вывод с цветом
            for (int i = 0; i < n; i++){
                if ((_intArray[i] % 2) == 0)
                    Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write($"{_intArray[i]}   ");

                Console.ForegroundColor = oldClr;
            } // for i

            Console.ForegroundColor = oldClr;

        } // task1_1

        // Сумма элементов массива, расположенных между первым и последним нулевыми элементами
        public void task1_2(){
            Console.Write("\n\n\tДля этого задания массив будет генирироваься по другому по отоношению к 1 и 3 заданию\n");

            int sum = 0;
            Console.WriteLine("\n\n\t\tМассив целых чисел:");
            int n = _intArray.Length;
            _intArray.Data = new int[n];
            for (int i = 0; i < n; i++)
                _intArray[i] = Utils.Random.Next(-3, 3);
            Console.Write($"\t{_intArray.Show()}\n\t");

            // int firstNul = Array.FindIndex(_intArray.Data, item=>item == 0), lastNul = Array.FindLastIndex(_intArray.Data, item => item == 0);
            // я не понял почему так не работает, потому и написал по "старинке )"

            int firstNul = -1, lastNul = -1;
            // нахоим первый ноль
            for (int i = 0; i < n; i++)
                if (_intArray[i] == 0){
                    firstNul = i;
                    break;
                } // if
            // находим последний ноль
            for(int i = n - 1; i >= 0; i--)
                if (_intArray[i] == 0){
                    lastNul = i;
                    break;
                } // if

            // суммируем
            for(int i = 0; i < n; i++)
                if (firstNul <= i && i <= lastNul)
                    sum += _intArray[i];

            ConsoleColor oldClr = Console.ForegroundColor;
            // вывод результата
            Console.Write($"\n\tМассив с выделение границ и диапазона\n\t");
            for(int i = 0; i < n; i++){
                if (firstNul <= i && i <= lastNul)
                    Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write($"{_intArray[i]}   ");

                Console.ForegroundColor = oldClr;
            } // for i

            Console.Write($"\n\tСумма элементов массива в диапазоне = {sum}\n");
        } // task1_2

        // Отрицательным элементам массива поменять знак
        public void task1_3(){
            Console.WriteLine("\n\n\t\tМассив целых чисел до сортировки:\n");
            int n = _intArray.Length;

            Console.Write($"\t{_intArray.Show()}\n\t");

            for (int i = 0; i < n; i++)
                if (_intArray[i] < 0) _intArray[i] *= -1;

            SortIntArray();

            Console.WriteLine("\n\n\t\tМассив целых чисел после сортировки:\n");
            Console.Write($"\n\t{_intArray.Show()}\n");

        } // task1_3

        // Сотрировка вставками по убыванию
        public void SortIntArray(){
            int n = _intArray.Length;
            for (int i = 1; i < n; i++)
                for (int j = i; j > 0 && _intArray[j - 1] < _intArray[j]; j--){
                    int temp = _intArray[j - 1];
                    _intArray[j - 1] = _intArray[j];
                    _intArray[j] = temp;
                }
        } // SortIntArray

    } // App.Task1
}
