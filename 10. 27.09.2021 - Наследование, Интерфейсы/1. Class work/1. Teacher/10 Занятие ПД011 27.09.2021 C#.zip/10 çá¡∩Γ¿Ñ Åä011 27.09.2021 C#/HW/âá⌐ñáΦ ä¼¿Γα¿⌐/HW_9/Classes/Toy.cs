﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_9.Classes{
    public class Toy{
        public Toy(string name = "Медведь", int age = 4, int cost = 459){
            Name = name;
            Age = age;
            Cost = cost;
        } // Toy

        private string _name;
        public string Name { get; set; }
        private int _age;
        public int Age { get; set; }
        private int _cost;
        public int Cost { get; set; }

        // перегрузка операции + сложение объекта и целого числа
        public static Toy operator +(Toy t, int number) =>
            new Toy { Name = t.Name, Age = t.Age, Cost = t.Cost + number };

        // перегрузка операции - вычиатние целого числа из объекта
        public static Toy operator -(Toy t, int number) =>
            new Toy { Name = t.Name, Age = t.Age, Cost = t.Cost - number };

        public static bool operator >(Toy t1, Toy t2){
            return t1.Cost > t2.Cost;
        } // operator >
        public static bool operator <(Toy t1, Toy t2){
            return t1.Cost < t2.Cost;
        } // operator <

        public static bool operator true(Toy t) => t.Age > 5;
        public static bool operator false(Toy t) => t.Age <= 5;

        public override string ToString() => $"Название: {Name}\nВозрастная категория: {Age}\nСтоимость: {Cost}";

    } // Toy
}
