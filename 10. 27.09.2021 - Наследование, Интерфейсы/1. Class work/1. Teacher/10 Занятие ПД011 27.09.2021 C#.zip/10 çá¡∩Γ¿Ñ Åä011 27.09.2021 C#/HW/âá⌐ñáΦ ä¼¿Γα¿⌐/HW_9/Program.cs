﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW_9.Classes;
using HW_9.App;
using Microsoft.VisualBasic;

namespace HW_9{
    class Program{
        static void Main(string[] args){
            Console.Title = "HW";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Произведение элементов массива с четными номерами" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Сумма элементов массива, расположенных между первым и последним нулевыми элементами" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Отрицательным элементам массива поменять знак" },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.P, Text = "Демонстрация операций+ " },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            HW_9.App.App app = new HW_9.App.App();

            // главный цикл приложения
            while (true){
                try{
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();

                    switch (key){
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1
                        #region Задача 1
                        // Произведение элементов массива с четными номерами
                        case ConsoleKey.Q:
                            app.task1_1();
                            break;

                        // Сумма элементов массива, расположенных между первым и последним нулевыми элементами
                        case ConsoleKey.W:
                            app.task1_2();
                            break;

                        // Отрицательным элементам массива поменять знак
                        case ConsoleKey.E:
                            app.task1_3();
                            break;
                        #endregion
                        #region Задача 2
                        case ConsoleKey.P:
                            app.task2_1();
                            break;
                        #endregion

                        // Выход из приложения назначен на клавишу F10 или клавишу Z или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Black);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex){
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch


            } // while
        } // Main
    } // Program
}
