﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW_9.Classes;

namespace HW_9.App{
    partial class App{

        // Демонстрация операций
        public void task2_1(){
            Toy t1 = new Toy();
            Console.Write($"{t1}");

            Toy t = new Toy();

            t = t1 + 100;

            Console.Write($"\n\n\tt1+100 :\n{t}\n");

            t = t1 - 59;
            Console.Write($"\n\n\tt1 - 59 :\n{t}\n");


            Toy t2 = new Toy("Поезд", 6, 711);

            Console.Write($"\nt2 = \n{t2}");
            Console.Write($"\n\n\t t1 > t2  :{t1>t2}\n");

            Console.Write($"\n\n\t t1 < t2  :{t1<t2}\n");

            Console.Write($"\nВозрастная категория больше 5(t1):\n");
            if (t1)
                Console.WriteLine("True");
            else
                Console.WriteLine("False");

        } // task2_1

    } // App.Task2
}
