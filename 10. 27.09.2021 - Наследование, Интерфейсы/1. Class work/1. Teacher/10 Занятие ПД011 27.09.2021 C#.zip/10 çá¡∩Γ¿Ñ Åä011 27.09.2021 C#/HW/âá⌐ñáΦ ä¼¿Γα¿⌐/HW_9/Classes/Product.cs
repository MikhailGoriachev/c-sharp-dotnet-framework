﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_9.Classes{
    class Product {

        public Product(string name, int count, int cost) {
            Name = name;
            Count = count;
            Cost = cost;
        } // Product

        private string _name;
        public string Name { get; set; }

        private int _count;
        public int Count { get; set; }

        private int _cost;
        public int Cost { get; set; }

        // public static Product operator +(Product p, int number) =>
        //    new Product { Name = p.Name, Count = p.Count, Cost = p.Cost + number };

        // public static Product operator -(Product p, int number) =>
        //    new Product { Name = p.Name, Count = p.Count, Cost = p.Cost - number };

    } // Product
}
