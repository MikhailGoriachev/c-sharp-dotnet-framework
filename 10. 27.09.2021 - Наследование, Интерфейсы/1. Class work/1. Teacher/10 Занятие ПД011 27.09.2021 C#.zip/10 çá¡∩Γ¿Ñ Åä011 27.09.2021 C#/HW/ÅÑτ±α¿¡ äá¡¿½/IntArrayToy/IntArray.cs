﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntArrayToy
{
    //класс для хранения одномерного массива из п элементов, типа int
    class IntArray
    {
        
        private int[] _array = new int[10]; // контейнер для хранения массива
        public int Lenght => _array.Length; // размер массива

        public int GetRandInt(int a, int b) => Utils.GetRandomInt(a, b); // метод заполнения случайными числами

        public override string ToString() // метод вывода в строку
        {
            StringBuilder arr = new StringBuilder();
            foreach(var item in _array)
            {
                arr.Append(item);
            }
            return arr.ToString();

        }

        public int this[int index] // индексатор с контролем выхода за пределы массива
        {
            get => _array[index];
            set { if (value > Lenght) throw new Exception(" Выход за пределы массива");
                        _array[index] = value; }
        }

        public void NegativePositive()
        {
            

            for (int i = 0; i < _array.Length; ++i)
            {
                if (_array[i] < 0)
                {
                    _array[i] = -_array[i];
                }
            }
        }

        public void FillArray()
        {
            // заполнение массива случайными значениями
            for (int i = 0; i < _array.Length; ++i)
            {
                _array[i] = GetRandInt(-2, 3);
            }
        }




    }
}
