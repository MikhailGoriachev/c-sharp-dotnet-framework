﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 Задача 1. Разработайте класс для хранения одномерного массива из п элементов, типа int, имя класса IntArray.  В классе реализовать:
•	Индексатор с контролем выхода за допустимые пределы (при выходе выбрасывать исключение)
•	Контейнер данных – собственно массив с уровнем доступа private
•	свойство Length - размер массива
•	метод заполнения случайными числами
•	метод вывода в строку
В классе Task1 с использованием класса одномерного массива и индексатора реализовать обработки:
•	произведение элементов массива с четными номерами, вывести массив с выделением цветом элементов с четными номерами 
•	сумму элементов массива, расположенных между первым и последним нулевыми элементами, вывести диапазон суммирования с выделением цветом: границ и слагаемых
•	отрицательным элементам массива поменять знак, сортировать массив по убыванию. Метод сортировки – сортировка вставками


Задача 2. Разработайте класс Toy для представления игрушки со свойствами – название игрушки (string), возрастная категория (int), стоимость игрушки (int). 
Перегрузите операции для класса Toy:
•	+: сложения игрушки с целым числом – операция выполняет сложение цены и числа
•	–: вычитания целого числа из игрушки – операция выполняет вычитание целого числа из цены игрушки
•	< и >: сравнение цен двух игрушек
•	true: если возрастная категория больше 5
•	false: если возрастная категория меньше или равна 5 
Продемонстрируйте работу перегруженных операций.


Задача 3. Описать класс «товар», содержащий следующие закрытые поля:
•	название товара;
•	количество товара (в условных единицах);
•	стоимость товара в рублях.
Предусмотреть свойства для задания и получения состояния объекта.
Реализовать перегруженные операции:
•	+: сложения товаров с одинаковыми наименованиями, выполняющую сложение их стоимостей, т.е. цен, умноженных на количество
•	+: сложения товара и целого числа, выполняющего сложение цены и целого числа
•	–: вычитание товара и целого числа, выполняющего вычитание целого числа из цены
•	сравнение товаров по цене: < >, <= >=, == !=
•	операция true: стоимость товара в интервале 1, …, 1000
•	операция false: стоимость товара равна 0 или больше 1000
Создайте класс Shop (магазин), в котором хранить название магазина, закрытый массив товаров. Реализуйте в этом классе методы заполнения массива товаров данными, вывод товаров в консоль, суммирование цен товаров. Разработайте индексатор с контролем выхода за пределы массива.
При помощи индексатора, в классе решения Task3 реализуйте поиск товаров с минимальной ценой, максимальной ценой, сортировку товара по убыванию количества (метод быстрой сортировки). 
 */

namespace IntArrayToy
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 27.09.2021. Перегрузка операций, работа с индексатором ";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Вывести произведение элементов массива с четными номерами" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Вывести сумму элементов массива, расположенных между первым и последним нулевыми элементами" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Отрицательным элементам массива поменять знак, сортировать массив по убыванию" },
              //----------------------------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.R, Text = "Сложения игрушки с целым числом " },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Вычитания целого числа из игрушки " },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Сравнение цен двух игрушек" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "true: если возрастная категория больше 5" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "false: если возрастная категория меньше или равна 5 " },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.F, Text = "Вывод массив товаров в консоль " },
                
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // создание экземпляра класса приложения 
            App app = new App();

            while(true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - Перегрузка операций, работа с индексаторами");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с индексаторами и перегрузкой операци", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                     switch(key)
                    {
                        // пункты меню, относящиеся к Задаче 1
                        #region Задача 1
                        case ConsoleKey.Q:
                            app.Task1Point1();
                            break;
                        case ConsoleKey.W:
                            app.Task1Point2();
                            break;
                        case ConsoleKey.E:
                            app.Task1Point3();
                            break;
                        #endregion
                        // пункты меню, относящиеся к Задаче 2
                        #region Задача 2
                        case ConsoleKey.R:
                            app.Task2Point1();
                            break;
                        case ConsoleKey.T:
                            app.Task2Point2();
                            break;
                        case ConsoleKey.A:
                            app.Task2Point3();
                            break;
                        case ConsoleKey.S:
                            app.Task2Point4();
                            break;
                        case ConsoleKey.D:
                            app.Task2Point5();
                            break;
                        #endregion
                        // пункты меню, относящиеся к Задаче 3
                        #region Задача 3
                        case ConsoleKey.F:
                            app.Task3Point1();
                            break;
                        case ConsoleKey.G:
                            app.Task3Point2();
                            break;
                        case ConsoleKey.H:
                            app.Task3Point3();
                            break;
                        case ConsoleKey.X:
                            app.Task3Point4();
                            break;
                        case ConsoleKey.C:
                            app.Task3Point5();
                            break;
                        case ConsoleKey.V:
                            app.Task3Point6();
                            break;
                        #endregion
                        // Выход из приложения назначен на клавишу F10 или клавишу Z или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;
                        default:
                            throw new Exception("Нет такой команды меню");
                    }// switch
                     // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                }// try
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    Console.ReadKey();
                }

            }// while 

        }
    }
}
