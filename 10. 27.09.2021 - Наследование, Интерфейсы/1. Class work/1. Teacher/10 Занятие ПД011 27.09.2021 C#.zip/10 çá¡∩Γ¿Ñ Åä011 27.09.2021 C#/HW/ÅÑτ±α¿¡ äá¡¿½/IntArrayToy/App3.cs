﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IntArrayToy.Models;

namespace IntArrayToy
{
    internal partial class  App
    {
        public void Task3Point1()
        {
            Utils.ShowNavBarTask("Вывод массив товаров в консоль ");

            Task3 task3 = new Task3();

            task3.FillArray(); 

            

        }
        public void Task3Point2() 
        {
            Utils.ShowNavBarTask("Cложения товара и целого числа");

            Task3 task3 = new Task3();

            decimal min;
        }
        public void Task3Point3() 
        {
            Utils.ShowNavBarTask("Вычитание товара и целого числа");
        }
        public void Task3Point4() 
        {
            Utils.ShowNavBarTask("Сравнение товаров по цене: < >, <= >=, == !=");
        }
        public void Task3Point5() 
        {
            Utils.ShowNavBarTask("true: стоимость товара в интервале 1, …, 1000");
        }
        public void Task3Point6() 
        {
            Utils.ShowNavBarTask("false: стоимость товара равна 0 или больше 1000");
        }
        
    }
}
