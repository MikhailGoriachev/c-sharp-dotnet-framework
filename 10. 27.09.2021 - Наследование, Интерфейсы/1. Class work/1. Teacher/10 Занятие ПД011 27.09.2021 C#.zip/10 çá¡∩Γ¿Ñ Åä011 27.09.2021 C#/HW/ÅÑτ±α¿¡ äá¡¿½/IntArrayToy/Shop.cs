﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IntArrayToy.Models;

namespace IntArrayToy
{
    /*
     * Класс Shop (магазин), в котором храниться название магазина, закрытый массив товаров.
     */
    class Shop
    {
        private string  _title;

        public string  Title
        {
            get => _title; 
            set => _title = value; 
        }

        Toy[] toys;  // массив игрушек

        public int Lenght => toys.Length; 

        // метод заполнения массива случаными данными игрушек

        public void GenerateItems(int size)
        {
            toys = new Toy[size];

            string[] items = { "Кукла", "Мишка", "Зачик", "Пистолет", "Мозайка", "Калейдоскоп" };

           
            for (int i = 0; i < size; i++)
                toys[i] = new Toy
                {
                    ToyName = items[Utils.GetRandomInt(0, size - 1)],
                    Age = Utils.GetRandomInt(1, 10),
                    Price = (decimal)Utils.GetRandom(100, 500)
                };// for

        } // GenerateItems

        // суммирование цен товаров
        public decimal SumItems(Toy[] toys)
        {
            decimal total = 0;

            foreach(var item in toys)
            {
                total += item.Price;
            }

            return total;
        }

        public string ToTableRow1() => $"| Общая стоимость    |              | {SumItems(toys),15:n2}  |";


        public void ShowTable()
        {
            Console.WriteLine("\n\n");

            Console.WriteLine($"\t\t {Title}");
            Console.WriteLine("┌────────────────────┬──────────────┬──────────────────┐");
            Console.WriteLine("│   Название игрушки │  Возраст     │ Стоимость        │ ");
            Console.WriteLine("├────────────────────┼──────────────┼──────────────────┤");
            foreach (var item in toys)
            {
                
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(ToTableRow1());
            Console.WriteLine("└────────────────────┴──────────────┴──────────────────┘");
        }

        public Toy this[int index] // индексатор с контролем выхода за пределы массива
        {
            get => toys[index];
            set
            {
                if (index > Lenght) throw new Exception(" Выход за пределы массива");
                toys[index] = value;
            }
        }

        // поиск товара с минимальной ценой 
        public decimal MinPrice(Toy[] toys)
        {
            decimal min = decimal.MaxValue;
            foreach (var item in toys)
            {
                if (item.Price < min)
                {
                    min = item.Price;
                }
            }

            return min;
        }


    } 
}
