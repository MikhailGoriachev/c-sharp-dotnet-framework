﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntArrayToy
{
    /*
     Класс Toy для представления игрушки со свойствами – название игрушки (string), 
     возрастная категория (int), стоимость игрушки (int). 
     */
    class Toy
    {
        private string  _toyName; //название игрушки

        public string  ToyName
        {
            get => _toyName; 
            set => _toyName = value; 
        }

        private int _age;  // возрастная категория 

        public int Age
        {
            get=>  _age; 
            set=> _age = value; 
        }

        private decimal _price; // стоимость игрушки 

        public decimal Price
        {
            get => _price; 
            set =>_price = value;  
        }

        public override string ToString() => $"Игрушка \"{_toyName}\" для детей в возрасте {_age} лет, по цене {_price} ";

        public string ToTableRow() => $"| {ToyName,-18} | {Age,-12} | {Price,15:n2}  |";
       

        // перегрузка операции сложения игрушки с целым числом
        public static Toy operator +(Toy t1, int number) =>
            new Toy { ToyName = t1.ToyName, Age = t1.Age, Price = t1.Price + number };

        // перегрузка операции вычитания целого из игрушки
        public static Toy operator -(int number, Toy t1) =>
            new Toy { ToyName = t1.ToyName, Age = t1.Age, Price = number - t1.Price };

        // перегрузка операции "больше" >

        public static bool operator >(Toy t1, Toy t2) => t1.Price > t2.Price;

        //перегрузка операции "меньше" <
        public static bool operator <(Toy t1, Toy t2) => t1.Price < t2.Price;

        // перегрузка операции true для возрастной категории
        public static bool operator true(Toy t1) => t1.Age > 5; 
        public static bool operator false(Toy t1) => t1.Age <= 5; 


    }
}
