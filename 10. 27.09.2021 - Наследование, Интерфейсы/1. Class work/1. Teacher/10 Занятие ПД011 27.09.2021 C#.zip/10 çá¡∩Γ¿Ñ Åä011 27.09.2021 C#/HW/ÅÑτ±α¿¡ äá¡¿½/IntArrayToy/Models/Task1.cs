﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntArrayToy.Models
{
    internal class Task1
    {
        public IntArray arr = new IntArray(); // массив для работы по заданию 

        

        // поиск произведения элементов с четными номерами
        public int MultNumber()
        {
            // заполнение массива случайными значениями
            for(int i =0; i<arr.Lenght; ++i)
            {
                arr[i]= arr.GetRandInt(-2, 3);
            }

            int mult = 1; 

            // нахождение произведения 
            for(int i=0; i<arr.Lenght; ++i)
            {
                if((i+1) % 2 ==0)
                {
                    mult *= arr[i];
                }
            }

            return mult;
        }

        // поиск суммы элементов между нулевыми значениями
        public int SumBetweenZeros()
        {
            // заполнение массива случайными значениями
            for (int i = 0; i < arr.Lenght; ++i)
            {
                arr[i] = arr.GetRandInt(-2, 3);
            }

            int sum = 0;
            int indexFirstZero = 0;
            int indexSecondZero = 0; 
            for(int i =0; i<arr.Lenght; ++i)
            {
                if(arr[i] == 0)
                {
                    indexFirstZero = i;
                    break;
                }
            }

            for(int i = arr.Lenght- 1; i>=0; --i)
            {
                if(arr[i] == 0)
                {
                    indexSecondZero = i;
                    break;
                }
            }
            
            for(int i = indexFirstZero; i< indexSecondZero; ++i)
            {
                sum += arr[i]; 
            }

            return sum; 
        }

        //отрицательным элементам массива поменять знак, сортировать массив по убыванию

        public void NegativePositive()
        { 
            // заполнение массива случайными значениями
            for (int i = 0; i < arr.Lenght; ++i)
            {
                arr[i] = arr.GetRandInt(-2, 3);
            }

            for(int i = 0; i<arr.Lenght; ++i)
            {
                if(arr[i] <0)
                {
                    arr[i] = -arr[i];
                }
            }
        }

        //сортировка вставками
        public static void InsertionSort(IntArray array)
        {
            int j;

            for(int i = 1; i<array.Lenght; ++i)
            {
                bool isSorted = true;

                for(j =0; j<=i; ++j)
                   if(array[i] > array[j])
                    {
                        isSorted = false;
                        break;
                    }
                    if (isSorted) continue;

                    int temp = array[i];
                    for (int k = i; k > j; --k)
                        array[k] = array[k - 1];
                    array[j] = temp;
                
            }

            
        }

       


    }
}
