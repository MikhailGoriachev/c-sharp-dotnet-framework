﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntArrayToy.Models
{
    internal class Task2
    {
        // экземпляры класса для демонстрации перегрузок  по заданию
        public Toy t1 = new Toy { ToyName = "Барабан", Age = 6, Price = 120 };
        public Toy t2 = new Toy { ToyName = "Зайчик", Age = 10, Price = 150 };
        public Toy t3 = new Toy { ToyName = "Кукла", Age = 4, Price = 75 };
        public Toy t4 = new Toy(); 
        

        //игрушка + целое число
        public void ToyPlusInt ()
        {
            Toy t4 = t1 + 5;
            Console.WriteLine("\n");
            Console.WriteLine($" Цена игрушки {t1.ToyName} {t1.Price} руб + {5} руб  равно {t4}");
        }

        // целое число из игрушки 
        public void IntMinusToy ()
        {
            Toy t4 = 200 - t3;
            Console.WriteLine("\n");
            Console.WriteLine($" Из {200} вычли цену игрушки {t3.ToyName} равную {t3.Price} и получили {t4}");
        }

        //сравнение цен игрушек
        public void PriceComparison ()
        {
            bool comp = t1 > t2;
            bool comp1 = t3 < t2;
            Console.WriteLine("\n");
            Console.WriteLine($" Цена {t1.Price} игрушки {t1.ToyName} больше цены {t2.Price} игрушки {t2.ToyName} : {comp} ");
            Console.WriteLine($" Цена {t3.Price} игрушки {t3.ToyName} меньше цены {t2.Price} игрушки {t2.ToyName} : {comp1}");
        }

        public void AgeTrue()
        {
            
            Console.WriteLine("\n");
            Console.WriteLine($" Возраст для игрушки {t1.ToyName} составляет {t1.Age} и попадает в категорию : {(t1 ? true : false) }");
        }

        public void AgeFalse()
        {
            Console.WriteLine("\n");
            Console.WriteLine($"Возраст для игрушки {t3.ToyName} составляет {t3.Age} и попадает в категорию : {(t3 ? true: false)}");
        }

    }
}
