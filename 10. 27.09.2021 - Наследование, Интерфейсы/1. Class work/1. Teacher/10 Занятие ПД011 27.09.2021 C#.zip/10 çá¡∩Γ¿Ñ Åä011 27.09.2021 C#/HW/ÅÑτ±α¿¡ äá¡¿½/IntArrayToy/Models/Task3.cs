﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntArrayToy.Models
{
    internal class Task3
    {
        // заполнение массива данными об игрушках 

        public void FillArray ()
        {
            Shop outlet = new Shop() { Title = "Магазин" };

            int numberofItems = 6; // количество товара

             outlet.GenerateItems(numberofItems);

            outlet.ShowTable();

            
        }

        // поиск товара с минимальной ценой 
         public decimal MinPrice(Toy[] toys)
        {
            
            decimal min = decimal.MaxValue;
            foreach(var item in toys)
            {
                if(item.Price < min)
                {
                    min = item.Price;
                }
            }

                return min;
        }

        // поиск товара с максимальной ценой 
        public decimal MaxPrice(Toy[] toys)
        {
            decimal max = decimal.MinValue;
            foreach(var item in toys)
            {
                if(item.Price > max)
                {
                    max = item.Price;
                }
            }
            return max;
        }
    }
}
