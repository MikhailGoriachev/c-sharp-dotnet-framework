﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IntArrayToy.Models;

namespace IntArrayToy
{
    internal partial class App
    {
        //произведение элементов массива с четными номерами,
        //вывести массив с выделением цветом элементов с четными номерами 
        public void Task1Point1()
        {
            Utils.ShowNavBarTask("    Вывести произведение элементов массива с четными номерами");

            // создание объекта для обработки по заданию
            Task1 task1 = new Task1();

            int mult = task1.MultNumber();

            // вывести массив
            ShowArray(task1.arr);
            Console.WriteLine("\n");
            Console.WriteLine($"Произведение равно : {mult}");

            Console.ReadKey();
        }

        //Вывести сумму элементов массива, расположенных между первым и последним нулевыми элементами
        public void Task1Point2()
        {
            Utils.ShowNavBarTask(" Вывести сумму элементов массива, расположенных между первым и последним нулевыми элементами");
            Task1 task1 = new Task1();

            int sum = task1.SumBetweenZeros();

            ShowArraySum(task1.arr);
            Console.WriteLine("\n");
            Console.WriteLine($"Cумма равна : {sum}");

            Console.ReadKey();
        }
        // Отрицательным элементам массива поменять знак, сортировать массив по убыванию
        public void Task1Point3()
        {
            Utils.ShowNavBarTask(" Отрицательным элементам массива поменять знак, сортировать массив по убыванию");

            Task1 task1 = new Task1();

            task1.arr.FillArray();

            ShowInitialArray("Массив до замены : ",task1.arr);

            task1.arr.NegativePositive();

            ShowInitialArray("Массив после замены", task1.arr);

            Task1.InsertionSort(task1.arr);

            ShowInitialArray("Массив после сортировки", task1.arr);


            Console.ReadKey();


        }

        public void ShowArray(IntArray arr)
        {
            Console.WriteLine("\n\n");
            Console.Write("Массив элементов : ");
            for(int i =0; i<arr.Lenght; ++i)
            {
                if ((i+1) % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                }
                Console.Write($" {arr[i], 5} ");
                Console.ForegroundColor = ConsoleColor.Gray;
            }
        }

        public void ShowArraySum(IntArray arr)
        {
            Console.WriteLine("\n\n");
            Console.Write("Массив элементов : ");

            int indexFirstZero = 0;
            int indexSecondZero = 0;
            for (int i = 0; i < arr.Lenght; ++i)
            {
                if (arr[i] == 0)
                {
                    indexFirstZero = i;
                    break;
                }
            }

            for (int i = arr.Lenght - 1; i >= 0; --i)
            {
                if (arr[i] == 0)
                {
                    indexSecondZero = i;
                    break;
                }
            }

            for (int i = 0; i<arr.Lenght; ++i)
            {   
                if(i == indexFirstZero || i == indexSecondZero )
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                }

                if(i > indexFirstZero && i < indexSecondZero)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }
                Console.Write($" {arr[i],5} ");
                Console.ForegroundColor = ConsoleColor.Gray;
            }

           
        }

        public void ShowInitialArray(string text, IntArray arr)
        {
            Console.WriteLine("\n\n");
            Console.WriteLine(text);
            for (int i = 0; i < arr.Lenght; ++i)
            {
                
                Console.Write($" {arr[i],5} ");
                
            }
        }
    }
}
