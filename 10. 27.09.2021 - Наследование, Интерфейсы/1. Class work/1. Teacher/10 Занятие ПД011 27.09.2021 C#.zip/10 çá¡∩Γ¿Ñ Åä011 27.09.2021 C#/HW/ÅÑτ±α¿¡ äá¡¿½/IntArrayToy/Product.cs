﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntArrayToy
{
    /*
     * класс «товар», содержащий следующие закрытые поля:
•	название товара;
•	количество товара (в условных единицах);
•	стоимость товара в рублях.

     */
    class Product
    {
        private string _name ; // наименование товара

        public string Name
        {
            get => _name;
            set => _name =value; 
        }

        private int _number;  // количество товара

        public int Number
        {
            get => _number; 
            set => _number = value; 
        }

        private decimal _cost;  // цена 

        public  decimal Cost
        {
            get => _cost;
            set => _cost = value; 
        }


        public override string ToString() => $" {Name}, Количество {Number}, Стоимость {Cost}";

        //перегрузка операции + для двух одинаковых товаров
        public static Product operator+(Product p1, Product p2 )
        {
            if (!p2.Name.Equals(p1.Name))
                throw new InvalidOperationException();

            int newNumber = p1.Number + p2.Number; // новое количество товара

            return new Product
            {
                Name = p1.Name,
                Number = newNumber,
                Cost = p1.Number * p1.Cost };
        }

        //перегрузка операции + для цены товара и целого числа
        public static Product operator +(Product p1, int number) => new Product
        { Name = p1.Name, Number = p1.Number, Cost = p1.Cost + number };

        //перегрузка операции - для целого числа и цены товара
        public static Product operator -(int number, Product p1) => new Product
        { Name = p1.Name, Number = p1.Number, Cost = number - p1.Cost };

        //перегрузка операций сравнений по цене товара
        public static bool operator <(Product p1, Product p2) => p1.Cost < p2.Cost;
        public static bool operator >(Product p1, Product p2) => p1.Cost > p2.Cost;

        public static bool operator <=(Product p1, Product p2) => p1.Cost <= p2.Cost;
        public static bool operator >=(Product p1, Product p2) => p1.Cost <= p2.Cost;

        public static bool operator ==(Product p1, Product p2) => p1.Cost == p2.Cost;
        public static bool operator !=(Product p1, Product p2) => p1.Cost != p2.Cost;


        


    


        

    }
}
