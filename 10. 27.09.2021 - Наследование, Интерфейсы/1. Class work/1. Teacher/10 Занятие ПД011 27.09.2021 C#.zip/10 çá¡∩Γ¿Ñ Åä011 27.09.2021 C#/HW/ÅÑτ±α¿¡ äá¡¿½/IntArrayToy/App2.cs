﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IntArrayToy.Models;

namespace IntArrayToy
{
    internal partial class App
    {
        // Сложения игрушки с целым числом
        public void Task2Point1()
        {
            Utils.ShowNavBarTask("Сложения игрушки с целым числом");

            Task2 task2 = new Task2();

            task2.ToyPlusInt();
        }

        //Вычитания целого числа из игрушки
        public void Task2Point2()
        {
            Utils.ShowNavBarTask("Вычитания целого числа из игрушки");

            Task2 task2 = new Task2();

            task2.IntMinusToy(); 
        }
        //Сравнение цен двух игрушек
        public void Task2Point3()
        {
            Utils.ShowNavBarTask("Сравнение цен двух игрушек");

            Task2 task2 = new Task2();

            task2.PriceComparison();
        }
        public void Task2Point4()
        {
            Utils.ShowNavBarTask("true: если возрастная категория больше 5");

            Task2 task2 = new Task2();

            task2.AgeTrue();
        }
        public void Task2Point5()
        {
            Utils.ShowNavBarTask("false: если возрастная категория меньше или равна 5");

            Task2 task2 = new Task2();

            task2.AgeFalse();
        }
    }
}
