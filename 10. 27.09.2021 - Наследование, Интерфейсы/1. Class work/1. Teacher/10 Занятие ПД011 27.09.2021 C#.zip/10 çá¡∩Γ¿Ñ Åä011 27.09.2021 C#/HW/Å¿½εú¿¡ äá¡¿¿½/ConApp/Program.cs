﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using ConApp.Classes;


namespace ConApp
{
    class Program
    {
        static void Main(string[] args)
        {
            App app = new App();
            bool flag = true;

            try
            {
                while(flag)
                {
                    app.ShowMenu();
                    switch (Console.ReadKey().Key)
                    {
                        case ConsoleKey.Q:
                            app.Task1Sol1();
                            break;
                        case ConsoleKey.W:
                            app.Task1Sol2();
                            break;
                        case ConsoleKey.E:
                            app.Task1Sol3();
                            break;
                        case ConsoleKey.A:
                            app.Task2();
                            break;
                        case ConsoleKey.S:
                            app.Task3Sol1();
                            break;
                        case ConsoleKey.D:
                            app.Task3Sol2();
                            break;
                        case ConsoleKey.Escape:
                            flag = false;
                            break;
                        default:
                            continue;
                    }
                }
             }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical);
                
            }
        }

    }
}
