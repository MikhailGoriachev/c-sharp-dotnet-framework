﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp.Classes
{
    class Toy
    {
        private string _name;           //название игрушки
        private int _ageCategory;       //возрастная категория
        private int _cost;              //стоимость игрушки

        //конструкторы
        public Toy()
        {
            _name = "\"Человек Паук\" фигурка";
            _ageCategory = 6;
            _cost = 6;
        }

        public Toy(string name, int age, int cost)
        {
            Name = name;
            AgeCategory = age;
            Cost = cost;
        }

        //свойства
        public string Name
        {
            get => _name;
            set 
            { 
                _name = (!string.IsNullOrEmpty(value)) ? value :
                    throw new Exception($"Неверно указано имя!"); 
            }
        }
        public int AgeCategory
        {
            get => _ageCategory;
            set { _ageCategory = (value >= 0) ? value :
                    throw new Exception($"Возростная категория не может быть отрицательной {value}!"); }
        }
        public int Cost
        {
            get => _cost;
            set
            {
                _cost = (value > 0) ? value :
                    throw new Exception($"Стоимость не может быть отрицательная {value}!");
            }
        }


        //сложения игрушки с целым числом – операция выполняет сложение цены и числа
        static public int operator +(Toy t, int n) => t.Cost + n;
        //вычитания целого числа из игрушки – операция выполняет
        //вычитание целого числа из цены игрушки
        static public int operator -(Toy t, int n) => t.Cost - n;
        //сравнение цен двух игрушек
        static public bool operator >(Toy t1, Toy t2) => t1.Cost > t2.Cost;
        static public bool operator <(Toy t1, Toy t2) => t1.Cost < t2.Cost;
        //true: если возрастная категория больше 5
        static public bool operator true(Toy t) => t.AgeCategory > 5;
        //false: если возрастная категория меньше или равна 5
        static public bool operator false(Toy t) => t.AgeCategory <= 5;

        public override string ToString() => $"[{_name},{_ageCategory}+, {_cost}$]";
    }
}
