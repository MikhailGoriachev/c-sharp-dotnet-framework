﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//множественное использование методов консоли => для экономии времени использую псевдоним
//(конфиликтов в названии методов нет)
using static System.Console;

namespace ConApp.Classes
{
    class App
    {
        private Task1 task1 = new Task1();
        private Task3 task3 = new Task3();
        private string[] menu = {
            "T1.Произведение элементов массива с четными номерами - Q",
            "T1.Cумма элементов массива, расположенных между первым и последним нулем - W",
            "T1.Отрицательным элементам массива поменять знак - E",
            "T2.Работа перегруженных операций Toy - A",
            "T3.Поиск товаров с минимальной ценой, максимальной ценой - S",
            "T3.Сортировка товара по убыванию количества - D",
            "Выход - Esc",
        };



        public void Task1Sol1()
        {
            Clear();
            SetCursorPosition(18, 1);
            BackgroundColor = ConsoleColor.Blue;

            WriteLine($"Произведение элементов массива с четными номерами = {task1.MultiEven()}");

            //устанавливаем цвета консоли по умолчанию
            DefColor();

            task1.ShowEven();

            ReadKey();
            Clear();
        }
        public void Task1Sol2()
        {
            Clear();

            SetCursorPosition(4, 1);
            BackgroundColor = ConsoleColor.Blue;

            WriteLine($"Сумма элементов массива, расположенных между первым и последним нулевыми элементами = {task1.SumBetweenZeros()}");

            //устанавливаем цвета консоли по умолчанию
            DefColor();

            task1.ShowBetweenZeros();

            ReadKey();
            Clear();
        }
        public void Task1Sol3()
        {
            Clear();

            SetCursorPosition(35, 1);
            BackgroundColor = ConsoleColor.Blue;
            WriteLine($"Массив до изменений");
            DefColor();
            task1.ShowNeg();

            SetCursorPosition(23, 5);
            BackgroundColor = ConsoleColor.Blue;
            WriteLine($"Отрицательным элементам массива поменялся знак");
            DefColor();
            task1.PositiveArr();
            task1.ShowNeg();


            SetCursorPosition(29, 9);
            BackgroundColor = ConsoleColor.Blue;
            WriteLine($"Массив отсортирован по убыванию");
            DefColor();
            task1.SortInsert();
            task1.ShowNeg();

            ReadKey();
            Clear();
        }
        public void Task2()
        {
            Clear();

            Toy spiderMan = new Toy();
            Toy venom = new Toy("\"Веном\" фигурка", 7, 6);
            string temp = spiderMan ? "True" : "False";


            SetCursorPosition(0, 1);
            BackgroundColor = ConsoleColor.Blue;

            WriteLine($"Cложение игрушки с целым числом: {spiderMan} + 3 = {spiderMan + 3}\n");
            WriteLine($"Вычитание целого числа из игрушки: {spiderMan} - 2 = {spiderMan - 2}\n");
            WriteLine($"Сравнение цен двух игрушек: {spiderMan} > {venom} = {spiderMan > venom}\n");
            WriteLine($"Сравнение цен двух игрушек: {spiderMan} < {venom} = {spiderMan < venom}\n");
            WriteLine($"true: если возрастная категория больше 5: {spiderMan} = {temp}\n");
            WriteLine($"false: если возрастная категория меньше или равна 5: {spiderMan} = {temp}\n");

            DefColor();

            ReadKey();
            Clear();
        }
        public void Task3Sol1()
        {
            Clear();

            SetCursorPosition(5, 1);
            var minMax = task3.FindMaxMinCost();
            Console.WriteLine($"Товар с минимальной ценой под номером - {minMax.min + 1}, с максимальной - {minMax.max + 1}");
            task3.ShowMinMax();

            ReadKey();
            Clear();
        }
        public void Task3Sol2()
        {
            Clear();

            SetCursorPosition(5, 1);
            Console.WriteLine($"Массив до сортировки");
            task3.Show();
            Console.WriteLine($"Отсортированный массив");
            task3.QSort(task3.GetShop());
            task3.Show();


            ReadKey();
            Clear();
        }
        public void ShowMenu()
        {
            for (int i = 0; i < menu.Length; i++)
            {
                ForegroundColor = ConsoleColor.Blue;
                SetCursorPosition(7,i+10);
                WriteLine(menu[i]);
                ForegroundColor = ConsoleColor.White;

            }
        }

        private void DefColor()
        {
            BackgroundColor = ConsoleColor.Black;
            ForegroundColor = ConsoleColor.White;
        }
    }
}
