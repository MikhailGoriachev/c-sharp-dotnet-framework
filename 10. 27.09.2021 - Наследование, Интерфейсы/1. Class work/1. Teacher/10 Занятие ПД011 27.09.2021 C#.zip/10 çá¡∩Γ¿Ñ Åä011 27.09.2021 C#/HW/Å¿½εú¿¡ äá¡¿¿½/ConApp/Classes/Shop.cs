﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp.Classes
{
    //класс Shop (магазин)
    class Shop
    {
        static Random random = new Random();
        //Array.Sort использует метод быстрой сортировки 
        //https://coderoad.ru/21639900/Arrays-sort-%D0%B8-%D0%B0%D0%BB%D0%B3%D0%BE%D1%80%D0%B8%D1%82%D0%BC-%D1%81%D0%BE%D1%80%D1%82%D0%B8%D1%80%D0%BE%D0%B2%D0%BA%D0%B8

        private string _name;           //название магазина
        private Product[] _products;    //массив товаров


        //конструкторы
        public Shop()
        {
            _name = "Пятерочка";
            Fill();
        }
        public Shop(string name, Product[] products)
        {
            Name = name;
            Products = products;
        }

        //свойства
        public string Name
        {
            get { return _name; }
            set { _name = !string.IsNullOrEmpty(value) ? value :
                    throw new Exception($"Некорректное название магазина!"); }
        }
        public Product[] Products
        {
            get { return _products; }
            set { _products = value ?? throw new Exception("Пустая коллекция товаров!"); }
        }


        //индексатор
        public Product this[int index]
        {
            get 
            {
                if (index < 0 || index > _products.Length)
                    throw new Exception($"Неверный индекс!");
                else return _products[index];
            
            }
            set 
            {
                if (index < 0 || index > _products.Length)
                    throw new Exception($"Неверный индекс!");
                else _products[index] = value;
            }
        }



        //заполнение массива товаров данными
        public void Fill(int n = 15)
        {
            //массив названи продуктов
            string[] names = {
                "Хлеб",
                "Coca-Cola",
                "Банан",
                "Гречневая каша",
                "Чипсы Leys",
                "Лимон",
                "Mars батончик",
                "Вода газированная",
                "Тетрадь в клетку 42л.",
                "Ручка шариковая",
                "Молоко",
                "Мороженное",
                "Колбaса",
                "Cыр",
                "Огурцы"
            };

            _products = new Product[n];

            for (int i = 0; i < _products.Length; i++)
                _products[i] = new Product(names[random.Next(0, 15)],
                    random.Next(1, 20),
                    random.Next(1, 10_000));
        }
        //суммирование цен товаров
        public int SumCost()
        {
            int sum = 0;
            for (int i = 0; i < _products.Length; i++)
                sum += _products[i].Cost;
            return sum;
        }
        //cуммирвоание количества товаров
        public int SumAmt()
        {
            int sum = 0;
            for (int i = 0; i < _products.Length; i++)
                sum += _products[i].Amt;
            return sum;
        }
        //размер массива товаров
        public int Length() => _products.Length;
        //вывод товаров в консоль
        public void Show()
        {
            Console.WriteLine($"\t\t\t\t{_name}");
            Console.WriteLine("\t _____________________________________________________________");
            Console.WriteLine("\t| N  | Наименование товара | Цена товара | Количество товаров |");
            Console.WriteLine("\t|____|_____________________|_____________|____________________|");

            for (int i = 0; i < _products.Length; i++)
            {
                Console.WriteLine($"\t| {i+1,2} |{_products[i].Name,21}|{_products[i].Cost,8} р.  |{_products[i].Amt,10} шт.      |");
            }
            Console.WriteLine("\t|____|_____________________|_____________|____________________|");
            Console.WriteLine($"\t|    |                     |{SumCost(),8} р.  |{SumAmt(),10} шт.      |");
            Console.WriteLine("\t|____|_____________________|_____________|____________________|");
        }
    }
}
