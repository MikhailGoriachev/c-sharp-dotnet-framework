﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp.Classes
{
    //класс «товар»
    class Product
    {
        private string _name;   //название товара
        private int _amt;       //количество товара
        private int _cost;      //стоимость товара в рублях.

        //конструкторы
        public Product()
        {
            _name = "Печенье";
            _amt = 34;
            _cost = 115;
        }
        public Product(string name, int amt, int cost)
        {
            Name = name;
            Amt = amt;
            Cost = cost;
        }

        //cвойства
        public int Amt
        {
            get { return _amt; }
            set { _amt = value >= 0 ? value :
                    throw new Exception($"Не верно указано количесвто товара {value}!"); }
        }
        public string Name
        {
            get { return _name; }
            set { _name = !string.IsNullOrWhiteSpace(value) ?  value :
                    throw new Exception($"Не верно введено наименование товара!"); }
        }
        public int Cost
        {
            get { return _cost; }
            set
            {
                _cost = value > 0 ? value :
                  throw new Exception($"Не верная стоимость товара {value}!");
            }
        }


        //сложения товаров с одинаковыми наименованиями,
        //выполняющую сложение их стоимостей, т.е. цен, умноженных на количество
        static public int operator +(Product a, Product b)
        {
            if (a.Name == b.Name)
                return a._cost * a._amt + b._cost * b._amt;
            else throw new Exception("Нельзя складывать товары разных нименований!");
        }
        //сложения товара и целого числа, выполняющего сложение цены и целого числа
        static public Product operator +(Product a, int b)
        {
            if (a._cost + b < 0) 
                throw new Exception("Ошибка сочитания. Цена товара не может быть отрицательной!");

            a._cost += b;

            return a;
        }
        //вычитание товара и целого числа, выполняющего вычитание целого числа из цены
        static public Product operator -(Product a, int b)
        {
            if (a._cost - b < 0)
                throw new Exception("Ошибка вычитания. Цена товара не может быть отрицательной!");

            a._cost -= b;

            return a;
        }
        //сравнение товаров по цене
        static public bool operator >(Product a, Product b) => a._cost > b._cost;
        static public bool operator <(Product a, Product b) => a._cost < b._cost;
        static public bool operator <=(Product a, Product b) => a._cost <= b._cost;
        static public bool operator >=(Product a, Product b) => a._cost >= b._cost;
        static public bool operator ==(Product a, Product b) => a._cost == b._cost;
        static public bool operator !=(Product a, Product b) => a._cost != b._cost;
        //операция true: стоимость товара в интервале 1, …, 1000
        static public bool operator true(Product a) => a._cost >= 1 && a._cost <= 1000;
        //операция false: стоимость товара равна 0 или больше 1000
        static public bool operator false(Product a) => a._cost == 1 || a._cost > 1000;
        //возвращает строку, представляющую текущий объект
        public override string ToString() => $"[{_name}, {_amt} шт., {_cost} руб.]";

    }
}
