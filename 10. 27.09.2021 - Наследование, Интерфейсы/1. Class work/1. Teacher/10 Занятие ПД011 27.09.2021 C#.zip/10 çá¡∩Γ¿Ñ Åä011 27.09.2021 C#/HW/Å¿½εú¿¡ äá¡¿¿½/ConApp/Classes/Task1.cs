﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp.Classes
{
    class Task1
    {
        private IntArray _arr;

        //конструкторы
        public Task1()
        {
            _arr = new IntArray(20);
        }
        public Task1(int n, int lo = -5, int hi = 5)
        {
            _arr = new IntArray(n, lo, hi);
        }

        //вывести массив с выделением цветом элементов с четными номерами
        public void ShowEven()
        {
            int n = _arr.Length;
            for (int i = 0; i < n; i++)
            {
                Console.ForegroundColor = ((i + 1) % 2 == 0) ? ConsoleColor.Blue : ConsoleColor.White;
                Console.Write($"       {_arr[i]}");
                if ((i + 1) % 10 == 0) Console.WriteLine();

            }
            Console.ForegroundColor = ConsoleColor.White;
        }
        //произведение элементов массива с четными номерами
        public int MultiEven()
        {
            int n = _arr.Length;
            int sum = 1;

            for (int i = 0; i < n; i++)
                sum *= ((i + 1) % 2 == 0) ? _arr[i] : 1;

            return sum;
        }
        //поиск первого и последнего нуля
        public (int,int) FindFnLZeros() =>(Array.FindIndex(_arr.Array, (int value) => value == 0),
                Array.FindLastIndex(_arr.Array, (int value) => value == 0));
        //суммf элементов массива, расположенных между первым и последним нулевыми элементами
        public int SumBetweenZeros()
        {
            int sum = 0;

            var zeros = FindFnLZeros();

            if ((zeros.Item1 == zeros.Item2) || (zeros.Item1 == -1 || zeros.Item2 == -1))
                throw new Exception($"Не хватает нулей для исполения программы!");

            for (int i = zeros.Item1 + 1; i < zeros.Item2; i++)
                sum += _arr[i];

            return sum;
        }
        //вывод диапазона суммирования с выделением цветом: границ и слагаемых
        public void ShowBetweenZeros()
        {
            int n = _arr.Length;
            var zeros = FindFnLZeros();
            for (int i = 0; i < n; i++)
            {
                Console.ForegroundColor = (i == zeros.Item1 || i == zeros.Item2) ? 
                    ConsoleColor.Green : (i > zeros.Item1 && i < zeros.Item2) ? 
                    ConsoleColor.Blue : ConsoleColor.White;

                Console.Write($"       {_arr[i]}");
                if ((i + 1) % 10 == 0) Console.WriteLine();

            }
            Console.ForegroundColor = ConsoleColor.White;
        }
        //отрицательным элементам массива меняется знак
        public void PositiveArr()
        {
            for (int i = 0; i < _arr.Length; i++)
                _arr[i] *= (_arr[i] < 0) ? -1 : 1;
        }
        //сортировать массив по убыванию. метод сортировки – сортировка вставками
        public void SortInsert()
        {
            int temp, a, b;

            for (int i = 0; i < _arr.Length; i++)
            {
                int key = _arr[i];
                int j = i;

                while ((j > 0) && (_arr[j - 1] < key))
                {
                    temp = _arr[j - 1];
                    _arr[j - 1] = _arr[j];
                    _arr[j] = temp;
                    j--;
                }

                _arr[j] = key;
            }
        }
        //вывод массива с выделением отрицательных элементов цветом
        public void ShowNeg()
        {
            int n = _arr.Length;
            for (int i = 0; i < n; i++)
            {
                Console.ForegroundColor = (_arr[i] < 0) ? ConsoleColor.Blue : ConsoleColor.White;
                Console.Write($"       {_arr[i]}");
                if ((i + 1) % 10 == 0) Console.WriteLine();

            }
            Console.ForegroundColor = ConsoleColor.White;
        }


    }
}
