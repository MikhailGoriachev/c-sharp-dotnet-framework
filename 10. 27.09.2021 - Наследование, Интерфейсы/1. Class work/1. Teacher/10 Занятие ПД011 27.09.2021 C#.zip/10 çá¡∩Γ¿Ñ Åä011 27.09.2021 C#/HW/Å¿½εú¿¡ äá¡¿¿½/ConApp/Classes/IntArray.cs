﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp.Classes
{
    class IntArray
    {
        static public Random random = new Random();
        private int[] _arr;        //Контейнер данных – собственно массив с уровнем доступа private
        private int _length;       //Длина массива


        

        //свойство Length - размер массива
        public int Length
        {
            get { return _length; }
            set { _length = (value >= 0) ? value : 
                    throw new Exception($"Недопустимый размер массива ({value})!"); }
        }
        //свойство самого массива
        public int[] Array
        {
            get { return _arr; }
            set { _arr = value; }
        }

        //конструкторы
        public IntArray()
        {
            _length = 10;
            _arr = new int[_length];
        }
        public IntArray(int n, int lo = -5, int hi = 5)
        {
            Length = n;
            _arr = new int[_length];

            Initialization(lo, hi);
        }

        //Индексатор с контролем выхода за допустимые пределы (при выходе выбрасывать исключение)
        public int this[int index]
        {
            get => (index >= 0 && index <= _length ) ? _arr[index] :
                  throw new Exception($"Вы вышли за пределы массива. Неверный индекс для чтения {index}!");
            set 
            {
                if (index >= 0 && index <= _length) _arr[index] = value;
                else throw new Exception($"Вы вышли за пределы массива. Неверный индекс для чтения {index}!");
            }
            
        }

        //метод заполнения случайными числами
        public void Initialization(int lo, int hi)
        {
            for (int i = 0; i < _length; i++)
                _arr[i] = random.Next(lo, hi + 1);
        }

        //метод вывода в строку
        public void Show()
        {
            for (int i = 0; i < _length; i++)
            {
                Console.Write($"       {_arr[i]}");
                if ((i+1) % 10 == 0) Console.WriteLine();
            }
        }
    }
}
