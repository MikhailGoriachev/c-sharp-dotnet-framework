﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp.Classes
{
    class Task3
    {
        private Shop shop = new Shop();

        //геттер
        public Shop GetShop() => shop;
        //вывод в консоль магазина
        public void Show()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            shop.Show();
            Console.ForegroundColor = ConsoleColor.White;
        }
        //вывод в консоль магазина c выделением товаров с минимальной ценой, максимальной ценой
        public void ShowMinMax()
        {
            Console.ForegroundColor = ConsoleColor.Blue;

            var maxMin = FindMaxMinCost();
            Console.WriteLine($"\t\t\t\t{shop.Name}");
            Console.WriteLine("\t _____________________________________________________________");
            Console.WriteLine("\t| N  | Наименование товара | Цена товара | Количество товаров |");
            Console.WriteLine("\t|____|_____________________|_____________|____________________|");

            for (int i = 0; i < shop.Length(); i++)
            {
                Console.ForegroundColor = (maxMin.max == i || maxMin.min == i) ? ConsoleColor.DarkGreen : ConsoleColor.Blue;
                Console.WriteLine($"\t| {i + 1,2} |{shop[i].Name,21}|{shop[i].Cost,8} р.  |{shop[i].Amt,10} шт.      |");
            }
            Console.WriteLine("\t|____|_____________________|_____________|____________________|");
            Console.WriteLine($"\t|    |                     |{shop.SumCost(),8} р.  |{shop.SumAmt(),10} шт.      |");
            Console.WriteLine("\t|____|_____________________|_____________|____________________|");

            Console.ForegroundColor = ConsoleColor.White;
        }
        //поиск товаров с минимальной ценой, максимальной ценой
        public (int min,int max) FindMaxMinCost()
        {
            int min = 0, max = 0;
            int minCost = int.MaxValue, maxCost = int.MinValue;

            int n = shop.Length();

            for (int i = 0; i < n; i++)
            {
                if(shop[i].Cost > maxCost)
                {
                    maxCost = shop[i].Cost;
                    max = i;
                }
                if (shop[i].Cost < minCost)
                {
                    minCost = shop[i].Cost;
                    min = i;
                }
            }

            return (min, max);
        }
        //сортировка товара по убыванию количества (метод быстрой сортировки)
        public void QSort(Shop array, int firstIndex = 0, int lastIndex = -1)
        {
            if (lastIndex < 0)
                lastIndex = array.Length() - 1;
            if (firstIndex >= lastIndex)
                return;
            int middleIndex = (lastIndex - firstIndex) / 2 + firstIndex, currentIndex = firstIndex;

            //swap
            Product tmp = array[firstIndex];
            array[firstIndex] = array[middleIndex];
            array[middleIndex] = tmp;

            for (int i = firstIndex + 1; i <= lastIndex; ++i)
            {
                if (array[i].Amt <= array[firstIndex].Amt)
                {
                    //swap
                    tmp = array[++currentIndex];
                    array[++currentIndex] = array[i];
                    array[i] = tmp;
                }
            }

            //swap
            tmp = array[firstIndex];
            array[firstIndex] = array[currentIndex];
            array[currentIndex] = tmp;

            QSort(array, firstIndex, currentIndex - 1);
            QSort(array, currentIndex + 1, lastIndex);
        }

    }
}
