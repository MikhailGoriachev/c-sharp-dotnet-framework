﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Models.Task1;

namespace Задание
{
    /* 
    * Методы для решения задачи 1
    */
    internal partial class App {

        // Произведение элементов массива с четными номерами
        public void Task1Part1() {
            Utils.ShowNavBarTask("   Произведение элементов массива с четными номерами");
            _intArray.Initialize();

            Console.Write("\n\n        Исходный массив: ");
            _intArray.ShowEvenNum();

            int prod = 1;
            for (int i = 1; i <  _intArray.Length; i+=2)
                // демонстрация работы индексатора
                if(_intArray[i] != 0) prod *= _intArray[i];

            Console.WriteLine($"\n        Произведение   : {prod}");
        } // Task1Part1

        // Сумма элементов массива, расположенных между первым и последним нулевыми элементами
        public void Task1Part2() {
            Utils.ShowNavBarTask("   Сумма элементов массива, расположенных между первым и последним нулевыми элементами");
            int first;
            int last;
            do {
                _intArray.Initialize();
                // поиск индексов первого и последнего нулевых элементов
                first = _intArray.FirstZero();
                last  = _intArray.LastZero();
            } while (first == last);

            Console.Write("\n\n        Исходный массив: ");
            _intArray.ShowZeros();

            int sum = 0;
            for (int i = first + 1; i < last; i++)
                // демонстрация работы индексатора
                sum += _intArray[i];

            Console.WriteLine($"\n        Сумма          : {sum}");
        } // Task1Part2

        // Поменять знак отрицательным элементам массива, сортировать массив по убыванию
        public void Task1Part3() {
            Utils.ShowNavBarTask("   Поменять знак отрицательным элементам массива, сортировать массив по убыванию");
            _intArray.Initialize();

            Console.Write($"\n\n        Исходный массив    : {_intArray}");

            for (int i = 0; i < _intArray.Length; i++)
                // демонстрация работы индексатора
                if (_intArray[i] < 0) _intArray[i] = -_intArray[i];

            Console.Write($"\n\n        Элементы изменены  : {_intArray}");

            _intArray.Sort();
            Console.Write($"\n\n        Массив отсортирован: {_intArray}");

        } // Task1Part3
    } // App
}
