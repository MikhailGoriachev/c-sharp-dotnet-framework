﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    // класс для представления игрушки 
    class Toy {
        string _name;     // название игрушки
        int _ageCategory; // возрастная категория
        int _price;       // стоимость игрушки

        public string Name {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Toy: Некорректное название игрушки!"); _name = value; }
        } // Name

        public int AgeCategory { 
            get => _ageCategory;
            set { if (value < 0) throw new Exception("Toy: Некорректное значение возрастной категории!"); _ageCategory = value; }
        } // AgeCategory

        public int Price {
            get => _price;
            set { if (value <= 0) throw new Exception("Toy: Некорректное значение стоимости игрушки!"); _price = value; }
        } // Price

        public override string ToString() => $"[{Name}: возрастная категория - {_ageCategory}, стоимость - {_price}]";

        // сложение игрушки с целым числом 
        public static Toy operator +(Toy t, int number) =>
           new Toy { Name = t.Name, Price = t.Price + number };

        // вычитание целого числа из игрушки 
        public static Toy operator -(Toy t, int number) =>
            new Toy { Name = t.Name, AgeCategory = t.AgeCategory, Price = t.Price - number };

        // сравнение цен двух игрушек
        public static bool operator >(Toy t1, Toy t2) => t1.Price > t2.Price;
        public static bool operator <(Toy t1, Toy t2) => t1.Price < t2.Price;

        // если возрастная категория больше 5
        public static bool operator true(Toy t1) => t1.AgeCategory > 5;
        // если возрастная категория меньше или равна 5 
        public static bool operator false(Toy t1) => t1.AgeCategory <= 5;
    } // Toy
}
