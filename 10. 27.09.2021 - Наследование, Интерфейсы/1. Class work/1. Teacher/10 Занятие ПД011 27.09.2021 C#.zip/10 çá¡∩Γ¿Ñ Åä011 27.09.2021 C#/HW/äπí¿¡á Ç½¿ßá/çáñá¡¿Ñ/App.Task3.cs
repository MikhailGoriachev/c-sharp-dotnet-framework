﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Models.Task3;

namespace Задание
{
    /* 
    * Методы для решения задачи 3
    */
    internal partial class App {

        // Начальное формирование массива товаров
        public void ShopInitialize() {
            Utils.ShowNavBarTask("   Начальное формирование массива товаров");

            _shop.Initialize();
            _shop.Show("Данные сформированы", 12);
        } // ShopInitialize

        // Вывод товаров в консоль
        public void ShopShow() {
            Utils.ShowNavBarTask("   Вывод товаров в консоль");

            _shop.Show("Массив товаров", 12);
        } // ShopShow

        // Товары с минимальной/максимальной ценой
        public void MinMaxPrice() {
            Utils.ShowNavBarTask("   Вывод товаров в консоль");

            Good[] minPrice = _shop.FindByPrice(_shop[MinPrice()].Price);
            Good[] maxPrice = _shop.FindByPrice(_shop[MaxPrice()].Price);
            Shop.Show("Товары с минимальной ценой: ", 12, minPrice);
            Shop.Show("Товары с максимальной ценой: ", 12, maxPrice);
        } // MinMaxPrice

        // Упорядочивание товаров по убыванию количества
        public void DemoOrderByNumber() {
            Utils.ShowNavBarTask("   Упорядочивание товаров по убыванию количества");

            _shop.Sort(0, _shop.Length - 1);
            _shop.Show("Массив товаров упорядочен по убыванию количества", 12);
        } // DemoOrderByNumber


        // Поиск индекса товара с минимальной ценой
        private int MinPrice() {
            int iMin = 0;
            for (int i = 1; i < _shop.Length; i++) 
                if (_shop[i] < _shop[iMin]) iMin = i;
            return iMin;
        } // MinPrice

        // Поиск индекса товара с максимальной ценой
        private int MaxPrice() {
            int iMax = 0;
            for (int i = 1; i < _shop.Length; i++)
                if (_shop[i] > _shop[iMax]) iMax = i;
            return iMax;
        } // MaxPrice

    }
}
