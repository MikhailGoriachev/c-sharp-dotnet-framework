﻿using System;
using Задание.Models.Task1;
using Задание.Models.Task3;

namespace Задание
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        IntArray _intArray; // объект для решения задачи 1
        Shop         _shop; // объект для решения задачи 3

        // конструктор по умолчанию
        public App() : this(new IntArray(), new Shop()) { }

        // конструктор с внедрением зависимостей
        public App(IntArray intArray, Shop shop) {
            _intArray = intArray;
            _shop = shop;
        } // App

    } // class App
}