﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    class IntArray {
        // контейнер данных
        private int[] _array;

        // свойство Length - размер массива
        public int Length { get => _array.Length; }

        public IntArray(int[] array) {
            _array = array;
        } // IntArray
        public IntArray() : this(new int[10]) {
            Initialize();
        } // IntArray

        // метод заполнения случайными числами
        public void Initialize(int lo = -5, int hi = 5) {
            for (int i = 0; i < Length; i++)
                _array[i] = Utils.Random.Next(lo, hi);
        } // Initialize

        // метод вывода в строку
        public override string ToString() {
                return string.Join("   ", _array);
        } // ToString


        // Индексатор. 
        public int this[int index] {
            get {    
                if (index < 0 || index >= Length)
                    throw new Exception("IntArray: Попытка обращения за пределы массива!");

                return _array[index];
            } // Аксессор.

            set {
                if (index < 0 || index >= Length)
                    throw new Exception("IntArray: Попытка обращения за пределы массива!");

                _array[index] = value;
            } // Мутатор
        }

        private bool izZero(int x) => x == 0;
        // поиск индекса первого нулевого элемента
        public int FirstZero() => Array.FindIndex(_array, izZero);
        // поиск индекса последнего нулевого элемента
        public int LastZero() => Array.FindLastIndex(_array, izZero);

        public void ShowZeros(ConsoleColor zeroColor = ConsoleColor.Green, ConsoleColor color = ConsoleColor.Yellow) {
            // старый цвет консоли
            ConsoleColor old = Console.ForegroundColor;

            // поиск индексов первого и последнего нулевых элементов
            int first = FirstZero();
            int last  = LastZero();

            // вывод с выделением цветом
            for (int i = 0; i < Length; i++)
            {
                if (i == first || i == last) Console.ForegroundColor = zeroColor;
                else if (i > first && i < last) Console.ForegroundColor = color;
                Console.Write($"{_array[i],5}");
                Console.ForegroundColor = old;
            } // for
        } // ShowZeros

        // вывести массив с выделением цветом элементов с четными номерами 
        public void ShowEvenNum(ConsoleColor color = ConsoleColor.Yellow) {
            // старый цвет консоли
            ConsoleColor old = Console.ForegroundColor;

            // вывод с выделением цветом
            for (int i = 0; i < Length; i++) {
                if ((i & 1) != 0) Console.ForegroundColor = color;
                Console.Write($"{_array[i], 5}");
                Console.ForegroundColor = old;
            } // for
        } // ShowZeros


        // сортировка вставками
        public void Sort() {
            for (int i = 1; i < Length; i++)
                for (int j = i; j > 0 && _array[j - 1] < _array[j]; j--)
                    (_array[j - 1], _array[j]) = (_array[j], _array[j - 1]);
        } // Sort

    } // IntArray
}
