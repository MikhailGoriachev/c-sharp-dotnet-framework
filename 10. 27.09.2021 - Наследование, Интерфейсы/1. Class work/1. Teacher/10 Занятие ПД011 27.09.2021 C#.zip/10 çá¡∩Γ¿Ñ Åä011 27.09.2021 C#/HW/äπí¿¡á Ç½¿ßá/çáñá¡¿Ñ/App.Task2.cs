﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Models.Task2;

namespace Задание
{
    /* 
    * Методы для решения задачи 2
    */
    internal partial class App {
        // Демонстрация работы перегруженных операций класса Toy
        public void Task2() {
            Utils.ShowNavBarTask("   Демонстрация работы перегруженных операций класса Toy");

            // Cложение игрушки с целым числом
            Utils.WriteXY(8, 4, "1. Cложение игрушки с целым числом: ", ConsoleColor.Yellow);
            Toy t1 = new Toy { Name = "Кукла", AgeCategory = 3, Price = 1500 };

            int n = 500;
            Toy t2 = t1 + n;

            Console.WriteLine($"\n    {t1} + {n} = {t2}");



            // Вычитание целого числа из игрушки
            Utils.WriteXY(8, 8, "2. Вычитание целого числа из игрушки: ", ConsoleColor.Yellow);
            t2 = t1 - n;
            Console.WriteLine($"\n    {t1} - {n} = {t2}");

            // Сравнение цен двух игрушек
            Utils.WriteXY(8, 12, "3. Сравнение цен двух игрушек: ", ConsoleColor.Yellow);
            t2 = new Toy { Name = "Мяч", AgeCategory = 6, Price = 2000 };

            Console.WriteLine($"\n    {t1} > {t2} - {t1 > t2}");
            Console.WriteLine($"    {t1} < {t2} - {t1 < t2}");



            // true и false
            Utils.WriteXY(8, 16, "4. true и false: ", ConsoleColor.Yellow);


            Console.Write($"\n    {t1} - ");
            if (t1) Console.Write("true");
            else Console.Write("false");

            Console.Write($"\n    {t2} - ");
            if (t2) Console.Write("true");
            else Console.Write("false");
        } // Task2
    }
}
