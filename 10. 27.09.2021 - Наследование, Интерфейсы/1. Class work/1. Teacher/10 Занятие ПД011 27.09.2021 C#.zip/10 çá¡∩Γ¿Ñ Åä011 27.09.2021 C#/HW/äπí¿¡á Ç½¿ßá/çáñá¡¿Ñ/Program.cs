﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction

namespace Задание
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 23.09.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Произведение элементов массива с четными номерами" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Сумма элементов массива, расположенных между первым и последним нулевыми элементами" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1. Поменять знак отрицательным элементам массива, сортировать массив по убыванию" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 2. Демонстрация работы перегруженных операций класса Toy" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 3. Начальное формирование массива товаров" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 3. Вывод товаров в консоль" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 3. Товары с минимальной/максимальной ценой" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 3. Упорядочивание товаров по убыванию количества" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 27.09.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Произведение элементов массива с четными номерами
                        case ConsoleKey.Q:
                            app.Task1Part1();
                            break;

                        // Сумма элементов массива, расположенных между первым и последним нулевыми элементами
                        case ConsoleKey.W:
                            app.Task1Part2();
                            break;

                        // Поменять знак отрицательным элементам массива, сортировать массив по убыванию
                        case ConsoleKey.E:
                            app.Task1Part3();
                            break;

                        // ------------------------------------------------------------

                        // Демонстрация работы перегруженных операций класса Toy
                        case ConsoleKey.R:
                            app.Task2();
                            break;

                        // ------------------------------------------------------------

                        // Начальное формирование массива товаров
                        case ConsoleKey.A:
                            app.ShopInitialize();
                            break;

                        // Вывод товаров в консоль
                        case ConsoleKey.S:
                            app.ShopShow();
                            break;

                        // Товары с минимальной/максимальной ценой
                        case ConsoleKey.D:
                            app.MinMaxPrice();
                            break;

                        // Упорядочивание товаров по убыванию количества
                        case ConsoleKey.F:
                            app.DemoOrderByNumber();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
