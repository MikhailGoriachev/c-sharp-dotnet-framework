﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task3
{
    class Shop {
        private string _name;              // название магазина
        private Good[] _goods;             // коллекция товаров

        public string Name
        {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Shop: Некорректное значение названия магазина!"); _name = value; }
        } // Name

        // свойство Length - размер массива
        public int Length { get => _goods.Length; }
        public bool Empty => _goods.Length == 0;

        public Shop(Good[] goods) {
            _goods = goods;
        } // Shop
        public Shop() { 
            Initialize();
        } // Shop

        public void Initialize() {
            Name = "Супермаркет \"Геркулес\"";
            _goods = new[] {
                new Good {Name = "Молоко"             , Number = 100, Price = 50},
                new Good {Name = "Хлеб"               , Number = 155, Price = 20},
                new Good {Name = "Мука"               , Number = 115, Price = 48},
                new Good {Name = "Сахар"              , Number = 130, Price = 55},
                new Good {Name = "Мороженое"          , Number = 200, Price = 61},
                new Good {Name = "Жевательная резинка", Number = 550, Price = 30},
                new Good {Name = "Зефир"              , Number = 53 , Price = 35},
                new Good {Name = "Мармелад"           , Number = 150, Price = 40}
        };
        } // Initialize

        // Вывести данные о магазине
        public void Show(string caption, int indent) {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Name}\n" +
                              $"{Good.Header(indent)}");

            // вывод всех элементов массива товаров
            int row = 1;
            void OutItem(Good p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(_goods, OutItem);

            Console.WriteLine($"{" ".PadRight(indent)}├─────┴───────────────────────┴───────────────┼──────────────────┤");
            Console.WriteLine($"{" ".PadRight(indent)}│ Суммарные значения:                         │ {SumPrice(), 15}  │");
            Console.WriteLine($"{" ".PadRight(indent)}└─────────────────────────────────────────────┴──────────────────┘");

        } // Show

        // Вывести массив товаров
        static public void Show(string caption, int indent, Good[] goods)
        {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n{space}{caption}\n" +
                              $"{Good.Header(indent)}");

            // вывод всех элементов массива маршрутов
            int row = 1;
            void OutItem(Good p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(goods, OutItem);

            // вывод подвала таблицы 
            Console.WriteLine(Good.Footer(indent));
        } // Show

        // Выбор товаров, стоимость которых, равна некоторому числу
        public Good[] FindByPrice(int price) {
            // предикат для отбора товаров
            bool IsFind(Good g) => g.Price == price;

            // отбор товаров 
            Good[] selected = Array.FindAll(_goods, IsFind);

            return selected;
        } // FindByPrice



        // Индексатор. 
        public Good this[int index] {
            get {
                if (index < 0 || index >= Length)
                    throw new Exception("Shop: Попытка обращения за пределы массива!");

                return _goods[index];
            } // Аксессор.

            set {
                if (index < 0 || index >= Length)
                    throw new Exception("Shop: Попытка обращения за пределы массива!");

                _goods[index] = value;
            } // Мутатор
        }

        // суммирование цен товаров
        public int SumPrice() {
            Good sum = new Good { Price = this[1].Price };
            for(int i = 1; i < Length; i++) {
                sum = this[i] + sum.Price;
            } // for i

            return sum.Price;
        } // SumPrice

        private int partition(Good[] arr, int start, int end) {
            int marker = start;
            for (int i = start; i < end; i++)
            {
                if(arr[i].Number > arr[end].Number)
                {
                    (arr[marker], arr[i]) = (arr[i], arr[marker]);
                    marker++;
                }
            }
            (arr[marker], arr[end]) = (arr[end], arr[marker]);
            return marker;

        } // partition

        // сортировка товаров по убыванию количества (метод быстрой сортировки). 
        public void Sort(int first, int last) {
            if (first >= last)
                return;

            var index = partition(_goods, first, last);
            Sort(first, index - 1);
            Sort(index + 1, last);
        } // Sort


    } // Shop
}
