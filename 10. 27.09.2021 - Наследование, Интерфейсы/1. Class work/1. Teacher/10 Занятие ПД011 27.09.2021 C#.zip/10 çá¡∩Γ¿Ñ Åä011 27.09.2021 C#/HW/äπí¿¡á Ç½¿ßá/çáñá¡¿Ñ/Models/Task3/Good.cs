﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task3
{
    class Good {
        string _name;     // название товара
        int _number;      // количество товара(в условных единицах)
        int _price;       // стоимость товара в рублях

        public string Name {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Good: Некорректное название товара!"); _name = value; }
        } // Name

        public int Number {
            get => _number;
            set { if (value < 0) throw new Exception("Good: Некорректное значение количества товара!"); _number = value; }
        } // Number

        public int Price {
            get => _price;
            set { if (value <= 0) throw new Exception("Good: Некорректное значение стоимости товара!"); _price = value; }
        } // Price

        // представление объекта в виде строки таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_name,-21} │ {_number, 11}   │ {_price, 15}  │";

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬───────────────────────┬───────────────┬──────────────────┐\n" +
                $"{spaces}│  №  │    Название товара    │ Кол-во товара │ Cтоимость товара │\n" +
                $"{spaces}├─────┼───────────────────────┼───────────────┼──────────────────┤\n";
                          
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴───────────────────────┴───────────────┴──────────────────┘";


       

        // сложения товаров с одинаковыми наименованиями,
        // выполняющую сложение их стоимостей, т.е. цен, умноженных на количество
        public static int operator +(Good g1, Good g2) {
            if (g1.Name != g2.Name) throw new Exception("Good: Выполнить операцию невозможно!");

            return g1.Number * g1.Price + g2.Number * g2.Price;
        } // operator +

        // сложение товара и целого числа, выполняющего сложение цены и целого числа
        public static Good operator +(Good g1, int n) =>
            new Good { Name = g1.Name, Price = g1.Price + n };

        // вычитание товара и целого числа, выполняющего вычитание целого числа из цены
        public static Good operator -(Good g1, int n) =>
            new Good { Name = g1.Name, Price = g1.Price - n };

        // сравнение товаров по цене
        public static bool operator >(Good g1, Good g2) => g1.Price > g2.Price;
        public static bool operator <(Good g1, Good g2) => g1.Price < g2.Price;

        public static bool operator >=(Good g1, Good g2) => !(g1 < g2);
        public static bool operator <=(Good g1, Good g2) => !(g1 > g2);

        public static bool operator ==(Good g1, Good g2) => g1.Price == g2.Price;
        public static bool operator !=(Good g1, Good g2) => !(g1 == g2);

        // операция true: стоимость товара в интервале 1, …, 1000
        public static bool operator true(Good g1) => g1.Price >= 1 && g1.Price <= 1000;
        // операция false: стоимость товара равна 0 или больше 1000
        public static bool operator false(Good g1) => g1.Price == 0 || g1.Price > 1000;

    } // Good
}
