﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace H_W9C_.Models
{    /* 
     * Методы для решения задачи 1
     */
    internal partial class App
    {
        private IntArray arr = new IntArray();
        public void Task1Array()
        {
            Utils.ShowNavBarTask("   Вывод одномерного массива заполненного случайными значениями");
           // IntArray arr = new IntArray();
 
            arr.Fill(-3,3);
            Console.WriteLine("\n\n\n");
            arr.Show();

        }// Task1Array

        public void Task1ArrayProiz()
        {
            Utils.ShowNavBarTask("   Произведение элементов массива с четными номерами");
            Console.WriteLine("\n\n\n");

            for (int i = 0; i < arr.Length; i++)
            {
                if (i % 2 == 0) Console.ForegroundColor = ConsoleColor.Red;
                else Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"{arr[i],8}");
            }// for i

            int prod = Task1.ProizElem(arr);

            Console.WriteLine($"\n\n\n Произведение элементов : {prod}");

        }// Task1ArrayProiz

        public void Task1ArraySumma()
        {
            Utils.ShowNavBarTask("   Сумма элементов массива, расположенных между первым и последним нулевыми элементами");
            Console.WriteLine("\n\n\n");

            int last = Task1.LastZero(arr);
            int first = Task1.FirstZero(arr);

            if (first == -1 || last == -1)
            {
                Console.WriteLine(" В массиве нет нулевых элементов\n\n");
                return;
            }
            int sum = Task1.SumBetweenZero(arr, first, last);
            ShowFirstLastZero(arr);
            Console.WriteLine($"\n\n\n Сумма элементов : {sum}");
        }// Task1ArraySumma


        public void Task1ArrayNegativSign()
        {
            Utils.ShowNavBarTask("   В массиве отрицательным элементам поменять знак и отсортировать по убыванию методом вставок");
            Console.WriteLine("\n\n\n");

            arr.Show();
            
            Console.WriteLine("\n\n");
            Task1.NegativElemSign(arr);

            Console.WriteLine("\n\n Массив отсортирован по убыванию методом вставок\n\n");
            Task1.ChoiceSortDescend(arr);
            arr.Show();

        }// Task1ArrayNegativSign

        // вывод массива в консоль(Выделение цветом первого и последнего положительных элементов)
        private static void ShowFirstLastZero(IntArray arr)
        {
            int iFirst = Task1.LastZero(arr);
            int iLast = Task1.FirstZero(arr);

            
            for (int i = 0; i < arr.Length; i++)
            {
                // задать цвет элементу по заданному правилу
                if (i == iFirst || i == iLast) Console.ForegroundColor = ConsoleColor.Black;
                if (iFirst > i && i > iLast) Console.ForegroundColor = ConsoleColor.DarkRed;
                 // else Console.ForegroundColor = ConsoleColor.White;

                Console.Write($"{arr[i],8}");

                Console.ForegroundColor = ConsoleColor.White;
            } // for i

            Console.WriteLine();
        } // ShowFirstLastZero




    }// class App
}
