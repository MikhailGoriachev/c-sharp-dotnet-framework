﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W9C_.Models
{
    internal partial class App
    {    /* 
        * Метод для решения задачи 2
        */
        public void Task2Toy()
        {
            Utils.ShowNavBarTask("   Класс Toy демонстрация перегрузки операций");

            Toy toy1 = new Toy { NameToys = "Мишка плюшевый", AgeCategory = 7, Price = 2000 };
            Toy toy2 = new Toy { NameToys = "Конструктор", AgeCategory = 5, Price = 1550 };

            int n = 50;
            Console.WriteLine($"\n\n {toy1}");
            toy1 += n;  
            Console.WriteLine($"\n\n {toy1} + {n} \n {toy1}");

            n = 1000;
            Console.WriteLine($"\n\n {toy1}");
            toy1 -= n;
            Console.WriteLine($"\n\n {toy1} - {n} \n {toy1}");

            // логическая операция
            bool result = toy1 > toy2;
            Console.WriteLine($"\n\n Цена игрушки1 : {toy1.Price} > Цена игрушки2 : {toy2.Price} = {result}"); 
            result = toy1 < toy2;
            Console.WriteLine($"\n Цена игрушки1 : {toy1.Price} < Цена игрушки2 : {toy2.Price} = {result}"); // false

            // демонстанция перегруженных операций true/false
            
            Console.Write($"\n\n Перегрузка операций true/false, возрастная категория больше 5           : {toy1.AgeCategory} --> ");

            if (toy1)
                Console.WriteLine("True");
            else
                Console.WriteLine("False");

            Console.Write($"\n Перегрузка операций true/false, возрастная категория меньше или равна 5 : {toy2.AgeCategory} --> ");

            if (toy2)
                Console.WriteLine("True");
            else
                Console.WriteLine("False");

        }// Task2Toy

    }// class App
}
