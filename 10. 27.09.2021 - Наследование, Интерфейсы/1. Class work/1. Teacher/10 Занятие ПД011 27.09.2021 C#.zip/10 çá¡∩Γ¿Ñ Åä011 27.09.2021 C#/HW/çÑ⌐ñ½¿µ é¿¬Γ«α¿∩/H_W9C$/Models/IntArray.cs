﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Разработайте класс для хранения одномерного массива из п элементов,
/// типа int, имя класса IntArray.  В классе реализовать:
///•	Индексатор с контролем выхода за допустимые пределы
///    (при выходе выбрасывать исключение)
///•	Контейнер данных – собственно массив с уровнем доступа private
///•	свойство Length - размер массива
///•	метод заполнения случайными числами
///•	метод вывода в строку
/// </summary>
namespace H_W9C_.Models
{
    internal class IntArray
    {
        // размер одномерного массива
        private static int n = 10;
        
        // контейнер данных
        private int[] _array; 


        // индексатор 
        public int this[int index]
        {
            // аксессор
            get
            {
                if (index < 0)
                    index = 0;
                else if (index >= _array.Length)
                    index = _array.Length - 1;
                return _array[index];
            }// get
            // мутатор
            set
            {
                if (index < 0)
                    throw new Exception("IntArray : Вы вышли за пределы массива");
                if (index >= _array.Length)
                    throw new Exception("IntArray : Вы вышли за пределы массива");
                _array[index] = value;
            }// set 
        }

        public int Length { get { return _array.Length; } }

        public IntArray() : this(n) { }
        public IntArray(int size)
        {
            if (size <= 0) size = n;
            _array = new int[size];
        } // IntArray

        // заполнение массива случайными числами
        public void Fill(int lo, int hi)
        {
            for (int i = 0; i < _array.Length; i++)
            {
                _array[i] = Utils.Random.Next(lo, hi);
            } // for i
        } // Fill

        // вывод массива
        public void Show()
        {
            for (int i = 0; i < _array.Length; i++)
            {
                Console.Write($"{_array[i], 8}");
            } // for i
        }// Show
    }// class IntArray
}
