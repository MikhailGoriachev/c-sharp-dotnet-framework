﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W9C_.Models
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Домашнее задание № 9.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1.Формирование и вывод одномерного массива." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Произведение элементов массива с четными номерами." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Сумма эл. массива, расположенных между первым и последним нулевыми эл-ми." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Отрицательным элементам массива поменять знак, сортировать массив по убыванию." },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2.Класс Toy демонстрация перегрузки операций." },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 3.Формирование коллекции товара." },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Класс Goods. Демонстрация перегрузки операций." },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Поиск товара с минимальной ценой." },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Поиск товара с максимальной ценой." },
                new MenuItem { HotKey = ConsoleKey.H, Text = "Сортировка товара по убыванию количества." },
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App();

                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Меню приложения : ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // Формирование и вывод одномерного массива
                        case ConsoleKey.Q:
                            app.Task1Array();
                            break;

                        // Произведение элементов массива с четными номерами
                        case ConsoleKey.W:
                             app.Task1ArrayProiz();
                            break;

                        // Сумма эл. массива, расположенных между первым и последним нулевыми эл-ми
                        case ConsoleKey.E:
                            app.Task1ArraySumma();
                            break;

                        // Отрицательным элементам массива поменять знак
                        case ConsoleKey.R:
                             app.Task1ArrayNegativSign();
                            break;
                        // ------------------------------------------------------------
                        // пункт меню, относящийся к задаче 2

                        // Класс Toy демонстрация перегрузки операций
                        case ConsoleKey.A:
                            app.Task2Toy();
                           break;

                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 3

                        // Формирование коллекции товара
                        case ConsoleKey.S:
                            app.ShopShow();
                           break;

                        // Класс Goods. Демонстрация перегрузки операций
                        case ConsoleKey.D:
                            app.Task3Goods();
                            break;

                        // Поиск товара с минимальной ценой
                        case ConsoleKey.F:
                            app.ShopMinPriceGoods();
                             break;

                        // Поиск товара с максимальной ценой
                        case ConsoleKey.G:
                            app.ShopMaxPriceGoods();
                            break;

                        // Сортировка товара по убыванию количества
                        case ConsoleKey.H:
                            app.SortGoods();
                            break;
                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                } // while

            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;

        }// Main
    }// class Program
}
