﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// В классе Task1 с использованием класса одномерного массива
/// и индексатора реализовать обработки:
///•	произведение элементов массива с четными номерами,
///   вывести массив с выделением цветом элементов с четными номерами 
///•	сумму элементов массива, расположенных между первым и
///   последним нулевыми элементами, вывести диапазон суммирования с 
///   выделением цветом: границ и слагаемых
///•	отрицательным элементам массива поменять знак, 
///   сортировать массив по убыванию. Метод сортировки – сортировка вставками
/// </summary>
namespace H_W9C_.Models
{
    internal class Task1
    {
        
        // произведение элементов массива с четными номерами
        public static int ProizElem(IntArray myArr)
        {
            int prod = 1;
            for (int i = 0; i < myArr.Length; i += 2)
            {
                prod *= myArr[i];
            }
            return prod;
        }// ProizElem

        // поиск индекса первого нулевого элемента
        public static int FirstZero(IntArray arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == 0) return i;
            } // for i
            return -1;
        } // FirstZero

        // поиск индекса последнего нулевого элемента
        public static int LastZero(IntArray arr)
        {
            int iZero = -1;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == 0) iZero = i;
            } // for i
            return iZero;
        } // LastZero

        // суммa элементов массива, расположенных между первым и последним нулевыми элементами
        public static int SumBetweenZero(IntArray array, int first, int last)
        {
            int sum = 0;

            for (int i = first; i < last; i++)
                sum += array[i];

            return sum;
        }// SumBetweenZero

        // отрицательным элементам массива поменять знак
        public static void NegativElemSign(IntArray array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] < 0)
                    array[i] = array[i] * (-1);
                Console.Write($"{array[i],8}");
            }// for i
        }// NegativElemSign

        // сортировка вставками
        public static void ChoiceSortDescend(IntArray array)
        {
            int i, j, k;
            bool flag;
            for (i = 1; i < array.Length; i++) {
                flag = false;
                for (j = 0; j <= i; j++) {
                    if (array[i] > array[j]) {
                        flag = true;
                        break;
                    }// if
                }// for j
                if (!flag) continue;
                int temp = array[i];
                for (k = i; k > j; k--) {
                    array[k] = array[k - 1];
                }// for k
                array[j] = temp;
            }// for i
        }// ChoiceSortDescend

    }// class Task1
}
