﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Создайте класс Shop (магазин), в котором хранить название магазина,
/// закрытый массив товаров. Реализуйте в этом классе методы заполнения массива
/// товаров данными, вывод товаров в консоль, суммирование цен товаров.
/// Разработайте индексатор с контролем выхода за пределы массива.
/// </summary>
namespace H_W9C_.Models
{
    public class Shop
    {
        private string _nameShop;
        private Goods[] _goods;

        public string NameShop
        {
            get => _nameShop;
            set { if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Shop: Некорректное значение названия магазина");
                _nameShop = value; }
        } // NameShop

        // проверка массива маршрутов на пустоту
        public bool Empty => _goods.Length == 0;


        // индексатор 
        public Goods this[int index]
        {
            // аксессор
            get
            {
                if (index < 0)
                    index = 0;
                else if (index >= _goods.Length)
                    index = _goods.Length - 1;
                return _goods[index];
            }// get
            // мутатор
            set
            {
                if (index < 0)
                    throw new Exception("Shop : Вы вышли за пределы массива");
                if (index >= _goods.Length)
                    throw new Exception("Shop : Вы вышли за пределы массива");
                _goods[index] = value;
            }// set 
        }
        
        public void Initialize()
        {
            NameShop = "Магазин бытовой химии <<Элина>>";
            _goods = new[] {
                new Goods {NameGoods = "Шампунь 'Чистая линия'" , QuantityGoods = 5  , PriceGoods = 110d},
                new Goods {NameGoods = "Белизна 'Чистюля'"      , QuantityGoods = 12 , PriceGoods = 23d},
                new Goods {NameGoods = "Зубная паста 'Colgate'" , QuantityGoods = 3  , PriceGoods = 58d},
                new Goods {NameGoods = "Мыло кусковое 'Nivea'"  , QuantityGoods = 8  , PriceGoods = 55d},
                new Goods {NameGoods = "Бальзам д/волос 'Dove'" , QuantityGoods = 3  , PriceGoods = 230d},
                new Goods {NameGoods = "Шампунь 'Nivea'"        , QuantityGoods = 4  , PriceGoods = 180d},
                new Goods {NameGoods = "Шампунь 'Dove'"         , QuantityGoods = 2  , PriceGoods = 200d},
                new Goods {NameGoods = "Бальзам д/волос 'Nivea'" , QuantityGoods = 4 , PriceGoods = 200d},
                new Goods {NameGoods = "Мыло кусковое 'Dove'"    , QuantityGoods = 8 , PriceGoods = 85d},
                new Goods {NameGoods = "Зубная паста 'Oral-B'"   , QuantityGoods = 6 , PriceGoods = 90d},
            };
        } // Initialize

        // суммирование цен товаров
        public double SumGoods()
        {
            double sum = 0;
            for (int i = 0; i < _goods.Length; i++)
            {
                sum +=_goods[i].PriceQuantity();
            }
            return sum;
        }// SumGoods

        // вывести данные магазина в консоль
        public void Show()
        {
            // вывод заголовка таблицы данных магазина
            Console.Write($"\n\n\t{NameShop}\t  {DateTime.Now:g}\n {Goods.Header()}\n");

            // вывод всех элементов массива товаров
            void OutItem(Goods obj) => Console.WriteLine($"{obj.ToTableRow()}");
            Array.ForEach(_goods, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Goods.Footer());
            double sumGoodsShop = SumGoods();

            Console.Write($"\tТовара в магазине на сумму: {sumGoodsShop, 19:f1}рубл.\n");
        } // Show


    }// class Shop
}
