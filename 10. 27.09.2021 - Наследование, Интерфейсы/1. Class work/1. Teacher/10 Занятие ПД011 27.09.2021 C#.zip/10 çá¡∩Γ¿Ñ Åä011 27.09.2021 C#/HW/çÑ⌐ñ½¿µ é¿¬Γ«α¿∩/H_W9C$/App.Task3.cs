﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W9C_.Models
{/// <summary>
/// При помощи индексатора, в классе решения Task3 реализуйте
/// поиск товаров с минимальной ценой,
/// максимальной ценой,
/// сортировку товара по убыванию количества (метод быстрой сортировки). 
/// </summary> 
/// * Метод для решения задачи 3
    internal partial class App
    {
        // объект для обработки
        private static Shop _shop;


        public App() : this(new Shop()) { }
        public App(Shop shop)
        {
            _shop = shop;
            
        } // App

        // Вывод данных о товаре в магазине
        public void ShopShow()
        {
            Utils.ShowNavBarTask("   Вывод данных о товаре в магазине");

            _shop.Initialize();
            _shop.Show();
        } // ShopShow

        public void Task3Goods()
        {
            Utils.ShowNavBarTask("   Класс Goods демонстрация перегрузки операций");

            Goods goods1 = new Goods { NameGoods = "Порошок 'Persil'", QuantityGoods = 1, PriceGoods = 87d };
            Goods goods2 = new Goods { NameGoods = "Порошок 'Gala'", QuantityGoods = 1, PriceGoods = 69d };
            Goods goods3 = new Goods { NameGoods = "Порошок", QuantityGoods = 1, PriceGoods = 10d };
            Goods goods4 = new Goods { NameGoods = "Порошок", QuantityGoods = 1, PriceGoods = 1200d };

            int n = 50;
            Console.WriteLine($"\n {goods1}");
            goods1 += n;

            Console.WriteLine($"\n\n {goods1} + {n} \n {goods1}");

            n = 20;
            Console.WriteLine($"\n {goods1}");
            goods1 -= n;

            Console.WriteLine($"\n\n {goods1} - {n} \n {goods1}");

            goods3 = goods1 + goods2;
            Console.WriteLine($"\n\n {goods1} + \n {goods2} = \n {goods3}");

            // логическая операция
            bool result = goods1 > goods2;
            Console.WriteLine($"\n\n Цена товара1 : {goods1.PriceGoods} > Цена товара2 : {goods2.PriceGoods} = {result}");
            result = goods1 < goods2;
            Console.WriteLine($"\n\n Цена товара1 : {goods1.PriceGoods} < Цена товара2 : {goods2.PriceGoods} = {result}"); // false

            // демонстанция перегруженных операций true/false

            Console.Write($"\n\n Перегрузка операций true/false, стоимость товара в интервале от 1 до 1000: {goods1.PriceGoods} --> ");

            if (goods1)
                Console.WriteLine("True");
            else
                Console.WriteLine("False");

            Console.Write($"\n Перегрузка операций true/false, стоимость товара равна 0 или больше 1000 : {goods4.PriceGoods} --> ");

            if (goods4)
                Console.WriteLine("True");
            else
                Console.WriteLine("False");
        }// Task3Goods


        public void ShopMinPriceGoods()
        {
            Utils.ShowNavBarTask("   Товар с минимальной ценой");

            int min = Min();

            Show("\n\n\t  В массиве цветом выделен товар с минимальной ценой:\n", min);
        }// ShopMinPriceGoods

        public void ShopMaxPriceGoods()
        {
            Utils.ShowNavBarTask("   Товар с максимальной ценой");

            int max = Max();

            Show("\n\n\t  В массиве цветом выделен товар с максимальной ценой:\n", max);
        }// ShopMaxPriceGoods

        public void SortGoods()
        {
            Utils.ShowNavBarTask("   Сортировка товара по убыванию количества товара");

            Console.WriteLine("\n\n\n\t\t\t Метод в разработке.....");

        }

        // поиск минимального товара в массиве 
        private static int Min()
        {
            int imin = 0;
            for (int i = 0; i < 10; i++)
            {
                if (_shop[i].PriceGoods < _shop[imin].PriceGoods)
                    imin = i;

            }// for i
            return imin;
        } // Min

        // поиск максимального товара в массиве 
        private static int Max()
        {
            int imax = 0;
            for (int i = 0; i < 10; i++)
            {
                if (_shop[i].PriceGoods > _shop[imax].PriceGoods)
                    imax = i;

            }// for i
            return imax;
        } // Max

        private void QSort(Goods[] goods, int first = 0, int last = -1)
        {
            if (last < 0)
                last = goods.Length - 1;
            if (first >= last) return;

            int mid = (last - first) / 2 + first, current = first;
            (goods[first], goods[mid]) = (goods[mid], goods[first]);
            for (int i = first +1; i <= last; i++)
            {
                if(goods[i] <= goods[first])
                {
                    (goods[++current], goods[i]) = (goods[i], goods[++current]);
                }
            }
            (goods[first], goods[current]) = (goods[current], goods[first]);
            QSort(goods, first, current - 1);
            QSort(goods, current +1, last);
        }

        //вывод массива с выделением цветом элемента с минимальной ценой
        private static void Show(string title, int value)
        {
            Console.WriteLine(title);
            Console.WriteLine(Goods.Header());
            
            for (int i = 0; i < 10; ++i)
            {
                // задать цвет элементу с заданным значением
                if (i == value)
                //{
                    Console.ForegroundColor = ConsoleColor.Red;
                    else Console.ForegroundColor = ConsoleColor.White;
                //} // if

                Console.Write($"{_shop[i].ToTableRow()} \n ");

               
            } // for
            Console.WriteLine(Goods.Footer());
            Console.WriteLine();
        } // Show
    }// class App
}
