﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Разработайте класс Toy для представления игрушки со свойствами 
/// * название игрушки (string),
/// * возрастная категория (int),
/// * стоимость игрушки (int). 
/// Перегрузите операции для класса Toy:
///•	+: сложения игрушки с целым числом – операция выполняет сложение цены и числа
///•	–: вычитания целого числа из игрушки – операция выполняет вычитание целого числа из цены игрушки
///•	< и >: сравнение цен двух игрушек
///•	true: если возрастная категория больше 5
///•	false: если возрастная категория меньше или равна 5 
/// </summary>
namespace H_W9C_.Models
{
    internal class Toy
    {
        // переменная для операции true, false
        private static int age = 5;
        // название игрушки
        public string NameToys { get; set; }

        // возрастная категория
        public int AgeCategory { get; set; }

        // стоимость игрушки
        public int Price { get; set; }

        public override string ToString() => $"Игрушка : {NameToys, 10}, возрастная категория{AgeCategory, 4}, цена : {Price, 4}";

        //Перегрузка операций

        // перегрузка операции + сложение объекта и целого числа
        public static Toy operator +(Toy obj, int number)=>
            new Toy {NameToys = obj.NameToys, AgeCategory = obj.AgeCategory, Price = obj.Price + number};

        // перегрузка операции - вычитание объекта и целого числа
        public static Toy operator -(Toy obj, int number) =>
            new Toy { NameToys = obj.NameToys, AgeCategory = obj.AgeCategory, Price = obj.Price - number };

        // парная перегрузка оператора >, < в новом синтаксисе
        public static bool operator <(Toy obj1, Toy obj2) => obj1.Price < obj2.Price;

        public static bool operator >(Toy obj1, Toy obj2) => obj1.Price > obj2.Price;

        // true и false перегрузка 
        public static bool operator true(Toy obj) => obj.AgeCategory > age;

        public static bool operator false(Toy obj) => obj.AgeCategory <= age; // operator false

    }// class Toy
}
