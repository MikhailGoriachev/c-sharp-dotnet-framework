﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/// <summary>
/// Описать класс «товар», содержащий следующие закрытые поля:
///•	название товара;
///•	количество товара(в условных единицах);
///•	стоимость товара в рублях.
/// Предусмотреть свойства для задания и получения состояния объекта.
/// Реализовать перегруженные операции:
///•	+: сложения товаров с одинаковыми наименованиями, выполняющую сложение их стоимостей, т.е. цен, умноженных на количество
///•	+: сложения товара и целого числа, выполняющего сложение цены и целого числа
///•	–: вычитание товара и целого числа, выполняющего вычитание целого числа из цены
///•	сравнение товаров по цене: < >, <= >=, == !=
///•	операция true: стоимость товара в интервале 1, …, 1000
///•	операция false: стоимость товара равна 0 или больше 1000
/// </summary>
namespace H_W9C_.Models
{
    public class Goods
    {
        // переменная для операции true, false
        private static double interval1 = Utils.GetRandom(1, 1000);
        private static double interval2 = Utils.GetRandom(0, 1100);
        // название товара
        private string _nameGoods;
        public string NameGoods
        {
            get => _nameGoods;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Goods: Не указано название товара");

                _nameGoods = value;
            }
        }// NameGoods

        // количество товара(в условных ед.)
        private int _quantityGoods;
        public int QuantityGoods
        {
            get => _quantityGoods;
            set
            {
                if (value <= 0)
                    throw new Exception("Goods: Товар отсутствует");

                _quantityGoods = value;
            }
        }// QuantityGoods

        // стоимость товара в рубл.
        private double _priceGoods;
        public double PriceGoods
        {
            get => _priceGoods;
            set
            {
                if (value <= 0)
                    throw new Exception("Goods: Не допустимое значение стоимости товара");

                _priceGoods = value;
            }
        }// PriceGoods

        // конструкторы
        public Goods() : this("Товар", 1, 10d) { }
        public Goods(string namegoods, int quantity, double price)
        {
            NameGoods     = namegoods;
            QuantityGoods = quantity;
            PriceGoods    = price;
        }// Goods

        // формирование строкового представления объекта
        public override string ToString() => $" Товар: {_nameGoods, 23} ; количество: { _quantityGoods, 11} ; цена: {_priceGoods, 8}рубл.";

        public string ToTableRow() =>
           $"\t│ {_nameGoods,-23} | {_quantityGoods, 11} | {_priceGoods,8:f2} │";

        public double PriceQuantity() => PriceGoods * QuantityGoods;

        //Перегрузка операций

        // перегрузка операции + сложение двух объектов
        public static Goods operator +(Goods obj1, Goods obj2)
        {
          //if(obj1.NameGoods == obj2.NameGoods)
           return new Goods { PriceGoods = obj1.PriceGoods + obj2.PriceGoods };
        }

        //public static Goods operator +(Goods obj1, Goods obj2)=>

        //    new Goods { PriceQuantity() = obj1.PriceGoods + obj2.PriceGoods };

        // перегрузка операции + сложение объекта и целого числа
        public static Goods operator +(Goods obj1, int number) =>
            new Goods { NameGoods = obj1.NameGoods, QuantityGoods = obj1.QuantityGoods, PriceGoods = obj1.PriceGoods + number };

        // перегрузка операции - вычитание объекта и целого числа
        public static Goods operator -(Goods obj1, int number) =>
            new Goods { NameGoods = obj1.NameGoods, QuantityGoods = obj1.QuantityGoods, PriceGoods = obj1.PriceGoods - number };

        // парная перегрузка операторов < >, <= >=, == != 
        public static bool operator <(Goods obj1, Goods obj2) => obj1.PriceGoods < obj2.PriceGoods;

        public static bool operator >(Goods obj1, Goods obj2) => obj1.PriceGoods > obj2.PriceGoods;
        public static bool operator <=(Goods obj1, Goods obj2) => obj1.PriceGoods <= obj2.PriceGoods;
        public static bool operator >=(Goods obj1, Goods obj2) => obj1.PriceGoods >= obj2.PriceGoods;
        public static bool operator true(Goods obj1) => obj1.PriceGoods >= interval1;
        public static bool operator false(Goods obj1) => obj1.PriceGoods >= interval2 ;


        // статическое свойство для вывода шапки таблицы
        public static string Header()
        {
            string str =
            $"\t┌─────────────────────────┬─────────────┬──────────┐\n" +
            $"\t│     Название            │ Количество  │   Цена   │\n" +
            $"\t│              товара     │      товара │  товара  │\n" +
            $"\t├─────────────────────────┼─────────────┼──────────┤";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"\t└─────────────────────────┴─────────────┴──────────┘";
    }// class Goods
}
