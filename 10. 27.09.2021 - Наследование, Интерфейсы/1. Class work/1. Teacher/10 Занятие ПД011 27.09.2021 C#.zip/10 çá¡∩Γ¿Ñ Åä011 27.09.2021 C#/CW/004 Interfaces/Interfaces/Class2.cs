﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Interfaces;

namespace AbstrMethods
{

    class Class2 : IMethods
    {
        public void Method1() {
            throw new NotImplementedException();
        }

        public void Method1(int x) {
            throw new NotImplementedException();
        }
    }
}
