#include "ExtendedChemicalElement.h"


void ExtendedChemicalElement::Show()
{
	cout << "\n============================\n";
	ChemicalElement::Show();

	density = pInformation->GetDensity(name);
	position = pInformation->GetPositionFromPeriodicTable(name);

	cout << "Density of Element: " << density
	     << "\nPosition in Periodic Table:" << position
	     << "\n\n============================\n";
}
