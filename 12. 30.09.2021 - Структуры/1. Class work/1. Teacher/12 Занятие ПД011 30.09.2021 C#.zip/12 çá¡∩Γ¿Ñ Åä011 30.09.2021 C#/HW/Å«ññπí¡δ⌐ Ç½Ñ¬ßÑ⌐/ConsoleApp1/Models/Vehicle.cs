﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClasses.Models
{
    // абстрактный класс Vehicle (транспортное средство)
    abstract class Vehicle
    {
        // географические координаты
        protected (double,double) _geoCoord;
        public (double,double) GeoCoord
        {
            get { return _geoCoord; }
            set { _geoCoord = value; }
        }

        // цена
        protected double  _price;
        public double  Price
        {
            get { return _price; }
            set { if (value <= 0)
                    throw new Exception("Vehicle: ошибка цены");
                    _price = value; }
        }

        // скорость
        protected double _speed;
        public double Speed
        {
            get { return _speed; }
            set {
                if (value <= 0)
                    throw new Exception("Vehicle: ошибка скорости"); 
                _speed = value; }
        }


        // год выпуска
        protected int _year;
        public int Year
        {
            get { return _year; }
            set {
                if (value <= 0)
                    throw new Exception("Vehicle: ошибка года выпуска"); 
                _year = value; }
        }

        // конструктор
        public Vehicle((double, double) geo, double price, double speed, int year) {

            GeoCoord = geo;
            Price = price;
            Speed = speed;
            Year = year;

        }







    }
}
