﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClasses.Models
{
    // класс Ship (корабль)
    class Ship : Vehicle
    {
        private string _homePort;

        public string HomePort
        {
            get { return _homePort; }
            set { if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Ship: ошибка порта приписки");
                _homePort = value; }
        }

        // количество пассажиров
        private int _pass;
        public int Pass
        {
            get { return _pass; }
            set
            {
                if (value < 0)
                    throw new Exception("Plane: ошибка количества пассажиров");
                _pass = value;
            }
        }

        public Ship((double, double) geo, double price, double speed, int year, int pass, string port) : base(geo, price, speed, year) {

            Pass = pass;
            HomePort = port;
        }


        public override string ToString()
        {

            StringBuilder result = new StringBuilder();

            result.Append($"*************************************************\n");
            result.Append($"Тип транспорта :                          Корабль\n");
            result.Append($"Географические координаты :     {_geoCoord,6:f2}\n");
            result.Append($"Цена :                             {_price,6:f2}\n");
            result.Append($"Скорость :                         {_speed,6:f2}\n");
            result.Append($"Год выпуска :                      {_year,6:f2}\n");
            result.Append($"Количество пассажиров :            {_pass,6}\n");
            result.Append($"Порт приписки :     {_homePort}\n");
            result.Append($"*************************************************\n");


            return result.ToString();


        }


    }
}
