﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClasses.Models
{
    // класс Car автомобиль
    class Car : Vehicle
    {

        public Car((double, double) geo, double price, double speed, int year) : base(geo, price, speed, year) { }



        public override string ToString()
        {

            StringBuilder result = new StringBuilder();
            result.Append($"*************************************************\n");
            result.Append($"Тип транспорта :                       Автомобиль\n");
            result.Append($"Географические координаты :     {_geoCoord,6:f2}\n");
            result.Append($"Цена :                             {_price,6:f2}\n");
            result.Append($"Скорость :                         {_speed,6:f2}\n");
            result.Append($"Год выпуска :                      {_year,6:f2}\n");   
            result.Append($"*************************************************\n");

            return result.ToString();


        }

    }
}