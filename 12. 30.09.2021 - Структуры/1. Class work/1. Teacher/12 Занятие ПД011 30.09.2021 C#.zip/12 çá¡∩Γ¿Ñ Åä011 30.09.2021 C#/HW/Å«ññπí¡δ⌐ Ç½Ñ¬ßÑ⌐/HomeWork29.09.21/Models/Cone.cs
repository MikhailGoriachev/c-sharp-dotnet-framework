﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork29._09._21.Models
{
    class Cone : Figure, VolumetricFigure
    {
        private double _h;
        public double H
        {
            get { return _h; }
            set
            {
                if (value <= 0)
                    throw new Exception("Cylinder: высота цилиндра не может быть меньше или равна 0");
                _h = value;
            }
        }

        private double _r;
        public double R
        {
            get { return _r; }
            set
            {
                if (value <= 0)
                    throw new Exception("Cylinder: радиус цилиндра не может быть меньше или равна 0");
                _r = value;
            }
        }

        public Cone(double h, double r)
        {

            H = h;
            R = r;
        }

        // Метод для вычисления площади поверхности
        public override double Area()
        {
            double l = Math.Sqrt(_r * _r + _h * _h);
            return Math.PI * _r * l;
        }

        // Метод для нахождения объема
        public double Volume()
        {
            return (Math.PI * _h * _r * _r)/3d;                        
        }

        // компаратор для сортировки по убыванию площади
        public override int AreaComparer(Figure p1, Figure p2)
        {

           return p2.Area().CompareTo(p1.Area());
        }

        public override string ToString()
        {

            StringBuilder result = new StringBuilder();
            result.Append($"*************************************************\n");
            result.Append($"Тип фигуры :                              Конус\n");
            result.Append($"Высота H  :                            {_h,6:f2}\n");
            result.Append($"Радиус R  :                            {_r,6:f2}\n");
            result.Append($"Обьем   :                        {Volume(),6:f2}\n");
            result.Append($"Площадь поверхности   :            {Area(),6:f2}\n");
            result.Append($"*************************************************\n");

            return result.ToString();


        }
    }
}
