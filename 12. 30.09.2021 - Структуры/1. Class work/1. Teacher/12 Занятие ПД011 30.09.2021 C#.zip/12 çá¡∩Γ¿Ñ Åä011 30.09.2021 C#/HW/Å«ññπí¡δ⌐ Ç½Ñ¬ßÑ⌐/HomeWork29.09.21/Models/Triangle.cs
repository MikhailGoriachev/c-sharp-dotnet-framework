﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork29._09._21.Models
{
    class Triangle : Figure, FlatFigure
    {
        private double _a;
        public double A
        {
            get { return _a; }
            set { if (value <= 0)
                    throw new Exception("Triangle: сторона треугольника не может быть меньше или равна 0");
                        _a = value; }
        }

        private double _b;
        public double B
        {
            get { return _b; }
            set
            {
                if (value <= 0)
                    throw new Exception("Triangle: сторона треугольника не может быть меньше или равна 0");
                _b = value;
            }
        }

        private double _c;
        public double C
        {
            get { return _c; }
            set
            {
                if (value <= 0)
                    throw new Exception("Triangle: сторона треугольника не может быть меньше или равна 0");
                _c = value;
            }
        }


        public Triangle(double a, double b, double c) {

            A = a;
            B = b;
            C = c;
        }




        // Метод для нахождения площади
        public override double Area()
        {
            double p = Perimetr() / 2d;

            return Math.Sqrt(p * (p - _a) * (p - _b) * (p - _c));

        }

        // Метод для нахождения периметра
        public double Perimetr()
        {
            return _a + _b + _c;
        }

        // компаратор для сортировки по убыванию площади
        public override int AreaComparer(Figure p1, Figure p2) {

            return p2.Area().CompareTo(p1.Area());
        }


        public override string ToString()
        {

            StringBuilder result = new StringBuilder();
            result.Append($"*************************************************\n");
            result.Append($"Тип фигуры :                          Треугольник\n");
            result.Append($"Сторона А  :                            {_a,6:f2}\n");
            result.Append($"Сторона B  :                            {_b,6:f2}\n");
            result.Append($"Сторона C  :                            {_c,6:f2}\n");
            result.Append($"Периметр   :                    {Perimetr(),6:f2}\n");
            result.Append($"Площадь    :                        {Area(),6:f2}\n");            
            result.Append($"*************************************************\n");

            return result.ToString();


        }





    }
}
