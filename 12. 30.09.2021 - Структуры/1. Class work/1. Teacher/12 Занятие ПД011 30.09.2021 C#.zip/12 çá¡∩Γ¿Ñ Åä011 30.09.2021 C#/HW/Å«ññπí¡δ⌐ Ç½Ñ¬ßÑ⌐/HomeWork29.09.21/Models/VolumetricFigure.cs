﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork29._09._21.Models
{
    // Интерфейс ОбъемнаяФигура с методами для вычисления площади поверхности и объема
    interface VolumetricFigure
    {
        // Метод для нахождения объема
        double Volume();

        // Метод для вычисления площади поверхности
        double Area();



    }
}
