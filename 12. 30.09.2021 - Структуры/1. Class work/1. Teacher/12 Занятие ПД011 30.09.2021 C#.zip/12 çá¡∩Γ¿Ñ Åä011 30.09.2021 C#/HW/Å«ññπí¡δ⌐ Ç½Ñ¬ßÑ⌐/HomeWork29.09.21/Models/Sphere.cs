﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork29._09._21.Models
{
    class Sphere : Figure, VolumetricFigure
    {
        private double _r;
        public double R
        {
            get { return _r; }
            set
            {
                if (value <= 0)
                    throw new Exception("Sphere: радиус шара не может быть меньше или равна 0");
                _r = value;
            }
        }

        public Sphere(double r)
        {            
            R = r;
        }

        public override double Area()
        {
            return 4d * Math.PI * _r * _r;
        }

        public override int AreaComparer(Figure p1, Figure p2)
        {
            return p2.Area().CompareTo(p1.Area());
        }

        public double Volume()
        {
            return (4d * Math.PI * _r * _r * _r) / 3d;
        }

        public override string ToString()
        {

            StringBuilder result = new StringBuilder();
            result.Append($"*************************************************\n");
            result.Append($"Тип фигуры :                                 Шар\n");
            result.Append($"Радиус R  :                            {_r,6:f2}\n");
            result.Append($"Обьем   :                        {Volume(),6:f2}\n");
            result.Append($"Площадь поверхности   :            {Area(),6:f2}\n");
            result.Append($"*************************************************\n");

            return result.ToString();


        }


    }
}
