﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork29._09._21.Models;

namespace HomeWork29._09._21.Task
{
    class Task1
    {

        public Figure[] _array { get; private set; }

        // Инициализация массива фигур
        public void Init()
        {

            _array = new Figure[]{

                new Triangle( 10, 12, 15 ),
                new Triangle( 3, 4, 5),
                new Rectangle( 5, 6 ),
                new Rectangle(5,9),
                new Cylinder( 10, 5 ),
                new Cylinder( 6, 9),
                new Cone(5,3),
                new Cone(5,8),
                new Sphere(10),
                new Sphere(6),


            };


        }


        // Вывод на экран массива транспорта
        public void Show()
        {

            foreach (Figure item in _array)
            {
                Console.WriteLine(item.ToString());
            }


        }

        // Упорядочить массив по убыванию площади
        public void SortToArea()
        {

            Array.Sort(_array, _array[0].AreaComparer);
            Show();
        }







        // Выбрать объекты с минимальной и максимальной площадью 

        public void MinAndMaxArea()
        {

            double maxArea = _array[0].Area();
            double minArea = _array[0].Area();

            for (int i = 1; i < _array.Length; i++)
            {
                if (_array[i].Area() > maxArea)
                    maxArea = _array[i].Area();

                if (_array[i].Area() < minArea)
                    minArea = _array[i].Area();

            }

            Console.WriteLine($"\nФигуры с максиамльной площадью: ");
            foreach (Figure item in _array)
            {
                if (item.Area() == maxArea)
                    Console.WriteLine(item.ToString());

            }

            Console.WriteLine($"\nФигуры с минимальной площадью: ");
            foreach (Figure item in _array)
            {
                if (item.Area() == minArea)
                    Console.WriteLine(item.ToString());

            }

        }

        // компаратор для сортровки массива фигур по возрастанию площади
        public static int AreaUpComparer(Figure p1, Figure p2)
        {

            return p1.Area().CompareTo(p2.Area());

        }


        // упорядочить массив по фигур по возрастанию площади

        public void SortToAreaUp()
        {

            Array.Sort(_array, Task1.AreaUpComparer);

        }



    }
}
