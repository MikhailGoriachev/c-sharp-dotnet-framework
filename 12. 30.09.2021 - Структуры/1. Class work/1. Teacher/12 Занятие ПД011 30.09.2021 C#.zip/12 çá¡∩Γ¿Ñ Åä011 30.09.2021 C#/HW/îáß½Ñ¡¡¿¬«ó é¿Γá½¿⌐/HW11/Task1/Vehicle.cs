﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace HW11.Task1
{
	// базовый абстрактный класс ТС
	internal abstract class Vehicle
	{
		// географические координаты
		protected Point _geoCoords;
		
		// цена
		protected int _price;
		
		// скорость
		protected int _speed;
		
		// год выпуска
		protected int _productionYear;

		// тип ТС
		protected string _type;

		public Point GeoCoords
		{
			get => _geoCoords;
			set => _geoCoords = value;
		}

		public int Price
		{
			get => _price;
			set => _price = value;
		}

		public int Speed
		{
			get => _speed;
			set => _speed = value;
		}

		public int ProductionYear
		{
			get => _productionYear;
			set => _productionYear = value;
		}


		// конструкторы

		protected Vehicle():this(new Point(1,1), 56324, 210, 2010, "Vehicle" )
		{}
		
		protected Vehicle(Point geoCoords, int price, int speed, int productionYear, string type)
		{
			_geoCoords = geoCoords;
			_price = price;
			_speed = speed;
			_productionYear = productionYear;
			_type = type;
		}

		public override string ToString() => $"Тип техники: {_type, 10}, координаты: {_geoCoords,11}," +
		                                     $" цена: {_price,8}," + $" скорость: {_speed,5}, год выпуска: {_productionYear}";

		public static string Header(int indent)
		{
			string spaces = $" ".PadRight(indent);
			return
				$"{spaces}╔════════════╦═════════════╦══════════╦══════════╦═════════════╦════════════╦═════════╦════════╗\n" +
				$"{spaces}║   Тип ТС   ║ Координаты  ║   Цена   ║ Скорость ║     Год     ║ Количество ║   Порт  ║ Высота ║\n" +
				$"{spaces}║            ║             ║          ║          ║   Выпуска   ║ Пассажиров ║ Приписки║ Полёта ║\n" +
				$"{spaces}╠════════════╬═════════════╬══════════╬══════════╬═════════════╬════════════╬═════════╬════════╣\n";

				
		}

		public static string Footer(int indent) =>
			$" ".PadRight(indent) + 
			$"╚════════════╩═════════════╩══════════╩══════════╩═════════════╩════════════╩═════════╩════════╝\n";


		public virtual string ToTableRow(int indent)
		{
			string spaces = $" ".PadRight(indent);

			return 
				$"{spaces}║ {_type,-10} ║ {_geoCoords,11} ║ {_price,8} ║ {_speed,8} ║ {_productionYear,11} ║";
		}


		public static int ComparePriceDesc(Vehicle v1, Vehicle v2)
			=> v2.Price.CompareTo(v1.Price);

	}
}
