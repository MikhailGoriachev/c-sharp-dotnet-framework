﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW11.Task2.Interfaces;

namespace HW11.Task2.Classes
{
	// Класс определения треугольника
	class Triangle : Figure, IFlateFigure
	{
		public double A => _a;
		public double B => _b;
		public double C => _c;

		public override double Area => CalcArea();
		public double Perimeter => CalcPerimeter();

		// свойство для задания длин треугольника
		public (double A, double B, double C) Sides
		{
			get => (_a, _b, _c);
			set
			{
				if (!IsTriangle(value.A, value.B, value.C))
					throw new ArgumentException(
						"Некорректные параметры для сторон треугольника");

				_a = value.A; _b = value.B; _c = value.C;
			}
		}

		// конструкторы
		public Triangle() : this(1d) { }

		// равносторонние
		public Triangle(double a) : this(a, a, a) { }

		// равнобедренные треугольники
		public Triangle(double a, double b) : this(a, b, b) { }

		// разносторонние треугольники
		public Triangle(double a, double b, double c)
		{
			if (!IsTriangle(a, b, c))
				throw new ArgumentException("Невозможно создать треугольник");

			Sides = (a, b, c);
		}

		// проверка возможности создания треугольника
		public static bool IsTriangle(double a, double b, double c) =>
			a + b > c && a + c > b && b + c > a && a > 0 && b > 0 && c > 0;


		public double CalcPerimeter() => _a * _b + _c;

		public double CalcArea()
		{
			double p = CalcPerimeter() / 2;  // полупериметр
			double area = Math.Sqrt(p * (p - _a) * (p - _b) * (p - _c));
			return area;
		}

		public override string ToString()
		{
			return base.ToString() + $"Треугольник,   a: {_a,6:f2}; b: {_b,6:f2}; c: {_c,6:f2};" +
			       $" S = {Area,8:f2}; P = {Perimeter,8:f2}" ;
		}
		
		public override string ToTableRow(int n) =>
			" ".PadRight(n) +
			MakeTableString("Треугольник", ("a", _a), ("b", _b),("c", _c), ("Area", Area), ("Perimeter", Perimeter));

		// Фабрика создания треугольника со случайными сторонами
		public static Triangle Generate()
		{
			// генерация сторон треугольника
			double a, b, c;

			do
			{
				a = Utilities.GenerateDouble(1d, 20d);
				b = Utilities.GenerateDouble(1d, 20d);
				c = Utilities.GenerateDouble(1d, 20);
			} while (!Triangle.IsTriangle(a, b, c));

			return new Triangle { Sides = (a, b, c) };
		}
	}
}
