﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace HW11.Task1
{
	class Car : Vehicle
	{
		// конструкторы
		public Car() : this(new Point(3, 5), 25167, 120, 1994)
		{}
		
		public Car(Point coords, int price, int speed, int prodYear) : base(coords, price, speed, prodYear, "Автомобиль")
		{}


		public static Car Generate()
		{
			var coords = new Point(Utilities.GenerateInt(1, 100), Utilities.GenerateInt(1, 100));
			var price = Utilities.GenerateInt(1000, 1_000_000);
			var speed = Utilities.GenerateInt(160, 350);
			var year = Utilities.GenerateInt(1990, 2021);
			return new Car(coords, price, speed, year);
		}


		public override string ToTableRow(int indent)=> 
			base.ToTableRow(indent) + "            ║         ║        ║";

	}
}
