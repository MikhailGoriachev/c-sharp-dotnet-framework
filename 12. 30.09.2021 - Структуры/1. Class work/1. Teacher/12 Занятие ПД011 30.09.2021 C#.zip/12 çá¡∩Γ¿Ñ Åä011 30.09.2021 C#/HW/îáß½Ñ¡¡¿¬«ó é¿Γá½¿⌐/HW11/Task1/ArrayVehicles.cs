﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW11.Task1
{
	class ArrayVehicles
	{
		private Vehicle[] _vehicles;

		public bool EmptyArray() => _vehicles is null || _vehicles.Length == 0;

		public void Show(string title) => Show(title, _vehicles);

		public static void Show(string title, Vehicle[] vehicles)
		{
			Console.WriteLine(title);
			Console.Write(Vehicle.Header(4));

			foreach (var elem in vehicles)
				Console.WriteLine(elem.ToTableRow(4));

			Console.Write(Vehicle.Footer(4));
		}

		public void OrderByPriceDesc() => Array.Sort(_vehicles, Vehicle.ComparePriceDesc);
		

		// самое старое транспортное средство
		public Vehicle[] SelectOldestVehicles()
		{
			Vehicle[] find = {_vehicles[0]};
			int minYear = _vehicles[0].ProductionYear;
			
			for (int i = 1; i < _vehicles.Length; i++)
			{
				int year = _vehicles[i].ProductionYear;
				if ( year < minYear)
				{
					find = new []{ _vehicles[i] };
					minYear = year;
				}else if (year == minYear)
				{
					Array.Resize(ref find, find.Length + 1);
					find[find.Length - 1] = _vehicles[i];
				}
			}

			return find;
		}

	
		// самое быстрое транспортное средство
		public Vehicle[] FindFastest()
		{
			Vehicle[] find = { _vehicles[0] };
			int maxSpeed = _vehicles[0].Speed;

			for (int i = 1; i < _vehicles.Length; i++)
			{
				int speed = _vehicles[i].Speed;
				if (speed > maxSpeed)
				{
					find = new [] { _vehicles[i] };
					maxSpeed = speed;
				}
				else if (speed == maxSpeed)
				{
					Array.Resize(ref find, find.Length + 1);
					find[find.Length - 1] = _vehicles[i];
				}
			}
			return find;
		}
		// самое медленное транспортное средство
		public Vehicle[] FindSlowest()
		{
			Vehicle[] find = { _vehicles[0] };
			int minSpeed = _vehicles[0].Speed;

			for (int i = 1; i < _vehicles.Length; i++)
			{
				int speed = _vehicles[i].Speed;
				if (speed < minSpeed)
				{
					find = new [] { _vehicles[i] };
					minSpeed = speed;
				}
				else if (speed == minSpeed)
				{
					Array.Resize(ref find, find.Length + 1);
					find[find.Length - 1] = _vehicles[i];
				}
			}
			return find;
		}

		// заполнение массива
		public void Initialize()
		{
			_vehicles = new Vehicle[]
			{
				Car.Generate(),
				Car.Generate(),
				Car.Generate(),
				Car.Generate(),
				Car.Generate(),
				Plane.Generate(),
				Plane.Generate(),
				Ship.Generate("Порт1"),
				Ship.Generate("Порт2"),
				Ship.Generate("Порт3")
			};
		}

	}
}
