﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW11.Task1;

namespace HW11
{
	internal partial class App
	{
		private void Task1MenuItem1()
		{
			Utilities.ShowNavBar("    Создание массива транспортных средств");
			
			_arrayVehicles.Initialize();
			Console.WriteLine("\n\n    Коллекция транспортных средств сгенерирована.\n\n\n");
			_arrayVehicles.Show("    Список транспортных средств:\n");
		}

		private void Task1MenuItem2()
		{
			Utilities.ShowNavBar("   Вывод списка транспортных средств");

			if (_arrayVehicles.EmptyArray())
			{
				Console.WriteLine("\n\n    Нет данных.");
				return;
			}

			_arrayVehicles.Show("    Список транспортных средств:\n");
		}

		private void Task1MenuItem3()
		{
			Utilities.ShowNavBar("    Найти самое старое транспортное средство");

			if (_arrayVehicles.EmptyArray())
			{
				Console.WriteLine("\n\n    Нет данных.");
				return;
			}

			_arrayVehicles.Show("    Список транспортных средств:\n");

			ArrayVehicles.Show("\n\n\n    Самое старое транспортное средство/средства:", _arrayVehicles.SelectOldestVehicles());

		}

		private void Task1MenuItem4()
		{
			Utilities.ShowNavBar("    Найти самые быстрые и самое медленное транспортные средства");

			if (_arrayVehicles.EmptyArray())
			{
				Console.WriteLine("\n\n    Нет данных.");
				return;
			}
			_arrayVehicles.Show("    Список транспортных средств:\n");

			ArrayVehicles.Show("\n\n\n    Самое быстрое транспортное средство/средства:", _arrayVehicles.FindFastest());

			ArrayVehicles.Show("\n\n\n    Самое медленное транспортное средство/средства:", _arrayVehicles.FindSlowest());
		}

		private void Task1MenuItem5()
		{
			Utilities.ShowNavBar("    Упорядочить массив по убыванию цены транспортного средства");

			if (_arrayVehicles.EmptyArray())
			{
				Console.WriteLine("\n\n    Нет данных.");
				return;
			}
			
			_arrayVehicles.OrderByPriceDesc();

			_arrayVehicles.Show("    Список транспортных средств, упорядоченных по убыванию цены:\n");
		}
	}
}
