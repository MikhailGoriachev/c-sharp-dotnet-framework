﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW11.Task2;

namespace HW11
{
	internal partial class App
	{
		private void Task2MenuItem1()
		{
			Utilities.ShowNavBar("    Создание коллекции фигур");
			_arrayFigures.Initialize();
			Console.WriteLine("\n\n    Коллекция фигур сгенерирована.\n\n\n");
			_arrayFigures.Show("    Список фигур:\n");
		}

		private void Task2MenuItem2()
		{
			Utilities.ShowNavBar("    Вывод списка фигур");
			
			if (_arrayFigures.EmptyArray())
			{
				Console.WriteLine("\n\n    Нет данных.");
				return;
			}
			
			_arrayFigures.Show("\n\n    Список фигур:\n");
		}

		private void Task2MenuItem3()
		{
			Utilities.ShowNavBar("    Упорядочить массив по убыванию площади");
			if (_arrayFigures.EmptyArray())
			{
				Console.WriteLine("\n\n    Нет данных.");
				return;
			}

			_arrayFigures.OrderByAreaDesc();
			_arrayFigures.Show("    Список фигур, упорядоченных по убыванию площади:\n");

		}
		private void Task2MenuItem4()
		{
			Utilities.ShowNavBar("    Упорядочить массив по возрастанию площади");
			if (_arrayFigures.EmptyArray())
			{
				Console.WriteLine("\n\n    Нет данных.");
				return;
			}

			_arrayFigures.OrderByArea();
			_arrayFigures.Show("    Список фигур, упорядоченных по возрастанию площади:\n");
		}


		private void Task2MenuItem5()
		{
			Utilities.ShowNavBar("    Выбрать объекты с минимальной и максимальной площадью");
			if (_arrayFigures.EmptyArray())
			{
				Console.WriteLine("\n\n    Нет данных.");
				return;
			}

			_arrayFigures.Show("    Список фигур:\n");

			ArrayFigures.Show("\n\n    Фигура с максимальной площадью:", _arrayFigures.FindMaxArea());
			ArrayFigures.Show("\n\n    Фигура с минимальной площадью:", _arrayFigures.FindMinArea());
		}

		
	}
}