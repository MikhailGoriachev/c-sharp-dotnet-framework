﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW11
{
	internal partial class App
	{
		private Menu _mainMenu;
		private Menu _subMenu1;
		private Menu _subMenu2;

		private Task1.ArrayVehicles _arrayVehicles;
		private Task2.ArrayFigures _arrayFigures;

		public App() : this(new Task1.ArrayVehicles(), new Task2.ArrayFigures())
		{}

		public App(Task1.ArrayVehicles arrayVehicles, Task2.ArrayFigures arrayFigures)
		{
			_arrayVehicles = arrayVehicles;
			_arrayFigures = arrayFigures;
			InitMenu();
		}

		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem("Задание 1", MainMenuItem1),
					new Menu.MenuItem("Задание 2", MainMenuItem2),
					new Menu.MenuItem("Выход")
				}, new Point(5, 5),
				"Меню приложения");

			// Подменю - первое задание
			_subMenu1 = new Menu(new[]
				{
					new Menu.MenuItem("Создание коллекции транспортных средств", Task1MenuItem1),
					new Menu.MenuItem("Вывод списка транспортных средств", Task1MenuItem2),
					new Menu.MenuItem("Найти самое старое транспортное средство", Task1MenuItem3),
					new Menu.MenuItem("Найти самые быстрые и самое медленное транспортные средства", Task1MenuItem4),
					new Menu.MenuItem("Упорядочить массив по убыванию цены транспортного средства", Task1MenuItem5),
					new Menu.MenuItem("Назад")
				}, new Point(5, 5),
				"Задание 1");

			// Подменю - второе задание
			_subMenu2 = new Menu(new[]
				{
					new Menu.MenuItem("Создание коллекции фигур", Task2MenuItem1),
					new Menu.MenuItem("Вывод списка фигур", Task2MenuItem2),
					new Menu.MenuItem("Упорядочить массив по убыванию площади", Task2MenuItem3),
					new Menu.MenuItem("Упорядочить массив по возрастанию площади", Task2MenuItem4),
					new Menu.MenuItem("Выбрать объекты с минимальной и максимальной площадью", Task2MenuItem5),
					new Menu.MenuItem("Назад")
				}, new Point(5, 5),
				"Задание 2");
			
		}
		
		public void Run() =>_mainMenu.Run();
		private void MainMenuItem1() => _subMenu1.Run(true);
		private void MainMenuItem2() => _subMenu2.Run(true);
		}
}
