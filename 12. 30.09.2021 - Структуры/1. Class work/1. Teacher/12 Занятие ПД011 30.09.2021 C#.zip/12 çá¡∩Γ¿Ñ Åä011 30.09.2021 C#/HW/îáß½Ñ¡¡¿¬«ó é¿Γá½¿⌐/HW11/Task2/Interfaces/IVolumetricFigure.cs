﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW11.Task2.Interfaces
{
	interface IVolumetricFigure
	{
		double CalcVolume();
		double CalcSurfaceArea();
	}
}
