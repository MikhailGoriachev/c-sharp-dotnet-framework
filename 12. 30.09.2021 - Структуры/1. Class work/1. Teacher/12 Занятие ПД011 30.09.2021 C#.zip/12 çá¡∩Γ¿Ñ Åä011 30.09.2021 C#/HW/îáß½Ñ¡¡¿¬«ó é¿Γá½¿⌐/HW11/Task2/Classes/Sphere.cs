﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW11;
using HW11.Task2.Classes;
using HW11.Task2.Interfaces;

namespace HW10.Task2.Classes
{
	// Класс определения сферы (шара)
	class Sphere : Figure, IVolumetricFigure
	{
		public double R
		{
			get => _r;
			private set
			{
				if (value <= 0)
					throw new ArgumentException(
						"Радиус должен иметь положительное значение");
				_r = value;
			}

		}

		public override double Area => CalcSurfaceArea();
		

		public double Volume => CalcVolume();
		public Sphere(double r) => R = r;


		public double CalcVolume() => 4d / 3d * Math.PI * Math.Pow(_r, 3);

		public double CalcSurfaceArea() => 4d * Math.PI * _r * _r;

		public override string ToString() =>
			base.ToString() + $"Шар,       r: {_r,6:f2};" +
			$" S = {Area,8:f2}; V = {Volume,8:f2}";


		public override string ToTableRow(int n) =>
			" ".PadRight(n) +
			MakeTableString("Шар", ("r", _r), ("Area", Area), ("Volume", Volume));

		public static Sphere Generate() => new Sphere(Utilities.GenerateDouble(1d, 20d));
		
	}
}
