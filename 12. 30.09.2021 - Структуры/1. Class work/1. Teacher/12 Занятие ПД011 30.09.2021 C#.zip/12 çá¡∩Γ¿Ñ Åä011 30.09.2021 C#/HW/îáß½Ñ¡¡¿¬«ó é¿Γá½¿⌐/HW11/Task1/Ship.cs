﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW11.Task1
{
	class Ship : Vehicle
	{
		// Порт приписки
		public string SeaPort { get; set; }

		// Кол-во пассажиров
		public int Passengers { get; set; }

		public Ship():this(new Point(14, 30), 35000000, 560, 2000, "Артур", 300)
		{}

		public Ship(Point coords, int price, int speed, int prodYear, string seaPort, int passengers)
			: base(coords, price, speed, prodYear, "Корабль")
		{
			SeaPort = seaPort;
			Passengers = passengers;
		}


		public override string ToString() =>
			base.ToString() + $", порт приписки: {SeaPort}, пассажиров: {Passengers}";

		public override string ToTableRow(int indent) =>
			base.ToTableRow(indent) + $" {Passengers,10} ║ {SeaPort,-7} ║        ║";

		public static Ship Generate(string port)
		{
			var coords = new Point(Utilities.GenerateInt(1, 100), Utilities.GenerateInt(1, 100));
			var price = Utilities.GenerateInt(1000, 99_000_000);
			var speed = Utilities.GenerateInt(350, 917);
			var year = Utilities.GenerateInt(1990, 2021);
			var passengers = Utilities.GenerateInt(50, 500);
			return new Ship(coords, price, speed, year, port, passengers);
		}
	}
}
