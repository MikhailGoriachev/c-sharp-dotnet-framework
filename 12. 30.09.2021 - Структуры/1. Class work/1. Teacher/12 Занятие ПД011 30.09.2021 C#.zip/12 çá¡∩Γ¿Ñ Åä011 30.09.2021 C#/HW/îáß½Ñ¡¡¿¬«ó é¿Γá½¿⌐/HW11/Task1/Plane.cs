﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace HW11.Task1
{
	class Plane : Vehicle
	{
		// Высота полёта в метрах

		public int FlightElevation { get; set; }

		// Кол-во пассажиров

		public int Passengers { get; set; }

		public Plane() : this(new Point(14, 30), 15000000, 560, 2005, 30, 300)
		{}


		public Plane(Point coords, int price, int speed, int prodYear, int flightElevation, int passengers) 
			: base(coords, price, speed, prodYear, "Самолёт")
		{
			FlightElevation = flightElevation;
			Passengers = passengers;
		}

		public override string ToString() =>
			base.ToString() + $", высота полёта: {FlightElevation}, пассажиров: {Passengers}";


		public override string ToTableRow(int indent) =>
			base.ToTableRow(indent) + $" {Passengers,10} ║         ║ {FlightElevation,6} ║";

		public static Plane Generate()
		{
			var coords = new Point(Utilities.GenerateInt(1, 100), Utilities.GenerateInt(1, 100));
			var price =Utilities.GenerateInt(1000, 99_000_000);
			var speed =Utilities.GenerateInt(350, 917);
			var year = Utilities.GenerateInt(1990, 2021);
			var flightElev = Utilities.GenerateInt(2000, 13000);
			var passengers = Utilities.GenerateInt(50, 500);
			return new Plane(coords, price, speed, year, flightElev, passengers);
		}
	}
}
