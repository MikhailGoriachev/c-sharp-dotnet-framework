﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW11.Task2.Interfaces;

namespace HW11.Task2.Classes
{
	// Класс определения конуса
	class Cone : Figure, IVolumetricFigure
	{
		public double R
		{
			get => _r;
			private set
			{
				if (value <= 0)
					throw new ArgumentException(
						"Радиус должен иметь положительное значение");
				_r = value;
			}

		}

		public double H
		{
			get => _h;
			private set
			{
				if (value <= 0)
					throw new ArgumentException(
						"Высота должна иметь положительное значение");

				_h = value;
			}
		}

		public override double Area => CalcSurfaceArea();
		public double Volume => CalcVolume();


		public Cone(double r, double h)
		{
			R = r;
			H = h;
		}

		public double CalcVolume() => (1d / 3d) * Math.PI * _r * _r * _h;
		
		public double CalcSurfaceArea() => _r * Math.PI *(_r + Math.Sqrt(_r * _r + _h * _h));

		public override string ToString() =>
			base.ToString() + $"Конус,         r: {_r,6:f2}; h: {_h,6:f2};" +
			$" S = {Area,8:f2}; V = {Volume,8:f2}";

		public override string ToTableRow(int n) =>
			" ".PadRight(n) +
			MakeTableString("Конус", ("r", _r), ("h", _h), ("Area", Area), ("Volume", Volume));

		public static Cone Generate()
		{
			double r, h;
			r = Utilities.GenerateDouble(1d, 20d);
			h = Utilities.GenerateDouble(1d, 20d);

			return new Cone(r, h);
		}


	}
}
