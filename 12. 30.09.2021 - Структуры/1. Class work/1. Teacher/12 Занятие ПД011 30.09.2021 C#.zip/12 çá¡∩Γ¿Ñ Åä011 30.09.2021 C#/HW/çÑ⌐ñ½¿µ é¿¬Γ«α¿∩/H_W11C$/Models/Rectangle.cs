﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // Класс Прямоугольник, наследует от Фигура, реализует интерфейс ПлоскаяФигура
    class Rectangle : Figure, IFlatFigure
    {

		public double A
		{
			get => _a;
			set
			{
				if (value <= 0)
					throw new ArgumentException("Rectangle: Некорректное значение");
				_a = value;
			}
		}// A

		// сторона прямоугольника
		private double _b;
		public double B
		{
			get => _b;
			set
			{
				if (value <= 0)
					throw new ArgumentException("Rectangle: Некорректное значение");
				_b = value;
			}
		}// B

		public override double Area() => _a * _b;


		public double Perimeter() => _a + _a + _b + _b;


		public override string ToTableRow()=>
			$"│ {"Прямоугольник",-15} │ {Perimeter(),12:f2} │ {Area(),10:f2} │ {" ",11} │";
	}// class Rectangle
}
