﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // Интерфейс ОбъемнаяФигура с методами для вычисления площади поверхности и объема
    interface IVolumetricFigure
    {
        double Area();
 
        double Volume();
    }
}
