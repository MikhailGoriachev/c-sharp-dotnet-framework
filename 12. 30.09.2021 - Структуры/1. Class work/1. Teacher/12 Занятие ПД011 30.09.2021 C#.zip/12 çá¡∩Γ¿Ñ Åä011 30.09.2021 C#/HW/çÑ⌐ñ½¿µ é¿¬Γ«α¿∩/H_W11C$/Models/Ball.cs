﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    //  Класс Шар, наследует от Фигура, реализует интерфейс ОбъемнаяФигура
    class Ball : Figure, IVolumetricFigure
    {
        // радиус шара
        public double R
        {
            get => _a;
            set
            {
                if (value <= 0)
                    throw new ArgumentException("Ball: Некорректное значение");
                _a = value;
            }
        }// R

        public override double Area() => 4d * Math.PI * (_a * _a);


        public double Volume() => (3d / 4d) * (Math.PI * Math.Pow(_a, 3));

        public override string ToTableRow() =>
            $"│ {"Шар",-15} │ {" ",12} │ {Area(),10:f2} │ {Volume(),11:f2} │";
    }// class Ball
}
