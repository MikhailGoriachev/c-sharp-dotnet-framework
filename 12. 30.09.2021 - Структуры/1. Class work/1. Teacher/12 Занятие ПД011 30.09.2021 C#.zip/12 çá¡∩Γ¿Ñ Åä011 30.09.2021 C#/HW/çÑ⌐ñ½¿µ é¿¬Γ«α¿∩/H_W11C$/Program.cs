﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Домашнее задание № 11.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1.Формирование и вывод массива транспортных средств." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Самое старое транспортное средство." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Самые быстрые транспортные средства." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Самые медленные транспортные средства." },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2.Формирование и вывод массива объектов класса Фигура." },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Упорядочить массив по убыванию площади." },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Упорядочить массив по возрастанию площади." },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Выбрать объекты с максимальной площадью фигуры." },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Выбрать объекты с минимальной площадью фигуры." },
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App();

                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Меню приложения : ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // Формирование и вывод массива транспортных средств
                        case ConsoleKey.Q:
                            app.Task1();
                            break;

                        // Самое старое транспортное средство
                        case ConsoleKey.W:
                            app.OldVehicle();
                            break;

                        // Самые быстрые транспортные средства
                        case ConsoleKey.E:
                            app.FastVehicle();
                            break;

                        // Самые медленные транспортные средства
                        case ConsoleKey.R:
                            app.SlowVehicle();
                            break;
                        // ------------------------------------------------------------
                        // пункт меню, относящийся к задаче 2

                        // Вывод массива объектов класса Фигура
                        case ConsoleKey.A:
                            app.Task2();
                            break;

                        // Упорядочить массив по убыванию площади
                        case ConsoleKey.S:
                            app.SortFigeres();
                            break;

                        // Упорядочить массив по возрастанию площади
                        case ConsoleKey.D:
                            app.SortFiguresGrow();
                            break;

                        // Выбрать объекты с максимальной площадью фигуры
                        case ConsoleKey.F:
                            app.FigureMaxArea();
                            break;

                        // Выбрать объекты с минимальной площадью фигуры
                        case ConsoleKey.G:
                            app.FigureMinArea();
                            break;

                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                } // while

            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;
        }// Main
    }// class Program
}
