﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // решение для задачи 1
    internal partial class App
    {
        ArrayVehicle _arr;

        // конструктор по умолчанию
        public App() : this(new ArrayVehicle()) { }

        // конструктор с внедрением зависимостей
        public App(ArrayVehicle arr)
        {
            _arr = arr;
        } // App

        // Вывод списка транспортных средств
        public void Task1()
        {
            Utils.ShowNavBarTask("   Вывод списка транспортных средств");
            _arr.Initialize();

            Console.WriteLine("\n\n\t\t\tМассив транспортных средств:\n");
            Console.WriteLine(Header());
            _arr.Show();
            Console.WriteLine(Footer());
        }// Task1

        // Самое старое транспортное средство
        public void OldVehicle()
        {
            Utils.ShowNavBarTask("   Самое старое транспортное средство");
            _arr.Initialize();

            Console.WriteLine("\n\n\t\t\tСамые старые транспортные средства:\n");
            Console.WriteLine(Header());
            _arr.Show(_arr.FindOldVehicle()); 
            Console.WriteLine(Footer());
        }// OldVehicle

        // Самое быстрое транспортное средство
        public void FastVehicle()
        {
            Utils.ShowNavBarTask("   Самое быстрое транспортное средство");
            _arr.Initialize();

            Console.WriteLine("\n\n\t\t\tСамые быстрые транспортные средства:\n");
            Console.WriteLine(Header());
            _arr.Show(_arr.FindFastVehicle());
            Console.WriteLine(Footer());
        }// FastVehicle

        //  Самое медленное транспортное средство
        public void SlowVehicle()
        {
            Utils.ShowNavBarTask("   Самое медленное транспортное средство");
            _arr.Initialize();

            Console.WriteLine("\n\n\t\t\tСамые медленные транспортные средства:\n");
            Console.WriteLine(Header());
            _arr.Show(_arr.FindSlowVehicle());
            Console.WriteLine(Footer());

        }// SlowVehicle


        // статическое свойство для вывода шапки таблицы
        public static string Header()
        {
            string str =
            $"┌────────────┬────────────────┬──────────┬──────────┬─────────┬────────────┬────────┬──────────────────────┐\n" +
            $"│   Тип      │   Координаты   │ Цена($)  │ Скорость │  Год    │ Количество │ Высота │    Порт              │\n" +
            $"│    ТС      │ широта/долгота │   ТС     │ ТС(км/ч) │ выпуска │ пассажиров │ полёта │        приписки      │\n" +
            $"├────────────┼────────────────┼──────────┼──────────┼─────────┼────────────┼────────┼──────────────────────┤";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"└────────────┴────────────────┴──────────┴──────────┴─────────┴────────────┴────────┴──────────────────────┘";
    }// class App
}
