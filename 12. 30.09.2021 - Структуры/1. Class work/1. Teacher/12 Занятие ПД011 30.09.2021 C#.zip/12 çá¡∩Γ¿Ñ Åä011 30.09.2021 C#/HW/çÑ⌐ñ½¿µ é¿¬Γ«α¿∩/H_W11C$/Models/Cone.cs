﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // Класс Конус, наследует от Фигура, реализует интерфейс ОбъемнаяФигура
    class Cone : Figure, IVolumetricFigure
    {
		// высота конуса
		public double H
		{
			get => _a;
			set
			{
				if (value <= 0)
					throw new ArgumentException("Cone: Некорректное значение");
				_a = value;
			}
		}// H


		// радиус конуса
		private double _r;
		public double R
		{
			get => _r;
			set
			{
				if (value <= 0)
					throw new ArgumentException("Cone: Некорректное значение");
				_r = value;
			}
		}// R

		public override double Area()=>_r* Math.PI *(_r + Math.Sqrt(_r* _r + _a* _a));


        public double Volume() => (1d / 3d) * Math.PI * _a * _r * _r;

		public override string ToTableRow() =>
			$"│ {"Конус",-15} │ {" ",12} │ {Area(),10:f2} │ {Volume(),11:f2} │";
	}// class Cone
}
