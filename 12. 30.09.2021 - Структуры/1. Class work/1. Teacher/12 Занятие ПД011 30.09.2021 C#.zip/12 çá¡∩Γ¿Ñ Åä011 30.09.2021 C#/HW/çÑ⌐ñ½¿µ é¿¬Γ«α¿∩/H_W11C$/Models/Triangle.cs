﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // Класс Треугольник, наследует от Фигура, реализует интерфейс ПлоскаяФигура
    class Triangle : Figure, IFlatFigure
    {
        private double _b;
        private double _c;

        public double A => _a;
        public double B => _b;
        public double C => _c;


        // свойство для задания длин треугольника
        public (double A, double B, double C) Sides
        {
            get => (_a, _b, _c);
            set
            {
                if (!IsTriangle(value.A, value.B, value.C))
                    throw new ArgumentException(
                        "Некорректные параметры для сторон треугольника");

                _a = value.A; _b = value.B; _c = value.C;
            }
        }// Sides

        // проверка возможности создания треугольника
        public static bool IsTriangle(double a, double b, double c) =>
            a + b > c && a + c > b && b + c > a && a > 0 && b > 0 && c > 0;
        public override double Area()
        {
            double p = Perimeter() / 2;  // полупериметр
            return Math.Sqrt(p * (p - _a) * (p - _b) * (p - _c));
        }// Area()

        public double Perimeter() => _a * _b + _c;

        // создание треугольника со случайными сторонами
        public static Triangle CreateTriangle(double lo = 1d, double hi = 10d)
        {
            // генерация сторон треугольника
            double a, b, c;

            do
            {
                a = Utils.GetRandom(lo, hi);
                b = Utils.GetRandom(lo, hi);
                c = Utils.GetRandom(lo, hi);
            } while (!Triangle.IsTriangle(a, b, c));

            return new Triangle { Sides = (a, b, c) };
        }// CreateTriangle

        public override string ToTableRow() =>
           $"│ {"Треугольник",-15} │ {Perimeter(),12:f2} │ {Area(),10:f2} │ {" ",11} │";

    }// class Triangle
}
