﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{

    class ArrayVehicle
    {   
        // коллекция транспортных средств
        private Vehicle[] _vehicles;

        public bool Empty => _vehicles.Length == 0;

        public ArrayVehicle(Vehicle[] vehicles)
        {
            _vehicles = vehicles;
        } // ArrayVehicle
        public ArrayVehicle()
        {
            Initialize();
        } // ArrayVehicle

		// заполнение массива
		public void Initialize()
		{
			_vehicles = new Vehicle[]
			{
				new Car{GeografCoordinX=25d, GeografCoordinY= 45d, Price= 25_000d, Speed= 40d, YearOfIssue = 2000 },
				new Car{GeografCoordinX=84d, GeografCoordinY= 55d, Price= 50_000d, Speed= 90d, YearOfIssue = 2018 },
				new Car{GeografCoordinX=47d, GeografCoordinY= 92d, Price= 37_500d, Speed= 60d, YearOfIssue = 2015 },
				new Car{GeografCoordinX=58d, GeografCoordinY= 86d, Price= 83_700d, Speed= 220d, YearOfIssue = 2020 },
				new Car{GeografCoordinX=25d, GeografCoordinY= 45d, Price= 27_000d, Speed= 100d, YearOfIssue = 2000 },
				new Plane{GeografCoordinX=10d, GeografCoordinY= 79d, Price= 839_600d, Speed= 250d, YearOfIssue = 2019, Hight = 8_000d, Passenger = 150 },
				new Plane{GeografCoordinX=68d, GeografCoordinY= 40d, Price= 574_300d, Speed= 210d, YearOfIssue = 2017, Hight = 12_000d, Passenger = 220 },
				new Ship{GeografCoordinX=38d, GeografCoordinY= 45d, Price= 680_000d, Speed= 80d, YearOfIssue = 2020, PortRegistration = "Намибия 'Walvisbaai'", Passenger = 67 },
				new Ship{GeografCoordinX=25d, GeografCoordinY= 73d, Price= 450_000d, Speed= 45d, YearOfIssue = 2000, PortRegistration = "Сингапур 'Maritime'", Passenger = 90 },
				new Ship{GeografCoordinX=85d, GeografCoordinY= 59d, Price= 999_900d, Speed= 40d, YearOfIssue = 2021, PortRegistration = "Роттердам", Passenger = 55 },
			};
		}

        // Вывести массив транспортных средств
        public void Show()
        {
           // вывод всех элементов массива транспортных средств
            void OutItem(Vehicle p) => Console.WriteLine($"{p.ToTableRow()}");
            Array.ForEach(_vehicles, OutItem);

        } // Show

		public void Show(Vehicle[] vehicles)
		{
			foreach (var elem in vehicles)
				Console.WriteLine(elem.ToTableRow());

		} // Show

		// самое старое транспортное средство
		public Vehicle[] FindOldVehicle()
		{
			Vehicle[] old = new Vehicle[1] { _vehicles[0] };
			int minYear = _vehicles[0].YearOfIssue;

			for (int i = 1; i < _vehicles.Length; i++)
			{
				int year = _vehicles[i].YearOfIssue;
				if (year < minYear)
				{
					old = new Vehicle[1] { _vehicles[i] };
					minYear = year;
				}
				else if (year == minYear)
				{
					Array.Resize(ref old, old.Length + 1);
					old[old.Length - 1] = _vehicles[i];
				}// if
			}// for i

			return old;
		}// FindOldVehicle

		// поиск скорости самого быстрого транспортного средства
		public Vehicle[] FindFastVehicle()
		{
			Vehicle[] find = new Vehicle[1] { _vehicles[0] };
			double fast = _vehicles[0].Speed;
			for (int i = 1; i < _vehicles.Length; i++)
			{
				double speed = _vehicles[i].Speed;
				if (speed > fast)
				{
					find = new Vehicle[1] { _vehicles[i] };
					fast = speed;
				}
				else if (_vehicles[i].Speed == fast)
				{
					Array.Resize(ref find, find.Length + 1);
					find[find.Length - 1] = _vehicles[i];
				}// if
			}// for i

			return find;
		} // FindFastVehicle

		// поиск скорости самого медленного транспортного средства
		public Vehicle[] FindSlowVehicle()
		{
			Vehicle[] find = new Vehicle[1] { _vehicles[0] };
			double slow = _vehicles[0].Speed;
			for (int i = 1; i < _vehicles.Length; i++)
			{
				if (_vehicles[i].Speed < slow)
				{
					find = new Vehicle[1] { _vehicles[i] };
					slow = _vehicles[i].Speed;
				}
				else if (_vehicles[i].Speed == slow)
				{
					Array.Resize(ref find, find.Length + 1);
					find[find.Length - 1] = _vehicles[i];
				}// if
			}// for i

			return find;
		} // FindSlowVehicle

	}// class ArrayVehicle
}
