﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // абстрактный класс Vehicle (транспортное средство)
    abstract internal class Vehicle
    {
        // географические координаты(широта от 0 до 90)
        protected double _geografCoordinX; 
        public double GeografCoordinX
        {
            get => _geografCoordinX;
            set
            {
                if (value > 90d || value < 0)
                    throw new ArithmeticException("Недопустимые географические координаты ТС");
                _geografCoordinX = value;
            }
        }// GeografCoordinX

        // географические координаты (долгота от 0 до 180)
        protected double _geografCoordinY; 
        public double GeografCoordinY
        {
            get => _geografCoordinY;
            set
            {
                if (value < 0 || value > 180d)
                    throw new ArithmeticException("Недопустимые географические координаты ТС");
                _geografCoordinY = value;
            }
        }// GeografCoordinY

        // цена ($)
        protected double _price; 
        public double Price
        {
            get => _price;
            set
            {
                if (value < 0)
                    throw new ArithmeticException("Недопустимая стоимость ТС");

                _price = value;
            }
        }// Price

        // скорость (км/ч)
        protected double _speed; 
        public double Speed
        {
            get => _speed;
            set
            {
                if (value < 0)
                    throw new ArithmeticException("Недопустимая скорость ТС");

                _speed = value;
            }
        }// Speed

        // год выпуска 
        protected int _yearOfIssue; 
        public int YearOfIssue
        {
            get => _yearOfIssue;
            set
            {
                if (value <= 0 || value > DateTime.Now.Year)
                    throw new ArithmeticException("Недопустимый год выпуска ТС");

                _yearOfIssue = value;
            }
        }// YearOfIssue
        /*
        public Vehicle(): this(0d, 0d, 1d, 10d, 1) { }
        //public Vehicle(): this(1d , 10d, 1) { }

        public Vehicle(double x, double y, double price, double speed, int year)
        {
            GeografCoordinX = x;
            GeografCoordinY = y;
            Price           = price;
            Speed           = speed;
            YearOfIssue     = year;
        }

        public Vehicle(double price, double speed, int year)
        {
            Price = price;
            Speed = speed;
            YearOfIssue = year;
        }
        */
        public override string ToString() =>
            $" Координаты ТС: {GeografCoordinX :f2}, {GeografCoordinX: f2};\n Скорость TC: {Speed:f1};\n " +
            $" Год выпуска ТС: {YearOfIssue}; Цена TC: {Price:f1};\n ";

        // представление объекта в виде строки таблицы
        public abstract string ToTableRow();
    }// class Vehicle
}
