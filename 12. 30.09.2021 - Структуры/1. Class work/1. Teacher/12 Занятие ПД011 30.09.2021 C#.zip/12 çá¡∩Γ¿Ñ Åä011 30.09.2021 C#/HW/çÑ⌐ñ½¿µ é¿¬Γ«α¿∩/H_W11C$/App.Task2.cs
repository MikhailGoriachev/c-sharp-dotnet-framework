﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // решение для задачи 2
    internal partial class App
    {
        ArrayFigure _arr1 = new ArrayFigure();


        // вывод массива объектов класса Фигура
        public void Task2()
        {
            Utils.ShowNavBarTask("   Вывод массива объектов класса Фигура");
            _arr1.Initialize();

            Console.WriteLine("\n\n\t\tМассив объектов класса Фигура:\n");
            Console.WriteLine(HeaderFigure());
            _arr1.Show();
            Console.WriteLine(FooterFigure());
        }// Task1

        // упорядочить массив по убыванию площади
        public void SortFigeres()
        {
            Utils.ShowNavBarTask("   Упорядочить массив по убыванию площади");
            _arr1.Initialize();

            Console.WriteLine("\n\n\tМассив объектов упорядочен по убыванию площади:\n");
            Console.WriteLine(HeaderFigure());
            _arr1.SortByArea();
            _arr1.Show();
            Console.WriteLine(FooterFigure());
        }// SortFigeres

        // упорядочить массив по возрастанию площади
        public void SortFiguresGrow()
        {
            Utils.ShowNavBarTask("   Упорядочить массив по возрастанию площади");
            _arr1.Initialize();

            Console.WriteLine("\n\n\tМассив объектов упорядочен по возрастанию площади:\n");
            Console.WriteLine(HeaderFigure());
            _arr1.SortByAreGrow();
            _arr1.Show();
            Console.WriteLine(FooterFigure());
        }// SortFiguresGrow

        public void FigureMaxArea()
        {
            Utils.ShowNavBarTask("   Выбрать объекты с максимальной площадью фигуры");
            _arr1.Initialize();

            Console.WriteLine("\n\n   Фигура/фигуры с максимальной площадью:\n");
            Console.WriteLine(HeaderFigure());
            _arr1.Show(_arr1.FindMaxAreaFigure());
            Console.WriteLine(FooterFigure());
        }// FigureMaxArea

        public void FigureMinArea()
        {
            Utils.ShowNavBarTask("   Выбрать объекты с минимальной площадью фигуры");
            _arr1.Initialize();

            Console.WriteLine("\n\n   Фигура/фигуры с минимальной площадью:\n");
            Console.WriteLine(HeaderFigure());
            _arr1.Show(_arr1.FindMinAreaFigure());
            Console.WriteLine(FooterFigure());
        }// FigureMinArea

        // статическое свойство для вывода шапки таблицы
        public static string HeaderFigure()
        {
            string str =
            $"┌─────────────────┬──────────────┬────────────┬─────────────┐\n" +
            $"│  Название       │   Периметр   │  Площадь   │    Объём    │\n" +
            $"│       фигуры    │  фигуры(см)  │ фигуры(см) │  фигуры(см) │\n" +
            $"├─────────────────┼──────────────┼────────────┼─────────────┤";
            return str;
        } // HeaderFigure

        // статический метод для вывода подвала таблицы
        public static string FooterFigure() =>
            $"└─────────────────┴──────────────┴────────────┴─────────────┘";

    }// class App
}
