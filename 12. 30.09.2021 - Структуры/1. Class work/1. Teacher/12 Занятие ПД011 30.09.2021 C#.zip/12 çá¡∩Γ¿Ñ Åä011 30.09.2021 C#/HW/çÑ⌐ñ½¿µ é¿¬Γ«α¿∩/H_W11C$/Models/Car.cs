﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // клас автомобиль
    class Car : Vehicle
    {
        public override string ToTableRow() =>
            $"│ {"Автомобиль",-10} │ {$"{_geografCoordinX:f2}; {_geografCoordinY:f2}",14} │ {_price,8:f1} │ {_speed,8:f1} │ {_yearOfIssue,7} │            │        │                      │ ";
    }// class Car
}
