﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // Массив фигур
    class ArrayFigure
    {
        // коллекция фигур
        private Figure[] _figures;

        public bool Empty => _figures.Length == 0;

        public ArrayFigure(Figure[] figures)
        {
            _figures = figures;
        } // ArrayFigure
        public ArrayFigure()
        {
            Initialize();
        } // ArrayFigure


        public void Initialize()
        {
            _figures = new Figure[] {
                Triangle.CreateTriangle(),
                Triangle.CreateTriangle(),
                new Rectangle{A = Utils.GetRandom(1d, 10d), B = Utils.GetRandom(1d, 10d)},
                new Rectangle{A = Utils.GetRandom(1d, 10d), B = Utils.GetRandom(1d, 10d)},
                new Cylinder {H = Utils.GetRandom(1d, 10d), R = Utils.GetRandom(1d, 10d)},
                new Cylinder {H = Utils.GetRandom(1d, 10d), R = Utils.GetRandom(1d, 10d)},
                new Cone     {H = Utils.GetRandom(1d, 10d), R = Utils.GetRandom(1d, 10d)},
                new Cone     {H = Utils.GetRandom(1d, 10d), R = Utils.GetRandom(1d, 10d)},
                new Ball     {R = Utils.GetRandom(1d, 10d)},
                new Ball     {R = Utils.GetRandom(1d, 10d)}
            };
        } // Initialize



        // сортировка массива фигур по убыванию площади
        public void SortByArea() => Array.Sort(_figures, Figure.AreaCompare);

        // сортировка массива фигур по возрастанию площади
        public void SortByAreGrow() => Array.Sort(_figures, Figure.AreaCompare1);

        // фигуры с максимальнаой площадью
        public Figure[] FindMaxAreaFigure()
        {
            Figure[] find = new Figure[1] { _figures[0] };
            double maxArea = _figures[0].Area();

            for (int i = 1; i < _figures.Length; i++)
            {
                double area = _figures[i].Area();
                if (area > maxArea)
                {
                    find = new Figure[1] { _figures[i] };
                    maxArea = area;
                }
                else if (Math.Abs(area - maxArea) < Math.E)
                {
                    Array.Resize(ref find, find.Length + 1);
                    find[find.Length - 1] = _figures[i];
                }// if
            }// for i

            return find;
        }// FindMaxAreaFigure

        // фигуры с минимальной площадью
        public Figure[] FindMinAreaFigure()
        {
            Figure[] find = new Figure[1] { _figures[0] };
            double minArea = _figures[0].Area();

            for (int i = 1; i < _figures.Length; i++)
            {
                double area = _figures[i].Area();
                if (area < minArea)
                {
                    find = new Figure[1] { _figures[i] };
                    minArea = area;
                }
                else if (Math.Abs(area - minArea) < Math.E)
                {
                    Array.Resize(ref find, find.Length + 1);
                    find[find.Length - 1] = _figures[i];
                }// if
            }// for i

            return find;
        }// FindMinAreaFigure

        // вывести массив фигур
        public void Show()
        {
            // вывод всех элементов массива транспортных средств
            void OutItem(Figure p) => Console.WriteLine($"{p.ToTableRow()}");
            Array.ForEach(_figures, OutItem);

        } // Show

        public void Show(Figure[] figeres)
        {
            foreach (var elem in figeres)
                Console.WriteLine(elem.ToTableRow());

        } // Show
    }// class ArrayFigure
}
