﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // Класс Фигура – базовый класс иерархии
    abstract class Figure
    {
        protected double _a;

        public abstract double Area();

        public abstract string ToTableRow();

        // Компаратор для сортировки по убыванию площади
        public static int AreaCompare(Figure f1, Figure f2) =>
            f2.Area().CompareTo(f1.Area());

        // Компаратор для сортировки по возрастанию площади
        public static int AreaCompare1(Figure f1, Figure f2) =>
            f1.Area().CompareTo(f2.Area());
    }// class Figure
}
