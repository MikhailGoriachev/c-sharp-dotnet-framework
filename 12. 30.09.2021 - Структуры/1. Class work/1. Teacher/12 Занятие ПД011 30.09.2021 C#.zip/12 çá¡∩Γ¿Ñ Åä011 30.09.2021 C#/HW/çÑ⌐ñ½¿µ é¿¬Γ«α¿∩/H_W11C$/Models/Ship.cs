﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // класс корабль
    class Ship : Vehicle
    {
        // порт приписки корабля
        private string _portRegistration;
        public string PortRegistration 
        { 
            get => _portRegistration;
            set { if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Ship: Некорректное значение порта приписки!");
                _portRegistration = value; }
        }// PortRegistration 

        // количество пассажиров
        private int _passenger;
        public int Passenger
        { 
            get => _passenger;
            set => _passenger = value;
        }// Passenger

        public override string ToTableRow() =>
            $"│ {"Корабль",-10} │ {$"{_geografCoordinX:f2}; {_geografCoordinY:f2}",14} │ {_price,8:f1} │ {_speed,8:f1} │ {_yearOfIssue,7} │ {_passenger,11}│        │ {_portRegistration,-20} │";
    }// class Ship
}
