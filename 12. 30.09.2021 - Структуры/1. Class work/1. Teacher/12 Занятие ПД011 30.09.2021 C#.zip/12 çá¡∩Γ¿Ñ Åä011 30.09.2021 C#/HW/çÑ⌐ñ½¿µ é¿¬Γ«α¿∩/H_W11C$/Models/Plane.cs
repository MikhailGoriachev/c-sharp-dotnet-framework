﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W11C_.Models
{
    // класс самолёт
    class Plane : Vehicle
    {
        // высота полёта самолёта
        private double _hight;
        public double Hight
        {
            get => _hight;
            set=> _hight = value;
        }

        // количество пассажиров
        private int _passenger;
        public int Passenger
        { 
            get =>_passenger;
            set => _passenger = value;
        }

        public Plane() { }
        public Plane(double hight, int passenger) : base()
        {
            Hight = hight;
            Passenger = passenger;
        }// Plane

        public override string ToString()
        {
            // base - ссылка на базовый класс, ToString() надо явно указывать
            // т.к. base - это ключевое слово
            return $"{base.ToString()}; \n Высота самолёта: {Hight:f1}; Количество пассажиров: {Passenger};";
        } // ToString

        // представление объекта в виде строки таблицы
        public override string ToTableRow() =>
            $"│ {"Самолет",-10} │ {$"{_geografCoordinX:f2}; {_geografCoordinY:f2}",14} │ {_price,8:f1} │ {_speed,8:f1} │ {_yearOfIssue,7} │ {_passenger,11}│ {_hight,6} │                      │ ";
    }// class Plane
}
