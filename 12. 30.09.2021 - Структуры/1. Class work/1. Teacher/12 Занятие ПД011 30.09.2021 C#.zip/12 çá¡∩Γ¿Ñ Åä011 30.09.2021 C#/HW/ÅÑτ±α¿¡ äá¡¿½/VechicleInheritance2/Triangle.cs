﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInheritance2
{
    public class Triangle : Figure,  IFlatfigure
    {
        public override string Name => "Треугольник";
        private (double _a, double _b, double _c) _sides;

        public double SideA => _sides._a;
        public double SideB => _sides._b;
        public double SideC => _sides._c;

        public (double a, double b, double c) Sides
        {
            get => _sides;
            set
            {
                var (a, b, c) = value;
                if (a < 0 || b < 0 || c < 0)
                    throw new Exception("Значение не может быть меньше нуля");
                if (!(a + b > c && b + c > a && a + c > b))
                    throw new Exception("Треугольник не может быть создан");

                _sides = value;

            }// set

        }// Sides
        public override double Area => AreA();
        public double Perimetr() => _sides._a + _sides._b + _sides._c;
        public double AreA()
        {
            double hP = Perimetr() / 2; // полупериметр

            return Math.Sqrt(hP * ((hP - _sides._a) * (hP - _sides._b) * (hP - _sides._c)));
        }

        public override string ToTableRow() => $"| {Name, -18} |{Sides, 11} | {Perimetr(), 18} | {AreA(), 9:n2} |"; 

    }
}
