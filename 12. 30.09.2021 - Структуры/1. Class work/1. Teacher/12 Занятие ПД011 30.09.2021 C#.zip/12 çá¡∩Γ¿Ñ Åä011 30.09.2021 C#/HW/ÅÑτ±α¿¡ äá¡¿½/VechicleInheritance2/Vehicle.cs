﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 абстрактный класс Vehicle (географические координаты, цена, скорость, год выпуска) 
 */

namespace VehicleInheritance2
{
    public abstract class Vehicle
    {
        private int _coordX;

        public int CoordX
        {
            get =>  _coordX;

            set
            {
                if (value < 0) throw new Exception("Недопустимы значения для координат");
                _coordX = value;
            }
        }

        private int _coordY;

        public int CoordY
        {
            get=> _coordY;
            set
            {
                if (value < 0) throw new Exception("Недопустимы значения для координат");
                _coordY = value;
            }
        }

        private int _price;

        public int Price
        {
            get=> _price;
            set
            {
                if (value < 0) throw new Exception("Недопустимы значения для цены");
                _price = value;
            }
        }

        private int _speed;

        public int Speed
        {
            get => _speed;
            set { if (value < 0) throw new Exception("Недопустимы значения для скорости");
                _speed = value; } 
        }

        private int _productionYear;

        public int ProductionYear
        {
            get => _productionYear;
            set {
                if (value < 0) throw new Exception("Недопустимы значения для года выпуска");
                _productionYear = value; }
        }

        public string ToTableRow() => $"| {CoordX,10} | {CoordY,7} | {Price, 15:n2}  | {Speed, 9} | {ProductionYear, 15} |";

        public static int CompareByPrice(Vehicle v1, Vehicle v2) => v2.Price.CompareTo(v1.Price);




    }
}
