﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInheritance2
{
    public class Cylinder : Figure, IVolumeFigure
    {
        public override string Name => "Цилиндр";
        public double Height
        {
            get => _a;
            set
            {
                if (value < 0) throw new Exception("Недопустимое значение для высоты");
                _a = value;
            }
        }

        private double _radius;

        public double Radius
        {
            get => _radius;
            set
            {
                if (value < 0) throw new Exception("Недопустимое значение для радиуса");
                _radius = value;
            }
        }

        public override double Area => SurfaceArea();
        public double SurfaceArea() => 2 * Math.PI * Radius * (Height + Radius);

        public double Volume() => Math.PI * Math.Pow(Radius, 2) * Height;

        public override string ToTableRow() => $"| {Name, -18} |{Height, 4}  {Radius, 5} | {SurfaceArea(), 18:n2} | {Volume(), 9:n2} |";

    }
}
