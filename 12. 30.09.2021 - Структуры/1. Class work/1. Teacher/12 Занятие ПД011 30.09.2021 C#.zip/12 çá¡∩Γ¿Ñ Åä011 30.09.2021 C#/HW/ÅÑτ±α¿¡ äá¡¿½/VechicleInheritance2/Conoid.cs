﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInheritance2
{
    public class Conoid:Figure, IVolumeFigure
    {
        public override string Name => "Конус";
        private double _radius;

        public double Radius
        {
            get=> _radius; 
            set{
                if (value < 0) throw new Exception("Недопустимое значение для радиуса");
                _radius = value; }
        }

        public double Height
        {
            get => _a;
            set
            {
                if (value < 0) throw new Exception("Недопустимое значение для высоты");
                _a = value; 
            }
        }

        public override double Area => SurfaceArea();
        public double Generatrix() => Math.Sqrt(Math.Pow(Height, 2) + Math.Pow(Radius, 2));



        public double SurfaceArea() => Math.PI * Radius * (Radius + Generatrix());




        public double Volume() => (1d / 3d * Math.PI) + Math.Pow(Radius, 2) * Height;

        public override string ToTableRow() => $"| {Name, -18} |{Height, 4}, {Radius, 5} | {Volume(), 18:n2} | {SurfaceArea(), 9:n2} |";

    }
}
