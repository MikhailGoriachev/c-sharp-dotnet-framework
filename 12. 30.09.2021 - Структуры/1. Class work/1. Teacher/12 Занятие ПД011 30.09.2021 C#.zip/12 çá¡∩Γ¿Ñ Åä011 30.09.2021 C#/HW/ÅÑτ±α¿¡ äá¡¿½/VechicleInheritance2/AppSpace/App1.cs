﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VehicleInheritance2.Modules;

namespace VehicleInheritance2.AppSpace
{
    internal partial class App
    {
        Task1 task1 = new Task1();
        public void Task1Point1()
        {
            Utils.ShowNavBarTask("Вывести масив Vechicles в консоль");
            task1.ShowTable();

            Console.WriteLine("\n");
            Console.WriteLine($"Самое страрое транспортное стредство {task1.EarlyYear()} года");
            Console.WriteLine($"Самое быстрое транспортное средство {task1.MaxSpeed()} ");
            Console.WriteLine($"Самое медленное транспортное средство {task1.MinSpeed()}"); 

            Console.ReadKey(); 
        }

        public void Tas1Point2()
        {
            Utils.ShowNavBarTask("Отсортировать массив по убыванию транспортных средств");

            task1.SortByPrice();

            Console.WriteLine("\n");
            Console.WriteLine("Массив отсортирован по убыванию цены транспортного средства");
            task1.ShowTable();

            Console.ReadKey();


        }
    }
}
