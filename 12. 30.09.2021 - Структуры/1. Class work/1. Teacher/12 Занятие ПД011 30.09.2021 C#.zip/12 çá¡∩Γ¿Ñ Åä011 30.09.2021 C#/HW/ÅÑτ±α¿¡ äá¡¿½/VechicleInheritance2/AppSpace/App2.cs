﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VehicleInheritance2.Modules;

namespace VehicleInheritance2.AppSpace
{
    internal partial class App
    {
        Task2 task2 = new Task2();
        public void Task2Point2()
        {
            Utils.ShowNavBarTask("Фигуры ");

            task2.ShowTable();
            Console.ReadKey();
            
            Console.ReadKey();
        }

        public void Task2Point3()
        {
            Utils.ShowNavBarTask(" Упорядочить фигуры по убыванию площадей");

            Console.WriteLine("\n\n");
            Console.WriteLine("Массив упорядочен по убыванию площадей");
            task2.SortbyArea();
            task2.ShowTable();

            Console.WriteLine($" Фигура с минимальной площадью {task2.MinArea()}"); 
            Console.WriteLine($" Фигура с максимальной площадью {task2.MaxArea()}"); 

            Console.ReadKey(); 
        }

        public void Task2Point4()
        {
            Utils.ShowNavBarTask(" Упорядочить фигуры по возрастанию площадей");
            Console.WriteLine("\n\n");
            Console.WriteLine("Массив упорядочен по возрастанию площадей");
            task2.SortbyAreaIncrease();
            task2.ShowTable();

            Console.ReadKey();

        }
    }

}
