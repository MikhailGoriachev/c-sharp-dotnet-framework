﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInheritance2
{
    class Sphere :Figure, IVolumeFigure
    {
        public override string Name => "Шар";

        public double Radius
        {
            get => _a;
            set
            {
                if (value < 0) throw new Exception("Недопустимое значение для высоты");
                _a = value;
            }
        }

        public double SurfaceArea() => 4 * Math.PI * Math.Pow(Radius, 2);

        public override double Area => SurfaceArea();

        public double Volume() => 4 / 3 * Math.PI * Math.Pow(Radius, 3);

        public override string ToTableRow() => $"| {Name,-18} |  {Radius,9} | {SurfaceArea(),18:n2} | {Volume(),9:n2} |";




    }
}
