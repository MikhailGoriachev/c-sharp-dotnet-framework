﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntro.Models.Task1
{
    // автомобиль, не добавляет никаких свойств базовому классу
    internal class Car : Vehicle
    {
        // вывод строки таблицы, два последних столбца оставляем пустыми
        // для совместимости с другими классами этой иерархии
        public override string ToTableRow(int row) =>
            $"│ {row,3} │ {_category, -10} │ {_coordinates.Latitude, 8:f3};{_coordinates.Longitude, 8:f3} " +
            $"│ {_price, 14:n2} " +
            $"│ {_velocity, 9:n2} │ {_year, 4} │         │ {" ", 17} │";
        
    } // class Car
}
