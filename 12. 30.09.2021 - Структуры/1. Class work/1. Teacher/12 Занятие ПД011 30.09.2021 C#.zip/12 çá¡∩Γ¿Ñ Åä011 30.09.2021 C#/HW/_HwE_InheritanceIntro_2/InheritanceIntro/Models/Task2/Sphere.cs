﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

namespace InheritanceIntro.Models.Task2
{
    // Шар, наследует от Фигура, реализует интерфейс ОбъемнаяФигура
    internal class Sphere: Figure, IVolumetric
    {
        // Радиус шара
        public double R {
            get => SideA;
            set => SideA = value > 0
                ? value
                : throw new InvalidDataException($"Недопустимый радиус: {value}");
        } // R


        // реализация интерфейса IFigure3D - вычисление площади поверхности и объема сферы
        public double Area() => 4d * Math.PI * R * R;
        public double Volume() => 4d * Math.PI * R * R * R / 3d;

        // реализация интерфейса IFigure3D - вывод сферы в строку таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,5} │ {TypeFigure,-14} │ {R,9:f3} │ {" ", 9} │ {" ",9} │ {" ",9} │ {Area(),9:f3} │ {Volume(),9:f3} │";


        // Вывод сферы в строку
        public override string ToString() {
            double a = Area();
            double v = Volume();

            return $"{TypeFigure,-14} Радиус: {R:f3}. Объем: {v:f3}. Площадь: {a:f3}";
        } // ToString
    }
}
