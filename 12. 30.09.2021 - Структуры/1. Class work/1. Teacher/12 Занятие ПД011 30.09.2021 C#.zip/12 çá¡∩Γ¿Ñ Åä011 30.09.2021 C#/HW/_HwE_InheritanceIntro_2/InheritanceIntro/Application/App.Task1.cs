﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using InheritanceIntro.Models.Task1;

namespace InheritanceIntro.Application
{
    // Решение для задачи 1 - обработка массива транспортных средств
    internal partial class App {
        // Формирование массива транспортных средств для обработки
        public void FillVehicles() {
            Utils.ShowNavBarTask("   Заполнение массива транспортных средств данными для обработки");

            // Сформировать массив данных, вывести его в консоль
            _transportCompany.Initialize();
            Console.WriteLine(_transportCompany.Show("Сформирован массив транспортных средств для обработки", 12));
        } // FillVehicles

        // Вывод массива транспортных средств
        public void ShowVehicles() {
            Utils.ShowNavBarTask("   Вывод массива транспортных средств");
            Console.WriteLine(_transportCompany.Show("Массив транспортных средств для обработки", 12));
        } // ShowVehicles

        // Самые старые транспортные средства
        public void SelectOldestVehicles() {
            Utils.ShowNavBarTask("   Самые старые транспортные средства");

            // выборка самых старых транспортных средств
            Vehicle[] oldests = _transportCompany.GetOldests();

            // вывод выбранных трансопртных средств
            Console.WriteLine(TransportCompany.Show("Самые старые транспортные средства", 12, oldests));
        } // SelectOldestVehicles

        // Самые быстрые и самые медленные транспортные средства
        public void SelectFastestSlowestVehicles() {
            Utils.ShowNavBarTask("   Самые быстрые и самые медленные транспортные средства");
            
            // выборка самых медленных и самых быстрых транспортных средств
            Vehicle[] slowests = _transportCompany.GetSlowests();
            Vehicle[] fastests = _transportCompany.GetFastests();

            // вывод выбранных трансопртных средств
            Console.WriteLine(TransportCompany.Show("Самые медленные транспортных средства", 12, slowests));
            Console.WriteLine(TransportCompany.Show("Самые быстрые транспортные средства", 12, fastests));
        } // SelectFastestSlowestVehicles

        // Упорядочить массив по убыванию цены транспортного средства
        public void OrderByPriceDescend() {
            Utils.ShowNavBarTask("   Упорядочить массив по убыванию цены транспортного средства");

            _transportCompany.OrderByPriceDescend();
            Console.WriteLine(_transportCompany.Show("Массив транспортных средств упрядочен по убыванию цены:", 12));
        } // OrderByPriceDescend
    } // class App
}
