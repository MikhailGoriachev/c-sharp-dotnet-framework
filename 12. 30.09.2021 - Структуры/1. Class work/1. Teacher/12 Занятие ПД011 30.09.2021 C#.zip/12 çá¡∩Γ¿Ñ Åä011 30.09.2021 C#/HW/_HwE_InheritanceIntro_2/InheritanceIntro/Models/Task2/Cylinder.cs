﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntro.Models.Task2
{
    // Цилиндр, наследует от Фигура, реализует интерфейс ОбъемнаяФигура
    internal class Cylinder: Figure, IVolumetric
    {
        // Радиус цилиндра
        public double R {
            get => SideA;
            set => SideA = value > 0
                ? value
                : throw new InvalidDataException($"Недопустимый радиус: {value}");
        } // R

        // Высота цилиндра
        private double _height;
        public double H {
            get => _height;
            set => _height = value > 0
                ? value
                : throw new InvalidDataException($"Недопустимая высота: {value}");
        } // H

        // реализация интерфейса IFigure3D - вычисление площади поверхности и объема цилиндра
        public double Area() => 2d * Math.PI * (R + H);
        public double Volume() => Math.PI * R * R * H;

        // реализация интерфейса IFigure3D - вывод цилиндра в строку таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,5} │ {TypeFigure,-14} │ {R,9:f3} │ {_height,9:f3} │ {" ",9} │ {" ",9} │ {Area(),9:f3} │ {Volume(),9:f3} │";


        // Вывод цилиндра в строку
        public override string ToString() {
            double a = Area();
            double v = Volume();
            
            return $"{TypeFigure, -14} Радиус: {R:f3}. Высота {H:f3}. Объем: {v:f3}. Площадь: {a:f3}";
        } // ToString
    } // class Cylinder
}
