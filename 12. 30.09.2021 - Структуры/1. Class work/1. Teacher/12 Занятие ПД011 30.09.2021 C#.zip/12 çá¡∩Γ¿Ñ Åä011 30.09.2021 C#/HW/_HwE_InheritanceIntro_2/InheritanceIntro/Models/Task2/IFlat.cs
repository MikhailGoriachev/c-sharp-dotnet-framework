﻿namespace InheritanceIntro.Models.Task2
{
    // Интерфейс ПлоскаяФигура с методами для
    // вычисления площади и периметра
    internal interface IFlat: IFigure
    {
        double Perimeter();
    } // interface IFlat
}
