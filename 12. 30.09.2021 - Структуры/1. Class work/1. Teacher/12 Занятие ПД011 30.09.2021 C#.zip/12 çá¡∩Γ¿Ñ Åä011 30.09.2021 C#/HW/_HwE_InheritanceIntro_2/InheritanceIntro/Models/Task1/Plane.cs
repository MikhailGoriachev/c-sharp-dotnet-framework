﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntro.Models.Task1
{
    // Класс, описывающий самолет в иерархии транспортных средств
    // для самолета должна быть определена высота и количество пассажиров
    internal class Plane: Vehicle
    {
        // высота полета
        private int _altitude;
        public int Altitude {
            get => _altitude;
            set {
                if (value < 0)
                    throw new ArgumentException("Недопустимое значение высоты полета самолетпа");
                _altitude = value;
            }
        } // Altitude
        
        // количество пассажиров
        private int _pax;
        public int Pax {
            get => _pax;
            set {
                if (value < 0)
                    throw new ArgumentException("Недопустимое количества пассажиров");
                _pax = value;
            }
        } // Pax
        
        // вывод строки таблицы
        public override string ToTableRow(int row) =>
            $"│ {row,3} │ {_category,-10} │ {_coordinates.Latitude, 8:f3};{_coordinates.Longitude, 8:f3} " +
            $"│ {_price, 14:n2} " +
            $"│ {_velocity, 9:n2} │ {_year, 4} │ {_pax, 5}   │ {_altitude, 12:n0}      │";
    } // class Plane
}
