﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntro.Models.Task2
{
    internal class Figure
    {
        // одна из сторон
        protected double SideA;

        // название, тип фигуры
        public string TypeFigure { get; set; }

        // Шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return 
            $"{spaces}┌───────┬────────────────┬───────────┬───────────┬───────────┬───────────┬───────────┬───────────┐\n" +
            $"{spaces}│ N п/п │ Тип фигуры     │ Сторона A │ Сторона B │ Сторона C │  Периметр │   Площадь │     Объем │\n" +
            $"{spaces}├───────┼────────────────┼───────────┼───────────┼───────────┼───────────┼───────────┼───────────┤\n";
        } // Header

        // Подвал таблицы, статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└───────┴────────────────┴───────────┴───────────┴───────────┴───────────┴───────────┴───────────┘\n";
    }
}
