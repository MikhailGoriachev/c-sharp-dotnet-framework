﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InheritanceIntro.Models.Task2;

namespace InheritanceIntro.Application
{
    // Решение задачи 2 - обработка массива фигур  
    internal partial class App
    {
        // Формирование массива геометрическоих фигур для обработки
        public void FillFigures() {
            Utils.ShowNavBarTask("   Формирование массива геометрическоих фигур для обработки");
            _arrayFigures.Initialize();
            _arrayFigures.Show("Массив фигур для обработки по заданию:", 12);
        } // FillFigures
        
        // Вывод массива геометрических фигур
        public void ShowFigures() {
            Utils.ShowNavBarTask("   Формирование массива геометрическоих фигур для обработки");
            
            _arrayFigures.Show("Массив фигур сформирован для обработки:", 12);
        } // ShowFigures
        
        // Упорядочить массив геометрических фигур по убыванию площади
        public void OrderByAreaDescend() {
            Utils.ShowNavBarTask("   Упорядочить массив геометрических фигур по убыванию площади");
            
            _arrayFigures.OrderAreaDesc();
            _arrayFigures.Show("Массив фигур, упорядоченный по убыванию площади:", 12);
        } // OrderByAreaDescend


        // Упорядочить массив геометрических фигур по возрастанию площади
        public void OrderByArea() {
            Utils.ShowNavBarTask("   Упорядочить массив геометрических фигур по возрастанию площади");

            _arrayFigures.OrderArea();
            _arrayFigures.Show("Массив фигур, упорядоченный по возрастанию площади:", 12);
        } // OrderByAreaDescend


        // Выборка геометрических фигур с минимальной и максимальной площадями
        public void SelectMinMaxAreas() {
            Utils.ShowNavBarTask("   Выборка геометрических фигур с минимальной и максимальной площадями");
            // выборка фигур с минимальной и максимальной площадями
            IFigure[] mins  = _arrayFigures.GetMinArea();
            IFigure[] maxes = _arrayFigures.GetMaxArea();

            // вывод выбранных трансопртных средств
            FigureArray.Show("Фигуры с минимальной площадью", 12, mins);
            FigureArray.Show("Фигуры с максимальной площадью", 12, maxes);
        } // SelectMinMaxAreas
    } // class App
}
