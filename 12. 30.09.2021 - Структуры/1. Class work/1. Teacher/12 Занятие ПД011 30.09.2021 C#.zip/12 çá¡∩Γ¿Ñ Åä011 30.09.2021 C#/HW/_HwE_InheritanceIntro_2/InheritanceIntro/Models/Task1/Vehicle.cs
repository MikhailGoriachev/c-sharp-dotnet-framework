﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntro.Models.Task1
{
    // базовый класс для иерархии классов транспортных средств
    internal abstract class Vehicle
    {
        // географические координаты
        protected (double Latitude, double Longitude) _coordinates;

        public (double Latitude, double Longitude) Coordinates {
            get => _coordinates; 
            set {
                if (-180 > value.Latitude || value.Latitude > 180)
                    throw new ArgumentException("Недопустимое значение широты");

                if (-180 > value.Longitude || value.Longitude > 180)
                    throw new ArgumentException("Недопустимое значение долготы");

                _coordinates = value; 
            } // set
        } // Coordinates

        // категория транспортного средства
        protected string _category;
        public string Category {
            get => _category;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Не задано название категории транспортного средства");
                _category = value;
            } // set
        } // Category


        // цена
        protected int _price;
        public int Price {
            get => _price;
            set {
                if (value < 0)
                    throw new ArgumentException("Недопустимое значение цены транспортного средства");
                _price = value; 
            }
        } // Price

        // скорость
        protected int _velocity;
        public int Velocity {
            get => _velocity;
            set {
                if (value < 0)
                    throw new ArgumentException("Недопустимое значение скорости транспортного средства");
                _velocity = value;
            }
        } // Velocity

        // год выпуска
        protected int _year;
        public int Year {
            get => _year;
            set {
                if (value < 0)
                    throw new ArgumentException("Недопустимое значение года изготовления транспортного средства");
                _year = value;
            }
        } // Year

        // вывод шапки и подвала таблицы одинаковый для всех
        // транспортных средств 
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
                $"{spaces}┌─────┬────────────┬───────────────────┬────────────────┬───────────┬──────┬─────────┬───────────────────┐\n" +
                $"{spaces}│  №  │ Категория  │    Координаты     │ Цена  трансп., │ Скорость, │ Год  │ Кол-во  │ Высота полета, и  │\n" +
                $"{spaces}│ п/п │ тр. ср-ва  │ трансп. средства  │ средства, руб. │   км/ч    │ изг. │ пассаж. │ или порт приписки │\n" +
                $"{spaces}├─────┼────────────┼───────────────────┼────────────────┼───────────┼──────┼─────────┼───────────────────┤\n";
        } // Header
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴────────────┴───────────────────┴────────────────┴───────────┴──────┴─────────┴───────────────────┘";

        // вывод в табличном формате - разный для разных классов
        public abstract string ToTableRow(int row);
        
    } // class Vehicle
}
