﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// подключение пространсива имен моделей
using InheritanceIntro.Models.Task1;
using InheritanceIntro.Models.Task2;

namespace InheritanceIntro.Application
{
    internal partial class App
    {
        // массив транспортных средств
        private TransportCompany _transportCompany;

        // массив геометрических фигур
        private FigureArray _arrayFigures;

        // ансамбль конструкторов
        public App():this(new TransportCompany(), new FigureArray()) {
            _transportCompany.Initialize();
            _arrayFigures.Initialize();
        } // App

        public App(TransportCompany vehicles, FigureArray figures) {
            _transportCompany = vehicles;
            _arrayFigures = figures;
        } // App

    } // class App
}
