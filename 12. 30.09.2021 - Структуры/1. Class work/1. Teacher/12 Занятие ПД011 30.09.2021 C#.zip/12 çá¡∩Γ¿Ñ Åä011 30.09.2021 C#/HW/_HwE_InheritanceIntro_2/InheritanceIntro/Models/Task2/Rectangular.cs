﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntro.Models.Task2
{
    // Прямоугольник, наследует от Фигура, реализует интерфейс ПлоскаяФигура
    class Rectangular: Figure, IFlat
    {
        public double A {
            get => SideA;
            set => SideA = value > 0
                ? value
                : throw new InvalidDataException($"Недопустимое значение: {value}");
        } // A

        protected double SideB;
        public double B {
            get => SideB;
            set => SideB = value > 0
                ? value
                : throw new InvalidDataException($"Недопустимое значение: {value}");
        } // B

        // Реализация интерфейса IFlat - расчет площади
        public double Area() => SideB * SideA;

        // Реализация интерфейса IFlat - расчет периметра
        public double Perimeter() => 2d * (SideA + SideA);

        // реализация интерфейса IFigure - вывод прямоугольника в строку таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,5} │ {TypeFigure,-14} │ {SideA, 9:f3} │ {SideB, 9:f3} │ {" ", 9} │ {Perimeter(), 9:f3} │ {Area(), 9:f3} │ {" ", 9} │";

        // Вывод прямоугольника в строку
        public override string ToString() =>
            $"{TypeFigure, -14} Стороны: {SideA:f3} x {SideB:f3}. Периметр: {Perimeter():f3}. Площадь: {Area():f3}";

    } // class Rectangular
}
