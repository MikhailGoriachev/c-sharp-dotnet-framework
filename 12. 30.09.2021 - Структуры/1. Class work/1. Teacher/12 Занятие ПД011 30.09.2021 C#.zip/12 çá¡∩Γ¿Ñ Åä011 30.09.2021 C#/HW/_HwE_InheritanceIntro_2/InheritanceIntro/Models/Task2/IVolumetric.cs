﻿namespace InheritanceIntro.Models.Task2
{
    // Интерфейс ОбъемнаяФигура с методами для вычисления площади поверхности и объема
    internal interface IVolumetric: IFigure {
        double Volume();
    }
}
