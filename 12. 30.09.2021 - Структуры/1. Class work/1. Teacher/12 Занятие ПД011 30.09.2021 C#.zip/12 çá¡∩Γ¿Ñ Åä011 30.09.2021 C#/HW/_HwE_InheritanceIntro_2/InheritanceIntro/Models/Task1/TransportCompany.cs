﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntro.Models.Task1
{
    // полиморфный массив транспортных средств, обработка массива по заданию
    // В массиве найти:
    //      • самое старое транспортное средство
    //      • самое быстрое и самое медленное транспортные средства (может быть 
    //        найдено больше 1 транспортного средства)
    internal class TransportCompany
    {
        // название транспортной компании
        private string _name;

        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Не задано название транспортной компании");
                _name = value;
            } // set
        } // Name
            
        // транспортные средства
        private Vehicle[] _vehicles;
        
        // количество транспортных средств в массиве самолетов по умолчанию
        private const int DefNumber = 10;

        public TransportCompany():this("Увезем все, привезем всех", new Vehicle[DefNumber]) {
            Initialize();
        }

        TransportCompany(string name, Vehicle[] vehicles) {
            _name = name;
            _vehicles = vehicles;
        } // TransportCompany

        // Формирование массива транспортных средств по заданию:
        //     2 самолета
        //     3 корабля
        //     5 автомобилей
        public void Initialize() {
            _vehicles = new Vehicle[] {
                new Plane {
                    Category = "самолет",
                    Coordinates = (23.345, -23.345), Price = 13_000_000, Velocity = 980, Year = 2001, Pax = 360, 
                    Altitude = 12_000
                },
                new Plane {
                    Category = "самолет",
                    Coordinates = (123.123, -123.199), Price = 38_000_000, Velocity = 1180, Year = 2017, Pax = 160, 
                    Altitude = 19_000
                },
                new Ship {
                    Category = "корабль",
                    Coordinates = (13.123, -13.199), Price = 123_000_000, Velocity = 60, Year = 1998, Pax = 460, 
                    HomePort = "Новороссийск"
                },
                new Ship {
                    Category = "корабль",
                    Coordinates = (-93.3, -123.9), Price = 89_000_000, Velocity = 40, Year = 2012, Pax = 120, 
                    HomePort = "Керчь"
                },
                new Ship {
                    Category = "корабль",
                    Coordinates = (-113.3, 90.9), Price = 18_000_000, Velocity = 20, Year = 1995, Pax = 20, 
                    HomePort = "Новоазовск"
                },
                new Car {Category="автомобиль", Coordinates = (-123.3, 100.9), Price =      30_000, Velocity =   20, Year = 2012},
                new Car {Category="автомобиль", Coordinates = ( 113.3, 101.9), Price =   3_100_000, Velocity =  120, Year = 2019},
                new Car {Category="автомобиль", Coordinates = (-129.3,   1.6), Price =     230_000, Velocity =   50, Year = 1998},
                new Car {Category="автомобиль", Coordinates = (-132.3,  22.7), Price =     890_000, Velocity =   90, Year = 2002},
                new Car {Category="автомобиль", Coordinates = (  33.1,  89.3), Price = 140_980_000, Velocity = 1180, Year = 2019}
            };
        } // Initialize
        
        // Вывести данные в консоль
        public string Show(string caption, int indent) =>
            Show($"{caption} - {Name}", indent, _vehicles);

        // Вывести данные массива  в консоль - для вывода 
        // массивов, полученных из отбора
        public static string Show(string caption, int indent, Vehicle[] vehicles) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            StringBuilder sb = new StringBuilder($"\n\n\n\n{space}{caption}\n{Vehicle.Header(indent)}");

            // вывод всех элементов массива объектов данных
            int row = 1;
            void OutItem(Vehicle v) => sb.Append($"{space}{v.ToTableRow(row++)}\n");
            Array.ForEach(vehicles, OutItem);

            // вывод подвала таблицы
            return sb.Append($"{Vehicle.Footer(indent)}\n").ToString();
        } // Show

        // Выбрать в массив самые старые транспортные средства
        public Vehicle[] GetOldests() => SelectWhereYearEq(_vehicles, MinYear());

        // Выбрать в массив самые медленные транспортные средства
        public Vehicle[] GetSlowests() => SelectWhereVelocityEq(_vehicles, MinVelocity());
        
        // Выбрать в массив самые быстрые транспортные средства
        public Vehicle[] GetFastests() => SelectWhereVelocityEq(_vehicles, MaxVelocity());

        
        // найти минимальный год изготовления транспортных средств
        // (для поиска самого старого транспортного средства)
        private int MinYear() {
            int minYear = int.MaxValue;
            foreach (var vehicle in _vehicles) {
                if (vehicle.Year < minYear)
                    minYear = vehicle.Year;
            } // foreach vehicle

            return minYear;
        } // MinYear

        // найти минимальную скорость в массиве транспортных средств
        private int MinVelocity() {
            int minVelocity = int.MaxValue;
            foreach (var vehicle in _vehicles) {
                if (vehicle.Velocity < minVelocity)
                    minVelocity = vehicle.Velocity;
            } // foreach vehicle

            return minVelocity;
        } // MinVelocity
        
        
        // найти максимальную скорость в массиве транспортных средств
        private int MaxVelocity() {
            int maxVelocity = int.MinValue;
            foreach (var vehicle in _vehicles) {
                if (vehicle.Velocity > maxVelocity)
                    maxVelocity = vehicle.Velocity;
            } // foreach vehicle

            return maxVelocity;
        } // MinVelocity

        // выбрать элементы массива транспортных средств с заданным годом выпуска
        private Vehicle[] SelectWhereYearEq(Vehicle[] vehicles, int year) {
            bool Match(Vehicle v) => v.Year == year;
            return Array.FindAll(vehicles, Match);
        } // SelectWhereYearEq

        // выбрать элементы массива транспортных средств с заданной скоростью
        private Vehicle[] SelectWhereVelocityEq(Vehicle[] vehicles, int velocity) {
            bool Match(Vehicle v) => v.Velocity == velocity;
            return Array.FindAll(vehicles, Match);
        } // SelectWhereVelocityEq

        // Упорядочить массив транспортных средств по убыванию цены
        public void OrderByPriceDescend() {
            int PriceComparer(Vehicle v1, Vehicle v2) => v2.Price.CompareTo(v1.Price); 
            Array.Sort(_vehicles, PriceComparer);
        } // OrderByPriceDescend
    } // class TransportCompany
}
