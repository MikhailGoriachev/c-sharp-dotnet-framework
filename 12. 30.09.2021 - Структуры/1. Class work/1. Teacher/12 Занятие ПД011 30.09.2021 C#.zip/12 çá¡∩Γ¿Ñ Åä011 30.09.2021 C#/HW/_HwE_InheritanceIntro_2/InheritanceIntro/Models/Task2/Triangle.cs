﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntro.Models.Task2
{
    // Треугольник, наследует от Фигура, реализует интерфейс ПлоскаяФигура
    internal class Triangle: Figure, IFlat
    {
        public double A {
            get => SideA;
            private set => SideA = value;
        } // A

        protected double SideB;
        public double B {
            get =>  SideB;
            private set => SideB = value;
        } // B

        protected double SideC;
        public double C {
            get =>  SideC;
            private set => SideC = value;
        } // C

        // проверка возможности собрать треугольник из трех значений
        public static bool IsTriangle(double a, double b, double c) =>
            a + b > c && a + c > b && b + c > a;

        // задание трех сторон с контролем корректности
        public (double a, double b, double c) Sides {
            set {
                if (IsTriangle(value.a, value.b, value.c))
                    (SideA, SideB, SideC) = value;
                else {
                    string t = $"Значения {value.a}, {value.b} и {value.c} не образуют треугольник";
                    throw new InvalidDataException(t);
                } // if
            } // set
        } // Sides

        // Расчет площади - реализация интерфейса IFigure2D,
        // в расчете используем свойства класса
        public double Area() {
            double p = Perimeter() / 2;
            return Math.Sqrt(p * (p - A) * (p - B) * (p - C));
        } // Area

        // Расчет периметра -  - реализация интерфейса IFlat,
        // используем атрибуты класса
        public double Perimeter() => SideA + SideB + SideC;

        // реализация интерфейса IFlat - вывод треугольника в строку таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,5} │ {TypeFigure,-14} │ {SideA, 9:f3} │ {SideB, 9:f3} │ {SideC, 9:f3} │ {Perimeter(), 9:f3} │ {Area(), 9:f3} │ {" ", 9} │";

        // Вывод треугольника в строку
        public override string ToString() {
            // для разнообразия явно сохраним вычисленные периметр и площадь в переменые
            double p = Perimeter();
            double a = Area();
            return $"{TypeFigure, -14} Стороны: {SideA:f3} х {SideB:f3} х {SideC:f3}. Периметр: {p:f3}. Площадь: {a:f3}";
        } // ToString

    } // class Triangle

}
