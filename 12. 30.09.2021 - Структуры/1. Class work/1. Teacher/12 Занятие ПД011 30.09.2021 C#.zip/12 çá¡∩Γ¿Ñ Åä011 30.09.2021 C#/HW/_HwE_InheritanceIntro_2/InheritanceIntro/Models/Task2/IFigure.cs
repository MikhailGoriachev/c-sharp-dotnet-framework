﻿namespace InheritanceIntro.Models.Task2 {
    // базовый интерфейс для фигур
    public interface IFigure {
        // вычисление площади
        double Area();

        // вывод в строку таблицы
        string ToTableRow(int rowNumber);
    } // IFigure
}