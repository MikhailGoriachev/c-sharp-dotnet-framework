﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntro.Models.Task2
{
    // Конус, наследует от Фигура, реализует интерфейс ОбъемнаяФигура
    internal class Cone: Figure, IVolumetric
    {
        // радиус конуса
        public double R {
            get => SideA;
            set => SideA = value > 0
                ? value
                : throw new InvalidDataException($"Недопустимый радиус: {value}");
        } // R

        // Высота конуса
        protected double Height;
        public double H {
            get => Height;
            set => Height = value > 0
                ? value
                : throw new InvalidDataException($"Недопустимая высота: {value}");
        } // H

        // реализация IVolumetric
        public double Area() => Math.PI * R * (Math.Sqrt(R*R + H*H) + R);
        public double Volume() => Math.PI * R * R * H / 3d;

        // реализация интерфейса IFigure - вывод конуса в строку таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,5} │ {TypeFigure,-14} │ {R, 9:f3} │ {Height, 9:f3} │ {" ", 9} │ {" ", 9} │ {Area(), 9:f3} │ {Volume(), 9:f3} │";

        // Вывод конуса в строку
        public override string ToString() {
            double a = Area();
            double v = Volume();
            
            return $"{TypeFigure, -14} Радиус: {R:f3}. Высота {H:f3}. Объем: {v:f3}. Площадь: {a:f3}";
        } // ToString
    } // class Cone
}
