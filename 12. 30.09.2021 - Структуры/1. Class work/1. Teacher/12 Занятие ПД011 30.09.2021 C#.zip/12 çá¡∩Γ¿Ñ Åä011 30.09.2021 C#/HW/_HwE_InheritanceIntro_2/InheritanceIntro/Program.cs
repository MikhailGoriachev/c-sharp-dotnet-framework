﻿/*
 * Разработайте консольное приложение для решения следующих задач. 
 * Используйте простое меню, 
 * 
 * Задача 1. 
 * Создать абстрактный класс Vehicle (транспортное средство). На его основе
 * реализовать классы Plane (самолет), Саг (автомобиль) и Ship (корабль).
 * Классы должны иметь возможность задавать и получать параметры средств 
 * передвижения (географические координаты, цена, скорость, год выпуска) 
 * с помощью свойств.
 * Дополнительно для самолета должна быть определена высота, для самолета и 
 * корабля — количество пассажиров, для корабля — порт приписки. 
 * Создайте массив транспортных средств, состоящий из 2х самолетов, 
 * 3х кораблей и 5и автомобилей. В массиве найти:
 *     • самое старое транспортное средство
 *     • самое быстрое и самое медленное транспортные средства (может быть 
 *       найдено больше 1 транспортного средства) 
 *     • упорядочить массив по убыванию цены транспортного средства
 * 
 * Задача 2. 
 * Создать иерархию интерфейсов и классов по следующему заданию:
 *     • Интерфейс ПлоскаяФигура с методами для вычисления площади 
 *       и периметра   
 *     • Интерфейс ОбъемнаяФигура с методами для вычисления площади 
 *       поверхности и объема
 *     • Класс Фигура – базовый класс иерархии.
 *     • Треугольник, наследует от Фигура, реализует интерфейс 
 *       ПлоскаяФигура
 *     • Прямоугольник, наследует от Фигура, реализует интерфейс 
 *       ПлоскаяФигура
 *     • Цилиндр, наследует от Фигура, реализует интерфейс 
 *       ОбъемнаяФигура
 *     • Конус, наследует от Фигура, реализует интерфейс 
 *       ОбъемнаяФигура
 *     • Шар, наследует от Фигура, реализует интерфейс ОбъемнаяФигура
 *     • Разместить классы и интерфейсы в отдельных файлах 
 * Реализовать по два объекта каждого типа в массиве объектов класса 
 * Фигура. Для массива выполнить:
 *     • Упорядочить массив по убыванию площади
 *     • Упорядочить массив фигур по возрастанию площади
 *     • Выбрать объекты с минимальной и максимальной площадью
 * 
 */
using System;
using Microsoft.VisualBasic;

using InheritanceIntro.Application;



namespace InheritanceIntro {

    internal class Program {
        public static void Main(string[] args) {
            Console.Title = "Задание на 30.09.2021 - введение в наследование C#, понятие об интерфейсах";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Формирование массива транспортных средств для обработки"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Вывод массива транспортных средств"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Самые старые транспортные средства"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Самые быстрые и самые медленные транспортные средства"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "Упорядочить массив по убыванию цены транспортного средства"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.A, Text = "Формирование массива геометрическоих фигур для обработки"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Вывод массива геометрических фигур"},
                new MenuItem
                    {HotKey = ConsoleKey.D, Text = "Упорядочить массив геометрических фигур по убыванию площади"},
                new MenuItem
                    {HotKey = ConsoleKey.F, Text = "Упорядочить массив геометрических фигур по возрастанию площади"},
                new MenuItem {
                    HotKey = ConsoleKey.G, Text = "Выборка геометрических фигур с минимальной и максимальной площадями"
                },
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - интерфейсы, наследование");
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации наследования", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1

                        #region Задача 1

                        // Формирование массива транспортных средств для обработки
                        case ConsoleKey.Q:
                            app.FillVehicles();
                            break;

                        // Вывод массива транспортных средств
                        case ConsoleKey.W:
                            app.ShowVehicles();
                            break;

                        // Самые старые транспортные средства
                        case ConsoleKey.E:
                            app.SelectOldestVehicles();
                            break;

                        // Самые быстрые и самые медленные транспортные средства
                        case ConsoleKey.R:
                            app.SelectFastestSlowestVehicles();
                            break;

                        // Упорядочить массив по убыванию цены транспортного средства
                        case ConsoleKey.T:
                            app.OrderByPriceDescend();
                            break;

                        #endregion

                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 2

                        #region Задача 2

                        // Формирование массива геометрическоих фигур для обработки
                        case ConsoleKey.A:
                            app.FillFigures();
                            break;

                        // Вывод массива геометрических фигур
                        case ConsoleKey.S:
                            app.ShowFigures();
                            break;

                        // Упорядочить массив геометрических фигур по убыванию площади
                        case ConsoleKey.D:
                            app.OrderByAreaDescend();
                            break;

                        // Упорядочить массив геометрических фигур по возрастанию площади
                        case ConsoleKey.F:
                            app.OrderByArea();
                            break;

                        // Выборка геометрических фигур с минимальной и максимальной площадями
                        case ConsoleKey.G:
                            app.SelectMinMaxAreas();
                            break;
                        #endregion

                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    } // class Program
}