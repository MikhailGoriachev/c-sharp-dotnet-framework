﻿using System;
using System.Text;

namespace InheritanceIntro.Models.Task2 {
    // полиморфный массив фигур для реализации обработок по заданию 
    internal class FigureArray {
        // место в массиве предусмотрено для 2х элементов каждого класса
        private const int DefaulSize = 10;
        
        // собственно сам полиморфный массив для хранения фигур
        private IFigure[] _figures;
        
        public FigureArray():this(new IFigure[DefaulSize]) {
            Initialize();
        } // FigureArray

        public FigureArray(IFigure[] figures) {
            _figures = figures;
        } // FigureArray
        
        // заполнение полиморфного массива фигур начальными данными по заданию
        // по две фигуры каждого типа
        public void Initialize() {
            for (int i = 0, k = 0; i < _figures.Length/2; ++i, ++k) {
                _figures[k++] = FigureFactory(i);
                _figures[k] = FigureFactory(i);
            } // for i
        } // Initialize 
        
          // Фабричный метод для фигур
        private static IFigure FigureFactory(int code) {
            IFigure figure;
            switch (code) {
                case 0:
                    figure = new Triangle {TypeFigure = "Треугольник", 
                        Sides = (Utils.GetRandom(5d, 10d), Utils.GetRandom(5d, 10d), 
                            Utils.GetRandom(5d, 10d))};
                    break;

                case 1:
                    figure = new Sphere {
                        TypeFigure = "Сферв", R = Utils.GetRandom(5d, 10d)};
                    break;

                case 2:
                    figure = new Rectangular { TypeFigure = "Прямоугольник", 
                        A = Utils.GetRandom(5d, 10d), B = Utils.GetRandom(5d, 10d)};
                    break;

                case 3:
                    figure = new Cylinder { TypeFigure = "Цилиндр", 
                        H = Utils.GetRandom(5d, 10d), R = Utils.GetRandom(5d, 10d)};
                    break;

                default:
                    figure = new Cone { TypeFigure = "Конус", 
                        H = Utils.GetRandom(5d, 10d), R = Utils.GetRandom(5d, 10d)};
                    break;
            } // switch

            return figure;
        } // FigureFactory


        // при выводе, как обычно, будем пользоваться функционалом другого метода
        public void Show(string title, int indent) => Show(title, indent, _figures);

        // метод для вывода переданного массива фигур
        public static void Show(string caption, int indent, IFigure[] figures) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{Figure.Header(indent)}");

            // вывод всех элементов массива объектов данных 
            int row = 1;
            void OutItem(IFigure f) => Console.WriteLine($"{space}{f.ToTableRow(row++)}");
            Array.ForEach(figures, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Figure.Footer(indent));
        } // Show

        // выбрать элементы массива фигур с заданной площадью
        private IFigure[] SelectWhereAreaEq(IFigure[] figures, double area) {
            bool Match(IFigure f) => Math.Abs(f.Area() - area) < 1e-6;
            return Array.FindAll(figures, Match);
        } // SelectWhereAreaEq

        // определение минимальной площади в массиве фигур
        public double MinArea() {
            double minArea = double.MaxValue;
            foreach (var figure in _figures) {
                double area = figure.Area();
                if (area < minArea)
                    minArea = area;
            } // foreach

            return minArea;
        } // MinArea

        // определение максимальной площади в массиве фигур
        public double MaxArea() {
            double maxArea = double.MinValue;
            foreach (var figure in _figures) {
                double area = figure.Area();
                if (area > maxArea)
                    maxArea = area;
            } // foreach

            return maxArea;
        } // MaxArea
        
        // Выбрать в массив фигуры с минимальной площадью
        public IFigure[] GetMinArea() => SelectWhereAreaEq(_figures, MinArea());
        
        // Выбрать в массив фигуры с максималной площадью
        public IFigure[] GetMaxArea() => SelectWhereAreaEq(_figures, MaxArea());

        // сортировка массива фигур по убыванию площадей
        public void OrderAreaDesc() {
            // компаратор для сортировки масива фигур по убыванию площади
            int Comparer(IFigure f1, IFigure f2) => f2.Area().CompareTo(f1.Area());

            Array.Sort(_figures, Comparer);
        } // OrderAreaDesc

        // сортировка массива фигур по возрастанию площадей
        public void OrderArea() {
            // компаратор для сортировки масива фигур по возрастанию площади
            int Comparer(IFigure f1, IFigure f2) => f1.Area().CompareTo(f2.Area());

            Array.Sort(_figures, Comparer);
        } // OrderAreaDesc

    } // class FigureArray
}