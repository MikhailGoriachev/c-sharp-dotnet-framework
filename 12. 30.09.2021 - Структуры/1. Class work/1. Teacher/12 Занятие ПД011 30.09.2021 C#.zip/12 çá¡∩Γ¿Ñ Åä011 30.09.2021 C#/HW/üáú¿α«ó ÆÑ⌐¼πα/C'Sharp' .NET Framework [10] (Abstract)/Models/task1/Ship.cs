﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task1
{
    class Ship : Vehicle
    {
        private int MaxCountPas = 22_000;    //     максимальное количество пассажиров
        private int MinCountPas = 1;        //    минимальное количество пассажиров

        private string _port;   // порт приписки
        private int _countPas; //  количество пассажиров
        public int CouPas
        {
            get => _countPas;
            set => _countPas = value >= MinCountPas || value <= MaxCountPas ? value : 
                throw new Exception($"Количество пассажиров не может быть больше {MaxCountPas} или меньше {MinCountPas}");
        } // CouPas

       
        public string Port
        {
            get => _port;
            set => _port = !string.IsNullOrWhiteSpace(value) ? value : throw new Exception($"Данные о порте приписки невведенны ");
        } // Port
        public Ship(){
            Port = "Иокогама";
            CouPas = 222;
        }

 
        public Ship(CoordXY coord, double speed, double price, int year, string port, int couPas) : base(coord, speed, price, year){
            Port = port;
            CouPas = couPas;
        } // Plane

        public override string GetType() => "Корабль";

        public override string ToTableRow(string type) =>
        $"\t| {type,-9} │ {Coord,10} │ {Speed,8:f2} " +
        $"│ {Price,11:n2} │ {Year,10} " +
        $"│ {"─",8} " +
        $"│ {_countPas,10} │ {Port,-12} │";


    } // Ship
}
