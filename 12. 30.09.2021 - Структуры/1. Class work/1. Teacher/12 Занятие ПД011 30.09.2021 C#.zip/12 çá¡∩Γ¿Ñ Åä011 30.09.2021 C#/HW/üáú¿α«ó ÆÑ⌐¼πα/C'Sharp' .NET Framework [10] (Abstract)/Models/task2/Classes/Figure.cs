﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Interfaces;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Classes
{
    abstract class Figure 
    {
        protected double _a;  // Сторона а

        public double A
        {
            get => _a;
            set => _a = value > 0 ? value : throw new Exception($"Неверные данные для стороны a [ {value} ]");
        }

        public Figure() : this(1) { }
        public Figure(double a){
            A = a;
        }

        // Вычисление объема фигуры
        public abstract double Area();

        // Сортировка по убыванию площадей
        public static int CompareByDecreasingArea(Figure fig1, Figure fig2) =>
            fig2.Area().CompareTo(fig1.Area());
        
        // Сортировка по возрастанию площадей
        public static int CompareByArea(Figure fig1, Figure fig2) =>
            fig1.Area().CompareTo(fig2.Area());

        public override string ToString() => $"a = {A}";

        public virtual string GetFigure() => "Фигура";

        public virtual string ToTableRow(string type) =>
            $"\t| {type,-17} │ {A,7:f2} │ {"─",7:f2} " +
            $"│ {"─",7:f2} │ {"─",8:f2} " +
            $"│ {"─",7:f2} | {"─",10:f2} " +
            $"│ {"─",8:f2}";


        public static string Header() =>
                "\t┌─────────────────┬───────────┬───────────┬───────────┬────────────┬───────────┬─────────────┬──────────┐\n" +
                "\t│       Тип       │  Сторона  │  Сторона  │  Сторона  │  Периметр  │  Площадь  │   Площадь   │  Объем   │\n" +
                "\t│      Фигуры     │  А/радиус │  B/высота │     C     │   фигуры   │  фигуры   │ поверхности │  фигуры  │\n" +
                "\t├─────────────────┼───────────┼───────────┼───────────┼────────────┼───────────┼─────────────┼──────────┤\n";

        public static string Footer() => "\t└─────────────────┴───────────┴───────────┴───────────┴────────────┴───────────┴─────────────┴──────────┘";




    }

}
