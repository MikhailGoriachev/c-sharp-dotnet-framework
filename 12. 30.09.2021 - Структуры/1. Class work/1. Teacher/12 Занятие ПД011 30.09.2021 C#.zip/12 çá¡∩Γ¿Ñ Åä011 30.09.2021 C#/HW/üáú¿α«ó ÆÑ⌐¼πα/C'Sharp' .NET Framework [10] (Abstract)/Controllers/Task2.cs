﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Classes;

namespace C_Sharp_.NET_Framework__10___Abstract_.Controllers
{
    class Task2{ 
        
        private const int n = 10;
        private const double LowTriangle = 10d;
        private const double HighTriangle = 20d;
        private const double LowRectangle = 6d;
        private const double HighRectangle = 12d;
        private const double LowCylinder = 4d;
        private const double HighCylinder = 12d;
        private const double LowCone = 8d;
        private const double HighCone = 18d;
        private const double LowSphere = 6d;
        private const double HighSphere = 12d;


        private Figure[] _figures;

        public Figure[] Figures
        {
            get => _figures;
            set => _figures = value;
        }

        public Task2() : this(new Figure[n]) { Initialize(); }

        public Task2(Figure[] figur)
        {
            Figures = figur;
        } // Task2

        public void Initialize()
        {                
            int i = 0;
            Figures[i++] = new Triangle(Utils.GetRandom(LowTriangle, HighTriangle));
            Figures[i++] = new Triangle(Utils.GetRandom(LowTriangle, HighTriangle), Utils.GetRandom(LowTriangle, HighTriangle), Utils.GetRandom(LowTriangle, HighTriangle));
            Figures[i++] = new Rectangle(Utils.GetRandom(LowRectangle, HighRectangle), Utils.GetRandom(LowRectangle, HighRectangle));
            Figures[i++] = new Rectangle(Utils.GetRandom(LowRectangle, HighRectangle), Utils.GetRandom(LowRectangle, HighRectangle));
            Figures[i++] = new Cylinder(Utils.GetRandom(LowCylinder, HighCylinder), Utils.GetRandom(LowCylinder, HighCylinder));
            Figures[i++] = new Cylinder(Utils.GetRandom(LowCylinder, HighCylinder), Utils.GetRandom(LowCylinder, HighCylinder));
            Figures[i++] = new Cone(Utils.GetRandom(LowCone, HighCone), Utils.GetRandom(LowCone, HighCone));
            Figures[i++] = new Cone(Utils.GetRandom(LowCone, HighCone), Utils.GetRandom(LowCone, HighCone));
            Figures[i++] = new Sphere(Utils.GetRandom(LowSphere, HighSphere));
            Figures[i++] = new Sphere(Utils.GetRandom(LowSphere, HighSphere));
        } // Initialize

        #region Различные выводы в консоль
        public void Show(Figure[] vehic, string title = "")
        {
            Console.Write($"\n\n\t {title}\n" +
                              $"{Figure.Header() }");


            void OutItem(Figure fig) => Console.WriteLine($"{fig.ToTableRow(fig.GetFigure())}");
            Array.ForEach(vehic, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Figure.Footer());

        } // Show

        // Вывод с выделением цвета элементов с максимальной и минимальной площадью
        public void ShowMaxMinArea(Figure[] figurs, string title = "")
        {
            Console.Write($"\n\n\t {title}\n" +
                              $"{Figure.Header() }");

            double maxArea = MaxArea();
            double minArea = MinArea();

            // Сохранение цвета фона 
            ConsoleColor oldFgColor = Console.ForegroundColor;
            ConsoleColor oldBgColor = Console.BackgroundColor;

            void OutItem(Figure figure)
            {

                if (figure.Area() == maxArea)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                }
                else if (figure.Area() == minArea)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                }
                else
                {
                    Console.ForegroundColor = oldFgColor;
                    Console.BackgroundColor = oldBgColor;
                } // if else 

                Console.WriteLine($" {figure.ToTableRow(figure.GetFigure())}");
            };

            Array.ForEach(figurs, OutItem);

            // Необходимо на случай если последний элемент выделеться цветом
            Console.ForegroundColor = oldFgColor;
            Console.BackgroundColor = oldBgColor;

            // вывод подвала таблицы
            Console.WriteLine(Figure.Footer());

        } // ShowMaxMinArea
        #endregion

        #region Методы находящие значения для поисков по коллекции
        public double MaxArea()
        {
            double area = Figures[0].Area();
            for (int i = 1; i < Figures.Length; i++)
            {
                double tempArea = Figures[i].Area();
                if (tempArea > area)
                    area = tempArea;
            } // for
            return area;
        } // MaxArea

        public double MinArea()
        {
            double area = Figures[0].Area();
            for (int i = 1; i < Figures.Length; i++)
            {
                double tempArea = Figures[i].Area();
                if (tempArea < area && tempArea > 0.2)
                    area = tempArea;
            } // for
            return area;
        } // MinArea

        #endregion

        #region Различные поиски
        public Figure[] FindMaxArea()
        {
            double maxArea = MaxArea();
            bool IsMaxArea(Figure fig) => fig.Area() == maxArea;

            Figure[] figuresFind = Array.FindAll(Figures, IsMaxArea);
            return figuresFind;

        }//FindFastTC
        public Figure[] FindMinArea()
        {
            double minArea = MinArea();
            bool IsMinArea(Figure fig) => fig.Area() == minArea;

            Figure[] figuresFind = Array.FindAll(Figures, IsMinArea);
            return figuresFind;

        }//FindSlowTC
        #endregion

        #region Сортировки
        
        // Сортировка по убыванию площадей
        public void OrderByDecreasingArea() => Array.Sort(Figures, Figure.CompareByDecreasingArea);

        // Сортировка по возрастанию площадей
        public void OrderByArea() => Array.Sort(Figures, Figure.CompareByArea);

        #endregion

    }
}
