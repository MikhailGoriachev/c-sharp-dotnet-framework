﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Interfaces;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Classes
{
    class Sphere:Figure,ThreeDimensionalFigure{
 
 
        public Sphere(){ }
        public Sphere(double r) : base(r) { }
       
        //    Примечание свойства А в данном классе выступает как радиус
        public override string ToString() => $"r = {A}";


        public double Volume() => 4d/3d * Math.PI * (A * A * A);
        
        // Нахождение боковой поверхности 
        public override double Area() => 4d  * Math.PI * (A * A);

        public override string GetFigure() => "Шар";

        public override string ToTableRow(string type) =>
              $"\t| {type,-15} │ {A,9:f2} │ {"─",9:f2} " +
            $"│ {"─",9:f2} │ {"─",10:f2} " +
            $"│ {"─",9:f2} │ {Area(),11:f2} " +
            $"│ {Volume(),8:f2} │";

    }



}
 
