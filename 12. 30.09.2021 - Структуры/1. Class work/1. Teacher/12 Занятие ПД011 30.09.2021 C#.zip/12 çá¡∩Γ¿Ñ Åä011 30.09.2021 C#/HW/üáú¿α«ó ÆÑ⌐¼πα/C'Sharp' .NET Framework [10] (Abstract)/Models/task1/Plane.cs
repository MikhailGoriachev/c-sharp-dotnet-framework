﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task1
{
    class Plane : Vehicle{

        private double MaxHeight = 13_000d;     // максимальная высота (взято из интернета)
                                               //     https://news.rambler.ru/disasters/38108365-na-kakoy-vysote-letayut-samolety/
        private double MinHeight = 5d;        //   минимальная  высота (взято из головы для ограничения)
        private int MaxCountPas = 5_000;    //     максимальное количество пассажиров
        private int MinCountPas = 1;        //    минимальное количество пассажиров
        

        private double _height;  // высота полета
        private int _countPas;  //  количество пассажиров

        public double Height
        {
            get => _height;
            set => _height = value >= MinHeight && value <=MaxHeight?value:
                           throw new Exception($"Высота самолета не может быть выше {MaxHeight} или ниже {MinHeight}");
        } // Height
        public int CouPas
        {
            get => _countPas;
            set => _countPas = value >= MinCountPas || value <= MaxCountPas ? value : 
                throw new Exception($"Количество пассажиров не может быть больше {MaxCountPas} или меньше {MinCountPas}");
        } // CouPas

        public Plane() {
            Height = 33;
            CouPas = 22;
        }

        public Plane(CoordXY coord, double speed, double price, int year,double height, int couPas) : base(coord, speed, price, year){
            Height = height;
            CouPas = couPas;

        }

        public override string GetType() => "Самолет";

        public override string ToTableRow(string type) =>
        $"\t| {type,-9} │ {Coord,10} │ {Speed,8:f2} " +
        $"│ {Price,11:n2} │ {Year,10} " +
        $"│ {Height,8} │ {CouPas,10} " +
        $"| {"─",-12} |";


        public override string ToString() => base.ToString() + $"\n    Высота: {Height}\n    Количество пассажиров: {CouPas}";
    } // Plane

}


 
