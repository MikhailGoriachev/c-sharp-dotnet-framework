﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Interfaces;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Classes
{
    class Cone : Figure, ThreeDimensionalFigure { 
        //   ! Примечание ! Сторона а из наследуемого класса задействуется как радиус цилиндра, поэтому 
        //                                      радиус будет именоваться как 'а'

        private double _h;  // высота

        public double H
        {
            get => _h;
            set => _h = value > 0 ? value : throw new Exception($"Неверные данные для высоты h [ {value} ]");
        }

        public  Cone() : this(1d, 1d) { }
        public Cone(double r, double h) : base(r) => H = h;

        //    Примечание свойства А в данном классе выступает как радиус
        public override string ToString() => $"r = {A}, h = {H}";

 
        public  double Volume() => 1d / 3d * Math.PI * (A * A) * H;
        // Нахождение боковой поверхности 
        public override double Area() => Math.PI * A * Math.Sqrt(A * A + H * H);

        public override string GetFigure() => "Конус";

        public override string ToTableRow(string type) =>
              $"\t| {type,-15} │ {A,9:f2} │ {H,9:f2} " +
            $"│ {"─",9:f2} │ {"─",10:f2} " +
            $"│ {"─",9:f2} │ {Area(),11:f2} " +
            $"│ {Volume(),8:f2} │";

    }
}
