﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Interfaces
{
    interface FlatShape
    {
        // Вычисление площади
        double Area();

        // Вычисление периметра
        double Perimeter();
    
    }
}
