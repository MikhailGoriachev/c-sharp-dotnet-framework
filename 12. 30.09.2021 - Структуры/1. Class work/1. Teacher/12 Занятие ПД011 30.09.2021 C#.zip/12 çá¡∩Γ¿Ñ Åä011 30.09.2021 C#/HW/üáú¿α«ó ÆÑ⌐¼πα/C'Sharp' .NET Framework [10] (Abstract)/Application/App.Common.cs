﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp_.NET_Framework__10___Abstract_.Controllers;

namespace C_Sharp_.NET_Framework__10___Abstract_.Application
{
    partial class App
    {
        Task1 _task1; // объект для задачи 1
        Task2 _task2; // объект для задачи 2

        public App() : this(new Task1(),new Task2()) { }
        public App(Task1 task1, Task2 task2)
        {
            _task1 = task1;
            _task2 = task2;
        } // App

    }
}
