﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp_.NET_Framework__10___Abstract_.Controllers;
using C_Sharp_.NET_Framework__10___Abstract_.Models.task2.Classes;

namespace C_Sharp_.NET_Framework__10___Abstract_.Application
{
    partial class App
    {

        public void DemoInitializeFigure()
        {
            _task2.Initialize();
            _task2.Show(_task2.Figures,"Сгенерирована новая коллекция фигур");
        }
       
        public void DemoShowFigure() => _task2.Show(_task2.Figures,"Коллекция фигур");
        // ^ DemoShow ^

        public void DemoFindMaxMinArea()
        {
            Figure[] figureFindMaxArea = _task2.FindMaxArea();
            Figure[] figureFindMinArea = _task2.FindMinArea();

            // Вывод всей коллекции с выделением цветом определенных элементов
            _task2.ShowMaxMinArea(_task2.Figures, "Цветом выделенны элементы с максимальной площадью(голубой) и минимальной(зеленый)");

            // Вывод новой коллекции состоящей из найденных элементов (максимальная площадь)
            _task2.Show(figureFindMaxArea, "Выведена коллекция фигур с максимальной площадью");
           
            // Вывод новой коллекции состоящей из найденных элементов (минимальная площадь)
            _task2.Show(figureFindMinArea, "Выведена коллекция фигур с минимальной площадью");

        } // DemoFindFastSlowSpeed 
        
        public void DemoSortByDecreasingArea(){
            _task2.OrderByDecreasingArea();
            _task2.Show(_task2.Figures, "Коллекция фигур отсортирована по убыванию площади");
        } // DemoSortByDecreasingArea

        public void DemoSortByArea()
        {
            _task2.OrderByArea();
            _task2.Show(_task2.Figures, "Коллекция фигур отсортирована по убыванию площади");
        } // DemoSortByArea

    }



}
