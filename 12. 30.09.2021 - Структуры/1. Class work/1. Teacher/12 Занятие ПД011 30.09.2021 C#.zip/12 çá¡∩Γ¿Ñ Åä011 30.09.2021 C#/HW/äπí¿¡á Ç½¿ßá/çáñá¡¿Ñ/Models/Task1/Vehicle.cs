﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    // абстрактный класс транспортное средство
    abstract class Vehicle {
        // географические координаты
        protected double  _latitude;      // широта
        protected double _longitude;     // долгота

        protected double     _price;     // цена
        protected double     _speed;     // скорость (км/ч)
        protected int         _year;     // год выпуска

        public double Latitude {
            get => _latitude;
            set { if (value < -90d || value > 90d) throw new Exception("Vehicle: Некорректное значение географической координаты (широты)!"); _latitude = value; }
        } // Latitude

        public double Longitude {
            get => _longitude;
            set { if (value < -180d || value > 180d) throw new Exception("Vehicle: Некорректное значение географической координаты (долготы)!"); _longitude = value; }
        } // Longitude

        public double Price {
            get => _price;
            set { if (value <= 0d) throw new Exception("Vehicle: Некорректное значение цены!"); _price = value; }
        } // Price

        public double Speed {
            get => _speed;
            set { if (value < 0d) throw new Exception("Vehicle: Некорректное значение скорости!"); _speed = value; }
        } // Price

        public int Year {
            get => _year; 
            set { if (value <= 0 || value > DateTime.Now.Year) throw new Exception("Vehicle: Некорректное значение года выпуска!"); _year = value; }
        } // Year

        // представление объекта в виде строки таблицы
        public abstract string ToTableRow(int rowNumber);

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬───────────────────────┬───────────────────────┬────────────────┬────────────────┬─────────────┐\n" +
                $"{spaces}│  №  │ Транспортное средство │   Геогр. координаты   │      Цена      │    Cкорость    │ Год выпуска │\n" +
                $"{spaces}├─────┼───────────────────────┼───────────────────────┼────────────────┼────────────────┼─────────────┤\n";
                          
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴───────────────────────┴───────────────────────┴────────────────┴────────────────┴─────────────┘";

        // Компаратор для сортировки по убыванию цены
        public static int PriceComparer(Vehicle v1, Vehicle v2) =>
            v2.Price.CompareTo(v1.Price);

    } // Vehicle
}
