﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction

namespace Задание
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 30.09.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Начальное формирование массива транспортных средств" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Вывод массива транспортных средств в консоль" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1. Самое старое транспортное средство" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 1. Самые быстрые и самые медленные транспортные средства" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 1. Упорядочить массив по убыванию цены транспортного средства" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Начальное формирование массива фигур" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Вывод массива фигур в консоль" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2. Упорядочить массив по убыванию площади" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2. Упорядочить массив по возрастанию площади" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Задача 2. Выбрать объекты с минимальной и максимальной площадью" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 30.09.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Начальное формирование массива транспортных средств
                        case ConsoleKey.Q:
                            app.VehiclesInitialize();
                            break;

                        // Вывод массива транспортных средств в консоль
                        case ConsoleKey.W:
                            app.VehiclesShow();
                            break;

                        // Самое старое транспортное средство
                        case ConsoleKey.E:
                            app.OldestVehicle();
                            break;


                        // Самые быстрые и самые медленные транспортные средства
                        case ConsoleKey.R:
                            app.FastestSlowestVehicles();
                            break;

                        // Упорядочить массив по убыванию цены транспортного средства
                        case ConsoleKey.T:
                            app.DemoOrderByPrice();
                            break;

                        // ------------------------------------------------------------

                        // Начальное формирование массива фигур
                        case ConsoleKey.A:
                            app.FiguresInitialize();
                            break;

                        // Вывод массива фигур в консоль
                        case ConsoleKey.S:
                            app.FiguresShow();
                            break;

                        // Упорядочить массив по убыванию площади
                        case ConsoleKey.D:
                            app.DemoOrderByAreaDesc();
                            break;

                        // Упорядочить массив по возрастанию площади
                        case ConsoleKey.F:
                            app.DemoOrderByArea();
                            break;

                        // Выбрать объекты с минимальной и максимальной площадью
                        case ConsoleKey.G:
                            app.MinMaxArea();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
