﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    // корабль
    class Ship : Vehicle {
        protected string _port;    // порт приписки
        protected int _paxes;      // количество пассажиров

        public string Port {
            get => _port;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Ship: Некорректное значение порта приписки!"); _port = value; }
        } // Port

        public int Paxes
        {
            get => _paxes;
            set { if (value < 0d) throw new Exception("Plane: Некорректное значение количества пассажиров!"); _paxes = value; }
        } // Paxes

        // представление объекта в виде строки таблицы
        public override string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {"Корабль",-21} │ {$"{_latitude:f2}°; {_longitude:f2}°",21} │ {_price,14:f2} │ {_speed,9:f2} км/ч │ {_year,8} г. │";
    } // Ship
}
