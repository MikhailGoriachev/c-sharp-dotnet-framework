﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Models.Task2;

namespace Задание
{
    /* 
    * Методы для решения задачи 2
    */
    internal partial class App {
        // Начальное формирование массива фигур
        public void FiguresInitialize() {
            Utils.ShowNavBarTask("   Начальное формирование массива фигур");
            _task2.Initialize();
            _task2.Show("Данные сформированы:", 12);
        } // FiguresInitialize

        // Вывод массива фигур в консоль
        public void FiguresShow() {
            Utils.ShowNavBarTask("   Вывод массива фигур в консоль");
            _task2.Show("Массив фигур:", 12);
        } // FiguresShow

        // Упорядочить массив по убыванию площади
        public void DemoOrderByAreaDesc() {
            Utils.ShowNavBarTask("   Упорядочить массив по убыванию площади");
            _task2.OrderByAreaDesc();
            _task2.Show("Массив фигур упорядочен по убыванию площади:", 12);
        } // DemoOrderByArea

        // Упорядочить массив по возрастанию площади
        public void DemoOrderByArea() {
            Utils.ShowNavBarTask("   Упорядочить массив по возрастанию площади");
            _task2.OrderByArea();
            _task2.Show("Массив фигур упорядочен по возрастанию площади:", 12);
        } // DemoOrderByArea

        // Выбрать объекты с минимальной и максимальной площадью
        public void MinMaxArea() {
            Utils.ShowNavBarTask("   Выбрать объекты с минимальной и максимальной площадью");

            Figure[] MinArea = _task2.FindByArea(_task2.MinArea());
            Figure[] MaxArea = _task2.FindByArea(_task2.MaxArea());

            ArrayFigure.Show("Объекты с минимальной площадью:", 12, MinArea);
            ArrayFigure.Show("Объекты с максимальной площадью:", 12, MaxArea);
        } // MinMaxArea
    }
}
