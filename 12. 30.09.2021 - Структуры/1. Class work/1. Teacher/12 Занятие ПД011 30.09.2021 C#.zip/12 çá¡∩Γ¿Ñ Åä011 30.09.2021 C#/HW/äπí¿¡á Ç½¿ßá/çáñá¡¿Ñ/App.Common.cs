﻿using System;
using Задание.Models.Task1;
using Задание.Models.Task2;

namespace Задание
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        ArrayVehicle _task1;  // объект для решения задачи 1
        ArrayFigure  _task2;  // объект для решения задачи 2

        // конструктор по умолчанию
        public App() : this(new ArrayVehicle(), new ArrayFigure()) { }

        // конструктор с внедрением зависимостей
        public App(ArrayVehicle task1, ArrayFigure task2) {
            _task1 = task1;
            _task2 = task2;
        } // App

    } // class App
}