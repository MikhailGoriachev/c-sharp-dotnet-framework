﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    // самолет
    class Plane : Vehicle {
        protected double _height;      // высота (км.)
        protected int     _paxes;      // количество пассажиров

        public double Height{
            get => _height;
            set { if (value < 0d) throw new Exception("Plane: Некорректное значение высоты!"); _height = value; }
        } // Height

        public int Paxes{
            get => _paxes;
            set { if (value < 0d) throw new Exception("Plane: Некорректное значение количества пассажиров!"); _paxes = value; }
        } // Paxes

        // представление объекта в виде строки таблицы
        public override string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {"Самолет", -21} │ {$"{_latitude:f2}°; {_longitude:f2}°", 21} │ {_price,14:f2} │ {_speed,9:f2} км/ч │ {_year,8} г. │";
    } // Vehicle
}
