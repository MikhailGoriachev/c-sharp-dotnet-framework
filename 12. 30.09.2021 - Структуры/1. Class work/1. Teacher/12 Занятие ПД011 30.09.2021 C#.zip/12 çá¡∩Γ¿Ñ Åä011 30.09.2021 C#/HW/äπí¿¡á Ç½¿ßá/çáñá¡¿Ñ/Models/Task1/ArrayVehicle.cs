﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    class ArrayVehicle {
        private Vehicle[] _vehicles;         // коллекция транспортных средств

        public bool Empty => _vehicles.Length == 0;

        public ArrayVehicle(Vehicle[] vehicles) {
            _vehicles = vehicles;
        } // ArrayVehicle
        public ArrayVehicle() {
            Initialize();
        } // ArrayVehicle

        public void Initialize() {
            _vehicles = new Vehicle[] {
                new Plane {Latitude =  18d, Longitude =   11d, Price =   1_500_000d, Speed = 500d, Year = 2000, Paxes =  150, Height = 10},
                new Plane {Latitude =  90d, Longitude =  -10d, Price =   1_800_000d, Speed = 800d, Year = 2010, Paxes =  250, Height = 12},

                new Ship  {Latitude = -88d, Longitude =  171d, Price = 450_000_000d, Speed =  80d, Year = 1990, Paxes = 1500, Port = "Пёрл-Харбор, Гавайи"},
                new Ship  {Latitude = -43d, Longitude =   32d, Price = 500_000_000d, Speed = 100d, Year = 2005, Paxes = 2050, Port = "Днепропетровск"},
                new Ship  {Latitude =  81d, Longitude =  131d, Price = 100_000_000d, Speed =  95d, Year = 2000, Paxes = 1400, Port = "Чарлстон, Южная Каролина"},

                new Car   {Latitude =  45d, Longitude = -170d, Price =      50_000d, Speed =  55d, Year = 2001},
                new Car   {Latitude = -10d, Longitude =  105d, Price =      43_000d, Speed =  50d, Year = 2006},
                new Car   {Latitude =  17d, Longitude =   11d, Price =      28_000d, Speed =  60d, Year = 2008},
                new Car   {Latitude = -43d, Longitude =  -23d, Price =      10_000d, Speed =  50d, Year = 2009},
                new Car   {Latitude =  55d, Longitude =  123d, Price =      15_000d, Speed =  70d, Year = 2011}
            };
        } // Initialize

        // Вывести массив транспортных средств
        public void Show(string caption, int indent) {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n{space}{caption}\n" +
                              $"{Vehicle.Header(indent)}");

            // вывод всех элементов массива транспортных средств
            int row = 1;
            void OutItem(Vehicle p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(_vehicles, OutItem);

            // вывод подвала таблицы 
            Console.WriteLine(Vehicle.Footer(indent));
        } // Show

        // Вывести массив транспортных средств
        static public void Show(string caption, int indent, Vehicle[] vehicles) {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n{space}{caption}\n" +
                              $"{Vehicle.Header(indent)}");

            // вывод всех элементов массива транспортных средств
            int row = 1;
            void OutItem(Vehicle p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(vehicles, OutItem);

            // вывод подвала таблицы 
            Console.WriteLine(Vehicle.Footer(indent));
        } // Show

        // Вывести массив транспортных средств(выделяется цветом самое старое транспортное средство)
        public void ShowOldest(string caption, int indent, ConsoleColor color = ConsoleColor.Yellow) {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n{space}{caption}\n" +
                              $"{Vehicle.Header(indent)}");

            ConsoleColor old = Console.ForegroundColor;
            int oldest = OldestVehicle();
            // вывод всех элементов массива транспортных средств
            int row = 1;
            void OutItem(Vehicle p) {
                if (p.Year == oldest) Console.ForegroundColor = color;
                Console.WriteLine($"{space}{p.ToTableRow(row++)}");
                Console.ForegroundColor = old;
            }
            Array.ForEach(_vehicles, OutItem);

            // вывод подвала таблицы 
            Console.WriteLine(Vehicle.Footer(indent));
        } // ShowOldest

        // Выбор транспортных средств, скорость которых, равна некоторому числу
        public Vehicle[] FindBySpeed(double speed) {
            // предикат для отбора товаров
            bool IsFind(Vehicle v) => Math.Abs(v.Speed - speed) <= 1e-5;

            // отбор товаров 
            Vehicle[] selected = Array.FindAll(_vehicles, IsFind);

            return selected;
        } // FindBySpeed

        // поиск года выпуска самого старого транспортного средства
        public int OldestVehicle() {
            int year = _vehicles[0].Year;
            foreach (var item in _vehicles)
                if (item.Year < year) year = item.Year;
            return year;
        } // OldestVehicle

        // поиск скорости самого быстрого транспортного средства
        public double FastestVehicle() {
            double fastest = _vehicles[0].Speed;
            for (int i = 1; i < _vehicles.Length; i++)
                if (_vehicles[i].Speed > fastest)
                    fastest = _vehicles[i].Speed;
            return fastest;
        } // FastestVehicle

        // поиск скорости самого медленного транспортного средства
        public double SlowestVehicle() {
            double slowest = _vehicles[0].Speed;
            for (int i = 1; i < _vehicles.Length; i++)
                if (_vehicles[i].Speed < slowest)
                    slowest = _vehicles[i].Speed;
            return slowest;
        } // SlowestVehicle

        // сортировка транспортных средств по убыванию цены
        public void OrderByPrice() => Array.Sort(_vehicles, Vehicle.PriceComparer);

    } // ArrayVehicle
}
