﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    // Прямоугольник, наследует от Фигура, реализует интерфейс ПлоскаяФигура
    class Rectangle : Figure, FlatFigure {
        private double _a;
        private double _b;

        public double A { 
            get => _a;
            set { if (value <= 0d) throw new Exception("Rectangle: Некорректное значения стороны А!"); _a = value; }
        } // A
        public double B { 
            get => _b;
            set { if (value <= 0d) throw new Exception("Rectangle: Некорректное значения стороны В"); _b = value; }
        } // B

        public override double Area() => _a * _b;

        public double Perimeter() => _a + _a + _b + _b;

        public override string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {"Прямоугольник",-20} │ {Perimeter(),12:f2} cм │ {Area(),9:f2} см^2 │ {"───",14} │";
    } // Rectangle
}
