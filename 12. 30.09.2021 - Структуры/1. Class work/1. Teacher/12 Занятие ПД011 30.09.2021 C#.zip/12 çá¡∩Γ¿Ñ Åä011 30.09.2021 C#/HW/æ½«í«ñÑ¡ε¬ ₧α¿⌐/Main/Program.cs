﻿namespace Main
{


	internal class Program
	{
		public static void Main(string[] args)
		{
			App app = new App();

			app.Run();
		}
	}


}
