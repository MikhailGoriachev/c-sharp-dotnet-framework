﻿using Main.Utilities.TableFormatter;


namespace Main.Models.Task2
{


	public abstract class Figure
	{
		protected const int OutputWidth = -13;

		[TableData("Тип", "{0, -18}")]
		public abstract string Name { get; }

		[TableData("Параметры", "{0, -50}")]
		public abstract string ParametersAsString { get; }

		[TableData("Площадь", "{0, -12:F}")]
		public abstract double Area { get; }

		[TableData("Периметр/Обьем", "{0, -16:F}")]
		public abstract double PerimeterOrVolume { get; }
		
		
		public static int CompareByAreaAscending(Figure lhs, Figure rhs) => lhs?.Area.CompareTo(rhs?.Area) ?? 0;
		
		public static int CompareByAreaDescending(Figure lhs, Figure rhs) => rhs?.Area.CompareTo(lhs?.Area) ?? 0;
	}


}
