﻿using Main.Utilities.Guards;


namespace Main.Models.Task1
{


	public class Plane : Vehicle
	{
		private double _height;
		private int _passengers;


		public double Height
		{
			get => _height;
			set => _height = Guard.Against.Negative(value, nameof(value));
		}


		public int Passengers
		{
			get => _passengers;
			set => _passengers = Guard.Against.Negative(value, nameof(value));
		}
	}


}
