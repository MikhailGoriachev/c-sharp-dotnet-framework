﻿namespace Main.Models.Task2
{


	public interface IVolumeFigure
	{
		double SurfaceArea();

		double Volume();
	}


}
