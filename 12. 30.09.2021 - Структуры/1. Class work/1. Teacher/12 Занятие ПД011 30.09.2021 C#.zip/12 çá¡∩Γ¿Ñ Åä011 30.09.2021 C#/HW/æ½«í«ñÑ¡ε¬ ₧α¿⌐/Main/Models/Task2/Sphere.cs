﻿using System;
using Main.Utilities.Guards;


namespace Main.Models.Task2
{


	public class Sphere : Figure, IVolumeFigure
	{
		private double _radius;


		public Sphere() { }

		public Sphere(double radius) => Radius = radius;


		public double Radius
		{
			get => _radius;
			set => _radius = Guard.Against.Negative(value, nameof(value));
		}


		public override string ParametersAsString => $"R: {Radius,OutputWidth:F}";

		public override string Name => "Шар";
		
		public override double Area => (this as IVolumeFigure).SurfaceArea();


		public override double PerimeterOrVolume => (this as IVolumeFigure).Volume();


		double IVolumeFigure.SurfaceArea() => 4 * Math.PI * Math.Pow(Radius, 2);


		double IVolumeFigure.Volume() => 4d / 3d * Math.PI * Math.Pow(Radius, 3);
	}


}
