﻿using System;
using Main.Controllers;
using Main.Models.Task1;
using Main.Utilities.Menu;


namespace Main.Views
{


	public class Task1View : MenuWrapper
	{
		private readonly Task1Controller _controller = new Task1Controller();


		public Task1View() =>
			Menu = new Menu("Задача 1. Vehicle, Plane, Car, Ship", new[]
			{
				new MenuItem("Вывести массив транспортных средств", Show),
				new MenuItem("Найти самое старое транспортное средство", OldestVehicle),
				new MenuItem("Найти самое быстроe и самое медленное транспортные средства", FastestAndSlowest),
				new MenuItem("Упорядочить массив по убыванию цены", OrderByPriceDescending)
			});


		private void Show()
		{
			Console.WriteLine("Массив транспортных средств:");

			_controller.Show();
		}


		private void OldestVehicle()
		{
			var oldestVehicle = _controller.FindOldestVehicle();

			bool IsOldestVehicle(Vehicle vehicle) => vehicle.ProductionYear == oldestVehicle.ProductionYear;

			Console.WriteLine("");
			_controller.Show(IsOldestVehicle);
		}


		private void FastestAndSlowest()
		{
			var fastestVehicle = _controller.FindFastestVehicles();
			var slowestVehicle = _controller.FindSlowestVehicles();

			Console.WriteLine("Самые быстрые транспортные средства:");
			Task1Controller.Show(fastestVehicle);

			Console.WriteLine("\n\nСамые медленные транспортные средства: ");
			Task1Controller.Show(slowestVehicle);
		}


		private void OrderByPriceDescending()
		{
			Console.WriteLine("Массив упорядочен по убыванию стоимости:");

			_controller.OrderByPriceDescending();

			_controller.Show();
		}
	}


}
