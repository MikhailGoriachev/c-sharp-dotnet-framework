﻿using System;
using System.Windows;
using Main.Utilities.Guards;
using Main.Utilities.TableFormatter;


namespace Main.Models.Task1
{


	public abstract class Vehicle
	{
		private Point _coord;
		private decimal _price;
		private int _speed;


		[TableData("Координаты", "{0, -12}")]
		public Point Coord
		{
			get => _coord;
			set =>
				_coord = new Point(Guard.Against.Negative(value.X, nameof(value)),
					Guard.Against.Negative(value.Y, nameof(value)));
		}


		[TableData("Цена", "{0, -10:F}")]
		public decimal Price
		{
			get => _price;
			set => _price = Guard.Against.Negative(value, nameof(value));
		}


		[TableData("Скорость", "{0, -11:F}")]
		public int Speed
		{
			get => _speed;
			set => _speed = Guard.Against.Negative(value, nameof(value));
		}


		[TableData("Год выпуска", "{0, -13:yyyy}")]
		public DateTime ProductionYear { get; set; }


		public static int CompareByPriceDescending(Vehicle lhs, Vehicle rhs) => rhs?.Price.CompareTo(lhs?.Price) ?? 0;
	}


}
