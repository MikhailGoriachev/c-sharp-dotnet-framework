﻿namespace Main.Utilities.TableFormatter
{


	internal readonly struct TableChars
	{
		public TableChars(char atStart, char separator, char atEnd, char filler = '─')
		{
			AtStart = atStart;
			Separator = separator;
			AtEnd = atEnd;
			Filler = filler;
		}


		public char AtStart { get; }
		public char Separator { get; }
		public char AtEnd { get; }
		public char Filler { get; }
	}


}
