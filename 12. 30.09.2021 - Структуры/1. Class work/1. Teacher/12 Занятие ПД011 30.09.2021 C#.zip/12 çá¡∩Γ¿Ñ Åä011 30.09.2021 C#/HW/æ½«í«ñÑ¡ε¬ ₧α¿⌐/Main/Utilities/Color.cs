﻿using System;


namespace Main.Utilities
{


	public struct Color
	{
		public ConsoleColor Foreground { get; set; }
		public ConsoleColor Background { get; set; }


		public void AsCurrent() => (Console.ForegroundColor, Console.BackgroundColor) = (Foreground, Background);


		public static Color Instantiate() =>
			new Color
				{ Foreground = Console.ForegroundColor, Background = Console.BackgroundColor };
	}


}
