﻿using System;
using System.Windows;
using Main.Models.Task1;
using Main.Utilities.TableFormatter;


namespace Main.Controllers
{


	public class Task1Controller
	{
		private readonly Vehicle[] _vehicles =
		{
			new Plane
			{
				Coord = new Point { X = 1, Y = 1 }, Height = 1, Passengers = 1, Price = 1m, Speed = 1,
				ProductionYear = new DateTime(2015, 1, 1)
			},
			new Plane
			{
				Coord = new Point { X = 2, Y = 2 }, Height = 2, Passengers = 2, Price = 2m, Speed = 2,
				ProductionYear = new DateTime(2017, 2, 2)
			},
			new Ship
			{
				Coord = new Point { X = 3, Y = 3 }, Passengers = 3, Price = 3m, Speed = 3,
				ProductionYear = new DateTime(2017, 3, 3), Harbor = "Harbor1"
			},
			new Ship
			{
				Coord = new Point { X = 4, Y = 4 }, Passengers = 4, Price = 4m, Speed = 1,
				ProductionYear = new DateTime(2018, 4, 4), Harbor = "Harbor2"
			},
			new Ship
			{
				Coord = new Point { X = 5, Y = 5 }, Passengers = 5, Price = 5m, Speed = 5,
				ProductionYear = new DateTime(2016, 5, 5), Harbor = "Harbor3"
			},
			new Car
			{
				Coord = new Point { X = 6, Y = 6 }, Price = 6m, Speed = 10,
				ProductionYear = new DateTime(2019, 6, 6)
			},
			new Car
			{
				Coord = new Point { X = 7, Y = 7 }, Price = 7m, Speed = 7,
				ProductionYear = new DateTime(2013, 7, 7)
			},
			new Car
			{
				Coord = new Point { X = 8, Y = 8 }, Price = 8m, Speed = 10,
				ProductionYear = new DateTime(2020, 8, 8)
			},
			new Car
			{
				Coord = new Point { X = 9, Y = 9 }, Price = 9m, Speed = 9,
				ProductionYear = new DateTime(2015, 9, 9)
			},
			new Car
			{
				Coord = new Point { X = 10, Y = 10 }, Price = 10m, Speed = 10,
				ProductionYear = new DateTime(2019, 10, 10)
			}
		};


		public void Show() => new TableFormatter<Vehicle>().Show(_vehicles);


		public void Show(Predicate<Vehicle> colorIf) => new TableFormatter<Vehicle>().Show(_vehicles, colorIf);


		public static void Show(Vehicle[] vehicles) => new TableFormatter<Vehicle>().Show(vehicles);


		public Vehicle FindOldestVehicle()
		{
			int index = 0;
			int year = int.MaxValue;

			for (int i = 0; i < _vehicles.Length; i++)
				if (year > _vehicles[i].ProductionYear.Year)
				{
					year = _vehicles[i].ProductionYear.Year;
					index = i;
				}

			return _vehicles[index];
		}


		public Vehicle[] FindFastestVehicles()
		{
			int maxSpeed = int.MinValue;

			foreach (Vehicle t in _vehicles)
				if (maxSpeed < t.Speed)
					maxSpeed = t.Speed;

			bool IsFastestVehicle(Vehicle vehicle) => vehicle.Speed == maxSpeed;

			return Array.FindAll(_vehicles, IsFastestVehicle);
		}


		public Vehicle[] FindSlowestVehicles()
		{
			int minSpeed = int.MaxValue;

			foreach (Vehicle t in _vehicles)
				if (minSpeed > t.Speed)
					minSpeed = t.Speed;

			bool IsSlowestVehicle(Vehicle vehicle) => vehicle.Speed == minSpeed;

			return Array.FindAll(_vehicles, IsSlowestVehicle);
		}


		public void OrderByPriceDescending() => Array.Sort(_vehicles, Vehicle.CompareByPriceDescending);
	}


}
