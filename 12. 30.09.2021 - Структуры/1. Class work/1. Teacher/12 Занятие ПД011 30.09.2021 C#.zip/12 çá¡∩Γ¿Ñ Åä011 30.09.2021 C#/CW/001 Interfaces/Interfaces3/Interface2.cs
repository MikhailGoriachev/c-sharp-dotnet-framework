﻿
namespace Interfaces
{
    interface Interface2
    {
        void Method();
    }
}
