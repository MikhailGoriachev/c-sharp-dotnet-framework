﻿using System;

namespace Interfaces
{
    class BaseClass
    {
        public void Method()
        {
            Console.WriteLine("Метод класса - BaseClass.");
        }
    }
}
