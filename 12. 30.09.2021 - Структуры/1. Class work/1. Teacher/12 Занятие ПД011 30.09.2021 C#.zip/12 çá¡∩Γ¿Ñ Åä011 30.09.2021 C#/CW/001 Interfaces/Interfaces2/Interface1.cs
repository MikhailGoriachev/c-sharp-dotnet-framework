﻿
namespace Interfaces
{
    interface Interface1
    {
        void Method1();
    }
}
