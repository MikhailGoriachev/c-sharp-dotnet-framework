#pragma once
#include <iostream>
#include "AbstractCharacter.h"

using std::cout;

class RealCharacter : public AbstractCharacter
{
public:
	RealCharacter(char pSymbol, int pPointSize)	{
		symbol = pSymbol;
		width = 100;
		height = 90;
		ascent = 40;
		descent = 0;
		pointSize = pPointSize;
	}
	virtual ~RealCharacter() = default;

	void Show()const {
		cout << "Symbol is:" << symbol << " Size:" << pointSize;
	} // Show
};

