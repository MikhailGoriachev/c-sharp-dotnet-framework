#pragma once


#include<iostream>
#include<map>
#include "RealCharacter.h"

using namespace std;


class RealCharacterFactory
{
	map <char, const AbstractCharacter*> chars;
	int pointSize;

public:
	RealCharacterFactory(): pointSize() {}
	RealCharacterFactory(int pPointSize) : pointSize(pPointSize) {}
	
	virtual ~RealCharacterFactory()	{
		for (auto c = chars.begin(); c != chars.end(); ++c)
			delete c->second;
	} // ~RealCharacterFactory

	const AbstractCharacter& getChar(char key)
	{
		auto result = chars.find(key);

		// �������� ������� ������ ���� ��� ��� � ����
		if (chars.end() == result) {
			const RealCharacter* newCharacter = new RealCharacter(key, pointSize);
			chars[key] = newCharacter;

			return *newCharacter;
		} // if

		return *result->second;
	} // getChar

	size_t size() const { return chars.size(); }
};
