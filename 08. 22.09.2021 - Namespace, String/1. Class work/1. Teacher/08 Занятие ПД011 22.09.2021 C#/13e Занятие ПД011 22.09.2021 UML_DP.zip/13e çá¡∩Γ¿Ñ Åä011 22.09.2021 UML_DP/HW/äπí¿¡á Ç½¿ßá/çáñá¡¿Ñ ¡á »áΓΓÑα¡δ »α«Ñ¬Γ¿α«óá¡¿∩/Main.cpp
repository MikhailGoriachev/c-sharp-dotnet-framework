﻿#include "pch.h"
#include "Utils.h"
#include "Palette.h"
#include "Elf.h"
#include "Army.h"
#include "Giant.h"
#include "Gnome.h"
#include "Human.h"
#include "Orc.h"
#include "CompositeUnit.h"


/*
*   Разработайте консольное приложение на C++ для иллюстрации паттерна Компоновщик.
* 
*   Для некоторой игры требуется реализовать организацию армии. Армия может состоять 
*   из отрядов и одиночных воинов. Отряд может состоять из других отрядов и одиночных воинов.
*   Для армии, отряда, воина требуется вычисление силы. Для воина также требуется вычислять 
*   уровень здоровья. В армию или отряд можно добавлять/удалять воина или другие отряды,
*   для воина такая операция невозможна.
* 
*   В игре участвуют расы: эльфы, орки, люди, гномы, великаны. 
*/

Army* createArmy();

int main()
{
	// настройка вывода в консоль
	init(L"Задание на 22.09.2021");



    try {
        cout << "Создание армии... ";
        Army* army = createArmy();
        cout << "выполнено\n";

        int power = army->GetPower();
        cout << "Мощность армии        : " << power << " элемент(ов)\n";

        int health = army->GetHealth();
        cout << "Уровень здоровья армии: " << health;

        }
    catch (exception& ex) {
        setColor(mainColor);
        cls();
        showNavBarMessage(hintColor, "  Ошибка приложения, нажмите любую клавишу для продолжения...");

        // добавим 4 пробела перед выводимым сообщением об ошибке, длина строки 64 символа
        char buf[65];
        sprintf(buf, "    %-60s", ex.what());

        // в эту секцию передается управление оператором throw
        const char* msg[] = {
            " ",
            "    [Ошибка]",
            buf,
            " ",
            " ",
            nullptr
        };
        showMessage(8, 4, 64, msg, errColor);
    } // try-catch
    cout << endlm(2);
	return 0;
} // main

Army* createArmy(){
    Army* army = new Army;

    // Добавим в армию по 5 воинов каждой расы
    for (int i = 0; i < 5; i++) {
        army->AddUnit(new Elf());
        army->AddUnit(new Giant());
        army->AddUnit(new Gnome());
        army->AddUnit(new Human());
        army->AddUnit(new Orc());
    } // for i

    // Демонстрация добавления отряда в армию
    CompositeUnit* squad = new CompositeUnit;

   // Добавление воинов в отряд
    squad->AddUnit(new Elf());
    squad->AddUnit(new Giant());
    squad->AddUnit(new Gnome());
    squad->AddUnit(new Human());
    squad->AddUnit(new Orc());

    // Собственно добавление отряда в армию
    army->AddUnit(squad);

    // удаление отряда: 
    // army->RemoveUnit(squad);


    return army;
} // createArmy
