#pragma once
#include "ISoldier.h"


class Elf : public ISoldier
{
public:
	void fireSoldier(int index) override {}
	void addSoldier(unique_ptr<ISoldier> soldier) override {}
	
	int  getPower() override { return 5; }
	int  getHealth() override { return 2; }
};


class Orc : public ISoldier
{
public:
	void fireSoldier(int index) override {}
	void addSoldier(unique_ptr<ISoldier> soldier) override {}
	
	int getPower() override { return 8; }
	int getHealth() override { return 5; }
};


class Human : public ISoldier
{
public:
	void fireSoldier(int index) override {}
	void addSoldier(unique_ptr<ISoldier> soldier) override {}
	
	int getPower() override { return 1; }
	int getHealth() override { return 1; }
};


class Dwarf : public ISoldier
{
public:
	void fireSoldier(int index) override {}
	void addSoldier(unique_ptr<ISoldier> soldier) override {}
	
	int getPower() override { return 4; }
	int getHealth() override { return 8; }
};


class Giant: public ISoldier
{
public:
	void fireSoldier(int index) override {}
	void addSoldier(unique_ptr<ISoldier> soldier) override {}
	
	int getPower() override { return 2; }
	int getHealth() override { return 10; }
};