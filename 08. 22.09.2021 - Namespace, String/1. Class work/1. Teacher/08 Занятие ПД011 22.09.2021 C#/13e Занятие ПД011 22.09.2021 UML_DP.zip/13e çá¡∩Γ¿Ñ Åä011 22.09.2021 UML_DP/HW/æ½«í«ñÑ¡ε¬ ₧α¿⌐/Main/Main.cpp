#include "Libraries.h"
#include "Races.h"
#include "Squad.h"


int main()
{
	Utilities::init();

	unique_ptr<Squad> army(new Squad);
	
	unique_ptr<Squad> fSquad(new Squad);
	fSquad->addSoldier(make_unique<Elf>());
	fSquad->addSoldier(make_unique<Orc>());
	fSquad->addSoldier(make_unique<Giant>());
	army->addSoldier(move(fSquad));
	
	unique_ptr<Squad> sSquad(new Squad);
	sSquad->addSoldier(make_unique<Human>());
	sSquad->addSoldier(make_unique<Dwarf>());
	sSquad->addSoldier(make_unique<Elf>());
	army->addSoldier(move(sSquad));

	cout
		<< "����: " << army->getPower() << "\t"
		<< "��������: " << army->getHealth();

	Utilities::Console::switchCursorVisibility(false);
	Utilities::Console::setCoordInBottomLeft(3);
	return 0;
} 