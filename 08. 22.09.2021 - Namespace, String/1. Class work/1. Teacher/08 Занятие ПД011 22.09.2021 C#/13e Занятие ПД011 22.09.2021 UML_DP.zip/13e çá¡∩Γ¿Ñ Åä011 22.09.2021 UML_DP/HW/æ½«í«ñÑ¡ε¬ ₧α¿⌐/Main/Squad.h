#pragma once
#include "Libraries.h"
#include "ISoldier.h"


class Squad : public ISoldier
{
	deque<unique_ptr<ISoldier>> _composite;
	
public:
	void addSoldier(unique_ptr<ISoldier> soldier) override
	{
		_composite.push_back(move(soldier));
	}

	void fireSoldier(int index) override
	{		
		if (index < 0 || index >= _composite.size())
			return;

		_composite.erase(_composite.begin() + index);
	}

	
	int getPower() override
	{
		int sum = 0;
		
		for (auto& soldier : _composite)
			sum += soldier->getPower();
		
		return sum;
	}

	
	int getHealth() override
	{
		int sum = 0;

		for (auto& soldier : _composite)
			sum += soldier->getHealth();
		
		return sum;
	}
};
