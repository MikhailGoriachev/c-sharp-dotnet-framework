#pragma once


class ISoldier
{
public:
	virtual ~ISoldier() = default;

	virtual void fireSoldier(int index) = 0;
	virtual void addSoldier(unique_ptr<ISoldier> soldier) = 0;

	virtual int getPower() = 0;
	virtual int getHealth() = 0;
};
