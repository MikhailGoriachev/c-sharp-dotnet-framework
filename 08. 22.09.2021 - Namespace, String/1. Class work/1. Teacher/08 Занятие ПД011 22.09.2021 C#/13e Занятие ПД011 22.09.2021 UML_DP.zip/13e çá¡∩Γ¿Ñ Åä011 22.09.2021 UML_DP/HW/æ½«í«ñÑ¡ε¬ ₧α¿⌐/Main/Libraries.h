#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <algorithm>
#include <cassert>
#include <conio.h>
#include <corecrt_math_defines.h>
#include <cstdio>
#include <fstream>
#include <filesystem>
#include <functional>
#include <thread>
#include <future>
#include <iterator>   
#include <algorithm>  
#include <numeric>    
#include <io.h>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <Windows.h>

#include <vector>
#include <array>
#include <deque>
#include <list>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <stack>
#include <queue>

using namespace std;

#include "Variables.h"
#include "Functors.h"
#include "Utilities.h"

#include "Object.h"

#undef max
#undef min