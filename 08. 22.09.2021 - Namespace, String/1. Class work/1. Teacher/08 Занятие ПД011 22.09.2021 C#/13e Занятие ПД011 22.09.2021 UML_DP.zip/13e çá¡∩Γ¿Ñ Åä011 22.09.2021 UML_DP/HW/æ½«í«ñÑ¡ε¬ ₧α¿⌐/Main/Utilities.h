﻿#pragma once
#include "Libraries.h"


namespace Utilities
{
	using namespace Functors;

	/// Не трогать 
	static constexpr size_t GOLDEN_RATIO_INTEGRAL_PART = 0x9e3779b9;

	/// Стартовый пакет настроек
	void init();


#pragma region Генерация случайных значений


	template <typename T>
	auto getRand(T low, T high) -> enable_if_t<is_integral_v<decay_t<T>>, T>
	{
		return low + rand() % (high - low + 1);
	} // GetRand


	// Генерация чисел для вещественных типов
	template <typename T>
	auto getRand(T low, T high) -> enable_if_t<is_floating_point_v<decay_t<T>>, T>
	{
		return low + (high - low) * rand() / RAND_MAX;
	} // GetRand


#pragma endregion


	/// Получение кода любой клавиши
	unsigned char getKey();

	/// Вывод заголовка
	void printNavbar(string_view message, const ColorFunctors::Color& color);

	/// Начальный вывод
	void startOutput(string_view message);

	/// Завершающий вывод
	void endOutput();


	/// <summary>
	///		Вывод разделяющей строки в формате
	///		———————something—————
	/// </summary>
	/// <param name="message">Строка для вставки между тире</param>
	/// <param name="countOfDashes">Количество тире с обеих сторон</param>
	void outputLine(string_view message = ""sv, size_t countOfDashes = 70);


	/// Очистка буфера ввода
	void clearInputBuffer();


	///	Ввод чего-либо с оформлением
	/// <param name="inputFunc">
	///		Arg: результат проверки ввода на успешность(true - успешно)
	///		Second: строка исключения в случае неверного ввода
	/// </param>
	void input(string_view             message, const unsigned lineLength,
			   const function<void()>& inputFunc,
			   istream&                stream = cin);


#pragma region hashCombine


	template <typename Arg>
	void hashCombine(size_t& result, const Arg& arg)
	{
		hash<Arg> hasher;

		result ^= hasher(arg) + GOLDEN_RATIO_INTEGRAL_PART + (result << 6) + (result >> 2);
	} // hashCombine


	/// Обьединение хеш-кодов, код с boost::hash_combine
	template <typename Arg, typename ...Args>
	void hashCombine(size_t& result, const Arg& arg, const Args&...args)
	{
		hashCombine(result, arg);

		hashCombine(result, args...);
	} // hashCombine


#pragma endregion


	/// Получить текущую дату и время
	tm getCurrentDateAndTime();


	/// Проверка файла на открытие
	template <typename Stream>
	auto checkOpenedFile(const Stream&      fileStream,
						 const string_view& fileName) -> enable_if_t<is_base_of_v<basic_ios<char>, Stream>>
	{
		if (!fileStream.is_open())
		{
			ostringstream oss;
			oss << "Не удалось открыть файл " << fileName;
			throw runtime_error(oss.str());
		} // if
	} // CheckOpenedFile


	/// Шифровка/расшифровка строки 
	string stringCipher(string_view str);


	/// Выход из управляющего цикла
	unsigned char loopEscape(const IndentFunctor::Indent& indents = IndentFunctor::INDENT_0);


	namespace Errors
	{
		class UnexpectedBehavior final : public exception
		{
		public:
			~UnexpectedBehavior() override = default;

			const char* what() const override { return "Unexpected Behavior..."; }
		};


		/// Выбросить исключение если errno имеет код ошибки
		void throwIfErrno(const error_condition& error);


		/// Вывод ошибки
		void errorOutput(string_view                  error, bool isPause,
						 const IndentFunctor::Indent& indent = IndentFunctor::INDENT_3);

		/// Вывод исключения
		void exceptionOutput(const exception&             ex, bool isPause,
							 const IndentFunctor::Indent& indent = IndentFunctor::INDENT_3);
	} // Errors


	namespace Pointers
	{
		/// Очистка обычного указателя
		template <typename T, typename = enable_if_t<is_pointer_v<T>>>
		void resetPointer(T*& ptr)
		{
			// Если в указателе что-то есть
			if (ptr != nullptr)
			{
				// Освобождаем указатель
				delete ptr;
				ptr = nullptr;
			} // if
		} // ResetPointer

		/// Очистка массива
		template <typename T, typename = enable_if_t<is_pointer_v<T>>>
		void resetArrayPointer(T*& ptr)
		{
			if (ptr != nullptr)
			{
				delete[] ptr;
				ptr = nullptr;
			} // if
		} // ResetArrayPointer

		/// Очиста указателей в массиве
		template <typename T, typename = enable_if_t<is_pointer_v<T>>>
		void resetPointersInArray(T*& ptr, int arrLen)
		{
			if (ptr != nullptr)
			{
				// Освобождаем указатели в массиве
				for (int i = 0; i < arrLen; i++)
					delete ptr[i];

				// Освобождаем указатель на массив указателей
				delete[] ptr;
				ptr = nullptr;
			} // if
		} // ResetPointersInArray
	} // Pointers


	namespace Console
	{
		CONSOLE_SCREEN_BUFFER_INFO getCsbi();

		/// <summary>
		///		Перенос курсора в левый нижний угол
		/// </summary>
		/// <param name="indent">Отступ снизу</param>
		void setCoordInBottomLeft(unsigned short indent);

		/// Получение ткущей координаты курсора
		COORD getCoord();

		/// Получить цвет в текущей позиции курсора
		WORD getColorOfCoord(const COORD& readFrom);

		/// Получить центральную позицию
		COORD getCenter();

		/// Сделать отступы от текущей координаты и вернуться обратно
		void makeIndent(const IndentFunctor::Indent& indent = IndentFunctor::INDENT_5);

		/// Переключить видимость курсора
		void switchCursorVisibility(bool mode);

		/// Очистка консоли
		void clear();

		/// Пауза консоли
		void pause();
	} // Console


	namespace Files
	{
#pragma region writeBinaryFile


		template <typename Stream, typename Current>
		auto serializeFundamentals(Stream& stream, const Current& current) ->
		enable_if_t<is_base_of_v<basic_ios<char>, Stream>>
		{
			stream.write(reinterpret_cast<const char*>(&current), sizeof current);
		} // serializeFundamentals


		template <typename Stream, typename Current, typename ...Others>
		auto serializeFundamentals(Stream&          stream, const Current& current,
								   const Others& ...others) ->
		enable_if_t<is_base_of_v<basic_ios<char>, Stream>>
		{
			serializeFundamentals(stream, current);

			serializeFundamentals(stream, others...);
		} // serializeFundamentals


		template <typename Stream>
		auto serializeString(Stream& stream, const string& input) ->
		enable_if_t<is_base_of_v<basic_ios<char>, Stream>>
		{
			// Шифрование входной строки
			string encrypted = stringCipher(input);

			// Запись размера строки в файл
			serializeFundamentals(stream, encrypted.size());

			// Запись зашифрованной строки в файл
			stream.write(encrypted.c_str(), encrypted.size());
		} // serializeString


		template <typename Stream>
		auto serializeString(Stream&                                  stream,
							 deque<reference_wrapper<const string>>&& strings) ->
		enable_if_t<is_base_of_v<basic_ios<char>, Stream>>
		{
			for (; !strings.empty(); strings.pop_front())
				serializeString(stream, strings.front());
		} // serializeString


#pragma endregion


#pragma region readBinaryFile


		template <typename Stream, typename Current>
		auto deserializeFundamentals(Stream& stream, Current& current) ->
		enable_if_t<is_base_of_v<basic_ios<char>, Stream>>
		{
			stream.read(reinterpret_cast<char*>(&current), sizeof current);
		} // deserializeFundamentals


		template <typename Stream, typename Current, typename ...Others>
		auto deserializeFundamentals(Stream&    stream, Current& current,
									 Others& ...others) ->
		enable_if_t<is_base_of_v<basic_ios<char>, Stream>>
		{
			deserializeFundamentals(stream, current);

			deserializeFundamentals(stream, others...);
		} // deserializeFundamentals


		template <typename Stream>
		auto deserializeString(Stream& stream, string& input) ->
		enable_if_t<is_base_of_v<basic_ios<char>, Stream>>
		{
			// Чтение размера строки 
			size_t size {};
			deserializeFundamentals(stream, size);

			// Чтение зашифрованной строки
			string encrypted(size, 0);
			stream.read(encrypted.data(), size);

			// Возврат расшифрованной строки
			input = stringCipher(encrypted);
		} // deserializeString


		template <typename Stream>
		auto deserializeString(Stream&                            stream,
							   deque<reference_wrapper<string>>&& strings) ->
		enable_if_t<is_base_of_v<basic_ios<char>, Stream>>
		{
			for (; !strings.empty(); strings.pop_front())
				deserializeString(stream, strings.front());
		} // deserializeString


#pragma endregion
	} // Files
} // Utilities
