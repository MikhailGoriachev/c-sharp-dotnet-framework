﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Задача 2. Пеший туристический маршрут для информационной системы описывается следующим образом:
название начального пункта маршрута;
название конечного пункта маршрута;
буквенно-цифровой код маршрута
протяженность маршрута в километрах.
Определите свойства в классе, методы для вывода данных о маршруте в консоль. Для туристической фирмы, имеющей название и хранящей сведения о 10 маршрутах реализовать обработки:
Начальное формирование массива маршрутов;
Вывод данных фирмы в консоль
Упорядочивание маршрутов по
Коду маршрута
Начальному пункту маршрута
Убыванию протяженности маршрута
Выбрать в массив и вывести в консоль маршруты, протяженность которых, попадает в заданный диапазон. Диапазон формируйте при помощи генератора случайных чисел
Выбрать в массив и вывести в консоль маршруты, начинающиеся или завершающиеся в заданном пункте. Название пункта вводить при помощи InputBox из класса Interaction
*/
namespace HW_CLASS
{
    public class TransportCompany
    {
        public string Title { get; set; }
        public Route[] routes { get; set; }

        public void InitRoutes() {
            Title = $"ООО Транспортная компания \"Комфорт\"\n\t    Данные о маршрутах на {DateTime.Now:d}";
            routes = new[]
            {
                //Изивините,не увидел что надо было пеший маршрут
                new Route{Start = "Енакиево",End = "Горловка",Code = "А230Б",Len = 25.2},
                new Route{Start = "Дебальцево",End = "Донецк",Code = "АВ302",Len = 70.5},
                new Route{Start = "Снежное",End ="Торез",Code = "ВС300",Len = 30d },
                new Route{Start = "Донецк",End ="Ростов",Code="СВ20А",Len = 550d},
                new Route{Start = "Ясиноватая",End = "Донецк",Code = "СВ045",Len = 40d },
                new Route{Start = "Краснодар",End = "Горловка",Code = "АБ202",Len = 724.5 },
                new Route{Start = "Москва",End ="Воронеж",Code ="ВА111",Len = 800d },
                new Route{Start = "Горловка",End ="Луганск",Code ="ГЛ311",Len = 110d},
                new Route{Start = "Харцызк",End = "Донецк",Code ="ХД112",Len = 35.7},
                new Route{Start = "Зуевка",End ="Зугрес",Code = "ЗГ221",Len = 15.4 }

            };
        
        
        }

        //Компораторы для сортировки по заданию

        public void OrderByCode() =>
            Array.Sort(routes, Route.CodeComp); //по коду

        public void OrderByStart() =>
            Array.Sort(routes, Route.StartComp); //по началу маршрута

        public void OrderByLen() =>
            Array.Sort(routes, Route.LenComp); //по протяженности

        //по заданному диапозону протяженности
        public Route[] lenRange(double a,double b) {

            bool LenRangePerdicate(Route r) => a <= r.Len && r.Len <= b;
            Route[] selected = Array.FindAll(routes, LenRangePerdicate);
            return selected;
        }

        //по пункту начала или завершения маршрута
        public Route[] StationRange(string s)
        {
            bool StationPerdicate(Route r) => r.Start == s || r.End == s;
            Route[] selected = Array.FindAll(routes, StationPerdicate);
            return selected;
        }


        // Вывести массив маршуртов в консоль
        public void Show(string caption, int indent)
        {
            // вывод заголовка таблицы 
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Route.Header(indent)}");

            // вывод всех элементов массива 
            int row = 1;
            void OutItem(Route p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");

            Array.ForEach(routes, OutItem);

            Console.WriteLine(Route.Footer(indent));

        } // Show

        // Вывести массив отобранных маршуртов в консоль.
        public void Show(string caption, int indent, Route[] e1)
        {
            // вывод заголовка таблицы 
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Route.Header(indent)}");

            // вывод всех элементов массива 
            int row = 1;
            void OutItem(Route p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(e1, OutItem);

            Console.WriteLine(Route.Footer(indent));

        } // Show
    }
}
