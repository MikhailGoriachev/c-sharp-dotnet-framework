﻿using System;

namespace HW_CLASS
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        // объект для получения случайных чисел
        public static Random Random = new Random();
        
        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo)*Random.NextDouble();
        
        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line) {
            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;
            ConsoleColor oldFgColor = Console.ForegroundColor;

            // при выводе немного используем методы класса string :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
            Console.ForegroundColor = oldFgColor;
        } // ShowNavBarTask
        
        
        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor color) {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // Вывод меню приложения
        public static void ShowMenu(int x, int y, string title, MenuItem[] menu) {
            WriteXY(x, y, title, ConsoleColor.Red);
            int offsetY = 2;

            foreach (var menuItem in menu) {
                WriteXY(x, y + offsetY, menuItem.HotKey.ToString(), ConsoleColor.Red);
                WriteXY(x + 2, y + offsetY++, menuItem.Text, ConsoleColor.Blue);
            } // foreach menuItem
        } // ShowMenu

        // Вывод сообщения "Метод в разработке" по центру экрана
        public static void ShowUnderConstruction() {
            (ConsoleColor fg, ConsoleColor bg) = (Console.ForegroundColor, Console.BackgroundColor); 
            (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);

            string[] lines = { 
                 " ".PadRight(40),
                 " ".PadRight(40),
                 "     [К сведению]".PadRight(40),
                 " ".PadRight(40),
                 "     Метод в разработке".PadRight(40),
                 " ".PadRight(40),
                 " ".PadRight(40),
            };

            int x = (Console.WindowWidth - 40) / 2;
            int y = (Console.WindowHeight - lines.Length) / 2;
            foreach(var line in lines)
                WriteXY(x, y++, line, ConsoleColor.DarkGray);

            (Console.ForegroundColor, Console.BackgroundColor) = (fg, bg);
            Console.SetCursorPosition(0, Console.WindowHeight-1);
        } // ShowUnderConstruction
        

        //Строка ввода для double
        public static double InputDouble(int x, int y, string prompt)
        {
            // сохранить цвета консоли
            ConsoleColor bgColor = Console.BackgroundColor;
            ConsoleColor fgColor = Console.ForegroundColor;
            bool result;
            double value = 0;

            // отобразить курсор для удобства ввода 
            Console.CursorVisible = true;

            do
            {
                // вывод подсказки
                Console.BackgroundColor = bgColor;
                WriteXY(x, y, prompt, fgColor);

                // вывод имитации строки ввода 
                Console.BackgroundColor = ConsoleColor.Gray;
                WriteXY(x + prompt.Length + 1, y, " ".PadRight(20), Console.ForegroundColor);

                // собственно ввод
                Console.ForegroundColor = ConsoleColor.Black;
                Console.SetCursorPosition(x + prompt.Length + 2, y);
                result = double.TryParse(Console.ReadLine(), out value);
            } while (!result);

            // восстановить цвет консоли, спрятать текстовый курсор
            Console.ForegroundColor = fgColor;
            Console.BackgroundColor = bgColor;
            Console.CursorVisible = false;
            return value;
        } // InputDouble
          //
          
        //строка ввода для string
         public static string InputString(int x, int y, string prompt)
        {
            // сохранить цвета консоли
            ConsoleColor bgColor = Console.BackgroundColor;
            ConsoleColor fgColor = Console.ForegroundColor;
           

            // отобразить курсор для удобства ввода 
            Console.CursorVisible = true;

           
                // вывод подсказки
                Console.BackgroundColor = bgColor;
                WriteXY(x, y, prompt, fgColor);

                // вывод имитации строки ввода 
                Console.BackgroundColor = ConsoleColor.Gray;
                WriteXY(x + prompt.Length + 1, y, " ".PadRight(20), Console.ForegroundColor);

                // собственно ввод
                Console.ForegroundColor = ConsoleColor.Black;
                Console.SetCursorPosition(x + prompt.Length + 2, y);
                string str = Convert.ToString(Console.ReadLine());
            

            // восстановить цвет консоли, спрятать текстовый курсор
            Console.ForegroundColor = fgColor;
            Console.BackgroundColor = bgColor;
            Console.CursorVisible = false;
            return str;
        } // InputDouble
    } // class Utils
}