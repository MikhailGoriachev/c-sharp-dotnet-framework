﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
/**/

namespace HW_CLASS
{
    public partial class App
    {
       private Company company; //обьект для торогвой компании
       private TransportCompany _routes; //обьект для транспортной компании

        public App(): this(new Company(),new TransportCompany())
        {
            company.Initialize();
            _routes.InitRoutes();
        }

        public App(Company c,TransportCompany t)
        {
            company = c;
            _routes = t;
        }

        //создание и вывод данных о сотрудника комании
        public void InitCompany()
        {
           
            company.Show("Данные сформированны", 12);


        }

        //сортировка сотрудников по алфавиту
        public void SortCompanyByName()
        {
            company.OrderByName();
            company.Show("Данные сформированны", 12);
        }

        //сортировка сотрудников по году начала работы(по убыванию)
        public void SortCompanyByYear()
        {
            company.OrderByYear();
            company.Show("Данные сформированны", 12);
        }


        //сортировка сотрудников по должности
        public void SortCompanyByPos()
        {
            company.OrderByPos();
            company.Show("Данные сформированны", 12);
        }


        //Отбор сотрудников  по диапазону (зарплата)
        public void SalaryRange()
        {
           
            double s = Utils.InputDouble(12, 6,"Введите стартовое значение :");
            double e = Utils.InputDouble(12, 6,"Введите конечное значение :");
            
            Employee[] e1 = company.FindRangeSalary(s, e);
            company.Show("Данные сформированны", 12, e1);
           
        }

        //Отбор сотрудников по должности
        public void PosFind()
        {

            string p = Utils.InputString(12, 6, "Введите должность для поиска :");

            Employee[] e1 = company.FindPos(p);
            company.Show("Данные сформированны", 12, e1);
            
        }


        
    }
}
