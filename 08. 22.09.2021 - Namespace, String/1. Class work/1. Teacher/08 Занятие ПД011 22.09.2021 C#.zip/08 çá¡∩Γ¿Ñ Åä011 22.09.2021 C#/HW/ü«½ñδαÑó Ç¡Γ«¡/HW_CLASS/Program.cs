﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Microsoft.VisualBasic;

/*Разработайте консольное приложение для решения следующих задач. Используйте простое меню для выбора заданий по обработке. При ошибках в выполняемых заданиях обрабатывайте исключения. В классе App разместите методы решения каждой задачи в частичный тип. По возможности используйте элвис-оператор и оператор null-объединения 
Задача 1. Работник некоторого предприятия для информационной системы представляется классом с полями:
фамилия и инициалы работника;
название занимаемой должности;
год поступления на работу
оклад.
Определите свойства в классе, методы для вывода данных о работнике в консоль. Для предприятия, размещенного в заданном городе и хранящего сведения о 12 работниках реализовать обработки:
Начальное формирование массива работников;
Вывод данных предприятия в консоль
Упорядочивание работников по
Алфавиту
Должности
Убыванию стажа работы
Выбрать в массив и вывести в консоль работников, оклад которых, попадает в заданный диапазон
Выбрать в массив и вывести в консоль работников с заданной должностью
Задача 2. Пеший туристический маршрут для информационной системы описывается следующим образом:
название начального пункта маршрута;
название конечного пункта маршрута;
буквенно-цифровой код маршрута
протяженность маршрута в километрах.
Определите свойства в классе, методы для вывода данных о маршруте в консоль. Для туристической фирмы, имеющей название и хранящей сведения о 10 маршрутах реализовать обработки:
Начальное формирование массива маршрутов;
Вывод данных фирмы в консоль
Упорядочивание маршрутов по
Коду маршрута
Начальному пункту маршрута
Убыванию протяженности маршрута
Выбрать в массив и вывести в консоль маршруты, протяженность которых, попадает в заданный диапазон. Диапазон формируйте при помощи генератора случайных чисел
Выбрать в массив и вывести в консоль маршруты, начинающиеся или завершающиеся в заданном пункте. Название пункта вводить при помощи InputBox из класса Interaction
*/

namespace HW_CLASS
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Демонстрация сотрудников комании" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Демонстрация сортировки сотрудников алфавиту" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Демонстрация сортировки сотрудников по должности" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Демонстрация сортировки сотрудников по убыванию стажа работы" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Отбор в массив сотрудников,оклад которых попадает в заданный диапазон" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Отбор в массив сотрудников с заданной должностью" },
                 //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Формирование данных траснпортной компании" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Сортировка данных по коду маршрута" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Cортировка данных по началу маршрута" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Cортировка данных по убыванию протяженности маршрута" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Выбрать в массив и вывести в консоль маршруты, протяженность которых, попадает в заданный диапазон" },
                new MenuItem { HotKey = ConsoleKey.H, Text = "Выбрать в массив и вывести в консоль маршруты, начало или конец которых совпадает с запросом" },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            App app = new App();
            
            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.White);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# ");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                    
                   
                   

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Blue, ConsoleColor.White);
                    Console.Clear();

                    switch (key)
                    {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1
                        // Демонстрация сотрудников комании
                        case ConsoleKey.Q:
                            app.InitCompany();
                            break;

                        // Демонстрация сортировки сотрудников алфавиту
                        case ConsoleKey.W:
                            Utils.ShowNavBarTask("  Демонстрация сортировки сотрудников алфавиту");
                            app.SortCompanyByName();
                            break;


                        // Демонстрация сортировки сотрудников по должности
                        case ConsoleKey.E:
                            Utils.ShowNavBarTask(" Демонстрация сортировки сотрудников по должности");
                            app.SortCompanyByPos();
                            break;

                        // Демонстрация сортировки сотрудников по убыванию стажа работы
                        case ConsoleKey.R:
                            Utils.ShowNavBarTask("Демонстрация сортировки сотрудников по убыванию стажа работы");
                            app.SortCompanyByYear();
                            break;

                        // Отбор в массив сотрудников,оклад которых попадает в заданный диапазон
                        case ConsoleKey.T:
                            Utils.ShowNavBarTask("Отбор в массив сотрудников,оклад которых попадает в заданный диапазон");
                            app.SalaryRange();
                            break;
                        // Отбор в массив сотрудников с заданной должностью
                        case ConsoleKey.Y:
                            Utils.ShowNavBarTask("Отбор в массив сотрудников с заданной должностью");
                            app.PosFind();
                            break;
                        case ConsoleKey.A:
                            Utils.ShowNavBarTask("Формирование данных траснпортной компании");
                            app.RouteShow();
                            break;  
                        case ConsoleKey.S:
                            Utils.ShowNavBarTask("Сортировка данных по коду маршрута");
                            app.SortByCode();
                            break;
                            
                        case ConsoleKey.D:
                            Utils.ShowNavBarTask("Cортировка данных по началу маршрута");
                            app.SortByStart();
                            break; 
                        case ConsoleKey.F:
                            Utils.ShowNavBarTask("Cортировка данных по убыванию протяженности маршрута");
                            app.SortByLen();
                            break;
                        case ConsoleKey.G:
                            Utils.ShowNavBarTask("Выбрать в массив и вывести в консоль маршруты, протяженность которых, попадает в заданный диапазон");
                            app.RangeLen();
                            break;
                        case ConsoleKey.H:
                            Utils.ShowNavBarTask("Выбрать в массив и вывести в консоль маршруты, начало или конец которых совпадает с запросом");
                            app.RangeStation();
                            break;




                        // Выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.ReadKey(true);
                } // try
            
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
    }
}
