﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
//Для методов класса транспортная компания
namespace HW_CLASS
{
    public partial class App
    {
        public Random r = new Random();
        //вывод маршрутов
        public void RouteShow()
        {
            
            _routes.Show("Данные сфрмированны", 12);
        }
        //сортировка по коду
        public void SortByCode()
        {
            _routes.OrderByCode();
            _routes.Show("Данные сформированны", 12);
        }
        //сортировка по началу маршрута
        public void SortByStart()
        {
            _routes.OrderByStart();
            _routes.Show("Данные сформированны", 12);
        }

        //соритровка по проятженности
        public void SortByLen()
        {
            _routes.OrderByLen();
            _routes.Show("Данные сформированны", 12);
        }
        //Выбрать в массив и вывести в консоль маршруты, протяженность которых, попадает в заданный диапазон. Диапазон формируйте при помощи генератора случайных чисел
        public void RangeLen()
        {
            double d = r.Next(10, 300) + r.NextDouble();
            double s = r.Next(300, 1000) + r.NextDouble();
            Route[] r1 = _routes.lenRange(d,s);
            _routes.Show($"Данные сформированны в диапозоне от {d:n2} до {s:n2}", 12, r1);
        }
        //Выбрать в массив и вывести в консоль маршруты, начинающиеся или завершающиеся в заданном пункте. Название пункта вводить при помощи InputBox из класса Interaction

        public void RangeStation()
        {
            string msg = "";
            msg = Interaction.InputBox("Введите город",msg);
            Route[] r1 = _routes.StationRange(msg);
            _routes.Show($"Данные сформированны по запросу {msg}", 12, r1);
            //Console.ReadKey();
        }

    }
}
