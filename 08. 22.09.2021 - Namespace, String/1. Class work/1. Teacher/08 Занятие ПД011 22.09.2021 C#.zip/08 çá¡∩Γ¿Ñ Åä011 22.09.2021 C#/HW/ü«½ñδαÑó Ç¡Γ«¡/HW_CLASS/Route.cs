﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_CLASS
{
    public class Route
    {
        //начало маршрута
        private string _start;

        public string Start
        {
            get => _start;
            set => _start = value ?? throw new NullReferenceException("Отсутствие значения в поле \"Cтарт маршрута\"");
        }

        //конец маршрута
        private string _end;

        public string End
        {
            get => _end;
            set => _end = value ?? throw new NullReferenceException("Отсутствие значения в поле \"Конец маршрута\"");
        }

        //буквенно-цифровой код маршрута
        private string _code;

        public string Code
        {
            get => _code;
            set => _code = value ?? throw new NullReferenceException("Отсутствие значения в поле \"Код маршрута\"");
        }

        //длина маршрута в км
        private double _lenght;

        public double Len
        {
            get => _lenght;
            set => _lenght = value;
        }

        public Route():this("Горловка","Донецк","0АН200",60){}

        public Route(string s,string e,string c,double l)
        {
            _start = s;
            _end = e;
            _code = c;
            _lenght = l;

        }



        //компоратор для упорядочивания по коду маршрута
        public static int CodeComp(Route r1, Route r2) =>
            r1._code.CompareTo(r2._code);

        //компоратор для упорядочивания по начальному пункту маршрута
        public static int StartComp(Route r1, Route r2) =>
            r1._start.CompareTo(r2._start);

        //компоратор для упорядочивания по убыванию протяженности маршрута
        public static int LenComp(Route r1, Route r2) =>
            r2._lenght.CompareTo(r1._lenght);

        // Вывод строкового представления объекта
        public override string ToString() => $"Начало маршрута: {_start}\nКонец маршрута : {_end}\nКод маршрута : {_code}\nПротяженность : {_lenght} км";



        // формирование строки таблицы для представления объекта 
        public string ToTableRow(int rowNumber)
        {
            
            return $"│ {rowNumber,3} │ {_start,18} │ {_end,15} │ {_code,15} " +
            $"│ {_lenght,12:n2} │";
        } // ToTableRow

        // статический метод для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬────────────────────┬─────────────────┬─────────────────┬──────────────┐\n" +
                $"{spaces}│  №  │   Начало маршрута  │  Конец маршрута │   Код маршрута  │ Протяженность│\n" +
                $"{spaces}│ п/п │                    │                 │                 │   км         │\n" +
                $"{spaces}├─────┼────────────────────┼─────────────────┼─────────────────┼──────────────┤\n";
            return str;
        } // Header


        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴────────────────────┴─────────────────┴─────────────────┴──────────────┘";

    }
}
