﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*Определите свойства в классе, методы для вывода данных о работнике в консоль. Для предприятия, размещенного в заданном городе и хранящего сведения о 12 работниках реализовать обработки:
Начальное формирование массива работников;
Вывод данных предприятия в консоль
Упорядочивание работников по
Алфавиту
Должности
Убыванию стажа работы
Выбрать в массив и вывести в консоль работников, оклад которых, попадает в заданный диапазон
Выбрать в массив и вывести в консоль работников с заданной должностью
*/
namespace HW_CLASS
{
    public class Company
    {

        public string Title { get; set; }

        public Employee[] _employees { get; set; }

        public bool Empty => _employees.Length == 0;


        //инициилизация массива
        public void Initialize()
        {
            Title =  $"ООО Торговая компания \"Сапфир\"\n\t    Данные о сотрудниках на {DateTime.Now:d}";
            _employees = new[] {
                new Employee { Name = "Филатов А.Ю.", Position = "Уборщик", Year = 2010, Salary = 25000d },
                new Employee { Name = "Андропова К.В.", Position = "Секретарь", Year = 2006, Salary = 45500d },
                new Employee { Name = "Спекторенко И.Д.", Position = "Менеждер по продажам", Year = 2014, Salary = 89000d },
                new Employee { Name = "Морозов Р.Н.", Position = "Супервайзер", Year = 2009, Salary = 62000d },
                new Employee { Name = "Степанова Ю.А.", Position = "Уборщица", Year = 2014, Salary = 25000d },
                new Employee { Name = "Расколин С.В.", Position = "Главный бухгалтер", Year = 2006, Salary = 110000d },
                new Employee { Name = "Фролов Р.Л.", Position = "Менеждер по рекламе", Year = 2017, Salary = 75000d },
                new Employee { Name = "Кузьмин В.И.",Position = "Инженер по оборудованию",Year = 2019,Salary = 76000d},
                new Employee { Name = "Кулиш Д.А.",Position = "Товаровед",Year = 2012,Salary = 75000d},
                new Employee { Name = "Орлов Д.И.",Position = "Экономист по труду",Year = 2019, Salary = 90000d},
                new Employee { Name = "Ровенский Б.Ю.",Position = "Инженер по транспорту",Year = 2010,Salary = 90000d},
                new Employee { Name = "Лабунская А.Л.",Position ="Директор",Year = 2006,Salary = 200000d}

            };
        }

        //Упорядочить по алфавиту
        public void OrderByName() => Array.Sort(_employees, Employee.NameComp);


        //Упорядочить по должности
        public void OrderByPos() => Array.Sort(_employees, Employee.PosComp);

        //Упорядочить по убыванию стажа работы
        public void OrderByYear() => Array.Sort(_employees, Employee.YearComp);

        // Вывести массив персон в консоль
        public void Show(string caption, int indent)
        {
            // вывод заголовка таблицы персон
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Employee.Header(indent)}");

            // вывод всех элементов массива персон
            int row = 1;
            void OutItem(Employee p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            
            Array.ForEach(_employees, OutItem);
           
        } // Show

        // Вывести массив отобранных сотрудников в консоль.
        public void Show(string caption, int indent,Employee[] e1)
        {
            // вывод заголовка таблицы персон
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Employee.Header(indent)}");

            // вывод всех элементов массива персон
            int row = 1;
            void OutItem(Employee p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(e1 ,OutItem);

         
        } // Show

        public Employee[] FindRangeSalary(double a,double b)
        {
            bool RangeSalaryPerdicate(Employee e) =>a<= e.Salary && e.Salary <= b;
            Employee[] selected = Array.FindAll(_employees, RangeSalaryPerdicate);
            return selected;
        } 
        public Employee[] FindPos(string p)
        {
            bool RangeSalaryPerdicate(Employee e) =>e.Position == p;
            Employee[] selected = Array.FindAll(_employees, RangeSalaryPerdicate);
            return selected;
        }
    }

}
