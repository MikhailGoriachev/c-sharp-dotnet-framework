﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * Работник некоторого предприятия для информационной системы представляется классом с полями:
    фамилия и инициалы работника;

    название занимаемой должности;

    год поступления на работу

    оклад.
*/
namespace HW_CLASS
{
    public class Employee
    {

        //фамилия и инициалы сотрудника 
        private string _name;
        public string Name { get => _name; set => _name = value ?? throw new NullReferenceException("Иницалы сотрудника пусты!"); }

        //должность
        private string _position;
        public string Position { get => _position; set => _position = value ?? throw new NullReferenceException("Строка должности в анкете сотрудника пуста!"); }

        //год поступления на работу
        private int _year;
        public int Year { get => _year; set => _year = value<2005
                ?throw new EmployeeException("Год поступления сотрудника на должность раньше чем была основана компания!")
                :value; }

        //оклад (в рублях)
        private double _salary;
        public double Salary { get => _salary; set => _salary = value <=0
                ?throw new EmployeeException("Неправильное значение в поле зарпалата!")
                :value; }

        //конструкторы
        public Employee() : this("Федоров.А.А", "Охранник", 2008, 35000d){}

        public Employee(string name ,string pos,int year,double salary)
        {
            _name = name;
            _position = pos;
            _year = year;
            _salary = salary;
        }


        //компоратор длля упорядочивания по году начала работы
        public static int YearComp(Employee e1, Employee e2) =>
            e2._year.CompareTo(e1._year);

        //компоратор для сортировки по алфавиту
        public static int NameComp(Employee e1, Employee e2) =>
            e1._name.CompareTo(e2._name);

        //компоратор для сортировки по должности
        public static int PosComp(Employee e1, Employee e2) =>
            e1._position.CompareTo(e2._position);

        // Вывод строкового представления объекта
        public override string ToString() => $"ФИО : {_name}\nДолжность : {_position}\nГод начала работы : {_year}\nОклад : {_salary} руб";

        // представление объекта в виде строки таблицы
        public string ToTableRow(int rowNumber)
        {
            return $"│ {rowNumber,3} │\tФИО                 │ {_name,-27}     │ \n\t    │\t  │\tДолжность           │ {_position,-27}     │" +
            $" \n\t    │\t  │\tГод                 │ {_year,-27}     │  \n\t    │\t  │\tОклад               │ {_salary:n2}руб {"│",20}" +
            $"\n            ┼─────┼─────────────────────────┼─────────────────────────────────┼" ;

        }



        // статический метод для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬─────────────────────────┬─────────────────────────────────┬\n" +
                $"{spaces}│  №  │   Поля                  │     Данные о сотруднике         │\n" +
                $"{spaces}│ п/п │                         │                                 │\n" +
                $"{spaces}├─────┼─────────────────────────┼─────────────────────────────────┼\n";
            return str;
        } // Header

       
        
  
     



    }
}
