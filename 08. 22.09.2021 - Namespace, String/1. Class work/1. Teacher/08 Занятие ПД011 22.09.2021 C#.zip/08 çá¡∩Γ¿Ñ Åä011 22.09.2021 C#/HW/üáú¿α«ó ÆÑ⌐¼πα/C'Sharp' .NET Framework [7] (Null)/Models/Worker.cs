﻿using System;

namespace C_Sharp_.NET_Framework__7___Null_.Models
{
    public class Worker
    {
        private string _fio;           // фамилия и инициалы
        private string _jobPosition;  // должность 
        private int _yearReceipts;   // год поступления на работу
        private double _salary;     // оклад

        // ------------ Константные значения ------------
        private const int MinReceiptsYear = 1970; 
            public const int MaxReceiptsYear = 2021; 
            public const double MinSalary = 10_000d; 
            public const double MaxSalary = 100_000d; 
        // ----------------------------------------------
        Worker(string fio, string jobPosition,int yearReceipts,double salary)
        {
            Fio = fio;
            JobPosition = jobPosition;
            YearReceipts = yearReceipts;
            Salary = salary;
        }

        // Свойство Фамилия и инициалы работника
        public string Fio
        {
            get => _fio;
            set {
                if (string.IsNullOrWhiteSpace(value)) throw new Exception("Worker: Неверные данные :(");
                _fio = value;
            }
        } // Fio

        // Свойство должность работника
        public string JobPosition
        {
            get => _jobPosition;
            set
            {
                if (string.IsNullOrWhiteSpace(value)) throw new Exception("Worker: Неверные данные :(");
                _jobPosition = value;
            }
        } // JobPosition

        // Свойство год поступления работника на работу
        public int YearReceipts
        {
            get => _yearReceipts;
            set{
                if(value < 1930) throw new Exception("Worker: Неверные данные :(");
                _yearReceipts = value;
            }
        } // YearReceipts

        public double Salary
        {
            get => _salary;
            set {
                // Источник (минимальная зарплата в ДНР):
                // https://dnrsovet.su/minimalnyj-razmer-oplaty-truda-v-respublike-povyshen-do-7-460-rublej/
                if (value < 7460d) throw new Exception("Worker: Неверные данные :(");
                _salary = value;

            }
        } // Salary

        public override string ToString() => $" Фамилия и инициалы: {Fio}\n Должность: {JobPosition}\n" +
            $" Год поступления на работу: {YearReceipts}\n Оклад: {Salary}";

        public string ToTableRow(int index) => $"| {index,3} | {Fio,-19} | {JobPosition,-23} | " +
            $"{YearReceipts,10} | {Salary,11:n3} | {WorkExperience(),11} |";

        // Вычисление стажа работы |можно ли сделать свойством, а не методом?|
        public int WorkExperience() => DateTime.Now.Year - YearReceipts;




        public static string Header() =>
                "\t┌─────┬─────────────────────┬─────────────────────────┬────────────┬─────────────┬─────────────┐\n" +
                "\t│  №  │       Фамилия       │        Должность        │ Год найма  │    Оклад    │    Стаж     │\n" +
                "\t│ п/п │     и инициалы      │        работника        │ на работу  │  работника  │   работы    │\n" +
                "\t├─────┼─────────────────────┼─────────────────────────┼────────────┼─────────────┼─────────────┼";

        public static string Footer() => "\t└─────┴─────────────────────┴─────────────────────────┴────────────┴─────────────┴─────────────┘\n";

        public static Worker Generate()
        {
            // Массив для генерации случайной фамилии и инициалов
            string[] name = { "Смирнова В. А.", "Алексеева Е. З.", "Комаров С. М.", "Гусев Г. И.", "Попова А. П.",
            "Павлова В. С.","Павлова В. С.","Черняева С. К.","Макарова С. Р.","Морозов Я. И.",
            "Логинова Т. В.","Федосеева Е. М.","Яшина К. М.","Козлова М. Д.","Карпов Е. Д.","Хохлов И. Т."};
            // Массив для случайной генерации должности работника
            // Список должностей взять отсюда: https://www.kaus-group.ru/researches/111
            // Размер массива фамилий и инициалов
            int n_Name = name.Length;
            
            string[] position = { "HTML-верстальщик", "Программист JavaScript", "Web-дизайнер",
                "Программист PHP", "Системный аналитик" };
            // Размер массива должностей
            int n_Position = position.Length;

            return new Worker(name[Utils.GetRandom(0, n_Name-1)], position[Utils.GetRandom(0, n_Position-1)],
                   Utils.GetRandom(MinReceiptsYear, MaxReceiptsYear),Utils.GetRandom(MinSalary, MaxSalary));

        } // Generate

        // Сортировка работников по алфавиту
        public static int SortByFio(Worker wr1, Worker wr2) =>
            wr1.Fio.CompareTo(wr2.Fio);

        // Сортировка работников по должности
        public static int SortByJobPosition(Worker wr1, Worker wr2) =>
            wr1.JobPosition.CompareTo(wr2.JobPosition);

        // Сортировка работников по убыванию стажа работы
        public static int SortByDecreasingWorkExperience(Worker wr1, Worker wr2) =>
            wr2.WorkExperience().CompareTo(wr1.WorkExperience());

    }


}

