﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Sharp_.NET_Framework__7___Null_.Models;

namespace C_Sharp_.NET_Framework__7___Null_
{
    public partial class App
    {
       
        #region Реализация частичных методов
        // Формирование массива работников для обработки по заданию
        partial void WorkersInitialize(){

             _enterprises.Initializer();
             _enterprises.Show("Массив работников сформирован");
         } // WorkersInitialize

        // Вывод массива работников
        partial void WorkersShow()
        {
            _enterprises.Show("Массив работников");
        } // WorkersShow

        // Упорядочить массив работников по алфавиту
        partial void WorkersOrderByAlphabet()
        {
            _enterprises.OrderByFio();
            _enterprises.Show("Массив работников отсортирован по алфавиту");
        } // WorkersOrderByAlphabet  

        // Упорядочить массив работников по должности
        partial void WorkersOrderByJobPosition()
        {
            _enterprises.OrderByJobPosition();
            _enterprises.Show("Массив работников отсортирован по должности");
        } // WorkersOrderByJobPosition


        partial void WorkersOrderByDecreasingWorkExperience()
        {
            _enterprises.OrderByDecreasingWorkExperience();
            _enterprises.Show("Массив работников отсортирован по убыванию стажа работы");
        } // WorkersOrderByDecreasingWorkExperience

        // Запись работников в отдельный массив, поподающие в диапозон по своему окладу
        partial void WorkersFindSalary()
        {
            bool flag;

            _enterprises.Show();

            Console.Write("\n      Введите минимальное значение оклада для отбора работников: ");
            flag = double.TryParse(Console.ReadLine(), out double lo);
            if (!flag) throw new Exception("App: Введенны неверные данные");

            Console.Write("\n      Введите максимальное значение оклада для отбора работников:");
            flag = double.TryParse(Console.ReadLine(), out double hi);
            if (!flag) throw new Exception("App: Введенны неверные данные");

            // Кроче Exeption я ничего не придумал
            if (lo >= hi) throw new Exception("App: Введенны невалидные значения");

            Worker[] workersSalary = _enterprises.SearchSalary(lo, hi);
            if (workersSalary.Length == 0) return;
            Console.Clear();

            _enterprises.Show(workersSalary, $"Работники с окладом от {lo} до {hi}");

        } // WorkersOrderByDecreasingWorkExperience

        // Запись работников в отдельный массив, с заданной должностью
        partial void WorkersFindJobPosition()
        {
            bool flag;
            string jobPosition;
            _enterprises.Show();

            Console.Write("\n      Введите должность для отбора работников: ");
            jobPosition = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(jobPosition)) throw new Exception("App: Введенны неверные данные");


            Worker[] workersJobPosition = _enterprises.SearchJobPosition(jobPosition);
            if (workersJobPosition.Length == 0) return;
            Console.Clear();

            _enterprises.Show(workersJobPosition, $"Работники с должностью {jobPosition}");

        } // WorkersOrderByDecreasingWorkExperience

        #endregion


    }
}
