﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using C_Sharp_.NET_Framework__7___Null_.Models;


namespace C_Sharp_.NET_Framework__7___Null_
{
    public class Enterprises
    {
        public string City { get; set; }
        private Worker[] _workers;

        public const int Size = 12;

        public Enterprises() : this("Токио", new Worker[Size]) => Initializer();
        public  Enterprises(string city, Worker[] workers)
        {
            City = city;
            _workers = workers;
        }

        public void Initializer()
        {
           
            for (int i = 0; i < Size; i++) {
                _workers[i] = Worker.Generate();

            } // for
        } // Initializer

        public void Show(string title = "")
        {
            Console.WriteLine($"\n\n\n\n\n\t{title}\n\tГород предприятия: {City}\n" + Worker.Header());


            int row = 1;
            void OutItem(Worker work) => Console.WriteLine($"\t{work.ToTableRow(row++)}");
            Array.ForEach(_workers, OutItem);


            Console.WriteLine(Worker.Footer());

        } // Show

        // Вывод отобранных по различным критериям массива работников
        public void Show(Worker[] worker ,string title = "")
        {
            Console.WriteLine($"\n\n\n\n\n\t{title}\n\tГород предприятия: {City}\n" + Worker.Header());


            int row = 1;
            void OutItem(Worker work) => Console.WriteLine($"\t{work.ToTableRow(row++)}");
            Array.ForEach(worker, OutItem);


            Console.WriteLine(Worker.Footer());

        } // Show


        // Сортировка работников по алфавиту
        public void OrderByFio() => Array.Sort(_workers, Worker.SortByFio);

        // Сортировка работников по должности
        public void OrderByJobPosition() => Array.Sort(_workers, Worker.SortByJobPosition);

        // Сортировка работников по убыванию стажа работы
        public void OrderByDecreasingWorkExperience() => Array.Sort(_workers, Worker.SortByDecreasingWorkExperience);

        public Worker[] SearchSalary(double lo, double hi)
        {
            // предикат для отбора работников с откладом, попадающим в заданный диапозон
            bool SalaryPredicate(Worker wr) =>   wr.Salary > lo && wr.Salary < hi;

            // отбор работников через метод класса Array, используя предикат в новый массив
            Worker[] temp = Array.FindAll(_workers,SalaryPredicate);

            if (temp.Length == 0)
            {
                MessageBox.Show("Не удалось найти работников подходящих критерию", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
             
            }

            return temp;
        } // SearchSalary

        public Worker[] SearchJobPosition(string jobPosition)
        {
            // предикат для отбора работников по должности
            bool JobPositionPredicate(Worker wr) => wr.JobPosition == jobPosition;

            // отбор через метод класса Array в новый массив
            Worker[] temp = Array.FindAll(_workers, JobPositionPredicate);
            
            if(temp.Length == 0){
                MessageBox.Show("Не удалось найти работников подходящих критерию", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
         
            }

            return temp;
        } // SearchSalary

    }


}
