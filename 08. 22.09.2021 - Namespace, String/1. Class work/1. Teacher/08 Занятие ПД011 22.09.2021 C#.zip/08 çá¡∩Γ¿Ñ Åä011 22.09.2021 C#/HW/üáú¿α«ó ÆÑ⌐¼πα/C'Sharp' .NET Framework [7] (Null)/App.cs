﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__7___Null_
{
    public partial class App
    {
        // объекты для обработки

        private Enterprises _enterprises;
       

        public App() : this(new Enterprises()) { }
        public App(Enterprises enterprises)
        {
            _enterprises = enterprises;
 
        } // App


        #region Частичные методы
        // Формирование массива работников для обработки по заданию
        partial void WorkersInitialize();

        // Вывод массива работников
        partial void WorkersShow();

        // Упорядочить массив работников по алфавиту
        partial void WorkersOrderByAlphabet();

        // Упорядочить массив работников по должности
        partial void WorkersOrderByJobPosition();

        // Упорядочить массив работников по убыванию стажа работы
        partial void WorkersOrderByDecreasingWorkExperience();

        // Запись работников в отдельный массив, поподающие в диапозон по своему окладу
        partial void WorkersFindSalary();

        // Запись работников в отдельный массив, с заданной должностью
        partial void WorkersFindJobPosition();
        #endregion

        #region Оболочные методы (просто для вызова частичных)
        // Формирование массива работников для обработки по заданию
        public void DemoWorkersInitialize() => WorkersInitialize();

        // Вывод массива работников
        public void DemoWorkersShow() => WorkersShow();

        // Упорядочить массив работников по алфавиту
        public void DemoWorkersOrderByAlphabet() => WorkersOrderByAlphabet();

        // Упорядочить массив работников по должности
        public void DemoWorkersOrderByJobPosition() => WorkersOrderByJobPosition();

        // Упорядочить массив работников по убыванию стажа работы
        public void DemoWorkersOrderByDecreasingWorkExperience() => WorkersOrderByDecreasingWorkExperience();

        // Запись работников в отдельный массив, поподающие в диапозон по своему окладу
        public void DemoWorkersFindSalary() => WorkersFindSalary();

        // Запись работников в отдельный массив, с заданной должностью
        public void DemoWorkersFindJobPosition() => WorkersFindJobPosition();

        #endregion
        
        
      

    } // App
}