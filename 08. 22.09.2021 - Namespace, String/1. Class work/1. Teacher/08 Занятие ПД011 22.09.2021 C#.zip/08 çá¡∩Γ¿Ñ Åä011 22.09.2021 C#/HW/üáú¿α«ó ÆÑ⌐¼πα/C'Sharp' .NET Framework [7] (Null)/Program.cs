﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__7___Null_
{
    class Program
    {
        static void Main(string[] args)
        {

            App app = new App();
            Console.SetWindowSize(130, 40);
            while (true)
            {
                try
                {

                    int y = 4;
                    int x = 17;
                    int choi;
                    bool flu = true;
                    do
                    {
                        y = 4;
                        if (!flu) Console.Clear();
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|                       MENU                    |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   №   >|<             Задания                 |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   1   >|<            Формирование             |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |          массива работников          |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   2   >|<      Вывод данных                   |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |            предприятия в консоль     |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   3   >|<    Сортировка работников            |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |                 по алфавиту          |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   4   >|<   Сортировка работников             |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |                по должности          |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   5   >|<   Сортировка работников             |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |        по убыванию стажа работы      |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   6   >|< Выбор в отдельный массив работников |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |      с определенным окладом          |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   7   >|< Выбор в отдельный массив работников |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|        |      с определенной должностью       |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|   0   >|<               EXIT                  |>", ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, "<|-----------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);

                        Console.CursorVisible = false;

                        Console.Write("\n\n\t    Введите пункт: ");

                        choi = 0;
                        flu = int.TryParse(Console.ReadLine(), out choi);

                    } while (!flu || choi>7 || choi <0);
                    Console.Clear();
                    Console.CursorVisible = true;

                    switch (choi)
                    {
                        // ------------Демонстрация класса Enterprises -> Worker ------------
                                                                              
                        case 1: app.DemoWorkersInitialize();                       break;     
                        case 2: app.DemoWorkersShow();                             break;   
                        case 3: app.DemoWorkersOrderByAlphabet();                  break;   
                        case 4: app.DemoWorkersOrderByJobPosition();               break; 
                        case 5: app.DemoWorkersOrderByDecreasingWorkExperience();  break;  
                        case 6: app.DemoWorkersFindSalary();                       break;  
                        case 7: app.DemoWorkersFindJobPosition();                  break;  
                         
                        // ------------Демонстрация класса Room------------
              
                      


                        case 0: Console.Write("\n\n\tДо свидания\n"); return;
                    } // switch



                    
                   
                } // try
 
                catch (Exception ex)
                {
                    Console.Clear();
                    Utils.WriteXY(45, 15, "**********************************************", ConsoleColor.White, ConsoleColor.Red);

                    Utils.WriteXY(45, 16, "                     Error                    ", ConsoleColor.DarkRed);
                    Utils.WriteXY(45, 17, "   " + ex.Message    , ConsoleColor.Red);
                   
                    Utils.WriteXY(45, 16, "*", ConsoleColor.White, ConsoleColor.Red);
                    Utils.WriteXY(90, 16, "*", ConsoleColor.White, ConsoleColor.Red);
                    Utils.WriteXY(45, 17, "*", ConsoleColor.White, ConsoleColor.Red);
                    Utils.WriteXY(90, 17, "*", ConsoleColor.White, ConsoleColor.Red);
                    
                    Utils.WriteXY(45, 18, "**********************************************", ConsoleColor.White, ConsoleColor.Red);
                } // try-catch
                Console.ReadKey(false);
                Console.Clear();
            }// while
        
       
      

        } // Main

    } // Program
} // C_Sharp_.NET_Framework__7___Null_
