﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkersRoutes
{
    /* 
     * Работник некоторого предприятия для информационной системы представляется 
     * классом с полями:
     *     • фамилия и инициалы работника;
     *     • название занимаемой должности;
     *     • год поступления на работу
     *     • оклад.
     * Определите свойства в классе, методы для вывода данных о работнике в консоль      
     */
    public class Worker
    {
        // фамилия и инициалы работника
        private string _fullName;
        public string FullName {
            get => _fullName;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Не указаны фамилия и инициалы работника");

                _fullName = value;
            }
        } // FullName

        // название занимаемой должности
        private string _position;
        public string Position {
            get => _position;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Не указана должность работника");

                _position = value;
            }
        } // Position

        // год поступления на работу
        private int _startYear;
        public int StartYear {
            get => _startYear;
            set {
                if (value < 0)
                    throw new ArithmeticException("Недопустимый год поступления на работу");

                _startYear = value;
            }
        } // StartYear

        // оклад
        private int _salary;
        public int Salary {
            get => _salary;
            set {
                if (value <= 0)
                    throw new ArithmeticException("Недопустимый оклад работника");

                _salary = value;
            }
        } // Salary

        public Worker():this("Тимофеев Т.А.", "разработчик", 2019, 35_000) { } // Worker

        public Worker(string fullName, string position, int startYear, int salary) {
            FullName = fullName;
            Position = position;
            StartYear = startYear;
            Salary = salary;
        } // Worker

        // формирование строкового представления объекта
        public override string ToString() => $"{_fullName}, {_position}, работает с {_startYear} г.," +
            $"оклад: {_salary} руб.";

        // формирование строки таблицы для представления объекта 
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_fullName, -20} │ {_position, -13} │ {_startYear, 8}   │ {_salary, 12:n2} │";

        // статический метод для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬──────────────────────┬───────────────┬────────────┬──────────────┐\n" +
                $"{spaces}│  №  │ Фамилия и инициалы   │ Текущая       │ Год начала │    Оклад,    │\n" +
                $"{spaces}│ п/п │            работника │     должность │   работы   │     руб.     │\n" +
                $"{spaces}├─────┼──────────────────────┼───────────────┼────────────┼──────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴──────────────────────┴───────────────┴────────────┴──────────────┘";

        // Компаратор для сортировки работников по фамилиям в алфавитном порядке
        public static int FullNameComparator(Worker w1, Worker w2) =>
            w1._fullName.CompareTo(w2._fullName);

        // Компаратор для сортировки работников по должности
        public static int PositionComparator(Worker w1,  Worker w2) =>
            w1._position.CompareTo(w2._position);

        // Компаратор для сортировки работников по убыванию стажа работы
        public static int ExperienceDescComparator(Worker w1, Worker w2) =>
            w1._startYear.CompareTo(w2._startYear);

        // фабрика, создающая данные о работнике
        public static Worker Create() {
            // фамилии и инициалы для генерации данных
            string[] fullNames = { 
                "Петров А.Р.", "Михайлова Т.П.", "Гамджашвили Ю.И.", 
                "Грамаков С.Р.", "Галушка М.И.", "Дёмина Д.М.", 
                "Кустов Н.Р."
            };

            // должности и их оклады
            (string Title, int Salary) [] positions = {
                ("junior", 23_000), ("middle", 35_000),
                ("senior", 56_000), ("team lead", 88_000),
                ("teach lead", 76_000),
            };

            // получить индексы для извлечения данных
            var iFullName = Utils.Random.Next(0, fullNames.Length - 1);
            var iPosition = Utils.Random.Next(0, positions.Length - 1);
            
            // создать и вернуть объект данных
            return new Worker {
                FullName = fullNames[iFullName],
                Position =  positions[iPosition].Title, 
                Salary = positions[iPosition].Salary,
                StartYear = Utils.Random.Next(1982, 2021)
            };
        } // Create
    } // class Worker
}
