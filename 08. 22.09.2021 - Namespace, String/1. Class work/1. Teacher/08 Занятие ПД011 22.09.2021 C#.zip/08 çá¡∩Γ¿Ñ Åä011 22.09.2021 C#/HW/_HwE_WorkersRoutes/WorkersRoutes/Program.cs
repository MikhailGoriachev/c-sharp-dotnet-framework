﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;  // для класса Interaction

/* 
 * Разработайте консольное приложение для решения следующих задач. Используйте 
 * простое меню для выбора заданий по обработке. При ошибках в выполняемых 
 * заданиях обрабатывайте исключения. В классе App разместите методы решения 
 * каждой задачи в частичный тип. По возможности используйте элвис-оператор и 
 * оператор null-объединения 
 * 
 * Задача 1. 
 * Работник некоторого предприятия для информационной системы представляется 
 * классом с полями:
 *     • фамилия и инициалы работника;
 *     • название занимаемой должности;
 *     • год поступления на работу
 *     • оклад.
 * Определите свойства в классе, методы для вывода данных о работнике в консоль 
 * Для предприятия, размещенного в заданном городе и хранящего сведения о 12 
 * работниках реализовать обработки:
 *     • Начальное формирование массива работников;
 *     • Вывод данных предприятия в консоль
 *     • Упорядочивание работников по
 *         o Алфавиту
 *         o Должности
 *         o Убыванию стажа работы
 *     • Выбрать в массив и вывести в консоль работников, оклад которых 
 *       попадает в заданный диапазон
 *     • Выбрать в массив и вывести в консоль работников с заданной должностью
 * 
 * Задача 2. 
 * Пеший туристический маршрут для информационной системы описывается следующим
 * образом:
 *     • название начального пункта маршрута;
 *     • название конечного пункта маршрута;
 *     • буквенно-цифровой код маршрута
 *     • протяженность маршрута в километрах.
 * Определите свойства в классе, методы для вывода данных о маршруте в консоль. 
 * Для туристической фирмы, имеющей название и хранящей сведения о 10 маршрутах 
 * реализовать обработки:
 *     • Начальное формирование массива маршрутов;
 *     • Вывод данных фирмы в консоль
 *     • Упорядочивание маршрутов по
 *         o Коду маршрута
 *         o Начальному пункту маршрута
 *         o Убыванию протяженности маршрута
 *     • Выбрать в массив и вывести в консоль маршруты, протяженность которых, 
 *       попадает в заданный диапазон. Диапазон формируйте при помощи 
 *       генератора случайных чисел
 *     • Выбрать в массив и вывести в консоль маршруты, начинающиеся или 
 *       завершающиеся в заданном пункте. Название пункта вводить при помощи 
 *       InputBox из класса Interaction
 * 
 */
namespace WorkersRoutes
{
    class Program
    {
        static void Main(string[] args)
        {
              Console.Title = "Задание на 22.09.2021 - введение в обработку исключений, частичные типы";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Формирование данных предприятия по задаче 1" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Вывод данных предприятия и списка работников" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Упорядочить работников по алфавиту" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Упорядочить работников по должности" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Упорядочить работников по убыванию стажа работы" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Выбрать работников по диапазону оклада" },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Выбрать работников с заданной должностью" },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Формирование данных туристической фирмы по задаче 2" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Вывод данных туристической фирмы по задаче 2" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Упорядочить список маршрутов по коду маршрута" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Упорядочить список маршрутов по начальному пункту" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Упорядочить список маршрутов по убыванию протяженности" },
                new MenuItem { HotKey = ConsoleKey.H, Text = "Выбрать маршруты по диапазону протяженности" },
                new MenuItem { HotKey = ConsoleKey.J, Text = "Выбрать маршруты по начальному или конечному пункту" },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - исключения, классы, свойства, массивы объектов");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1
                        #region Задача 1
                        // Формирование данных предприятия по задаче 1
                        case ConsoleKey.Q:
                            app.InitializeEnterprizseData();
                            break;

                        // Вывод данных предприятия и списка работников
                        case ConsoleKey.W:
                            app.ShowEnterprise();
                            break;


                        // Упорядочить работников по алфавиту
                        case ConsoleKey.E:
                            app.EnterpriseOrderByFullName();
                            break;

                        // Упорядочить работников по должности
                        case ConsoleKey.R:
                            app.EnterpriseOrderByPosition();
                            break;

                        // Упорядочить работников по убыванию стажа работы
                        case ConsoleKey.T:
                            app.EnterpriseOrderByExperienceDesc();
                            break;

                        // Выбрать работников по диапазону оклада
                        case ConsoleKey.Y:
                            app.EnterpriseSelectWhereSalaryBetween();
                            break;

                        // Выбрать работников с заданной должностью
                        case ConsoleKey.U:
                            app.EnterpriseSelectWherePosition();
                            break;
                        #endregion


                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 2
                        #region Задача 2

                        // Формирование данных туристической фирмы по задаче 2
                        case ConsoleKey.A:
                            app.InitializeTravelAgencyData();
                            break;

                        // Вывод данных туристической фирмы по задаче 2
                        case ConsoleKey.S:
                            app.ShowTravelAgency();
                            break;

                        // Упорядочить список маршрутов по коду маршрута
                        case ConsoleKey.D:
                            app.TravelEgencyOrderByCodeRoute();
                            break;

                        // Упорядочить список маршрутов по начальному пункту
                        case ConsoleKey.F:
                            app.TravelEgencyOrderByStartPoint();
                            break;

                        // Упорядочить список маршрутов по убыванию протяженности
                        case ConsoleKey.G:
                            app.TravelAgencyOrderByDistanceDesc();
                            break;

                        // Выбрать маршруты по диапазону протяженности
                        case ConsoleKey.H:
                            app.TravelAgencySelectWhereDistanceBetween();
                            break;

                        // Выбрать маршруты по начальному или конечному пункту
                        case ConsoleKey.J:
                            app.TravelAgencySelectWherePoint();
                            break;
                        #endregion

                        // Выход из приложения назначен на клавишу F10 или клавишу Z или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try
               
                // обработка исключений - просто вывести сообщение
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch


            } // while
        } // Main
    } // class Program
}
