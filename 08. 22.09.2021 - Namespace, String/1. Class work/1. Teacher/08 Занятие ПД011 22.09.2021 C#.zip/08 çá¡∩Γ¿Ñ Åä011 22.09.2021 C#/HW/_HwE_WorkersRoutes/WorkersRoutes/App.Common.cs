﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkersRoutes
{
    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    public partial class App
    {
        private Enterprise _enterprise;
        private TravelAgency _travelAgency;

        // конструктор по умолчанию 
        public App():this(new Enterprise(), new TravelAgency()) {  } // App

        // конструктор с внедрением зависимостей
        public App(Enterprise enterprise, TravelAgency travelAgency) { 
            _enterprise = enterprise;
            _travelAgency = travelAgency;
        } // App
    } // class App
}
