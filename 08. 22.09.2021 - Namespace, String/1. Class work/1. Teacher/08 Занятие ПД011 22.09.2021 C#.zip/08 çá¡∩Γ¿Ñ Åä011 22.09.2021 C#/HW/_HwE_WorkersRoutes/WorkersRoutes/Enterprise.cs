﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkersRoutes
{
    /* 
     * Для предприятия, размещенного в заданном городе и хранящего сведения о 12 
     * работниках реализовать обработки:
     *     • Начальное формирование массива работников;
     *     • Вывод данных предприятия в консоль
     *     • Упорядочивание работников по
     *         o Алфавиту
     *         o Должности
     *         o Убыванию стажа работы
     *     • Выбрать в массив работников, оклад которых 
     *       попадает в заданный диапазон
     *     • Выбрать в массив работников с заданной должностью     
     */
    public class Enterprise
    {
        // количество работников в массиве по заданию 
        private const int n = 12;

        // название города, в котором размещено предприятие
        private string _city;
        public string City {
            get => _city;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Не указан город размещения предприятия");

                _city = value;
            }
        } // City

        // массив работников предприятия
        private Worker[] _workers;

        // Конструкторы для объекта
        // конструктор по умолчанию
        public Enterprise():this("Макеевка", new Worker[n]) {
            Initialize();
        } // Enterprise

        // конструктор с параметрами - для внедрения зависимостей
        public Enterprise(string city, Worker[] workers) {
            City = city;
            _workers = workers;
        } // Enterprise

        // проверка массива работников на пустоту
        public bool Empty => _workers.Length == 0;

        // начальное заполнение массива работников
        public void Initialize() {
            for (int i = 0; i < _workers.Length; i++)
                _workers[i] = Worker.Create();

        } // Initialize

        // Вывести данные преприятия в консоль
        public void Show(string caption, int indent) => 
            Show($"{caption} - {City}", indent, _workers);

        // Вывести данные массива работников преприятия в консоль - для вывода 
        // массивов, полученных из отбора
        public static void Show(string caption, int indent, Worker[] workers) {
            // вывод заголовка таблицы данных предприятия
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{Worker.Header(indent)}");

            // вывод всех элементов массива объектов данных - массива работников
            int row = 1;
            void OutItem(Worker w) => Console.WriteLine($"{space}{w.ToTableRow(row++)}");
            Array.ForEach(workers, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Worker.Footer(indent));
        } // Show

        // --------------------------------------------------------------
        // Обработка по заданию

        // Упорядочивание работников

        // Упорядочивание работников по алфавиту
        public void OrderByFullName() => Array.Sort(_workers, Worker.FullNameComparator);

        // Упорядочивание работников по должности
        public void OrderByPosition() => Array.Sort(_workers, Worker.PositionComparator);

        // Упорядочивание работников по убыванию стажа работы
        public void OrderByExperienceDesc() => Array.Sort(_workers, Worker.ExperienceDescComparator);


        // Выборка данных из массива работников

        // Выбрать в массив работников, оклад которых
        // попадает в заданный диапазон
        public Worker[] SelectWhereSalaryBetween(int lo, int hi) {
            bool BetweenPredicate(Worker w) => lo <= w.Salary && w.Salary <= hi;
            return Array.FindAll(_workers, BetweenPredicate);
        } // SelectWhereSalaryBetween

        // Выбрать в массив работников с заданной должностью
        public Worker[] SelectWherePosition(string position) {
            bool PositionPredicate(Worker w) => w.Position == position;
            return Array.FindAll(_workers, PositionPredicate);
        } // SelectWherePosition

    } // class Enterprise
}
