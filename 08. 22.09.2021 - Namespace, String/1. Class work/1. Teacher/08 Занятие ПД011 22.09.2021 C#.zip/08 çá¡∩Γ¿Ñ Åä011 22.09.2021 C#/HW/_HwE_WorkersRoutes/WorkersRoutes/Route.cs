﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkersRoutes
{
    /*
     * Пеший туристический маршрут для информационной системы описывается следующим
     * образом:
     *     • название начального пункта маршрута;
     *     • название конечного пункта маршрута;
     *     • буквенно-цифровой код маршрута
     *     • протяженность маршрута в километрах.
     * Определите свойства в классе, методы для вывода данных о маршруте в консоль.  
     */
    public class Route
    {
        // название начального пункта маршрута
        private string _startPoint;
        public string StartPoint {
            get => _startPoint;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Не указан начальный пункт маршрута");

                _startPoint = value;
            }
        } // StartPoint

        // название конечного пункта маршрута
        private string _endPoint;
        public string EndPoint {
            get => _endPoint;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Не указан конечный пункт маршрута");

                _endPoint = value;
            }
        } // EndPoint

        // буквенно-цифровой код маршрута
        private string _codeRoute;
        public string CodeRoute {
            get => _codeRoute;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Не указан код маршрута");

                _codeRoute = value;
            }
        } // CodeRoute

        // протяженность маршрута в километрах
        private int _distance;
        public int Distance {
            get => _distance;
            set {
                if (value < 0)
                    throw new ArithmeticException("Недопустимая протяженность маршрута");

                _distance = value;
            }
        } // Distance

        // конструкторы
        Route():this("Донецк", "Амвросиевка", "ДА_063", 63) { }
        Route(string startPoint, string endPoint, string codeRoute, int distance) { 
            StartPoint = startPoint;
            EndPoint = endPoint;
            CodeRoute = codeRoute;
            Distance = distance;
        } // Route

        // формирование строкового представления объекта
        public override string ToString() => $"{_codeRoute}: {_startPoint} -> {_endPoint}, " +
            $"протяженнось: {_distance} км.";

        // формирование строки таблицы для представления объекта 
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_codeRoute, -8} │ {_startPoint, -15} │ {_endPoint, -15} │ {_distance, 11:n3}    │";

        // статический метод для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬──────────┬─────────────────┬─────────────────┬────────────────┐\n" +
                $"{spaces}│  №  │    Код   │ Начальный пункт │ Конечный  пункт │ Протяженность, │\n" +
                $"{spaces}│ п/п │ маршрута │     маршрута    │     маршрута    │       км       │\n" +
                $"{spaces}├─────┼──────────┼─────────────────┼─────────────────┼────────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴──────────┴─────────────────┴─────────────────┴────────────────┘";

        // Компаратор для сортировки маршрутов по коду маршрута
        public static int CodeRouteComparator(Route r1, Route r2) =>
            r1._codeRoute.CompareTo(r2._codeRoute);

        // Компаратор для сортировки маршрутов по начальному пункту маршрута
        public static int StartPointComparator(Route r1, Route r2) =>
            r1._startPoint.CompareTo(r2._startPoint);

        // Компаратор для сортировки маршрутов по убыванию протяженности маршрута
        public static int DistanceDescComparator(Route r1, Route r2) =>
            r2._distance.CompareTo(r1._distance);

        // фабрика, создающая данные о маршруте
        public static Route Create() {
            // начальные и конечные пункты для генерации данных
            string[] points = {
                "Амворсиевка", "Новоласпа", "Греково",
                "Хомутово", "Приморское", "Крещатицкое",
                "Обрыв", "Седово", "Холодное", "Безыменное",
                "Самсоново", "Гусельщиково"
            };


            // получить индексы для извлечения данных 
            var iStart = Utils.Random.Next(0, points.Length - 1);
            var iEnd = Utils.GetRandomExclude(0, points.Length - 1, iStart);

            // сформировать протяженность маршрута 
            int distance = Utils.Random.Next(60, 120);

            // сформировать код маршрута - первая буква названия начаьного пункта маршрута,
            // первая буква названия конечного пункта маршрута, знак подчеркивания и
            // протяженность маршрута, дополненная символами '0' до трех знаков
            string codeRoute = $"{points[iStart][0]}{points[iEnd][0]}_{distance:00#}";

            // создать и вернуть объект данных
            return new Route { CodeRoute = codeRoute, StartPoint = points[iStart], EndPoint = points[iEnd], Distance = distance };
        } // Create
    } // class Route
}
