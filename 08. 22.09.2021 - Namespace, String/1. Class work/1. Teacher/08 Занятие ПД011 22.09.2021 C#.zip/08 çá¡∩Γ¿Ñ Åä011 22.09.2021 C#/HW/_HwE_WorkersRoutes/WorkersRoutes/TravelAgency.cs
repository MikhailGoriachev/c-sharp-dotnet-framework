﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkersRoutes
{
    /* 
     * Для туристической фирмы, имеющей название и хранящей сведения о 10 маршрутах 
     * реализовать обработки:
     *     • Начальное формирование массива маршрутов;
     *     • Вывод данных фирмы в консоль
     *     • Упорядочивание маршрутов по
     *         o Коду маршрута
     *         o Начальному пункту маршрута
     *         o Убыванию протяженности маршрута
     *     • Выбрать в массив и вывести в консоль маршруты, протяженность которых, 
     *       попадает в заданный диапазон. Диапазон формируйте при помощи 
     *       генератора случайных чисел
     *     • Выбрать в массив и вывести в консоль маршруты, начинающиеся или 
     *       завершающиеся в заданном пункте. Название пункта вводить при помощи 
     *       InputBox из класса Interaction
     */
    public class TravelAgency
    {
        // количество маршрутов в массиве по заданию 
        private const int n = 10;

        // название туристической фирмы
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Не указано название туристичекой фирмы");

                _name = value;
            }
        } // Name

        // массив маршрутов предприятия
        private Route[] _routes;

        // Конструкторы для объекта
        // конструктор по умолчанию
        public TravelAgency() : this("Розовый слон", new Route[n]) {
            Initialize();
        } // TravelAgency

        // конструктор с параметрами - для внедрения зависимостей
        public TravelAgency(string name, Route[] routes) {
            Name = name;
            _routes = routes;
        } // TravelAgency

        // проверка массива маршрутов на пустоту
        public bool Empty => _routes.Length == 0;

        // начальное заполнение массива маршрутов
        public void Initialize() {
            for (int i = 0; i < _routes.Length; i++)
                _routes[i] = Route.Create();
        } // Initialize

        // Вывести данные туристической фирмы в консоль
        public void Show(string caption, int indent) =>
            Show($"{caption} - {Name}", indent, _routes);

        // Вывести данные массива маршрутов туристической фирмы в консоль - для вывода 
        // массивов, полученных из отбора
        public static void Show(string caption, int indent, Route[] routes) {
            // вывод заголовка таблицы данных туристической фирмы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{Route.Header(indent)}");

            // вывод всех элементов массива объектов данных - массива маршрутов
            int row = 1;
            void OutItem(Route r) => Console.WriteLine($"{space}{r.ToTableRow(row++)}");
            Array.ForEach(routes, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Route.Footer(indent));
        } // Show

        // --------------------------------------------------------------
        // Обработка по заданию

        // Упорядочивание маршрутов

        // Упорядочивание маршрутов по коду маршрута
        public void OrderByCodeRoute() => Array.Sort(_routes, Route.CodeRouteComparator);

        // Упорядочивание маршрутов по начальному пункту маршрута
        public void OrderByStartPoint() => Array.Sort(_routes, Route.StartPointComparator);

        // Упорядочивание маршрутов по убыванию протяженности маршрута
        public void OrderByDistanceDesc() => Array.Sort(_routes, Route.DistanceDescComparator);


        // Выборка данных из массива маршрутов

        //  Выбрать в массив маршруты, протяженность которых, попадает в заданный диапазон
        public Route[] SelectWhereDistanceBetween(int lo, int hi) {
            bool BetweenPredicate(Route r) => lo <= r.Distance && r.Distance <= hi;
            return Array.FindAll(_routes, BetweenPredicate);
        } // SelectWhereDistanceBetween

        // Выбрать в массив маршруты, начинающиеся или завершающиеся в заданном пункте
        public Route[] SelectWherePoint(string point) {
            bool PointPredicate(Route r) => r.StartPoint == point || r.EndPoint == point;
            return Array.FindAll(_routes, PointPredicate);
        } // SelectWherePoint
    } // class TravelAgency
}
