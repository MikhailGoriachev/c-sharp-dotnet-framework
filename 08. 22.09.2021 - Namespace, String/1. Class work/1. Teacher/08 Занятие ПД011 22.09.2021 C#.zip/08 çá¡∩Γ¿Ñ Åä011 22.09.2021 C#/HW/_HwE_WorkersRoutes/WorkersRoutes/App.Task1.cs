﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkersRoutes
{
    /* 
     * Методы для решения задачи 1
     */
    partial class App
    {
        // Формирование данных предприятия по задаче 1
        public void InitializeEnterprizseData() {
            Utils.ShowNavBarTask("   Формирование данных предприятия по задаче 1");

            _enterprise.Initialize();
            _enterprise.Show("Предприятие по задаче 1", 12);
        } // InitializeEnterpriseData

        // Вывод данных предприятия и списка работников
        public void ShowEnterprise() {
            Utils.ShowNavBarTask("   Вывод данных предприятия и списка работников");
            _enterprise.Show("Данные предприятия по задаче 1", 12);
        } // ShowEnterprise

        // Упорядочить работников по алфавиту
        public void EnterpriseOrderByFullName() {
            Utils.ShowNavBarTask("   Упорядочить работников по алфавиту");

            _enterprise.OrderByFullName();
            _enterprise.Show("Работники предприятия упорядочены по алфавиту", 12);
        } // EnterpriseOrderByFullName

        // Упорядочить работников по должности
        public void EnterpriseOrderByPosition() {
            Utils.ShowNavBarTask("   Упорядочить работников по должности");

            _enterprise.OrderByPosition();
            _enterprise.Show("Работники предприятия упорядочены по должностям", 12);
        } // EnterpriseOrderByPosition

        // Упорядочить работников по убыванию стажа работы
        public void EnterpriseOrderByExperienceDesc() {
            Utils.ShowNavBarTask("   Упорядочить работников по убыванию стажа работы");

            _enterprise.OrderByExperienceDesc();
            _enterprise.Show("Работники предприятия упорядочены по убыванию стажа работы", 12);
        } // EnterpriseOrderByExperienceDesc

        // Выбрать работников по диапазону оклада 
        public void EnterpriseSelectWhereSalaryBetween() {
            Utils.ShowNavBarTask("   Выбрать работников по диапазону оклада");

            int lo = Utils.Random.Next(20, 50)*1_000, hi = lo + Utils.Random.Next(20, 50) * 1_000;

            Worker[] selected = _enterprise.SelectWhereSalaryBetween(lo, hi);
            Enterprise.Show($"Работники предприятия с диапазоном окладов от {lo} до {hi} руб.", 12, selected);
        } // EnterpriseSelectWhereSalaryBetween

        // Выбрать работников с заданной должностью
        public void EnterpriseSelectWherePosition() {
            Utils.ShowNavBarTask("   Выбрать работников с заданной должностью");

            // получить должность для выборки данных
            string[] positions = { "junior", "middle", "senior", "team lead", "teach lead" };
            string position = positions[Utils.Random.Next(0, positions.Length)]; 
            
            Worker[] selected = _enterprise.SelectWherePosition(position);
            Enterprise.Show($"Работники предприятия с должностью '{position}'", 12, selected);
        } // EnterpriseSelectWherePosition
    } // class App
}
