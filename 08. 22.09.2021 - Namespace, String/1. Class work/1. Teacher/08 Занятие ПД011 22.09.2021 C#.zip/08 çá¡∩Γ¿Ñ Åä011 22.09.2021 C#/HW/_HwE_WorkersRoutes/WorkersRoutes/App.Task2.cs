﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;  // для класса Interaction

namespace WorkersRoutes
{
    /* 
     * Методы для решения задачи 2
     */
    partial class App
    {
        // Формирование данных туристической фирмы по задаче 2
        public void InitializeTravelAgencyData() {
            Utils.ShowNavBarTask("    Формирование данных туристической фирмы по задаче 2");

            _travelAgency.Initialize();
            _travelAgency.Show("Туристическое агенство по задаче 2", 12);
        } // InitializeEnterprizeData

        // Вывод данных туристической фирмы по задаче 2
        public void ShowTravelAgency() {
            Utils.ShowNavBarTask("   Вывод данных туристической фирмы по задаче 2");

            _travelAgency.Show("Данные туристического агенства по задаче 2", 12);
        } // ShowTravelAgency

        // Упорядочить список маршрутов по коду маршрута
        public void TravelEgencyOrderByCodeRoute() {
            Utils.ShowNavBarTask("   Упорядочить список маршрутов по коду маршрута");

            _travelAgency.OrderByCodeRoute();
            _travelAgency.Show("Маршруты туристической фирмы, упорядоченные по коду маршрута", 12);
        } // TravelEgencyOrderByCodeRoute

        // Упорядочить список маршрутов по начальному пункту
        public void TravelEgencyOrderByStartPoint() {
            Utils.ShowNavBarTask("   Упорядочить список маршрутов по начальному пункту");
            
            _travelAgency.OrderByStartPoint();
            _travelAgency.Show("Маршруты туристической фирмы, упорядоченные по начальному пункту", 12);
        } // TravelEgencyOrderByStartPoint

        // Упорядочить список маршрутов по убыванию протяженности
        public void TravelAgencyOrderByDistanceDesc() {
            Utils.ShowNavBarTask("   Упорядочить список маршрутов по убыванию протяженности");

            _travelAgency.OrderByDistanceDesc();
            _travelAgency.Show("Маршруты туристической фирмы, упорядоченные по убыванию протяженности", 12);
        } // TravelAgencyOrderByDistanceDesc

        // Выбрать маршруты по диапазону протяженности
        public void TravelAgencySelectWhereDistanceBetween() {
            Utils.ShowNavBarTask("   Выбрать маршруты по диапазону протяженности");

            int lo = Utils.Random.Next(2, 4)*10, hi = lo + Utils.Random.Next(3, 8)*10;

            Route[] selected = _travelAgency.SelectWhereDistanceBetween(lo, hi);
            TravelAgency.Show($"Маршруты туристической фирмы с диапазоном проятженности от {lo} до {hi} км", 12, selected);
        } // TravelAgencySelectWhereDistanceBetween

        // Выбрать маршруты по начальному или конечному пункту
        public void TravelAgencySelectWherePoint() {
            Utils.ShowNavBarTask("   Выбрать маршруты по начальному или конечному пункту");

            // получить пункт для выборки данных, при вводе пустой строки или клике
            // по кнопке "Отмена" - выход без отбора данных
            string point = "Хомутово";
            point = Interaction.InputBox(
                "Выберите пункт, в котором начинается или заканчивается маршрут",
                "Данные для отбора",
                point
            );
            if (string.IsNullOrEmpty(point)) return;

            Route[] selected = _travelAgency.SelectWherePoint(point);
            TravelAgency.Show($"Маршруты, начинающиеся или заканчивающиеся в '{point}'", 12, selected);
        } // TravelAgencySelectWherePoint
    } // class App
}
