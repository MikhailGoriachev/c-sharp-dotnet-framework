﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    // Класс предприятия
    public class Company {

        private string _name;              // название предприятия 
        private string _city;              // город, где размещено предприятие
        private Worker[] _workers;         // коллекция работников предприятия

        public string Name {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Company: Некорректное значение названия предприятия!"); _name = value; }
        } // Name

        public string City {
            get => _city;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Company: Некорректное значение города!"); _city = value; }
        } // City

        public bool Empty => _workers.Length == 0;

        public void Initialize() {
            Name = "Супермаркет \"Геркулес\"";
            City = "Донецк";
            _workers = new[] {
                new Worker {Name = "Семенов Р.О."  , Position = "Продавец-консультант", Year = 2019, Salary = 15000d},
                new Worker {Name = "Дунаев Д.Н."   , Position = "Администратор"       , Year = 2009, Salary = 20000d},
                new Worker {Name = "Харламова Ю.Т.", Position = "Зам. дтректора"      , Year = 2008, Salary = 25000d},
                new Worker {Name = "Олегова Б.Д."  , Position = "Директор"            , Year = 2008, Salary = 30000d},
                new Worker {Name = "Янковский Н.К.", Position = "Кассир"              , Year = 2020, Salary = 10000d},
                new Worker {Name = "Абалкин Л.П."  , Position = "Уборщик"             , Year = 2020, Salary = 5000d},
                new Worker {Name = "Романова А.Г." , Position = "Уборщик"             , Year = 2019, Salary = 5000d},
                new Worker {Name = "Воликов Б.Е."  , Position = "Продавец-консультант", Year = 2018, Salary = 15000d},
                new Worker {Name = "Абалкин Л.Ю."  , Position = "Уборщик"             , Year = 2020, Salary = 5000d},
                new Worker {Name = "Жукова П.В."   , Position = "Кассир"              , Year = 2017, Salary = 10000d},
                new Worker {Name = "Соколов А.С."  , Position = "Продавец-консультант", Year = 2016, Salary = 15000d},
                new Worker {Name = "Лебедев Л.А."  , Position = "Кассир"              , Year = 2018, Salary = 10000d}
            };
        } // Initialize

        // Вывести данные о предприятии
        public void Show(string caption, int indent) {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Name}\n{space}Город: {City}\n" +
                              $"{Worker.Header(indent)}");

            // вывод всех элементов массива работников
            int row = 1;
            void OutItem(Worker p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(_workers, OutItem);

            // вывод подвала таблицы 
            Console.WriteLine(Worker.Footer(indent));
        } // Show

        // Выбор работников, оклад которых, попадает в заданный диапазон
        public Worker[] FindBySalary(double lo, double hi) {
            // предикат для отбора работников
            bool InDiapazone(Worker w) => w.Salary >= lo && w.Salary <= hi;

            // отбор работников 
            Worker[] selected = Array.FindAll(_workers, InDiapazone);

            return selected;
        } // FindBySalary

        // Выбор работников с заданной должностью
        public Worker[] FindByPosition(string position)
        {
            // предикат для отбора работников
            bool IsPosition(Worker w) => w.Position.ToLower() == position.ToLower();

            // отбор работников 
            Worker[] selected = Array.FindAll(_workers, IsPosition);

            return selected;
        } // FindByPosition

        // сортировка массива работников по алфавиту
        public void OrderByName() => Array.Sort(_workers, Worker.NameComparer);

        // сортировка массива работников по должности
        public void OrderByPosition() => Array.Sort(_workers, Worker.PositionComparer);

        // сортировка массива работников по убыванию стажа работы
        public void OrderByWorkExperience() => Array.Sort(_workers, Worker.WorkExperienceComparer);

    }
}
