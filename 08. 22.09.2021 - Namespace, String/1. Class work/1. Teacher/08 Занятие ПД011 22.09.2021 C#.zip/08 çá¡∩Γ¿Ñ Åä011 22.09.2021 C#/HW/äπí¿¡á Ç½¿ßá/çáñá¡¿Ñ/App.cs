﻿using System;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction

namespace Задание
{
    
    // Объекты и методы для обработки по заданию
    public class App {

        private Company _workers;
        private TravelCompany _routes;

        // в конструкторе по умолчанию будем заполнять коллекции
        public App() : this(new Company(), new TravelCompany()) {
            _workers.Initialize();
            _routes.Initialize();
        } // App

        // конструктор с внедрением зависимостей/ dependency injection
        public App(Company workers, TravelCompany routes) {
            _workers = workers;
            _routes = routes;
        } // App

        // вывод массива работников
        private void ShowWorkers(Worker[] workers, string caption, int indent) {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n" +
                              $"{Worker.Header(indent)}");

            // вывод всех элементов массива работников
            int row = 1;
            void OutItem(Worker p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(workers, OutItem);

            // вывод подвала таблицы 
            Console.WriteLine(Worker.Footer(indent));
        } // ShowWorkers

        // вывод массива маршрутов
        private void ShowRoutes(Route[] routes, string caption, int indent)
        {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n" +
                              $"{Route.Header(indent)}");

            // вывод всех элементов массива маршрутов
            int row = 1;
            void OutItem(Route p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(routes, OutItem);

            // вывод подвала таблицы 
            Console.WriteLine(Route.Footer(indent));
        } // ShowRoutes


        // ---------------------------------------------------------------

        // Начальное формирование массива работников
        public void WorkerInitialize() {
            Utils.ShowNavBarTask("    Начальное формирование массива работников");

            _workers.Initialize();
            _workers.Show("Данные сформированы", 8);
        } // WorkerInitialize

        // Вывод данных предприятия в консоль
        public void WorkerShow()
        {
            Utils.ShowNavBarTask("    Вывод данных предприятия в консоль");

            _workers.Show("", 8);
        } // WorkerShow


        // Упорядочивание работников по алфавиту
        public void DemoOrderByName(){
            Utils.ShowNavBarTask("    Упорядочивание работников по алфавиту");

            _workers.OrderByName();
            _workers.Show("Работники упорядочены по алфавиту", 8);
        } // DemoOrderByName


        // Упорядочивание работников по должности
        public void DemoOrderByPosition()
        {
            Utils.ShowNavBarTask("  Упорядочивание работников по должности");

            _workers.OrderByPosition();
            _workers.Show("Работники упорядочены по должности", 8);
        } // DemoOrderByPosition

        // Упорядочивание работников по убыванию стажа работы
        public void DemoOrderByWorkExperience()
        {
            Utils.ShowNavBarTask("  Упорядочивание работников по убыванию стажа работы");

            _workers.OrderByWorkExperience();
            _workers.Show("Работники упорядочены по убыванию стажа работы", 8);
        } // DemoOrderByWorkExperience

        // Выбрать работников, оклад которых, попадает в заданный диапазон
        public void DemoShowBySalary(double from = 4000d, double to = 31000d)
        {
            Utils.ShowNavBarTask("    Выбрать работников, оклад которых, попадает в заданный диапазон");
            // генерация диапазона значений
            double lo = Utils.GetRandom(from, to);
            double hi = Utils.GetRandom(lo, to);

            Worker[] temp = _workers.FindBySalary(lo, hi);

            if (temp.Length != 0) ShowWorkers(temp, $"Работники, оклад которых, попадает в диапазон ({lo,4:f2}... {hi,4:f2})", 8);

            else Utils.WriteXY(9, 5, $"Работники, оклад которых, попадает в диапазон ({lo, 4:f2}... {hi, 4:f2}) не найдены!", ConsoleColor.Yellow);
        } // WorkerShow

        // Выбрать работников с заданной должностью
        public void DemoShowByPosition()
        {
            Utils.ShowNavBarTask("    Выбрать работников с заданной должностью");
            // ввод должности 
            string position = Interaction.InputBox("Введите должность для поиска:", "Выбрать работников с заданной должностью");
            
            Worker[] temp = _workers.FindByPosition(position);

            if (temp.Length != 0) ShowWorkers(temp, $"Работники с заданной должностью:", 8);

            else {
                Utils.WriteXY(9, 5, $"Работники с заданной должностью не найдены!", ConsoleColor.Yellow);
                Console.ReadKey(true);
            } // if

            // Ожидать нажатия любой клавиши 
            Console.CursorVisible = true;
            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
            Console.ReadKey(true);
        } // WorkerShow


        // ---------------------------------------------------------------

        // Начальное формирование массива маршрутов
        public void RoutesInitialize(){
            Utils.ShowNavBarTask("  Начальное формирование массива маршрутов");

            _routes.Initialize();
            _routes.Show("Данные сформированы", 8);
        } // RoutesInitialize

        // Вывод данных фирмы в консоль
        public void RoutesShow() {
            Utils.ShowNavBarTask("  Вывод данных фирмы в консоль");

            _routes.Show("Данные фирмы", 8);
        } // RoutesShow

        // Упорядочивание маршрутов по коду маршрута
        public void DemoOrderByCode()
        {
            Utils.ShowNavBarTask("  Упорядочивание маршрутов по коду маршрута");

            _routes.OrderByCode();
            _routes.Show("Маршруты упорядочены по коду маршрута", 8);
        } // DemoOrderByCode

        // Упорядочивание маршрутов по начальному пункту маршрута
        public void DemoOrderByStartingPoint()
        {
            Utils.ShowNavBarTask("  Упорядочивание маршрутов по начальному пункту маршрута");

            _routes.OrderByStartingPoint();
            _routes.Show("Маршруты упорядочены по начальному пункту маршрута", 8);
        } // DemoOrderByStartindPoint

        // Упорядочивание маршрутов по убыванию протяженности маршрута
        public void DemoOrderByLenght()
        {
            Utils.ShowNavBarTask("  Упорядочивание маршрутов по убыванию протяженности маршрута");

            _routes.OrderByLenght();
            _routes.Show("Маршруты упорядочены по убыванию протяженности маршрута", 8);
        } // DemoOrderByStartindPoint

        // Выбрать маршруты, протяженность которых, попадает в заданный диапазон
        public void DemoShowByLenght(double from = 100d, double to = 301d)
        {
            Utils.ShowNavBarTask("    Выбрать маршруты, протяженность которых, попадает в заданный диапазон");
            // генерация диапазона значений
            double lo = Utils.GetRandom(from, to);
            double hi = Utils.GetRandom(lo, to);

            Route[] temp = _routes.FindByLenght(lo, hi);

            if (temp.Length != 0) ShowRoutes(temp, $"Маршруты, протяженность которых, попадает в диапазон ({lo,4:f2}... {hi,4:f2})", 8);

            else Utils.WriteXY(9, 5, $"Маршруты, протяженность которых, попадает в диапазон ({lo,4:f2}... {hi,4:f2}) не найдены!", ConsoleColor.Yellow);
        } // DemoShowByLenght

        // Выбрать маршруты, начинающиеся или завершающиеся в заданном пункте
        public void DemoShowByPoint()
        {
            Utils.ShowNavBarTask("    Выбрать маршруты, начинающиеся или завершающиеся в заданном пункте");
            // TODO: ввод пункта 
            // ввод должности 
            string point = Interaction.InputBox("Введите пункт для поиска:", "Выбрать маршруты, начинающиеся или завершающиеся в заданном пункте");

            Route[] temp = _routes.FindByPoint(point);

            if (temp.Length != 0) ShowRoutes(temp, $"Маршруты, начинающиеся или завершающиеся в заданном пункте:", 8);

            else
            {
                Utils.WriteXY(9, 5, $"Маршруты, начинающиеся или завершающиеся в заданном пункте не найдены!", ConsoleColor.Yellow);
                Console.ReadKey(true);
            } // if

            // Ожидать нажатия любой клавиши 
            Console.CursorVisible = true;
            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
            Console.ReadKey(true);
        } // WorkerShow
    } // class App
}