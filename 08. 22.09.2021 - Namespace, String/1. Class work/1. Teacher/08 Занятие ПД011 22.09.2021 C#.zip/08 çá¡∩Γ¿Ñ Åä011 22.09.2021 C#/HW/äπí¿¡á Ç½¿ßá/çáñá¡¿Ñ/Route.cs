﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    // класс туристического маршрута
    public class Route
    {
        private string _startingPoint;// название начального пункта маршрута

        private string _finishedPoint;// название конечного пункта маршрута
        private string _code;         // буквенно-цифровой код маршрута
        private double _lenght;       // протяженность маршрута в километрах

        public string StartingPoint {
            get => _startingPoint;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Route: Некорректное значение начального пункта маршрута!"); _startingPoint = value; }
        } // StartingPoint

        public string FinishedPoint {
            get => _finishedPoint;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Route: Некорректное значение конечного пункта маршрута!"); _finishedPoint = value; }
        } // FinishedPoint

        public string Code {
            get => _code;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Route: Некорректное значение кода маршрута!"); _code = value; }
        } // Code

        public double Lenght {
            get => _lenght;
            set { if (value <= 0d) throw new Exception("Route: Некорректное значение протяженности маршрута!"); _lenght = value; }
        } // Lenght

        // представление объекта в виде строки таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_startingPoint ?? "не указано",-24} │ {_finishedPoint ?? "не указано",-23} │ {_code,12} " +
            $"│ {_lenght, 18:f2} км. |";

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬──────────────────────────┬─────────────────────────┬──────────────┬────────────────────────┐\n" +
                $"{spaces}│  №  │ Начальный пункт маршрута │ Конечный пункт маршрута │ Код маршрута │ Протяженность маршрута │\n" +
                $"{spaces}├─────┼──────────────────────────┼─────────────────────────┼──────────────┼────────────────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴──────────────────────────┴─────────────────────────┴──────────────┴────────────────────────┘";

        // Компаратор для сортировки по коду маршрута
        public static int CodeComparer(Route r1, Route r2) =>
            r1.Code.CompareTo(r2.Code);

        // Компаратор для сортировки по начальному пункту маршрута
        public static int StartingPointComparer(Route r1, Route r2) =>
            r1.StartingPoint.CompareTo(r2.StartingPoint);

        // Компаратор для сортировки по убыванию протяженности маршрута
        public static int LenghtComparer(Route r1, Route r2) =>
            r2.Lenght.CompareTo(r1.Lenght);

    } // Route
}
