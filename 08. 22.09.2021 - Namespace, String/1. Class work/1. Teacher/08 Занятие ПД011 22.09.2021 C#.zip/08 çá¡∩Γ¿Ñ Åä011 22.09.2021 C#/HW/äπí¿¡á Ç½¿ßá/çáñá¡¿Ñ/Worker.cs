﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    // Класс работника некоторого предприятия
    public class Worker
    {
        
        private string _name;           // фамилия и инициалы работника
        private string _position;       // название занимаемой должности
        private int _year;              // год поступления на работу
        private double _salary;         // оклад

        public string Name{
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Worker: Некорректное значение фамилии и инициалов работника!"); _name = value; }
        } // Name

        public string Position {
            get => _position;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Worker: Некорректное значение должности работника!"); _position = value; }
        } // Position

        public int Year {
            get => _year; 
            set { if (value <= 0 || value > DateTime.Now.Year) throw new Exception("Worker: Некорректное значение года поступления на работу!"); _year = value; }
        } // Year

        public double Salary {
            get => _salary;
            set { if (value <= 0d) throw new Exception("Worker: Некорректное значение оклада работника!"); _salary = value; }
        } // Salary

        // метод вычисления стажа работы
        public int WorkExperience() => DateTime.Now.Year - _year;

        // представление объекта в виде строки таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_name??"не указано", -18} │ {_position ?? "не указано", -21} │ {_year, 11} год " +
            $"│ {_salary, 9:f2}  │ {WorkExperience(), 10}   |";

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬────────────────────┬───────────────────────┬─────────────────┬────────────┬──────────────┐\n" +
                $"{spaces}│  №  │    Фамилия И.О.    │       Должность       │ Год поступления │   Оклад,   │ Стаж работы, │\n" +
                $"{spaces}│     │                    │                       │    на работу    │    руб.    │      г.      │\n" +
                $"{spaces}├─────┼────────────────────┼───────────────────────┼─────────────────┼────────────┼──────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴────────────────────┴───────────────────────┴─────────────────┴────────────┴──────────────┘";


        // Компаратор для сортировки по алфавиту
        public static int NameComparer(Worker w1, Worker w2) =>
            w1.Name.CompareTo(w2.Name);

        // Компаратор для сортировки по должности
        public static int PositionComparer(Worker w1, Worker w2) =>
            w1.Position.CompareTo(w2.Position);

        // Компаратор для сортировки по убыванию стажа работы
        public static int WorkExperienceComparer(Worker w1, Worker w2) =>
            w2.WorkExperience().CompareTo(w1.WorkExperience());
    }
}
