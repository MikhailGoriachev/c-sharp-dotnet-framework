﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction

namespace Задание
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 22.09.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Начальное формирование массива работников" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Вывод данных предприятия в консоль" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1. Упорядочивание работников по алфавиту" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 1. Упорядочивание работников по должности" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 1. Упорядочивание работников по убыванию стажа работы" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Задача 1. Выбрать работников, оклад которых, попадает в заданный диапазон" },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Задача 1. Выбрать работников с заданной должностью" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Начальное формирование массива маршрутов" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Вывод данных фирмы в консоль" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2. Упорядочивание маршрутов по коду маршрута" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2. Упорядочивание маршрутов по начальному пункту маршрута" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Задача 2. Упорядочивание маршрутов по убыванию протяженности маршрута" },
                new MenuItem { HotKey = ConsoleKey.H, Text = "Задача 2. Выбрать маршруты, протяженность которых, попадает в заданный диапазон" },
                new MenuItem { HotKey = ConsoleKey.J, Text = "Задача 2. Выбрать маршруты, начинающиеся или завершающиеся в заданном пункте" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 22.09.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Начальное формирование массива работников
                        case ConsoleKey.Q:
                            app.WorkerInitialize();
                            break;

                        // Вывод данных предприятия в консоль
                        case ConsoleKey.W:
                            app.WorkerShow();
                            break;


                        // Упорядочивание работников по алфавиту
                        case ConsoleKey.E:
                            app.DemoOrderByName();
                            break;

                        // Упорядочивание работников по должности
                        case ConsoleKey.R:
                            app.DemoOrderByPosition();
                            break;

                        // Упорядочивание работников по убыванию стажа работы
                        case ConsoleKey.T:
                            app.DemoOrderByWorkExperience();
                            break;

                        // Выбрать работников, оклад которых, попадает в заданный диапазон
                        case ConsoleKey.Y:
                            app.DemoShowBySalary();
                            break;

                        // Выбрать работников с заданной должностью
                        case ConsoleKey.U:
                            app.DemoShowByPosition();
                            break;

                        // ------------------------------------------------------------

                        // Начальное формирование массива маршрутов
                        case ConsoleKey.A:
                            app.RoutesInitialize();
                            break;

                        // Вывод данных фирмы в консоль
                        case ConsoleKey.S:
                            app.RoutesShow();
                            break;

                        // Упорядочивание маршрутов по коду маршрута
                        case ConsoleKey.D:
                            app.DemoOrderByCode();
                            break;

                        // Упорядочивание маршрутов по начальному пункту маршрута
                        case ConsoleKey.F:
                            app.DemoOrderByStartingPoint();
                            break;

                        // Упорядочивание маршрутов по убыванию протяженности маршрута
                        case ConsoleKey.G:
                            app.DemoOrderByLenght();
                            break;

                        // Выбрать маршруты, протяженность которых, попадает в заданный диапазон
                        case ConsoleKey.H:
                            app.DemoShowByLenght();
                            break;

                        // Выбрать маршруты, начинающиеся или завершающиеся в заданном пункте
                        case ConsoleKey.J:
                            app.DemoShowByPoint();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
