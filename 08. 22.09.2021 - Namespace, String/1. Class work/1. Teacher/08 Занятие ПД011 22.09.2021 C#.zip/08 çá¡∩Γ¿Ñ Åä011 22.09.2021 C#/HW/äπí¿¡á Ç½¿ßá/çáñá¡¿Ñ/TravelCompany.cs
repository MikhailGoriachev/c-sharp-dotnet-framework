﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    // класс туристической фирмы
    public class TravelCompany {
        private string _name;              // название туристической фирмы 
        private Route[] _routes;           // коллекция маршрутов

        public string Name {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("TravelCompany: Некорректное значение названия туристической фирмы!"); _name = value; }
        } // Name
        public bool Empty => _routes.Length == 0;

        public void Initialize()
        {
            Name = "Turnado";
            _routes = new[] {
                new Route {StartingPoint = "дер. Бяково"        , FinishedPoint = "река Венёвка"       , Code = "BV16", Lenght = 168d},
                new Route {StartingPoint = "с. Глебовское"      , FinishedPoint = "Александрова гора"  , Code = "GA20", Lenght = 200d},
                new Route {StartingPoint = "пос. Тюнгур"        , FinishedPoint = "водопап Текелю"     , Code = "TT25", Lenght = 250d},
                new Route {StartingPoint = "пос. Верхний Баксан", FinishedPoint = "Лунная поляна"      , Code = "VL30", Lenght = 300d},
                new Route {StartingPoint = "с. Любимовка"       , FinishedPoint = "Ласпинский перевал" , Code = "LL11", Lenght = 115d},
                new Route {StartingPoint = "г. Хабаровск"       , FinishedPoint = "река Анюй"          , Code = "HA15", Lenght = 150d},
                new Route {StartingPoint = "пос. Чупа"          , FinishedPoint = "дер. Нижняя Пулонга", Code = "CN11", Lenght = 116d},
                new Route {StartingPoint = "г. Мурманск"        , FinishedPoint = "храм \"Два брата\"" , Code = "MD13", Lenght = 130d},
                new Route {StartingPoint = "г. Иркутск"         , FinishedPoint = "пос. Хужир"         , Code = "IH25", Lenght = 250d},
                new Route {StartingPoint = "храм \"Два брата\"" , FinishedPoint = "г. Мурманск"        , Code = "DM13", Lenght = 130d},
            };
        } // Initialize

        // Вывести данные о туристической фирме
        public void Show(string caption, int indent)
        {
            // вывод заголовка таблицы
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}Название туристической фирмы: \"{Name}\"\n" +
                              $"{Route.Header(indent)}");

            // вывод всех элементов массива маршрутов
            int row = 1;
            void OutItem(Route p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(_routes, OutItem);

            // вывод подвала таблицы 
            Console.WriteLine(Route.Footer(indent));
        } // Show

        //  Выбор маршрутов, протяженность которых, попадает в заданный диапазон
        public Route[] FindByLenght(double lo, double hi)
        {
            // предикат для отбора маршрутов
            bool InDiapazone(Route w) => w.Lenght >= lo && w.Lenght <= hi;

            // отбор маршрутов 
            Route[] selected = Array.FindAll(_routes, InDiapazone);

            return selected;
        } // FindByLenght

        //  Выбор маршрутов, начинающиеся или завершающиеся в заданном пункте
        public Route[] FindByPoint(string point)
        {
            // предикат для отбора маршрутов
            bool IsPoint(Route r) => r.StartingPoint.ToLower() == point.ToLower() || r.FinishedPoint.ToLower() == point.ToLower();

            // отбор маршрутов 
            Route[] selected = Array.FindAll(_routes, IsPoint);

            return selected;
        } // FindByPoint

        // сортировка массива маршрутов по коду
        public void OrderByCode() => Array.Sort(_routes, Route.CodeComparer);

        // сортировка массива маршрутов по начальному пункту
        public void OrderByStartingPoint() => Array.Sort(_routes, Route.StartingPointComparer);

        // сортировка массива маршрутов по убыванию протяженности
        public void OrderByLenght() => Array.Sort(_routes, Route.LenghtComparer);
    }
}
