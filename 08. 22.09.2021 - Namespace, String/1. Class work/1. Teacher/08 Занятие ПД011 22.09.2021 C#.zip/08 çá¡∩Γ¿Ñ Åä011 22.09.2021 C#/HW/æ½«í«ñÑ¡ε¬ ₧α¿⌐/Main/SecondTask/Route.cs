﻿using System;
using Main.FirstTask;
using Main.Utilities.TableFormatter;


namespace Main.SecondTask
{


public class Route
{
	private double _distance;
	
	[TableData("Начальный пункт", "{0, -17}")]
	public string Dispatch { get; set; }

	[TableData("Конечный пункт", "{0, -17}")]
	public string Destination { get; set; }

	[TableData("Код", "{0,-12}")]
	public string Code { get; set; }
	
	
	[TableData("Протяженность", "{0, -15}")]
	public double Distance
	{
		get => _distance;
		set =>
			_distance = value < 0
							? throw new ArgumentOutOfRangeException
								  (nameof(value))
							: value;
	}


	public static int CompareByCodeAscending(Route lhs, Route rhs) =>
		lhs?.Code?.CompareTo(rhs?.Code) ?? 0;

	public static int CompareByDispatchAscending(Route lhs, Route rhs) =>
		lhs?.Dispatch?.CompareTo(rhs?.Dispatch) ?? 0;
	
	public static int CompareByDistanceDescending(Route lhs, Route rhs) =>
		rhs?.Distance.CompareTo(lhs?.Distance ?? 0) ?? 0;
}


}
