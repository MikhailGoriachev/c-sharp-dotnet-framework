﻿using System;
using Main.Utilities.TableFormatter;


namespace Main.FirstTask
{


public class Worker
{
	private decimal _salary;

	[TableData("Имя и инициалы", "{0, -28}")]
	public string FullName { get; set; }
	
	[TableData("Должность", "{0, -11}")]
	public string Position { get; set; }
	
	[TableData("Год поступления", "{0,-17:Y}")]
	public DateTime AdmissionDate { get; set; }
	
	[TableData("Стаж", "{0, -12}")]
	public int EmploymentPeriod => DateTime.Now.Year - AdmissionDate.Year;
	
	[TableData("Оклад", "{0, -14}")]
	public decimal Salary
	{
		get => _salary;
		set =>
			_salary = value <= 0
						  ? throw new ArgumentOutOfRangeException(nameof(value))
						  : value;
	}


	public static int CompareByFullNameAscending(Worker lhs, Worker rhs) =>
		lhs?.FullName?.CompareTo(rhs?.FullName) ?? 0;


	public static int CompareByPositionAscending(Worker lhs, Worker rhs) =>
		lhs?.Position?.CompareTo(rhs?.Position) ?? 0;


	public static int CompareByEmploymentPeriodDescending(Worker lhs, Worker rhs) =>
		rhs?.EmploymentPeriod.CompareTo(lhs?.EmploymentPeriod ?? 0) ?? 0;
}


}
