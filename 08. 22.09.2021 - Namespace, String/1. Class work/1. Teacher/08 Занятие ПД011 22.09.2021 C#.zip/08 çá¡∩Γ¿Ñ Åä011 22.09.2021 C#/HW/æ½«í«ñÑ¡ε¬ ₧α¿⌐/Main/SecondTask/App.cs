﻿using System;
using Main.FirstTask;
using Main.SecondTask;
using Main.Utilities;
using Main.Utilities.Menu;
using Main.Utilities.TableFormatter;
using Microsoft.VisualBasic;


namespace Main
{


public partial class App
{
	private void SecondTask()
	{
		MenuWrapper menu = new MenuWrapper()
		{
			Menu = new Menu("Задача 2. Маршруты и туристическая фирма", new[]
			{
				new MenuItem("Вывод данных фирмы в консоль", _tourOperator.Show),
				new MenuItem("Упорядочивание маршрутов по коду", OrderByCodeAscending),
				new MenuItem("Упорядочивание маршрутов по начальному пункту", OrderByDispatchAscending),
				new MenuItem("Упорядочивание маршрутов по убыванию протяженности маршрута", OrderByDistanceDescending),
				new MenuItem("Выборка маршрутов по протяженности", SelectByDistance),
				new MenuItem("Выборка маршрутов по пункту", SelectByDestination),
			})
		};

		menu.Run();
	}


	private void SelectByDistance()
	{
		_tourOperator.Show();

		double min, max;
		do
		{
			min = General.Rand.RealNextDouble(RandomRanges.min, RandomRanges.max);
			max = General.Rand.RealNextDouble(RandomRanges.min, RandomRanges.max);
		} while (min > max);

		Console.WriteLine("\n\nСгенерированный диапазон:");
		Console.WriteLine($"\tmin: {min:F}, max: {max:F}");

		bool IsInRange(Route route) => route.Distance > min && route.Distance < max;

		ShowSelectedRoutes(IsInRange);
	}


	private void SelectByDestination()
	{
		_tourOperator.Show();

		string searched = Interaction.InputBox("Destination1", "Введите название пункта");

		bool IsOurPoint(Route route) =>
			route.Destination.Equals(searched, StringComparison.CurrentCulture)
			|| route.Dispatch.Equals(searched, StringComparison.CurrentCulture);

		ShowSelectedRoutes(IsOurPoint);
	}


	private void OrderByCodeAscending()
	{
		_tourOperator.OrderByCodeAscending();

		_tourOperator.Show();
	}


	private void OrderByDispatchAscending()
	{
		_tourOperator.OrderByDispatchAscending();

		_tourOperator.Show();
	}


	private void OrderByDistanceDescending()
	{
		_tourOperator.OrderByDistanceDescending();

		_tourOperator.Show();
	}


	private void ShowSelectedRoutes(Predicate<Route> predicate)
	{
		var selectedRoutes = _tourOperator.Select(predicate);

		Console.WriteLine("\n\nВыбранные маршруты: ");
		TableFormatter<Route> table = new TableFormatter<Route>();
		table.Show(selectedRoutes);
	}
}


}
