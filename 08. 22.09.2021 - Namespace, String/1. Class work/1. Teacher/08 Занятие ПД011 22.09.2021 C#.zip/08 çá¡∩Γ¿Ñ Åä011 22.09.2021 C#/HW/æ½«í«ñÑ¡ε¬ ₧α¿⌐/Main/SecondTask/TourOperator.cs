﻿using System;
using System.Drawing;
using Main.Utilities;
using Main.Utilities.TableFormatter;


namespace Main.SecondTask
{


public class TourOperator
{
	private Route[] _routes;
	private string _title;


	public string Title { get => _title; set => _title = value.ReturnIfNotNullEmptyWhitespaceOtherwiseThrow(); }
	public Route[] Routes { get => _routes; set => _routes = value.ReturnIfNotNullOtherwiseThrow(); }


	public void Show()
	{
		TableFormatter<Route> table = new TableFormatter<Route>();

		Console.WriteLine(Title.Center(table.TableWidth));
		table.Options.CursorPosition = new Point(Console.CursorLeft, Console.CursorTop);
		table.Show(Routes);
	}


	public Route[] Select(Predicate<Route> predicate)
	{
		Route[] selected = new Route[Routes.Length];
		int index = 0;

		foreach (var i in Routes)
			if (predicate.Invoke(i))
				selected[index++] = i;

		Array.Resize(ref selected, index);

		return selected;
	}


	public void OrderByCodeAscending() => Array.Sort(Routes, Route.CompareByCodeAscending);
	public void OrderByDispatchAscending() => Array.Sort(Routes, Route.CompareByDispatchAscending);
	public void OrderByDistanceDescending() => Array.Sort(Routes, Route.CompareByDistanceDescending);
}


}
