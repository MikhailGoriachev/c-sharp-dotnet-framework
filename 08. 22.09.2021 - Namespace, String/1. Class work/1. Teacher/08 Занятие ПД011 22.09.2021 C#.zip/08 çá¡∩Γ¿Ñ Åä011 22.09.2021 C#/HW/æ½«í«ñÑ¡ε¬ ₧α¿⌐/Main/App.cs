﻿using System;
using Main.FirstTask;
using Main.SecondTask;
using Main.Utilities.Menu;


namespace Main
{


public partial class App : MenuWrapper
{
	private static readonly (double min, double max) RandomRanges = (0, 12);
	
	public App() =>
		Menu = new Menu("Главное меню приложения", new[]
		{
			new MenuItem("Задача 1. Работники и предприятие", FirstTask)
				{ IsSimpleInvoke = true },
			new MenuItem("Задача 2. Маршруты и туристическая фирма", SecondTask)
				{ IsSimpleInvoke = true }
		});


	private readonly Enterprise _enterprise = new Enterprise
	{
		City = "City", Workers = new[]
		{
			new Worker
			{
				FullName = "FullName01", Position = "Position01",
				Salary = 2, AdmissionDate = new DateTime(1453, 4, 6)
			},
			new Worker
			{
				FullName = "FullName02", Position = "Position02",
				Salary = 2, AdmissionDate = new DateTime(1185, 3, 16)
			},
			new Worker
			{
				FullName = "FullName03", Position = "Position03",
				Salary = 3, AdmissionDate = new DateTime(885, 11, 25)
			},
			new Worker
			{
				FullName = "FullName04", Position = "Position04",
				Salary = 4, AdmissionDate = new DateTime(1492, 8, 3)
			},
			new Worker
			{
				FullName = "FullName05", Position = "Position05",
				Salary = 5, AdmissionDate = new DateTime(2003, 9, 11)
			},
			new Worker
			{
				FullName = "FullName06", Position = "Position06",
				Salary = 6, AdmissionDate = new DateTime(2011, 5, 2)
			},
			new Worker
			{
				FullName = "FullName06", Position = "Position06",
				Salary = 6, AdmissionDate = new DateTime(1434, 5, 30)
			},
			new Worker
			{
				FullName = "FullName07", Position = "Position07",
				Salary = 7, AdmissionDate = new DateTime(1889, 4, 20)
			},
			new Worker
			{
				FullName = "FullName08", Position = "Position08",
				Salary = 8, AdmissionDate = new DateTime(1769, 8, 15)
			},
			new Worker
			{
				FullName = "FullName09", Position = "Position09",
				Salary = 9, AdmissionDate = new DateTime(1517, 10, 31)
			},
			new Worker
			{
				FullName = "FullName10", Position = "Position10",
				Salary = 10, AdmissionDate = new DateTime(1603, 7, 4)
			},
			new Worker
			{
				FullName = "FullName11", Position = "Position11",
				Salary = 11, AdmissionDate = new DateTime(1965, 1, 5)
			},
			new Worker
			{
				FullName = "FullName12", Position = "Position12",
				Salary = 12, AdmissionDate = new DateTime(2003, 2, 26)
			}
		}
	};


	private readonly TourOperator _tourOperator = new TourOperator
	{
		Title = "Title", Routes = new[]
		{
			new Route
			{
				Destination = "Destination01", Dispatch = "Dispatch01",
				Distance = 1, Code = "Code01"
			},
			new Route
			{
				Destination = "Destination02", Dispatch = "Dispatch05",
				Distance = 2, Code = "Code02"
			},
			new Route
			{
				Destination = "Destination03", Dispatch = "Dispatch03",
				Distance = 3, Code = "Code03"
			},
			new Route
			{
				Destination = "Destination04", Dispatch = "Dispatch04",
				Distance = 4, Code = "Code04"
			},
			new Route
			{
				Destination = "Destination05", Dispatch = "Dispatch05",
				Distance = 5, Code = "Code05"
			},
			new Route
			{
				Destination = "Destination06", Dispatch = "Dispatch06",
				Distance = 6, Code = "Code06"
			},
			new Route
			{
				Destination = "Destination07", Dispatch = "Dispatch05",
				Distance = 7, Code = "Code07"
			},
			new Route
			{
				Destination = "Destination08", Dispatch = "Dispatch08",
				Distance = 8, Code = "Code08"
			},
			new Route
			{
				Destination = "Destination09", Dispatch = "Dispatch09",
				Distance = 9, Code = "Code09"
			},
			new Route
			{
				Destination = "Destination10", Dispatch = "Dispatch10",
				Distance = 10, Code = "Code10"
			}
		}
	};
}


}
