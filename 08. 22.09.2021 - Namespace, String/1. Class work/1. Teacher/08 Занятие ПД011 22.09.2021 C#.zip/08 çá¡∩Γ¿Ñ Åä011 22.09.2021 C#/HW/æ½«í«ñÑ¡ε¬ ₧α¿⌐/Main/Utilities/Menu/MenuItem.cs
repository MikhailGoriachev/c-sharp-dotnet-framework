﻿using System;


namespace Main.Utilities.Menu
{


public sealed class MenuItem
{
	private readonly Action _callback;


	public MenuItem(string text, Action callback)
	{
		Text = text.ReturnIfNotNullEmptyWhitespaceOtherwiseThrow();

		_callback = callback.ReturnIfNotNullOtherwiseThrow();
	}


	public string Text { get; }
	public bool IsDivide { get; set; } = false;
	public bool IsSimpleInvoke { get; set; } = false;


	public void InvokeItem()
	{
		if (IsSimpleInvoke)
		{
			_callback.Invoke();
			return;
		}

		Console.Clear();
		Console.SetCursorPosition(0, 0);

		ShowTitleOfItem();
		_callback.Invoke();

		ProperlyMakeIndentsAfterInvoke();
		Console.Clear();
	}


	private static void ProperlyMakeIndentsAfterInvoke()
	{
		if (Console.CursorTop >= Console.WindowHeight)
			General.CursorToPositionAndPause(0, Console.CursorTop + 5);
		else
			General.CursorToBottomAndPause();
	}


	private void ShowTitleOfItem()
	{
		object space = ' ';

		$"{space,10} {Text} {space,10}".ColoredLine(Palette.Navbar);

		Console.WriteLine("\n\n");
	}
}


}
