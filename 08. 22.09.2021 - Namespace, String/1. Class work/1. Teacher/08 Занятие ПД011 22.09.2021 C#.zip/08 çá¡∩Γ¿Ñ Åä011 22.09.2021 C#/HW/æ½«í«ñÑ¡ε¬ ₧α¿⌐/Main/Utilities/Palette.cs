﻿using System;


namespace Main.Utilities
{


public static class Palette
{
	public static ConsoleColor DefaultForeground => ConsoleColor.Black;
	public static ConsoleColor DefaultBackground => ConsoleColor.DarkGray;
	public static ConsoleColor DefaultBackgroundDedicated => ConsoleColor.Gray;


	public static Color Default => new Color
		{ Foreground = DefaultForeground, Background = DefaultBackground };
	public static Color Info => new Color
		{ Foreground = ConsoleColor.Cyan, Background = DefaultBackground };
	public static Color Error => new Color
		{ Foreground = ConsoleColor.DarkRed, Background = ConsoleColor.Black };


	public static Color Accent => new Color
		{ Foreground = ConsoleColor.Green, Background = DefaultBackground };
	public static Color AccentDedicated => new Color
		{ Foreground = ConsoleColor.Green, Background = DefaultBackgroundDedicated };


	public static Color Secondary => new Color
		{ Foreground = ConsoleColor.Magenta, Background = DefaultBackground };
	public static Color SecondaryDedicated => new Color
		{ Foreground = ConsoleColor.Magenta, Background = DefaultBackgroundDedicated };


	public static Color Tertiary => new Color
		{ Foreground = ConsoleColor.Yellow, Background = DefaultBackground };
	public static Color TertiaryDedicated => new Color
		{ Foreground = ConsoleColor.DarkYellow, Background = DefaultBackgroundDedicated };
}


}
