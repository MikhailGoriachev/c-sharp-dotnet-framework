﻿using System;
using Main.FirstTask;
using Main.Utilities;
using Main.Utilities.Menu;
using Main.Utilities.TableFormatter;


namespace Main
{


public partial class App
{
	private void FirstTask()
	{
		MenuWrapper menu = new MenuWrapper()
		{
			Menu = new Menu("Задача 1. Работники и предприятие", new[]
			{
				new MenuItem("Вывод данных предприятия в консоль", _enterprise.Show),
				new MenuItem("Упорядочивание работников по алфавиту", OrderByFullNameAscending),
				new MenuItem("Упорядочивание работников по должности", OrderByPositionAscending),
				new MenuItem("Упорядочивание работников по убыванию стажа работы", OrderByEmploymentPeriodDescending),
				new MenuItem("Выборка сотрудников по диапазону оклада", SelectBySalary),
				new MenuItem("Выборка сотрудников по должности", SelectByPosition),
			})
		};

		menu.Run();
	}


	private void SelectByPosition()
	{
		_enterprise.Show();

		Console.Write("\n\nВведите должность: ");
		string position = Console.ReadLine();

		bool IsOurPosition(Worker worker) =>
			worker.Position.Equals(position,
				StringComparison.CurrentCulture);

		ShowSelectedWorkers(IsOurPosition);
	}


	private void SelectBySalary()
	{
		_enterprise.Show();

		decimal min, max;
		do
		{
			min = (decimal)General.Rand.RealNextDouble(RandomRanges.min, RandomRanges.max);
			max = (decimal)General.Rand.RealNextDouble(RandomRanges.min, RandomRanges.max);
		} while (min > max);

		Console.WriteLine("\n\nСгенерированный диапазон:");
		Console.WriteLine($"\tmin: {min:F}, max: {max:F}");
		
		bool IsInRange(Worker worker) => worker.Salary > min && worker.Salary < max;

		ShowSelectedWorkers(IsInRange);
	}


	private void OrderByFullNameAscending()
	{
		_enterprise.OrderByFullNameAscending();

		_enterprise.Show();
	}


	private void OrderByPositionAscending()
	{
		_enterprise.OrderByPositionAscending();

		_enterprise.Show();
	}


	private void OrderByEmploymentPeriodDescending()
	{
		_enterprise.OrderByEmploymentPeriodDescending();

		_enterprise.Show();
	}


	private void ShowSelectedWorkers(Predicate<Worker> predicate)
	{
		var selectedWorkers = _enterprise.Select(predicate);

		Console.WriteLine("\n\nВыбранные работники: ");
		TableFormatter<Worker> table = new TableFormatter<Worker>();
		table.Show(selectedWorkers);
	}
}


}
