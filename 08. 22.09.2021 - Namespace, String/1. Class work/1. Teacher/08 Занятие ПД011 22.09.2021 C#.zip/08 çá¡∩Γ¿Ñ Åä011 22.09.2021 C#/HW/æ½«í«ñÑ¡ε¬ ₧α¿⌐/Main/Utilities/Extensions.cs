﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Main.Utilities
{


public static class Extensions
{
	public static void ColoredLine(this string message, Color color)
	{
		message.Colored(color);
		Console.WriteLine();
	}


	public static void Colored(this string message, Color color)
	{
		Color old = Color.Instantiate();

		color.AsCurrent();

		Console.Write(message);

		old.AsCurrent();
	}


	public static string Center(this string message, int width)
	{
		if (message is null) return string.Empty;

		int leftPadding = (width - message.Length) / 2;
		int rightPadding = width - message.Length - leftPadding;

		if (leftPadding < 0 || rightPadding < 0)
			throw new ArgumentOutOfRangeException
				($"Строка для центрирования должна вмещаться в {nameof(width)}");

		return $"{" ".PadLeft(leftPadding)}{message}{"".PadRight(rightPadding)}";
	}


	public static string ReturnIfNotNullEmptyWhitespaceOtherwiseThrow(this string message)
	{
		if (string.IsNullOrWhiteSpace(message))
			throw new ArgumentException(
				"Параметр не может быть null, empty, whitespace",
				nameof(message));

		return message;
	}


	public static void ReplaceLast(this StringBuilder builder, char newSymbol) =>
		builder[builder.Length - 1] = newSymbol;


	public static T ReturnIfNotNullOtherwiseThrow<T>(this T obj)
		where T : class
	{
		if (obj is null)
			throw new ArgumentNullException(nameof(obj));

		return obj;
	}


	public static IEnumerable<T> ReturnIfNotNullOtherwiseThrow<T>(this IEnumerable<T> collection)
		where T : class
	{
		if (collection?.Any(triangle => triangle is null) ?? true)
			throw new ArgumentNullException(nameof(collection));

		return collection;
	}


	public static void ReplaceLast(this StringBuilder builder, string newString)
	{
		builder.RemoveLast();
		builder.Append(newString);
	}


	public static void RemoveLast(this StringBuilder builder) => builder.Remove(builder.Length - 1, 1);


	public static void Output(this Exception e)
	{
		if (e is null) return;

		Palette.Error.AsCurrent();
		Console.Clear();

		Console.SetCursorPosition(0, Console.WindowHeight / 5);
		Console.WriteLine(e);
		Console.ReadKey(true);

		Palette.Default.AsCurrent();
		Console.Clear();
	}


	public static double RealNextDouble(this Random rand, double min = 1, double max = 10) =>
		rand.ReturnIfNotNullOtherwiseThrow().NextDouble() * (max - min) + min;
}


}
