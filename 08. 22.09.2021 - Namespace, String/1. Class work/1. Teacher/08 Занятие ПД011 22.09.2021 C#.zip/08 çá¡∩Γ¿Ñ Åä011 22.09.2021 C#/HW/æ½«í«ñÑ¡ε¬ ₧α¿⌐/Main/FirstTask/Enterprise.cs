﻿using System;
using System.Drawing;
using Main.Utilities;
using Main.Utilities.TableFormatter;


namespace Main.FirstTask
{


public class Enterprise
{
	private string _city;
	private Worker[] _workers;


	public string City { get => _city; set => _city = value.ReturnIfNotNullEmptyWhitespaceOtherwiseThrow(); }
	public Worker[] Workers { get => _workers; set => _workers = value.ReturnIfNotNullOtherwiseThrow(); }


	public void Show()
	{
		TableFormatter<Worker> table = new TableFormatter<Worker>();

		Console.WriteLine(City.Center(table.TableWidth));
		table.Options.CursorPosition = new Point(Console.CursorLeft, Console.CursorTop);
		table.Show(Workers);
	}


	public Worker[] Select(Predicate<Worker> predicate)
	{
		Worker[] selected = new Worker[Workers.Length];
		int index = 0;

		foreach (var i in Workers)
		{
			if (predicate.Invoke(i))
				selected[index++] = i;
		}
		
		Array.Resize(ref selected, index);

		return selected;
	}


	public void OrderByFullNameAscending() => Array.Sort(Workers, Worker.CompareByFullNameAscending);
	public void OrderByPositionAscending() => Array.Sort(Workers, Worker.CompareByPositionAscending);
	public void OrderByEmploymentPeriodDescending() => Array.Sort(Workers, Worker.CompareByEmploymentPeriodDescending);
}


}
