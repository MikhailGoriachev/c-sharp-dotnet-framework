﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkerRoute
{
    /*
     * Работник некоторого предприятия для информационной системы представляется классом с полями:
•	фамилия и инициалы работника;
•	название занимаемой должности;
•	год поступления на работу
•	оклад.
     */
    public class Worker
    {
        public string FullName { get; set; } // фамилия инициалы 
        public string Position { get; set; } // название должности
        private int _yearOfadmission;

        private int EmploymentPeriod => 2021 - YearOfAdmission;

        

        public int YearOfAdmission // год поступления на должность
        {
            get =>_yearOfadmission; 
            set {
                if (value < 1913)
                    throw new Exception("Некоректный год поступления на должность"); 
                _yearOfadmission = value; }
        }

        private decimal _salary;

        
        public decimal Salary // оклад в рублях
        {
            get => _salary; 
            set {
                if (value < 12792) throw new Exception("Оклад не может быть меньше минимального");
                _salary = value; }
        }

        public string ToTableRow() => $"| {FullName,-18} | {Position,-12} | {YearOfAdmission,16} | {Salary,11} | {EmploymentPeriod, 13} |";

        // компаратор фамилий работников по имени
        public static int ComparatorFullName(Worker x, Worker y) => x?.FullName?.CompareTo(y.FullName) ?? 0;

        // компаратор работников по должности
        public static int ComparatorPosition(Worker x, Worker y) => x.Position.CompareTo(y.Position);

        // компаратор по убыванию стажа
        public static int ComparatorEmploymentPeriod(Worker x, Worker y) => y.EmploymentPeriod.CompareTo(x.EmploymentPeriod); 
    }
}
