﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkerRoute
{
    public class Enterprise
    {
        /*Класс, описывающий предприятие*/
        private string _town { get; set; } // город, в котором нахоится предприятие
        Worker[] _workers;

        public Enterprise(string name, Worker[] workers)
        {
            _town = name;
            _workers = workers;
        }

        // сортировка по алфавиту 

        public void OrderByName() => Array.Sort(_workers, Worker.ComparatorFullName);

        // сортировка по должности

        public void OrderByPosition() => Array.Sort(_workers, Worker.ComparatorPosition);

        //сортировка по убыванию стража

        public void OrderByEmploymentPeriod() => Array.Sort(_workers, Worker.ComparatorEmploymentPeriod);
        


    }
}
