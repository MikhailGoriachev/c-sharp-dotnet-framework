﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkerRoute
{
    public partial class App
    {
        Worker[] workers;
        Enterprise firm;
        Route[] routes;
        TourOperator oper;


        // Начальное формирование массива работников и вывод в консоль
        public void WorkersArray()
        {
            Utils.ShowNavBarTask(" Задача 1  Начальное формирование массива работников и вывод в консоль");

            ShowTask1();

            workers = new Worker[] {
            new Worker(){ FullName = "Иванов И.В.", Position = "механик", YearOfAdmission = 1995,Salary = 15500 },
            new Worker(){ FullName = "Петров В.В.", Position = "дворник", YearOfAdmission = 1991,Salary = 13000  },
            new Worker(){ FullName = "Сидоров Р.П.", Position = "тракторист", YearOfAdmission = 1993,Salary = 14324 },
            new Worker(){ FullName = "Парамонова А.Р.", Position = "доярка", YearOfAdmission = 1998,Salary = 14500 },
            new Worker(){ FullName = "Феклистов Н.Н.", Position = "агроном", YearOfAdmission = 1982,Salary = 15678 },
            new Worker(){ FullName = "Бодров С.Е.", Position = "бухгалтер", YearOfAdmission = 1984,Salary = 17342 },
            new Worker(){ FullName = "Никонов Г.О.", Position = "кладовщик", YearOfAdmission = 1989,Salary = 18456 },
            new Worker(){ FullName = "Шатц Я.А.", Position = "маляр", YearOfAdmission = 1990,Salary = 19745 },
            new Worker(){ FullName = "Квасков В.К.", Position = "механик", YearOfAdmission = 2001,Salary = 20000 },
            new Worker(){ FullName = "Громов М.С.", Position = "председатель", YearOfAdmission = 2002,Salary = 23000 },
            new Worker(){ FullName = "Орлов Г.Т.", Position = "массовик", YearOfAdmission = 2003,Salary = 21324 },
            new Worker(){ FullName = "Соколов С.Д.", Position = "водитель", YearOfAdmission = 2005,Salary = 32000 }

            };
            firm = new Enterprise("Красный партизан", workers);

            ShowTable();


            Console.ReadKey();
        }

        public void SortByName ()
        {
            Utils.ShowNavBarTask("  Задача 1 Упорядочивание работников по алфавиту");

            Console.WriteLine("Фамилии в массиве отсортированы в алфавитном порядке");

            firm.OrderByName();

            ShowTable();

            Console.ReadKey();
        }

        public void SortByPosition ()
        {
            Utils.ShowNavBarTask(" Задача 1 Упорядочивание работников по должности");

            Console.WriteLine("Дожности в массиве отсортированы в алфавитном порядке");

            firm.OrderByPosition();

            ShowTable();

            Console.ReadKey();
        }

        public void SortByEmploymentPeriod ()
        {
            Utils.ShowNavBarTask(" Задача 1 Упорядочивание работников по убыванию стажа");

            Console.WriteLine("Стаж работников отсортирован по убыванию");

            firm.OrderByEmploymentPeriod();

            ShowTable();

            Console.ReadKey();
            
        }

        public void SalaryDiapazon()
        {
            Utils.ShowNavBarTask( " Задача 1. Список сотрудников с зарплатами из диапазона");

            Console.WriteLine("\n\n\n");
            Console.WriteLine("Диапазон зарплат от 13000 до 15000");

            // создаем массив для сотрудников с заданным диапазоном
            Worker[] selectedWorkers = new Worker[12];
            decimal low = 13000;  // минимальная граница диапазона 
            decimal high = 15000; // максимальная граница диапазона

            // поиск по массиву
            int i = 0; 
            foreach(var item in workers)
            {
                if(item.Salary <high && item.Salary > low)
                {
                    selectedWorkers[i++] = item; 
                }
                
            }
            Array.Resize(ref selectedWorkers, i);

            ShowSelectedWorkers(selectedWorkers);

            Console.ReadKey();


        }

        public void PositionSelection()
        {
            Utils.ShowNavBarTask("Задача 1. Вывести сотрудников с заданной должностью ");

            Console.WriteLine("\n\n\n");
            Console.WriteLine("Выбрать сотрудников с должностью механик");

            // создаем массив для сотрудников с заданным диапазоном
            Worker[] selectedWorkers = new Worker[12];

            int i = 0;
            string position = "механик";  // искомая должность

            foreach(var item in workers)
            {
                if(item.Position.Equals(position))
                {
                    selectedWorkers[i++] = item;
                }
            }

            Array.Resize(ref selectedWorkers, i);

            ShowSelectedWorkers(selectedWorkers);

            Console.ReadKey();



        }

        private static void ShowTask1()
        {
            string text = @"  Задача 1. Работник некоторого предприятия для информационной системы 
             представляется классом с заданными полями.
             Определите свойства в классе, методы для вывода данных о работнике в консоль. 
             Для предприятия, размещенного в заданном городе и хранящего сведения о 12 работниках 
             реализовать обработки:";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);


        }

        private static void ShowTask2()
        {
            string text = @" Задача 2. Пеший туристический маршрут для информационной системы.
            Определите свойства в классе,методы для вывода данных о маршруте в консоль. 
            Для туристической фирмы, имеющей название и хранящей сведения о 10 маршрутах 
            реализовать обработки:";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        }

        private void ShowTable()
        {
            Console.WriteLine("\n\n");

            Console.WriteLine("┌────────────────────┬──────────────┬──────────────────┬─────────────┬───────────────┐");
            Console.WriteLine("│   Ф.И.О            │  Должность   │ Год поступления  │   Оклад     │    Стаж       │");
            Console.WriteLine("├────────────────────┼──────────────┼──────────────────┼─────────────┼───────────────┤");
            foreach (var item in workers)
            {
                Console.WriteLine(item.ToTableRow());
            }

            Console.WriteLine("└────────────────────┴──────────────┴──────────────────┴─────────────┴───────────────┘");
        }

        private void ShowSelectedWorkers(Worker [] arr)
        {
            Console.WriteLine("\n\n");

            Console.WriteLine("┌────────────────────┬──────────────┬──────────────────┬─────────────┬───────────────┐");
            Console.WriteLine("│   Ф.И.О            │  Должность   │ Год поступления  │   Оклад     │    Стаж       │");
            Console.WriteLine("├────────────────────┼──────────────┼──────────────────┼─────────────┼───────────────┤");
            foreach (var item in arr)
            {
                Console.WriteLine(item.ToTableRow());
            }

            Console.WriteLine("└────────────────────┴──────────────┴──────────────────┴─────────────┴───────────────┘");
        }

        public void ShowTable2()
        {
            Console.WriteLine("\n\n");

            Console.WriteLine("┌────────────────────┬─────────────────┬──────────────────┬────────────────┐");
            Console.WriteLine("│   Начальный пункт  │  Конечный пункт │ Код маршрута     │   Протяженность│");
            Console.WriteLine("├────────────────────┼─────────────────┼──────────────────┼────────────────┼");
            foreach (var item in routes)
            {
                Console.WriteLine(item.ToTableRow());
            }

            Console.WriteLine("└────────────────────┴─────────────────┴──────────────────┴────────────────┘");

        }

        public void ShowSelected(Route[] arr)
        {
            Console.WriteLine("\n\n");

            Console.WriteLine("┌────────────────────┬─────────────────┬──────────────────┬────────────────┐");
            Console.WriteLine("│   Начальный пункт  │  Конечный пункт │ Код маршрута     │   Протяженность│");
            Console.WriteLine("├────────────────────┼─────────────────┼──────────────────┼────────────────┼");
            foreach (var item in arr)
            {
                Console.WriteLine(item.ToTableRow());
            }

            Console.WriteLine("└────────────────────┴─────────────────┴──────────────────┴────────────────┘");
        }
    }
}
