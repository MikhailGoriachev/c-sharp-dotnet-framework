﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkerRoute
{
    /*Класс, описывающий туристическую фирму*/
    public class TourOperator
    {
        public string _name { get; set; } // назваение фирмы
        Route[] _routes { get; set; } // список маршрутов

        public TourOperator(string name, Route[] routes)
        {
            _name = name;
            _routes = routes;
        }

        // сортировка по коду маршрута

        public void OrderBycode() => Array.Sort(_routes, Route.ComparatorCode);

        // сортировка по начальному пункту
        public void OrderByDispatch() => Array.Sort(_routes, Route.ComparatorDispatch);

        // сортировка по убыванию протяженности

        public void OrderByDistance() => Array.Sort(_routes, Route.ComparatorDistance);
    }
}
