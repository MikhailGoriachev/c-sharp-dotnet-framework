﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkerRoute
{
    public partial class App
    {
        public void RouteArray()
        {
            Utils.ShowNavBarTask(" Задача 2. Начальное формирование массива маршрутов и вывод в коносль");

            ShowTask2();

            routes = new Route[]
            {
                new Route() {_dispatchPoint = "Горно-Алтайск", _destinationPoint = "Барнаул", _code = "ЛО8", _distance = 120 },
                new Route() {_dispatchPoint = "Катунь", _destinationPoint = "Белуха", _code = "КА9", _distance = 130 },
                new Route() {_dispatchPoint = "Большой Яломан", _destinationPoint = "Бадагор", _code = "РТ6", _distance = 150 },
                new Route() {_dispatchPoint = "Чике-Таман", _destinationPoint = "Семинский", _code = "ВК6", _distance = 145 },
                new Route() {_dispatchPoint = "Ильгумень", _destinationPoint = "Чуя", _code = "НЕ4", _distance = 231 },
                new Route() {_dispatchPoint = "Башкаус", _destinationPoint = "Чулымшан", _code = "ЦВ6", _distance = 198 },
                new Route() {_dispatchPoint = "Аргут", _destinationPoint = "Джазатор", _code = "ТИ9", _distance = 186 },
                new Route() {_dispatchPoint = "Ак-Алаха", _destinationPoint = "Кош-Агач", _code = "ШО5", _distance = 193 },
                new Route() {_dispatchPoint = "Аккем", _destinationPoint = "Телецкое", _code = "МС4", _distance = 207 },
                new Route() {_dispatchPoint = "Орой", _destinationPoint = "Шабага", _code = "ПА9", _distance = 207 },
            };

            oper = new TourOperator("Алтай Тур", routes);

            ShowTable2(); 

            Console.ReadKey(); 
        }

        public void SortByCode()
        {
            Utils.ShowNavBarTask(" Задача 2. Упорядочивание маршрутов по коду маршрута");

            oper.OrderBycode();

            ShowTable2();

            Console.ReadKey(); 
        }

        public void SortByDispatch ()
        {
            Utils.ShowNavBarTask(" Задача 2. Упорядочивание маршрутов по начальному пункту маршрута");

            oper.OrderByDispatch();

            ShowTable2();

            Console.ReadKey(); 
        }

        public void SortByDistance ()
        {
            Utils.ShowNavBarTask(" Задача 2. Упорядочивание маршрутов по убыванию протяженности маршрута");

            oper.OrderByDistance();

            ShowTable2();

            Console.ReadKey(); 
        }

        public void DistanceDiapason()
        {
            Utils.ShowNavBarTask(" Задача 2. Вывод в массив маршрутов с заданным диапазоном");

            // определяем границы диапазона
            int low = Utils.GetRandomInt(120, 231);
            int high = Utils.GetRandomInt(120, 231);
            Route[] selectedroutes = new Route[10]; 

            Console.WriteLine("\n\n\n");
            Console.WriteLine($" Диапазон расстояний маршрутов от {low} до  {high}");

            //поиск по массиву 
            int i = 0; 
            foreach(var item in routes)
            {
                if(item._distance < high && item._distance > low)
                {
                    selectedroutes[i++] = item;
                }
            }
            Array.Resize(ref selectedroutes, i);

            ShowSelected(selectedroutes);

            Console.ReadKey(); 

        }

        public void DispatchDestination()
        {
            Utils.ShowNavBarTask(" Задача 2. Вывод в массив маршрутов с заданным пунктом");

            Route[] selectedroutes = new Route[10];
            string disdes; 

            ShowTable2();

            disdes = Interaction.InputBox("Введите пунк назначения или отправления");

            int i = 0;
            foreach(var item in routes)
            {
                if(item._dispatchPoint.Equals(disdes) || item._destinationPoint.Equals(disdes))
                {
                    selectedroutes[i++] = item;
                }
            }

            Array.Resize(ref selectedroutes, i);

            ShowSelected(selectedroutes);

            Console.ReadKey(); 
            

        }
    }
}
