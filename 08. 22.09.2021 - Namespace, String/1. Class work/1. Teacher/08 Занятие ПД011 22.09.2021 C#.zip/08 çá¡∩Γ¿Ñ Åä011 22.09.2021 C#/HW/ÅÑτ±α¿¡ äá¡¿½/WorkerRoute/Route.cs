﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkerRoute
{
    public class Route
    {
        /*
         * Задача 2. Пеший туристический маршрут для информационной системы 
         */
        public string _dispatchPoint { get; set; } // название начального пункта
        public string _destinationPoint { get; set; } // назваение конечного пункта

        public string _code { get; set; } // код маршрута

        public double _distance { get; set; } // пункт назначения

        public Route() { }
        public Route(string dispatch, string destination, string code, double distance)
        {
            _dispatchPoint = dispatch;
            _destinationPoint = destination;
            _code = code;
            _distance = distance;
        }

        // компаратор по коду маршрут 
        public static int ComparatorCode(Route x, Route y) => x._code.CompareTo(y._code);

        // компаратор по названию начального пункта

        public static int ComparatorDispatch(Route x, Route y) => x._dispatchPoint.CompareTo(y._dispatchPoint);

        // компаратор по убыванию протяженности

        public static int ComparatorDistance(Route x, Route y) => y._distance.CompareTo(x._distance);

        public  string ToTableRow() => $"| {_dispatchPoint,-18} | {_destinationPoint,-15} | {_code,16} | {_distance,14} |";


    }
}
