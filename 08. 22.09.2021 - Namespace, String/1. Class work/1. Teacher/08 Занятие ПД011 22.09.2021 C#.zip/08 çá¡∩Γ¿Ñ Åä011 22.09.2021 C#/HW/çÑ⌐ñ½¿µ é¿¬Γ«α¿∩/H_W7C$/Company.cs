﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W7C_
{   // Класс предприятие/компания , размещенного в заданном городе и
    // хранящего сведения о 12 работниках 
    class Company
    {
        public string Name { get; set; }           // название предприятия/компания 
        private Worker[] Workers { get; set; }    // коллекция работников предприятия

        // проверка массива на пустоту
        public bool Empty => Workers.Length == 0;

        // формирование массива работников
        public void Initialize()
        {
            Name = "ЧАО <<Геркулес>>"; 
            Workers = new[] {
                new Worker {FullName = "Митин И.С.",    Position  = "Грузчик",   Year = 2000, Salary = 25400d},
                new Worker {FullName = "Дымарь Л.А.",   Position  = "Бухгалтер", Year = 1991, Salary = 37560.4},
                new Worker {FullName = "Молин А.В.",    Position  = "Дизайнер",  Year = 2010, Salary = 58480.67},
                new Worker {FullName = "Бурденко С.В.", Position  = "Менеджер",  Year = 2012, Salary = 50400d},
                new Worker {FullName = "Липецкий А.Т.", Position  = "Грузчик",   Year = 2017, Salary = 25400d},
                new Worker {FullName = "Юрко И.У.",     Position  = "Навесчица", Year = 1995, Salary = 28572.5},
                new Worker {FullName = "Ливан Р.О.",    Position  = "Оператор",  Year = 2019, Salary = 38750d},
                new Worker {FullName = "Шнуров Р.А.",   Position  = "Бухгалтер", Year = 2015, Salary = 37560.4},
                new Worker {FullName = "Паладий В.Р.",  Position  = "Навесчица", Year = 2012, Salary = 28572.5},
                new Worker {FullName = "Ремин А.Ю.",    Position  = "Менеджер",  Year = 2020, Salary = 52400d},
                new Worker {FullName = "Ухов А.У.",     Position  = "Оператор",  Year = 1995, Salary = 38750d},
                new Worker {FullName = "Заяц В.В.",     Position  = "Менеджер",  Year = 2017, Salary = 55400d}

            };
        } // Initialize

        // Выбрать в массив и вывести в консоль работников,
        // оклад которых, попадает в заданный диапазон
        public void SalaryDiapazone()
        {
            double lo = 25000d;
            double hi = 45000d;
            Utils.ShowNavBarTask($" Работники с окладом от {lo, 2:f2}рубл.  до  {hi,2:f2} рубл.");

            Console.WriteLine($"\n\n\t{Name}\n {Worker.Header()}");
            for (int i = 0; i < Workers.Length; i++)
            {
                if (Workers[i].Salary > lo && Workers[i].Salary < hi)
                    Console.WriteLine($"{Workers[i].ToTableRow()}");
            } // for i

            // вывод подвала таблицы
            Console.WriteLine(Worker.Footer());
        }// SalaryDiapazone

        // Выбрать в массив и вывести в консоль работников с заданной должностью
        public void WorkersByPosition()
        {
            string position = "Бухгалтер";

            Utils.ShowNavBarTask($" Работники с должность : {position}");

            Console.WriteLine($"\n\n\t{Name}\n {Worker.Header()}");
            for (int i = 0; i < Workers.Length; i++)
            {
                if (Workers[i].Position == position )
                    Console.WriteLine($"{Workers[i].ToTableRow()}");
            } // for i

            // вывод подвала таблицы
            Console.WriteLine(Worker.Footer());
        }// WorkersByPosition


        // Упорядочить массив работников по алфавиту
        public void OrderByFullName() => Array.Sort(Workers, Worker.ComparerByFullName);

        // Упорядочить массив работников по должности
        public void OrderByPosition() => Array.Sort(Workers, Worker.ComparerByPosition);

        // Упорядочить массив работников по убыванию стажа работы
        public void OrderByYearWork() => Array.Sort(Workers, Worker.ComparerByYearWork);

        // Вывести данные компании в консоль
        public void Show()
        {
            // вывод заголовка таблицы данных компании
            Console.Write($"\n\n\t{Name}\t\t{DateTime.Now:f}\n {Worker.Header()}\n");

            // вывод всех элементов массива работников
            void OutItem(Worker obj) => Console.WriteLine($"{obj.ToTableRow()}");
            Array.ForEach(Workers, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Worker.Footer());
        } // Show

    }// class Company
}
