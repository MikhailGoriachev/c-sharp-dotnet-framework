﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Для туристической фирмы, имеющей название и хранящей сведения 
/// о 10 маршрутах реализовать обработки:
///•	Начальное формирование массива маршрутов;
///•	Вывод данных фирмы в консоль
///•	Упорядочивание маршрутов по
///o	Коду маршрута
///o	Начальному пункту маршрута
///o	Убыванию протяженности маршрута
///•	Выбрать в массив и вывести в консоль маршруты, 
/// протяженность которых, попадает в заданный диапазон. 
/// Диапазон формируйте при помощи генератора случайных чисел
///•	Выбрать в массив и вывести в консоль маршруты, 
/// начинающиеся или завершающиеся в заданном пункте. 
/// Название пункта вводить при помощи InputBox из класса Interaction
/// </summary>
namespace H_W7C_
{
    class TouristAgency
    { 
        // название туристического агенства
        public string Name { get; set; }          
        // коллекция туристических маршрутов
        private TouristRoute[] TouristRoutes { get; set; }

        // проверка массива на пустоту
        public bool Empty => TouristRoutes.Length == 0;

        // формирование массива туристического маршрута
        public void Initialize()
        {
            Name = "Турагенство <<Розовый слон>>";
            TouristRoutes = new[] {
                new TouristRoute {StartRoute = "Ст-я верхняя 'Роза-Хутор'", FinishRoute  = "Вершина 'Каменный столб'", Coderoute = "AIO5673TR",  LengthRoute = 5000d},
                new TouristRoute {StartRoute = "Центр Сочи",                FinishRoute  = "'Агурские скалы'",         Coderoute = "PI840АTR",   LengthRoute = 5d},
                new TouristRoute {StartRoute = "Центр Сочи",                FinishRoute  = "Гора 'Ахун'",              Coderoute = "AIG567YOFR", LengthRoute = 7d},
                new TouristRoute {StartRoute = "Центр Сочи",                FinishRoute  = "'Воронцовские пещеры'",    Coderoute = "KLOO5673TA", LengthRoute = 60d},
                new TouristRoute {StartRoute = "Посёлок 'Псебай'",          FinishRoute  = "'Красная поляна'",         Coderoute = "BNO6373TR",  LengthRoute = 5000d},
                new TouristRoute {StartRoute = "Центр Сочи",                FinishRoute  = "Гора 'Ахун'",              Coderoute = "LIO567YOFR", LengthRoute = 6000d},
                new TouristRoute {StartRoute = "Посёлок 'Красная поляна'",  FinishRoute  = "Озеро 'Кардывач'",         Coderoute = "PTE7393TI",  LengthRoute = 63d},
                new TouristRoute {StartRoute = "Центр Сочи",                FinishRoute  = "Вершина 'Cахарная'",       Coderoute = "AI579373TR", LengthRoute = 24d},
                new TouristRoute {StartRoute = "Посёлок 'Красная поляна'",  FinishRoute  = "Озеро 'Зеркальное'",       Coderoute = "DUE4873TR",  LengthRoute = 15d},
                new TouristRoute {StartRoute = "Посёлок 'Красная поляна'",  FinishRoute  = "Посёлок 'Красная поляна'", Coderoute = "POT85073TR", LengthRoute = 8d}

            };
        } // Initialize

        // Выбрать в массив и вывести в консоль маршруты,
        // протяженность которых, попадает в заданный диапазон.
        // Диапазон формируйте при помощи генератора случайных чисел
        public void LengthRouteDiapazone()
        {
            double lo = Utils.GetRandom(7d, 10d);
            double hi = Utils.GetRandom(10d, 60d);
            Utils.ShowNavBarTask($" Протяжённость маршрута от {lo,2:f2}км  до  {hi,2:f2}км.");

            Console.WriteLine($"\n\n\t{Name}\n {TouristRoute.Header()}");
            for (int i = 0; i < TouristRoutes.Length; i++)
            {
                if (TouristRoutes[i].LengthRoute > lo && TouristRoutes[i].LengthRoute < hi)
                    Console.WriteLine($"{TouristRoutes[i].ToTableRow()}");
            } // for i

            // вывод подвала таблицы
            Console.WriteLine(TouristRoute.Footer());
        }// LengthRouteDiapazone


        // Выбрать в массив и вывести в консоль маршруты, начинающиеся или завершающиеся в заданном пункте
        public void ShowRoute()
        {
            string position = "";

            Utils.ShowNavBarTask($" Маршруты, начинающиеся или завершающиеся в заданном пункте : {position}");
            Show();


            Console.WriteLine($"\n\n\t{Name}\n {TouristRoute.Header()}");
            int n = TouristRoutes.Length;
            for (int i = 0; i < n; i++)
            {            
                position = Microsoft.VisualBasic.Interaction.InputBox(
                    "Введите начало или конец маршрута для поиска");
                // при вводе пустой строки или нажатии на кнопку "Отмена" - выход
                if (position == "") break;


                //bool succcess = string.Format(position, TouristRoutes[i]);
                // проверка условия выхода из цикла
                //if (number == 0) break;
                if (TouristRoutes[i].FinishRoute == position || TouristRoutes[i].StartRoute == position)
                    Console.WriteLine($"{TouristRoutes[i].ToTableRow()}");

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\t\t\t\tМетод в разработке!!!");
                Console.ForegroundColor = ConsoleColor.White;
            } // for i

            
            // вывод подвала таблицы
            Console.WriteLine(TouristRoute.Footer());
        }// ShowRoute

        // Упорядочить массив работников по коду маршрута
        public void OrderByCoderoute() => Array.Sort(TouristRoutes, TouristRoute.ComparerByCoderoute);

        // Упорядочить массив работников по начальному пункту маршрута
        public void OrderByStartRoute() => Array.Sort(TouristRoutes, TouristRoute.ComparerByStartRoute);


        // Упорядочить массив работников по убыванию протяженности маршрута
        public void OrderByLengthRoute() => Array.Sort(TouristRoutes, TouristRoute.ComparerByLengthRoute);

        // Вывести данные туристической компании в консоль
        public void Show()
        {
            // вывод заголовка таблицы данных компании
            Console.Write($"\n\n\t{Name}\n {TouristRoute.Header()}\n");

            // вывод всех элементов массива маршрутов
            void OutItem(TouristRoute obj) => Console.WriteLine($"{obj.ToTableRow()}");
            Array.ForEach(TouristRoutes, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(TouristRoute.Footer());
        } // Show

    }// class TouristAgency
}
