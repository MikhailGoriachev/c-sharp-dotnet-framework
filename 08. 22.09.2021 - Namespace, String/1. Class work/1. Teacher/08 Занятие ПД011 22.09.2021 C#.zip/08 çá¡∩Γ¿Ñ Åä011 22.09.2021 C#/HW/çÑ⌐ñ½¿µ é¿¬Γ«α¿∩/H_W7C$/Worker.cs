﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Работник некоторого предприятия для информационной системы
/// представляется классом с полями:
///•	фамилия и инициалы работника;
///•	название занимаемой должности;
///•	год поступления на работу
///•	оклад.
/// Определите свойства в классе, методы для вывода данных о работнике в консоль. 
/// </summary>
namespace H_W7C_
{
    class Worker
    {
        // год открытия предприятия
        private static int _yearOpneningCompany = 1990;

        // фамилия и инициалы работника
        private string _fullName; 
        public string FullName
        {
            get => _fullName;
            set => _fullName = string.IsNullOrWhiteSpace(value) ? _fullName : value;
        }// FullName

        // название занимаемой должности
        private string _position;
        public string Position
        {
            get => _position;
            set => _position = string.IsNullOrWhiteSpace(value) ? _position : value;
        }// Position

        // год поступления на работу
        private int _year;
        public int Year
        {
            get => _year;
            set
            {
                if (value < _yearOpneningCompany)
                    throw new Exception("Worker: Недопустимый год поступления на работу");
                _year = value;
            }
        }// Year

        // оклад сотрудника, рубл.
        private double _salary;
        public double Salary
        {
            get => _salary;
            set
            {
                if (value <= 0)
                    throw new Exception("Worker: Недопустимый оклад сотрудника");
                _salary = value;
            }
        }// Salary

        // строковое представление комнаты 
        public override string ToString() =>
            $"ФИО сотрудника: {_fullName,13}; Должность: {_position,12}; Поступил в штат : {_year,15}году ; Оклад : {_salary,10:f2}";

        public string ToTableRow() =>
            $"\t│ {_fullName,-13} | {_position,-12} | {_year,15} | {_salary,10:f2} │";


        // статическое свойство для вывода шапки таблицы
        public static string Header()
        {
            string str =
            $"\t┌───────────────┬──────────────┬─────────────────┬────────────┐\n" +
            $"\t│      ФИО      │  Занимаемая  │ Год поступления │   Оклад    │\n" +
            $"\t│  сотрудника   │    должность │    на работу    │ сотрудника │\n" +
            $"\t├───────────────┼──────────────┼─────────────────┼────────────┤";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"\t└───────────────┴──────────────┴─────────────────┴────────────┘";

        // Компараторы для сортировки по заданию
        // компаратор для сортировки по ФИО
        public static int ComparerByFullName(Worker obj1, Worker obj2) =>
           obj1._fullName.CompareTo(obj2._fullName);

        // компаратор для сортировки по занимаемой должности
        public static int ComparerByPosition(Worker obj1, Worker obj2) =>
           obj1._position.CompareTo(obj2._position);

        // компаратор для сортировки по убыванию стажа работы
        public static int ComparerByYearWork(Worker obj1, Worker obj2) =>
           obj1._year.CompareTo(obj2._year);

    }// class Worker
}
