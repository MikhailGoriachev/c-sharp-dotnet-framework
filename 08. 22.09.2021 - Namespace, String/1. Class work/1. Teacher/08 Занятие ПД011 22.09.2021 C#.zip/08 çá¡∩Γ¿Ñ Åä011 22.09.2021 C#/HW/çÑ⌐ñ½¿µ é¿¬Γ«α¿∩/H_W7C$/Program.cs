﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W7C_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Домашнее задание № 7.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.F5, Text = "Задача 1.Формирование коллекции работников предприятия." },
                new MenuItem { HotKey = ConsoleKey.F6, Text = "Упорядочить массив работников по алфавиту." },
                new MenuItem { HotKey = ConsoleKey.F7, Text = "Упорядочить массив работников по должности." },
                new MenuItem { HotKey = ConsoleKey.F8, Text = "Упорядочить массив работников по убыванию стажа работы." },
                new MenuItem { HotKey = ConsoleKey.F9, Text = "Вывести работников, оклад которых, попадает в заданный диапазон." },
                new MenuItem { HotKey = ConsoleKey.F10, Text = "Вывести работников с заданной должностью." },
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 2.Формирование коллекции туристических маршрутов." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Упорядочить массив по коду маршрута." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Упорядочить массив по начальному пункту маршрута." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Упорядочить массив по убыванию протяженности маршрута." },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Вывести маршруты, протяжённость которых, попадает в заданный диапазон." },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Вывести маршруты, начинающиеся или завершающиеся в заданном пункте." },
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App();

                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Меню приложения : ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // Формирование коллекции работников предприятия
                        case ConsoleKey.F5:
                            app.CompanyShow();
                            break;

                        // Сортировка коллекции работников по алфавиту
                        case ConsoleKey.F6:
                            app.CompanyOrderByFullName();
                            break;

                        // Сортировка коллекции работников по должности
                        case ConsoleKey.F7:
                            app.CompanyOrderByPosition();
                            break;

                        //  Сортировка коллекции работников по убыванию стажа работы
                        case ConsoleKey.F8:
                            app.CompanyOrderByYearWork();
                            break;

                        // Вывести работников, оклад которых, попадает в заданный диапазон
                        case ConsoleKey.F9:
                            app.ShowDiapazoneSalaryWorkers();
                            break;

                        // Вывести работников с заданной должностью
                        case ConsoleKey.F10:
                           app.ShowWorkersByPosition();
                            break;
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 2
                        // Задача 2.Формирование коллекции туристических маршрутов
                        case ConsoleKey.Q:
                            app.TouristAgencyShow();
                            break;

                        // Сортировка коллекции маршрутов по коду маршрута
                        case ConsoleKey.W:
                            app.AgencyOrderByCoderoute();
                            break;

                        // Сортировка коллекции маршрутов по начальному пункту маршрута
                        case ConsoleKey.E:
                            app.AgencyOrderByStartRoute();
                            break;

                        // Сортировка коллекции маршрутов по убыванию протяженности маршрута
                        case ConsoleKey.R:
                            app.AgencyOrderByLengthRoute();
                            break;

                        //Вывести маршруты, протяжённость которых, попадает в заданный диапазон
                        case ConsoleKey.T:
                            app.ShowDiapazoneLengthRoute();
                            break;

                        //Вывести маршруты, начинающиеся или завершающиеся в заданном пункте
                        case ConsoleKey.Y:
                            app.ShowStartFinishRoute();
                            break;
                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                } // while
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}"); 
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;
        }// Main
    }// class Program
}
