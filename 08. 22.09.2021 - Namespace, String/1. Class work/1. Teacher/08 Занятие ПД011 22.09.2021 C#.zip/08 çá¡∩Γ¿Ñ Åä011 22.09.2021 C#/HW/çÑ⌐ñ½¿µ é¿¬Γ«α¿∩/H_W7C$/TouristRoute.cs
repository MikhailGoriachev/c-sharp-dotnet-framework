﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Пеший туристический маршрут для информационной системы описывается следующим образом:
///•	название начального пункта маршрута;
///•	название конечного пункта маршрута;
///•	буквенно - цифровой код маршрута
///•	протяженность маршрута в километрах.
/// Определите свойства в классе, методы для вывода данных о маршруте в консоль. 
/// </summary>
namespace H_W7C_
{
    class TouristRoute
    {
        // название начального пункта маршрута
        private string _startRoute;
        public string StartRoute
        {
            get => _startRoute;
            set => _startRoute = string.IsNullOrWhiteSpace(value) ? _startRoute : value;
        }// StartRoute

        // название конечного пункта маршрута
        private string _finishRoute;
        public string FinishRoute
        {
            get => _finishRoute;
            set => _finishRoute = string.IsNullOrWhiteSpace(value) ? _finishRoute : value;
        }// FinishRoute

        // буквенно - цифровой код маршрута
        private string _codeRoute;
        public string Coderoute
        {
            get => _codeRoute;
            set => _codeRoute = string.IsNullOrWhiteSpace(value) ? _codeRoute : value;

        }// Coderoute

        // протяженность маршрута в километрах
        private double _lengthRoute;
        public double LengthRoute
        {
            get => _lengthRoute;
            set
            {
                if (value <= 0)
                    throw new Exception("TouristRoute: Недопустимое значение для длины туристического маршрута");
                _lengthRoute = value;
            }
        }// LengthRoute

        // строковое представление комнаты 
        public override string ToString() =>
            $"Начало маршрута : {_startRoute,25}; Конец маршрута: {_finishRoute,25};" +
            $" Код маршрута : {_codeRoute,15}; Протяженность маршрута : {_lengthRoute,10:f2}км";

        public string ToTableRow() => 
            $"\t│ {_startRoute,-25} | {_finishRoute,-24} | {_codeRoute, 17} | {_lengthRoute,13:f2} │";


        // статическое свойство для вывода шапки таблицы
        public static string Header()
        {
            string str =
            $"\t┌───────────────────────────┬──────────────────────────┬───────────────────┬───────────────┐\n" +
            $"\t│     Начальный  маршрут    │     Конечный  маршрут    │ Буквенно-цифровой │ Протяженность │\n" +
            $"\t│                           │                          │   код маршрута    │  маршрута, км │\n" +
            $"\t├───────────────────────────┼──────────────────────────┼───────────────────┼───────────────┤";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"\t└───────────────────────────┴──────────────────────────┴───────────────────┴───────────────┘";

        // Компараторы для сортировки по заданию
        // компаратор для сортировки по коду маршрута
        public static int ComparerByCoderoute(TouristRoute obj1, TouristRoute obj2) =>
           obj1._codeRoute.CompareTo(obj2._codeRoute);

        // компаратор для сортировки по начальному пункту маршрута
        public static int ComparerByStartRoute(TouristRoute obj1, TouristRoute obj2) =>
           obj1._startRoute.CompareTo(obj2._startRoute);

        // компаратор для сортировки по убыванию протяжённости маршрута
        public static int ComparerByLengthRoute(TouristRoute obj1, TouristRoute obj2) =>
           obj2._lengthRoute.CompareTo(obj1._lengthRoute);

    }// class TouristRoute
}
