﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W7C_
{
    class App
    {
        // объекты для обработки

        private Company _company ;
        private TouristAgency _touristAgency;

        public App() : this(new Company(), new TouristAgency()) { }
        public App(Company company, TouristAgency touristAgenc)
        {
            _company       = company;
            _touristAgency = touristAgenc;
        } // App


        #region Решение Задачи 1 Класс Company
        // Вывод данных о рабочих компании
        public void CompanyShow()
        {
            Utils.ShowNavBarTask("   Вывод данных о работниках компании");

            _company.Initialize();
            _company.Show();
        } // CompanyShow

        // упорядочить массив работников по алфавиту
        public void CompanyOrderByFullName()
        {
            Utils.ShowNavBarTask("   Упорядочить массив работников по алфавиту");

            if (_company.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _company.OrderByFullName();
            _company.Show();
        }// CompanyOrderByFullName

        // упорядочить массив работников по должности
        public void CompanyOrderByPosition()
        {
            Utils.ShowNavBarTask("   Упорядочить массив работников по должности");

            if (_company.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _company.OrderByPosition();
            _company.Show();
        }// CompanyOrderByPosition

        // упорядочить массив работников по убыванию стажа работы
        public void CompanyOrderByYearWork()
        {
            Utils.ShowNavBarTask("   Упорядочить массив работников по убыванию стажа работы");

            if (_company.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _company.OrderByYearWork();
            _company.Show();
        }// CompanyOrderByYearWork

        // вывести работников, оклад которых, попадает в заданный диапазон
        public void ShowDiapazoneSalaryWorkers()
        {
            Utils.ShowNavBarTask("   Вывести работников, оклад которых, попадает в заданный диапазон");

            if (_company.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _company.SalaryDiapazone();
        }// ShowDiapazoneSalaryWorkers

        // вывести работников с заданной должностью
        public void ShowWorkersByPosition()
        {
            Utils.ShowNavBarTask("   Вывести работников с заданной должностью");

            if (_company.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _company.WorkersByPosition();
        }// ShowWorkersByPosition
        #endregion

        #region Решение Задачи 2 Класс TouristAgency

        // Вывод данных о туристических маршрутах
        public void TouristAgencyShow()
        {
            Utils.ShowNavBarTask("   Вывод данных о туристических маршрутах");

            _touristAgency.Initialize();
            _touristAgency.Show();
        } // TouristAgencyShow

        // упорядочить массив по коду маршрута
        public void AgencyOrderByCoderoute()
        {
            Utils.ShowNavBarTask("   Упорядочить массив по коду маршрута");

            if (_touristAgency.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _touristAgency.OrderByCoderoute();
            _touristAgency.Show();
        }// AgencyOrderByCoderoute

        // упорядочить массив по начальному пункту маршрута
        public void AgencyOrderByStartRoute()
        {
            Utils.ShowNavBarTask("   Упорядочить массив по начальному пункту маршрута");

            if (_touristAgency.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _touristAgency.OrderByStartRoute();
            _touristAgency.Show();
        }// AgencyOrderByStartRoute


        // упорядочить массив по eбыванию протяженности маршрута
        public void AgencyOrderByLengthRoute()
        {
            Utils.ShowNavBarTask("   Упорядочить массив по убыванию протяженности маршрута");

            if (_touristAgency.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _touristAgency.OrderByLengthRoute();
            _touristAgency.Show();
        }// AgencyOrderByLengthRoute


        // вывести маршруты, протяжённость которых, попадает в заданный диапазо
        public void ShowDiapazoneLengthRoute()
        {
            Utils.ShowNavBarTask("   Вывести маршруты, протяжённость которых, попадает в заданный диапазон");

            if (_touristAgency.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _touristAgency.LengthRouteDiapazone();
        }// ShowDiapazoneLengthRoute


        // вывести маршруты, начинающиеся или завершающиеся в заданном пункте
        public void ShowStartFinishRoute()
        {
            Utils.ShowNavBarTask("   Вывести маршруты, начинающиеся или завершающиеся в заданном пункте");

            if (_touristAgency.Empty)
                throw new Exception("Массив данных не сформирован\nВыполните формирование массива данных");

            _touristAgency.ShowRoute();
        }// ShowStartFinishRoute
        #endregion
    }// class App
}
