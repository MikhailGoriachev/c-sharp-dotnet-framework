﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

namespace Home_Task_22_09
{
    public class App
    {
        public void Menu()
        {
            /*Console.ForegroundColor = Utils._SymbolsColor;
            Console.BackgroundColor = Utils._MainColor;*/
            Palette.MainColor.EstablishColor();
            string MainTitle = "Домашнее задание на 22.09";

            //Массивы пунктов меню. 
            MenuItem[] baseMenu = new[] {
                new MenuItem {key = " 1 ",Text = " - Задача 1: информационная система предприятия"},
                new MenuItem {key = " 2 ",Text = " - Задача 2: маршруты турагенства"},
                new MenuItem {key = "ESC",Text = " - выход из программы"}
            };

            while (true)
            {
                Console.Clear();
                Utils.ShowBarMessage(" ".PadRight(Console.WindowWidth/2-MainTitle.Length/2)+MainTitle);
                Console.CursorVisible = false;
                Utils.ShowMenu(3, 3, "Выберете задание", baseMenu);

                Console.ForegroundColor = Utils.colors.W;
                Console.BackgroundColor = Utils.colors.R;
                Console.SetCursorPosition(3, 14);
                Console.Write("Ps.Задание сделано на ~20%!");
                Palette.MainColor.EstablishColor();

                ConsoleKey key = Console.ReadKey().Key;

                try
                {
                    switch (key)
                    {
                        case ConsoleKey.D1:
                            {
                                Console.Clear();
                                Task1();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.D2:
                            {
                                Console.Clear();
                                Task2();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.Escape:
                            {
                                Console.Clear();
                                return;
                            }
                        default:
                            throw new Exception($"Клавиша {key.ToString()} не поддерживается");
                    }

                }
                //Обрабатываем общее исключение
                catch (Exception ex)
                {
                    Console.Clear();
                    Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);

                    Console.ReadKey();
                }//catch
            }

            #region Подменю
            //Меню задания 1
            void Task1()
            {
                //Console.SetWindowSize(60, 50);
                //Массивы пунктов меню 
                MenuItem[] FirstTaskMenu = new[] {
                new MenuItem {key = " Q ",Text = " - Вывести таблицу работников"},
                new MenuItem {key = " W ",Text = " - Cортировать работников"},
                new MenuItem {key = " E ",Text = " - Выборка работников по диапазону значений оклада"},
                new MenuItem {key = " R ",Text = " - Выборка работников по должности"},
                new MenuItem {key = "ESC",Text = " - выход из программы"}
            };

                //App app = new App();
                try
                {

                    while (true)
                    {
                        Console.Clear();
                        Utils.ShowBarMessage($"Задание 1, основные задачи:\n * Начальное формирование массива работников{" ".PadRight(Console.WindowWidth - 44)} * Вывод данных предприятия в консоль{" ".PadRight(Console.WindowWidth - 37)} * Отсортировать работников по: {" ".PadRight(Console.WindowWidth - 31)}    * Алфавиту, должности и убыванию стажа работы{" ".PadRight(Console.WindowWidth - 50)}\n");
                        Console.CursorVisible = false;
                        Utils.ShowMenu(3, 7, "Выберете действие", FirstTaskMenu);
                        ConsoleKey key = Console.ReadKey().Key;

                        switch (key)
                        {
                            case ConsoleKey.Q:
                                {
                                    Console.Clear();
                                    ShowEmployee();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.W:
                                {
                                    Console.Clear();
                                    SortEmployees();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.E:
                                {
                                    Console.Clear();
                                    SelectBySallaryRange();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.R:
                                {
                                    Console.Clear();
                                    SelectByPosition();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.Escape:
                                {

                                    return;
                                }
                            default:
                                throw new Exception($"Клавиша {key.ToString()} не поддерживается");
                        }//Switch

                    }//While

                }//Try
                 //Catсh блок
                 //Обрабатываем исключение, касающееся треугольника
                #region Рудиментраный catch для треугольников. TODO: удалить позже
                /* catch (TriangleException ex)
                 {
                     Console.Clear();
                     (double A, double B, double C) tempTuple = ex.GetSides;
                     //Список сторон приведших к исключению
                     string sidesList = $"Стороны: {tempTuple.A:f2} ; {tempTuple.B:f2} ; {tempTuple.C:f2}";
                     // Utils.ShowFrameMessage(ex.Message + sidesList, "Triangle.ERROR", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);

                     //Ширина пустого места под строку
                     string indent = " ".PadRight(ex.Message.Length > sidesList.Length ? ex.Message.Length : sidesList.Length),//Формирование пустого поля по 
                            inBrackets = "[Triangle.ERROR]";                                                                   //самой большой строке


                     //ширина полей
                     string field = " ".PadRight(3);
                     string message = "\n " + field + indent + field +
                                      "\n " + field + inBrackets + (" ".PadRight(indent.Length - inBrackets.Length)) + field +
                                      "\n " + field + ex.Message + field +
                                      "\n " + field + sidesList + field + (" ".PadRight(indent.Length - sidesList.Length)) +
                                      "\n " + field + indent + field;
                     //Выводим получившуюся строку
                     // Utils.ShowByCoords(message, ConsoleColor.Red, 2, 3);
                     (Console.BackgroundColor, Console.ForegroundColor) = (ConsoleColor.Red, ConsoleColor.White);
                     Console.SetCursorPosition(3, 3);
                     Console.Write(message);

                     (Console.BackgroundColor, Console.ForegroundColor) = (Utils._MainColor, Utils._SymbolsColor);
                     Utils.ShowByCoords("После выхода сразу попадёте в главное меню!", ConsoleColor.White, 3, 12);

                 }//catch TriangleException*/
                #endregion

                //Обрабатываем общее исключение
                catch (Exception ex)
                {
                    Console.Clear();
                    Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);

                }//catch

            } //Task 1

            //Меню задания 2
             void Task2()
            {
                //Массивы пунктов меню 
                MenuItem[] FirstTaskMenu = new[] {
                new MenuItem {key = " Q ",Text = " - Вывести маршруты в таблице"},
                new MenuItem {key = " W ",Text = " - Сортировать маршруты"},
                new MenuItem {key = " E ",Text = " - Выборка маршрутов по диапазону протяженности"},
                new MenuItem {key = " R ",Text = " - Выборка маршрутов по точке старта или финиша"},
                new MenuItem {key = "ESC",Text = " - выход из программы"}
            };
                try
                {
                    while (true)
                    {
                        Console.Clear();
                        //Полное заполнение строки вычисляется путём нахождения оставшегося пространства после строки до края
                        Utils.ShowBarMessage($"Задание 2: турагенство с маршрутами\n * Начальное формирование массива маршрутов{" ".PadRight(Console.WindowWidth - 43)} " +
                                             $"* Вывод данных фирмы в консоль{ " ".PadRight(Console.WindowWidth - 31)} * Упорядочивание маршрутов по:{ " ".PadRight(Console.WindowWidth - 31)}" +
                                             $"   * Коду маршрута, начальному пункту, убыванию протяженности{" ".PadRight(Console.WindowWidth - 61)} * Выборка маршрутов в определённом диапазоне протяженности{" ".PadRight(Console.WindowWidth - 59)}" +
                                             $" * Выборка маршрутов по точке старта или финиша (через VB){" ".PadRight(Console.WindowWidth - 58)}\n");
                        Console.CursorVisible = false;
                        Utils.ShowMenu(3, 10, "Выберете действие", FirstTaskMenu);
                        ConsoleKey key = Console.ReadKey().Key;

                        switch (key)
                        {
                            case ConsoleKey.Q:
                                {
                                    Console.Clear();
                                    ShowWays();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.W:
                                {
                                    Console.Clear();
                                    SortWays();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.E:
                                {
                                    Console.Clear();
                                    SelectByLengthRange();
                                    Console.ReadKey();
                                    break;
                                }
                            
                            case ConsoleKey.R:
                                {
                                    Console.Clear();
                                    SelectByABPoints();
                                    Console.ReadKey();
                                    break;
                                }
                            case ConsoleKey.Escape:
                                {

                                    return;
                                }
                            default:
                                throw new Exception($"Клавиша {key.ToString()} не поддерживается");
                        }

                    }//While
                }//try
                 //Catсh блок

                #region Рудиментарный catch
                //Обрабатываем исключение, касающееся треугольника
               /* catch (RoomException ex)
                {
                    Console.Clear();
                    (double S, double CeilingH, int WindowsAmount) tempTuple = ex.GetFields;
                    //Список сторон приведших к исключению
                    string FieldsList = $"Поля: Площадь ({tempTuple.S:f2}); Высота ({tempTuple.CeilingH:f2}); Кол-во окон ({tempTuple.WindowsAmount})";
                    // Utils.ShowFrameMessage(ex.Message + sidesList, "Triangle.ERROR", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);

                    int LengthMessage = ex.Message.Length,
                        LengthList = FieldsList.Length;

                    //Ширина пустого места под строку
                    string indent = " ".PadRight(LengthMessage > LengthList ? LengthMessage : LengthList),//Формирование пустого поля по 
                           inBrackets = "[Room.ERROR]";                                                   //самой большой строке


                    //ширина полей
                    string field = " ".PadRight(3);
                    string message = "";

                    //Выбор шаблона выравнивания цветного прямоугольника строк
                    if (LengthList > LengthMessage)
                    {
                        message = "\n " + field + indent + field +
                                  "\n " + field + inBrackets + (" ".PadRight(indent.Length - inBrackets.Length)) + field +
                                  "\n " + field + ex.Message + field + (" ".PadRight(indent.Length - LengthMessage)) +
                                  "\n " + field + FieldsList + field + //Поскольку ширина списка полей найбольшая - идёт выравнивание по ней
                                  "\n " + field + indent + field;      //и цвет заполнен до конца

                    }
                    else
                    {
                        message = "\n " + field + indent + field +
                                  "\n " + field + inBrackets + (" ".PadRight(indent.Length - inBrackets.Length)) + field +
                                  "\n " + field + ex.Message + field +  //Поскольку ширина строки сообщения найбольшая - идёт выравнивание по ней
                                  "\n " + field + FieldsList + field +  //и цвет заполнен до конца
                                  (" ".PadRight(indent.Length - LengthList)) +
                                  "\n " + field + indent + field;

                    }

                    //Выводим получившуюся строку

                    (Console.BackgroundColor, Console.ForegroundColor) = (ConsoleColor.Red, ConsoleColor.White);

                    Console.SetCursorPosition(3, 3);
                    Console.Write(message);

                    (Console.BackgroundColor, Console.ForegroundColor) = (Utils._MainColor, Utils._SymbolsColor);
                    Utils.ShowByCoords("После выхода сразу попадёте в главное меню!", ConsoleColor.White, 3, 12);

                }//catch*/
                #endregion
                //Обрабатываем общее исключение
                catch (Exception ex)
                {
                    Console.Clear();
                    Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);
                }//catch
            } //Task 2

            #endregion
        }


        //Поля коллекций 
        Enterprise company;

        TravelAgency travelAgency;
        //C_TOR'ы по умолчанию и инициализации
        public App ():this(new Enterprise(),new TravelAgency()) //Выделяем память
        {

            //Инициализация объектов 
            company.initialize();

        }

        //Инициирующий C_TOR
        public App(Enterprise Company, TravelAgency TravelAg)
        {
            this.company = Company;
            this.travelAgency = TravelAg;
        }

        #region Методы задания 1


        //Вывод таблицы работников
        public void ShowEmployee()
        {
            Utils.ShowBarMessage("Вывод таблицы работников предприятия: ");
            // Utils.ShowFrameMessage("Вывод таблицы в разработке!", "INFO", 2, 3);
            company.ShowCompany();
        }
        
        //Сортировки работников
        public void SortEmployees()
        {
           //Формируем подменю сортировок
            MenuItem[] SortMenu =
            {
                new MenuItem{key = " Q " , Text = " - сортировка по алфавиту" },
                new MenuItem{key = " W ", Text = " - сортировка по должности" },
                new MenuItem{key = " E ", Text = " - сортировка по убыванию стажа работы" },
                new MenuItem{key = "ESC", Text = " - выход" },
            };

            //App app = new App();
            try
            {

                while (true)
                {
                    Utils.ShowBarMessage("Сортировки работников: ");
                    Utils.ShowMenu(3, 3, "Выберете сортировку", SortMenu);
                    ConsoleKey key = Console.ReadKey().Key;

                    switch (key)
                    {
                        case ConsoleKey.Q:
                            {
                                Console.Clear();
                                SortByAlphabet();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.W:
                            {
                                Console.Clear();
                                SortByPosition();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.E:
                            {
                                Console.Clear();
                                SortDescByExpirience();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.Escape:
                            {
                                return;
                            }
                        default:
                            throw new Exception($"Клавиша {key.ToString()} не поддерживается");
                    }
                }
            }
            //Обрабатываем общее исключение
            catch (Exception ex)
            {
                Console.Clear();
                Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);
            }//catch


            //Реализации сортировок
            void SortByAlphabet()
            {
                Utils.ShowBarMessage("Сортировка работников по алфавиту: ");

                //Utils.ShowFrameMessage("Сортировка работников по алфавиту в разработке!", "INFO.Sort", 2, 3);

                company.SortByName();
            }
            
            void SortByPosition()
            {
                Utils.ShowBarMessage("Сортировки работников по должности: ");
                //Utils.ShowFrameMessage("Сортировка работников по должности в разработке!", "INFO.Sort", 2, 3);
                company.SortByPosition();
            }
            
            void SortDescByExpirience()
            {
                Utils.ShowBarMessage("Сортировки работников по убыванию оклада: ");
                //Utils.ShowFrameMessage("Сортировка работников по убыванию оклада в разработке!", "INFO.Sort", 2, 3);
                company.SortByExpirience();

            }

        }//SortEmployees

        //Выборка по диапазону значений оклада
        public void SelectBySallaryRange()
        {
            Utils.ShowBarMessage("Выборка по диапазону значений оклада: ");
            Utils.ShowFrameMessage("Выборка по диапазону в разработке!", "INFO", 2, 3);
            return;
            /* Не устранённая ошибка
            double Lo = Utils.GetRandom(Employee.MinSallary, Employee.MinSallary / 1.5),
                high = Utils.GetRandom(Lo, Employee.MinSallary );

            bool InRange(Employee emp)
                => emp.FieldsAccsessor.Salary > Lo && emp.FieldsAccsessor.Salary < high;
            Employee[] selected = Array.FindAll(company.GetCollection, InRange);

            Enterprise NewCompany = new Enterprise(selected);
            NewCompany.ShowCompany($"После выборки сотрудников в диапазоне зарплат ({Lo:f2};{high:f2})");*/
        }

        //Выборка по должности 
        public void SelectByPosition()
        {
            Utils.ShowBarMessage("Выборка по должности: ");
            Utils.ShowFrameMessage("Выборка по должности в разработке!", "INFO", 2, 3);
        }

        #endregion

        #region Методы задания 2

        //Вывод маршрутов
        public void ShowWays()
        {
            Utils.ShowBarMessage("Вывод таблицы туристических маршрутов: ");
            Utils.ShowFrameMessage("Вывод таблицы маршрутов в разработке!", "INFO.Task_2", 2, 3);
        }

        //Сортировки маршрутов
        public void SortWays()
        {
            //Формируем подменю сортировок
            MenuItem[] SortMenu =
            {
                new MenuItem{key = " Q " , Text =" - сортировка по коду маршрута" },
                new MenuItem{key = " W ", Text = " - сортировка по пункту отправления" },
                new MenuItem{key = " E ", Text = " - сортировка по убыванию протяженности" },
                new MenuItem{key = "ESC", Text = " - выход" },
            };

            //App app = new App();
            try
            {

                while (true)
                {
                    Utils.ShowBarMessage("Сортировки маршрутов: ");
                    Utils.ShowMenu(3, 3, "Выберете сортировку", SortMenu);
                    ConsoleKey key = Console.ReadKey().Key;

                    switch (key)
                    {
                        case ConsoleKey.Q:
                            {
                                Console.Clear();
                                SortByCode();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.W:
                            {
                                Console.Clear();
                                SortByPosition();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.E:
                            {
                                Console.Clear();
                                SortDescByExpirience();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.Escape:
                            {
                                return;
                            }
                        default:
                            throw new Exception($"Клавиша {key.ToString()} не поддерживается");
                    }
                }
            }
            //Обрабатываем общее исключение
            catch (Exception ex)
            {
                Console.Clear();
                Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);
            }//catch


            //Реализации сортировок
            void SortByCode()
            {
                Utils.ShowBarMessage("Сортировка маршрутов по коду: ");

                Utils.ShowFrameMessage("Сортировка маршрутов по коду в разработке!", "INFO.Sort", 2, 3);
            }

            void SortByPosition()
            {
                Utils.ShowBarMessage("Сортировка маршрутов по пункту отправления: ");

                Utils.ShowFrameMessage("Сортировка маршрутов по пункту отправления в разработке!", "INFO.Sort", 2, 3);
            }

            void SortDescByExpirience()
            {
                Utils.ShowBarMessage("Сортировки маршрутов по убыванию протяженности: ");

                Utils.ShowFrameMessage("Сортировка маршрутов по убыванию протяженности!", "INFO.Sort", 2, 3);

            }

        }//SortEmployees

        //Выборка маршрутов по диапазону протяженности
        public void SelectByLengthRange()
        {
            Utils.ShowBarMessage("Выборка маршрутов по диапазону протяженности маршрута: ");
            Utils.ShowFrameMessage("Выборка по диапазону протяженности в разработке!", "INFO", 2, 3);
        }

        //Выборка маршрутов по точке старта или финиша
        public void SelectByABPoints()
        {
            Utils.ShowBarMessage("Выборка маршрутов по точке старта или финиша: ");
            Utils.ShowFrameMessage("Выборка по точке старта или финиша в разработке!", "INFO", 2, 3);
        }
        #endregion

    }
}
