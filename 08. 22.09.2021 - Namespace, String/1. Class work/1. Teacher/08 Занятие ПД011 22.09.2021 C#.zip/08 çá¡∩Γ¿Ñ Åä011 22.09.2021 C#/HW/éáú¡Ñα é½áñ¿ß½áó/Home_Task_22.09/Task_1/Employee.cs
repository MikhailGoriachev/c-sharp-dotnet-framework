﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Task_22_09
{

    public class Employee
    {
        //Кортех хранящий основные цвета для тернарника - СЛУЖЕБНОЕ private поле
        private (ConsoleColor R, ConsoleColor Blu, ConsoleColor Y, ConsoleColor G, ConsoleColor W, ConsoleColor C, ConsoleColor Blk) colors = (ConsoleColor.Red, ConsoleColor.Blue, ConsoleColor.Yellow, ConsoleColor.Green, ConsoleColor.White, ConsoleColor.Cyan, ConsoleColor.Black);

        //Константные занчения
      public static double MinSallary = 1000d, MaxSallary = 5000d;

        //Поля 

        string _Surname;  //фамилия и инициалы работника
        string _Position; //Название занимаемой должности
        int _HiringDate;  //Для данного поля можно было реализовать отдельный класс даты, не хватило времени;
        double _Salary;   //Оклад

        //Кортежное свойство 
        public (string Surname, string Position, int Hiring, double Salary) FieldsAccsessor
        {
            //Возвращаем кортеж 4-х полей
            get => (_Surname, _Position, _HiringDate, _Salary);

            //Setter полей
            set
            {
                try
                {
                    //Проверка данных на валидность и корректность
                    if (string.IsNullOrWhiteSpace(value.Surname))
                    {
                        //Реализовать выброс исключения
                        throw new RouteException($"Строка фамилии и инициалов не может быть пустой");
                    }

                    _Surname = value.Surname;

                    //Проверка данных на валидность и корректность
                    if (string.IsNullOrWhiteSpace(value.Position))
                    {
                        //Реализовать выброс исключения
                        throw new RouteException($"Строка должности не может быть пустой");
                    }

                    _Position = value.Position;

                    //Проверка данных на валидность и корректность
                    if (value.Hiring < 0 || value.Hiring < 1900)
                    {
                        //Реализовать выброс исключения
                        throw new RouteException($"Некорректные данные даты принятия на работу: {value.Hiring}");
                    }

                    _Salary = value.Salary;

                    //Проверка данных на валидность и корректность
                    if (value.Salary <= 0 || value.Salary > double.MaxValue)
                    {
                        //Реализовать выброс исключения
                        throw new RouteException($"Некорректные оклада работника: {value.Salary:f2}");
                    }

                    _HiringDate = value.Hiring;

                }
                //Формируем раскрутку стека
                catch (RouteException ex)
                {
                    throw ex;
                }
            }

        }

        //C_TOR по умолчанию
        public Employee() : this(("Байко Б.А", "CTO", 2006,4500d))
        {
        }

        //C_TOR инициализации 
        public Employee((string Surname, string Position, int Hiring, double Salary) data)
        {
            //Устанавливаем значения через аксессор
            FieldsAccsessor = data;
        }

        #region Компараторы
        /*
         * Алфавит
           Должность
           Убыванию стажа работы
         */
        public static int CompareByName(Employee emp1,Employee emp2)
        {
            return emp1._Surname.CompareTo(emp2._Surname);
        }
        
        public static int CompareByPosition(Employee emp1,Employee emp2)
        {
            return emp1._Position.CompareTo(emp2._Position);
        }
        
        public static int CompareByExpirience(Employee emp1,Employee emp2)
        {
            return emp1._HiringDate < emp2._HiringDate ? -1 : emp1._HiringDate > emp2._HiringDate ? 1 : 0;
        }

        #endregion

        #region Вывод
        //Переопределение виртуального метода формирования строки
        public override string ToString()
        {
            return $"Работник: {_Surname}.\n Должность: {_Position}.\n Когда был принят: {_HiringDate}.\n Оклад: {_Salary:f2} ";
        }

        //Шапка таблицы
        public static string Header(int space)
        {
            string indent = " ".PadRight(space);

             
            string res = $"\n{indent}┌─────┬─────────────────────────┬───────────────────┬─────────────┬──────────────┐" +
                         $"\n{indent}│  N  │    Фамилия и            │    Должность в    │ Дата начала │     Оклад    │" +
                         $"\n{indent}│     │    инициалы работника   │    комапнии       │ работы      │              │" +
                         $"\n{indent}├─────┼─────────────────────────┼───────────────────┼─────────────┼──────────────┤";
            //└─────┴─────────────┴─────────────┴────────────┴────────────┴────────────┴─────────────┘
            return res;
        }


        //Подвал таблицы 
        public static string Footer(int space)
        {
            string indent = " ".PadRight(space);
                                   //├─────┼─────────────────────────┼───────────────────┼─────────────┼──────────────┤
            string res = $"\n{indent}└─────┴─────────────────────────┴───────────────────┴─────────────┴──────────────┘";

            return res;
        }


        //Разделительная линия 
        static public string MiddleLine(int space)
        {

            return $"\n{" ".PadRight(space)}├─────┼─────────────────────────┼───────────────────┼─────────────┼──────────────┤";
        }

        //Вывод ячейки 
        public string ToTableRow(int space, int num)
        {
            string indent = " ".PadRight(space),
                Line = num <= 1 ? "" : MiddleLine(space); //Если элемент первый в таблице - разделительную черту не выводим

            //Формируем сторку сразу с разделительной чертой
            string res = $"{Line}\n{indent}│{num,5}│{_Surname,25}│{_Position,19}│{_HiringDate,13}│{_Salary,14:f2}│";

            //├5┼25┼14┼13┼13┤
            return res;
        }

        public void ToTableRowHighlight(int space, int num, Employee HighlightEmployee, ConsoleColor BackGround = ConsoleColor.Yellow)
        {
            string indent = " ".PadRight(space),
                //В зависимости от ответа тернарника - ставим разделительную черту
                Line = num <= 1 ? "" : MiddleLine(space);

            if (this == HighlightEmployee)
            {
                Console.Write($"{Line}\n{indent}│");

                Console.BackgroundColor = BackGround;
                //Выбор цвета шрифта в зависимости от фона
                Console.ForegroundColor = BackGround == colors.Blk || BackGround == colors.Blu || BackGround == colors.R ? colors.W : colors.Blk;

                //Формируем сторку сразу с разделительной чертой
                Console.Write($"{num,5}│{_Surname,25}│{_Position,19}│{_HiringDate,13}│{_Salary,13:f2}");
                Console.BackgroundColor = Utils._MainColor;
                Console.ForegroundColor = Utils._SymbolsColor;
                Console.Write("│");

                //├5┼25┼14┼13┼13┤
            }
            else
                //Формируем сторку сразу с разделительной чертой
                Console.Write($"{Line}\n{indent}│{num,5}│{_Surname,25}│{_Position,19}│{_HiringDate,13}│{_Salary,13:f2}│");

        }
        #endregion
    }
}
