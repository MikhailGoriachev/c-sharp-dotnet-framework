﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Task_22_09

{
    public class Enterprise
    {
        const int MinSize = 10;
        int currSize = 0;
        //Массив работников
        Employee[] employees;

        //Имя компании
        string _Name;

        //Предикад заполенности массива
        public bool Empty
        {
            get
                => employees.Length == 0;
        }

        public Employee[] GetCollection
        {
            get;
        }

        //C_TOR по умолчанию 
        public Enterprise()
        {
             //currSize = Utils.Random.Next(MinSize, 15);
            //Выделяем память под массив
            employees = new Employee[MinSize];
            
        }

        //Инициирующий C_TOR
        public Enterprise(Employee[]Employees)
        {
            //выделяем память + инициализируем массив
            employees = new Employee[Employees.Length];
            employees = Employees;
        }

        //Метод инициализации массива
        public void initialize()
        {
            currSize = employees.Length;
            Employee[] toFill;

            _Name = "Web&AI";

            //Временный массив для заполнения
            toFill = new Employee[MinSize]
            {
                new Employee              (("Ростислав В.В","CFO",2010,3500d)),
                new Employee  (("Екатерина О.К","Product manager",2013,2000d)),
                new Employee      (("Репин Д.К","Finance manager",2009,2700d)),
                new Employee(("Данилов Т.В","Middle JS developer",2015,2500d)),
                new Employee             (("Вишневский  А.К","HR",2012,3500d)),
                new Employee   (("Литвинов О.В","Project manager",2014,1900d)),
                new Employee       (("Макарова И.К","Media buyer",2008,1500d)),
                new Employee    (("Дементьев Ф.Б","Nets engineer",2009,3500d)),
                new Employee         (("Литковский Е.И","Analyst",2013,3000d)),
                new Employee               (("Волкова  А.В","CMO",2014,3500d)),
            };


            if (employees[0] == null) //Если 1-й элемент массива не инициализирован - весь массив не инициализирован
            {
                //employees = new Triangle[10];
                for (int i = 0; i < employees.Length; i++)
                {
                    //Инициализируем каждый объект массива
                    employees[i] = new Employee();
                    employees[i] = toFill[i];
                }
            }
            //Если масситв проинициализирован - перезаписываем данные в него
            else
            {

                for (int i = 0; i < employees.Length; i++)
                {
                    
                    employees[i] = toFill[employees.Length - i - 1];

                }
            }
        }

        //Вывести массив
        public void ShowCompany(string message = "Вывод таблицы работников:", ConsoleColor TitleColor = ConsoleColor.White)
        {
            Console.Write("\n");
            Console.BackgroundColor = TitleColor;
            Console.Write(message);
            Console.BackgroundColor = Utils._MainColor;

            int indent = 3;
            Console.Write($"\n{Employee.Header(indent)}");

            if (Empty)
                throw new Exception("Коллекция треугольников пуста!");
            
            //Вывод ячеек
            int num = 1;

            foreach (Employee emp in employees)
            {

                Console.Write(emp.ToTableRow(indent, num));

                // tr.ToTableRowHighlight(indent, num, Triangles[h]);
                num += 1;
            }

            //Выводим подвал
            Console.Write(Employee.Footer(indent));
        }

        //Сортировки 
        /* Алфавит
         Должность
         Убыванию стажа работы*/

        //Сортировка по алфавиту
        public void SortByName()
        {
            ShowCompany("Вывод перед сортировки по алфавиту:");
            Array.Sort(employees, Employee.CompareByName);
            ShowCompany("Вывод после сортировки по алфавиту:",Utils.colors.Y);
        }
        
        //Сортировка по должности 
        public void SortByPosition()
        {
            ShowCompany("Вывод перед сортировки по должности:");
            Array.Sort(employees, Employee.CompareByPosition);
            ShowCompany("Вывод после сортировки по должности:", Utils.colors.Y);
        }
        
        //Сортировка по убыванию стажа
        public void SortByExpirience()
        {
            ShowCompany("Вывод перед сортировки по убыванию стажа:");
            Array.Sort(employees, Employee.CompareByExpirience);
            ShowCompany("Вывод после сортировки по убыванию стажа:", Utils.colors.Y);
        }
    }
}
