﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork04._10._21.Models.Task1
{
    public interface ISolver
    {
        void Solve();   // для решения уравнения
        void Show();    // для вывода решения в консоль 
        bool HasSolve();    // для определения наличия решения уравнения


    }
}
