﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork04._10._21.Models.Task2
{
    class Builder
    {
        static string[] names = new string[]{

            "Данилова Е.Р.",
            "Дроздова Т.И.",
            "Жукова З.Д.  ",
            "Зубкова А.Д. ",
            "Лосев Д.М.   ",
            "Медведев С.Г.",
            "Миронов Ю.А. ",
            "Пономарев Д.В.",
            "Устинов П.А.",
            "Хомякова А.А."
        };

        static string[] groups = new string[]{

            "ВБД1014",
            "БДК1025",
            "ЗКВ3210",
            "МДК1247",
            "ВВК1245"            
        };


        public static Student Newstudent() {

            return new Student(names[Utils.GetRandom(0, names.Length)], groups[Utils.GetRandom(0, groups.Length)]);            
        
        }






    }
}
