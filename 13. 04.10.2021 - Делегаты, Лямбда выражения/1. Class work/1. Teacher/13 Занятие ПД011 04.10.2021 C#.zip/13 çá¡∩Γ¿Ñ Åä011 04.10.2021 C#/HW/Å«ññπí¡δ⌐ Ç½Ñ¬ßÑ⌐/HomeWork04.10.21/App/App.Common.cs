﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork04._10._21.Models.Task1;
using HomeWork04._10._21.Models.Task2;

namespace HomeWork04._10._21.AppSpace
{
    internal partial class App
    {
        // массив уровнений
        private ArrayEquation array1;

        // массив студентов
       private ArrayStudents array2;

        // ансамбль конструкторов
        public App() : this(new ArrayEquation(), new ArrayStudents())
        {
            array1.Initialize();
            array2.Initialize();
        } // App

        public App(ArrayEquation equation  , ArrayStudents students)
        {
            array1 = equation;
            array2 = students;
        } // App

    }
}
