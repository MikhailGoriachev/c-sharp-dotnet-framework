﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork04._10._21.Models.Task1;


namespace HomeWork04._10._21.AppSpace
{
    // Решение для задачи 1 - обработка массива уравнений
    internal partial class App
    {

        public void DemoTask1() {

            //ArrayEquation Eq = new ArrayEquation();
            // Eq.Initialize();
            array1.ArraySolver();
            ArrayEquation.Show(array1);

            array1.CountEq();
            array1.CountEqR();



        }



    }
}
