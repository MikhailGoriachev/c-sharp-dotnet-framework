﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork04._10._21.Models.Task2;

namespace HomeWork04._10._21.AppSpace
{
    internal partial class App
    {
        // вывод массива студентов
        public void ShowArrayStudents()
        {            
            array2.ShowArrayStudents();           
        }

        /*•	вывод на экран фамилий и названия групп для всех студентов, имеющих хотя бы одну оценку 2*/
        public Student[] HaveTwo() {

            // предикатор 
            bool pred(Student v) {

                bool flag = false;

                for (int i = 0; i < v._marks.Length; i++)
                {
                    if (v._marks[i].Rating == 2)
                    {
                        flag = true;
                        break;
                    }
                }


                return flag;
            } 

           return Array.FindAll(array2.Array, pred);
        }

        /*•	вывод на экран фамилий и названий групп для всех студентов, имеющих оценки только 4 и 5 (если таких студентов нет, вывести соответствующее сообщение)*/
        public Student[] HavePositiv()
        {

            // предикатор 
            bool pred(Student v)
            {

                bool flag = true;

                for (int i = 0; i < v._marks.Length; i++)
                {

                    switch ((v._marks[i].Rating))
                    {
                        case 4:
                            continue;                        

                        case 5:
                            continue;
                            
                        default:
                            flag = false;
                            break;
                    }
                    
                }


                return flag;
            }

            return Array.FindAll(array2.Array, pred);
        }






        public void SortToName() 
        {
            Array.Sort(array2.Array, ArrayStudents.NameComparer);
        }

        public void SortToAVB()
        {
            Array.Sort(array2.Array, ArrayStudents.AVBComparer);
        }

        public void ShuffleArray()
        {
            
                Random rand = new Random();

                for (int i = array2.Array.Length - 1; i >= 1; i--)
                {
                    int j = rand.Next(i + 1);

                    Student tmp = array2.Array[j];
                    array2.Array[j] = array2.Array[i];
                    array2.Array[i] = tmp;
                }
            
        }


    }
}
