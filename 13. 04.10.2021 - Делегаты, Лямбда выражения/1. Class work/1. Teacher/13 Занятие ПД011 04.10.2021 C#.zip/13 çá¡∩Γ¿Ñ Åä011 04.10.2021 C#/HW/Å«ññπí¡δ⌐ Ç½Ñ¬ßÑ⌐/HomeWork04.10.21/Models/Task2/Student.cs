﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork04._10._21.Models.Task2
{
    // структура, описующая студента
    struct Student
    {
        // фамилия и инициалы
        string _name;
        public string Name
        {
            get { return _name; }
            set { if (String.IsNullOrWhiteSpace(value))
                    throw new Exception("Student: ошибка имени студента");
                    _name = value; }
        }

        // название группы
        string _groupName;
        public string GroupName
        {
            get { return _groupName; }
            set { if (String.IsNullOrWhiteSpace(value))
                    throw new Exception("Student: ошибка имени группы");
                _groupName = value; }
        }

        // успеваемость (массив из пяти элементов типа Mark– вложенная структура: название предмета, оценка (short)) 
        public Mark[] _marks;


        // вложенная структура: название предмета, оценка
        public struct Mark {

            // название предмета
            string _subjectName;
            public string SubjectName
            {
                get { return _subjectName; }
                set {
                    if (String.IsNullOrWhiteSpace(value))
                        throw new Exception("Student.Mark: ошибка имени предмета");                                    
                    _subjectName = value; }
            }

            // оценка
            short _rating;
            public short Rating
            {
                get { return _rating; }
                set { if (value < 0)
                        throw new Exception("Student.Mark: ошибка оценки предмета");
                            _rating = value; }
            }

            

        }//Mark

        // Индексатор. 
        public Mark this[int index]
        {
            get
            {    // Аксессор.
                if (index >= 0 && index < _marks.Length)
                    return _marks[index];
                else
                    throw new Exception("Student.Mark: попытка обращения за пределы массива.");
            }

            set
            {    // Мутатор.
                if (index >= 0 && index < _marks.Length)
                    _marks[index] = value;
                else
                    throw new Exception("Student.Mark: попытка записи за пределы массива.");
                
            } // set
            
        }

        // конструктор с параметрами
        public Student(string name, string group)
        {
            this._name = name;
            this._groupName = group;
            this._marks = new Mark[5];

            _marks[0].SubjectName = "Математика";
            _marks[0].Rating = (short)Utils.GetRandom(2,6);

            _marks[1].SubjectName = "Экономика";
            _marks[1].Rating = (short)Utils.GetRandom(3, 6);

            _marks[2].SubjectName = "История";
            _marks[2].Rating = (short)Utils.GetRandom(4, 6);

            _marks[3].SubjectName = "Информатика";
            _marks[3].Rating = (short)Utils.GetRandom(2, 6);

            _marks[4].SubjectName = "Программирование";
            _marks[4].Rating = (short)Utils.GetRandom(4, 6);



        } // MyStruct

        // вычисление среднего бала
        public double AVB()
        {

            double result = 0;

            for (int i = 0; i < _marks.Length; i++)
            {
                result += _marks[i].Rating;
            }

            result /= _marks.Length;

            return result;


        }


        public string ToTableRow() =>
       $"│ {_name,-18} │ {_groupName,-13} │ {AVB(),12:f2} │";

    }
}
