﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HomeWork04._10._21.Models.Task2
{
    class ArrayStudents
    {
        // размер массива 
        private const int Size = 10;

        // массив студентов
        private Student[] _array;

        public Student[] Array
        {
            get { return _array; }
            set { _array = value; }
        }





        // заполнение массива уровнений начальными данными по заданию        
        public void Initialize()
        {
            _array = new Student[Size];
            for (int i = 0; i < Size; i++)
            {
                _array[i] = Builder.Newstudent();
            }
        } // Initialize 


        // компаратор для сортировки по возрастанию среднего бала
        public static int AVBComparer(Student p1, Student p2)
        {

            return p1.AVB().CompareTo(p2.AVB());
        }

        // компаратор для сортировки по возрастанию среднего бала
        public static int NameComparer(Student p1, Student p2)
        {

            return p1.Name.CompareTo(p2.Name);
        }

        public static string Header()
        {

            return $"┌────────────────────┬───────────────┬──────────────┐\n" +
                   $"│ Фамилия и инициалы │   Группа      │ Средний бал  │\n" +                  
                   $"├────────────────────┼───────────────┼──────────────┤";

        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
             $"└────────────────────┴───────────────┴──────────────┘";

        // представление объекта в виде строки таблицы
        public static void ShowArray(Student[] _array) {

            Console.WriteLine(Header());

            foreach (Student item in _array)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Footer());


        }

        // представление объекта в виде строки таблицы
        public void ShowArrayStudents()
        {

            Console.WriteLine(Header());

            foreach (Student item in _array)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Footer());


        }




    }
}
