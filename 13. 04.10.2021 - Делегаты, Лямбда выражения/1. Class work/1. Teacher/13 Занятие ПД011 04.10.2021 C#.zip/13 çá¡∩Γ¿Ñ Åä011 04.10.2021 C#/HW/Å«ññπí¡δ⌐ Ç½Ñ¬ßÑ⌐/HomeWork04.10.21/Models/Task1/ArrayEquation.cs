﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using HomeWork04._10._21;


namespace HomeWork04._10._21.Models.Task1
{
    class ArrayEquation
    {
        private ISolver[] array;



        // количество транспортных средств в массиве самолетов по умолчанию
        private const int Size = 20;



        // Фабричный метод для создания уровнений
        private static ISolver IFactory(int code)
        {
            ISolver root;
            switch (code & 1)
            {
                case 0:
                    root = new Linear(Utils.GetRandom(2, 10), Utils.GetRandom(2, 10));
                    break;

                default:
                    root = new Square(Utils.GetRandom(2, 10), Utils.GetRandom(6, 15),Utils.GetRandom(2, 10));
                    break;               

                
            } // switch

            return root;
        } // FigureFactory


        // заполнение массива уровнений начальными данными по заданию        
        public void Initialize()
        {
            array = new ISolver[Size];
            for (int i = 0; i < Size; i++)
            {
                array[i] = IFactory(Utils.GetRandom(0, 100));

            }
        } // Initialize 


        // метод для вывода переданного массива фигур
        public static void Show(ArrayEquation array)
        {

            
            // вывод всех элементов массива объектов данных 

            void OutItem(ISolver f) {
                if (f.HasSolve())
                    f.Show();
                else {

                    
                    Console.WriteLine($" Уровнениие не имеет корней!");
                    f.Show();

                }


            } 
            Array.ForEach(array.array, OutItem);

            
        } // Show


        // решить все уравнения в массиве
        public void ArraySolver()
        {
            void OutItem(ISolver f)
            {
                if (f.HasSolve()) { 
                    f.Solve();
                }
                

            }
            Array.ForEach(array, OutItem);
        } // Initialize 

        // общее количество уравнений
        public void CountEq() {

            Linear Exlinear=new Linear(0,0);
            Square ExSquqre = new Square(0, 0,0);

            int countEx = 0;

            int countL = 0;
            int countS = 0;

            foreach (Root item in array)
            {
                if (item.GetType() == Exlinear.GetType())
                    countL++;
                if (item.GetType() == ExSquqre.GetType())
                    countS++;

                countEx++;
            }

            Console.WriteLine($"Статистика ");
            Console.WriteLine($"Общее количество уравнений: {countEx}");
            Console.WriteLine($"         из них квадратных: {countS}");
            Console.WriteLine($"           из них линейных: {countL}");


        }

        public void CountEqR()
        {

            Linear Exlinear = new Linear(0, 0);
            Square ExSquqre = new Square(0, 0, 0);

            int countEx = 0;

            int countL = 0;
            int countS = 0;

            foreach (ISolver item in array)
            {
                if (item.HasSolve())
                {
                    countEx++;

                    if (item.GetType() == Exlinear.GetType() && item.HasSolve())
                        countL++;
                    if (item.GetType() == ExSquqre.GetType() && item.HasSolve())
                        countS++;
                }
            }

            Console.WriteLine($"Статистика ");
            Console.WriteLine($"Общее количество решений       : {countEx}");
            Console.WriteLine($"    из них квадратных уравнений: {countS}");
            Console.WriteLine($"      из них линейных уравнений: {countL}");


        }




    }
}
