﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork04._10._21.Models.Task1
{
    // класс для линейных уравнений   ax + b = 0
    class Linear : Root, ISolver
    {
        // коэфициент а
        private int _a;

        public int A
        {
            get { return _a; }
            set { _a = value; }
        }


        // коэфициент в
        private int _b;

        public int B
        {
            get { return _b; }
            set { _b = value; }
        }

        // корень х
        private double _x;

        public double X
        {
            get { return _x; }
            set { _x = value; }
        }

        public Linear(int a, int b) {

            A = a;
            B = b;
        
        }

        public string ShowForm() {

            return $" {_a}x + {_b} = 0";


        }


        bool ISolver.HasSolve()
        {
            return _a != 0 ? true : false;
        }

        void ISolver.Show()
        {
            
            
            Console.WriteLine($" {ShowForm()};  x = {_x,3:f2} ");
        }

        void ISolver.Solve()
        {
            
            _x = (double)(-_b )/(double) _a;

        }
    }
}
