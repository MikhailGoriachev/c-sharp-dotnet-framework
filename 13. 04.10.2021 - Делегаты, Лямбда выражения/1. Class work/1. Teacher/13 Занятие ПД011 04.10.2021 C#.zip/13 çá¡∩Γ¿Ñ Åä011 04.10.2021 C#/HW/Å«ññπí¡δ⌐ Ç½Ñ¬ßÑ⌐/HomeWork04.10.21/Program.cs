﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork04._10._21.Models.Task1;
using HomeWork04._10._21.Models.Task2;
using HomeWork04._10._21.AppSpace;

using Microsoft.VisualBasic;




namespace HomeWork04._10._21
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.Title = "Домашние задание на 04.10.21";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Решение задания 1"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Вывод массива структур типа Student"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Вывод фамилий и названия групп для всех студентов, имеющих хотя бы одну оценку 2 "},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Вывод фамилий и названий групп для всех студентов, имеющих оценки только 4 и 5 "},
                new MenuItem {HotKey = ConsoleKey.A, Text = "Упорядочивание массива по возрастанию среднего балла"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Упорядочивание массива по фамилиям и инициалам"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Перемешивание массива студентов"},
               
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();
            

            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("Интрефейсы, структуры");
                    Utils.ShowMenu(12, 5, "Меню ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key)
                    {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1

                       

                       
                        case ConsoleKey.Q:
                            app.DemoTask1();
                            break;


                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 2


                        // Вывод массива 
                        case ConsoleKey.W:

                            app.ShowArrayStudents();

                            break;

                        // Вывод на экран фамилий и названия групп для всех студентов, имеющих хотя бы одну оценку 2
                        case ConsoleKey.E:
                            Console.WriteLine($"Вывод на экран фамилий и названия групп для всех студентов, имеющих хотя бы одну оценку 2 ");
                            ArrayStudents.ShowArray(app.HaveTwo());
                            break;

                        // Вывод на экран фамилий и названий групп для всех студентов, имеющих оценки только 4 и 5 
                        case ConsoleKey.R:
                            Console.WriteLine($"Вывод на экран фамилий и названия групп для всех студентов, имеющих оценки только 4 и 5 ");
                            ArrayStudents.ShowArray(app.HavePositiv());
                            break;

                        // Упорядочивание массива по возрастанию среднего балла
                        case ConsoleKey.A:
                            Console.WriteLine($"Упорядочивание массива по возрастанию среднего балла");
                            app.SortToAVB();
                            app.ShowArrayStudents();
                            break;

                        // Упорядочивание массива по фамилиям и инициалам
                        case ConsoleKey.S:
                            Console.WriteLine($"Упорядочивание массива по фамилиям и инициалам");
                            app.SortToName();
                            app.ShowArrayStudents();
                            break;

                        // Перемешивание массива студентов
                        case ConsoleKey.D:
                            Console.WriteLine($"Перемешивание массива студентов");
                            app.ShuffleArray();
                            app.ShowArrayStudents();
                            break;


                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while


        }
    }
}
