﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Structures.Task2Classes;
using Structures.Task1Classes;


namespace Structures
{
    class App
    {
        static public Random random = new Random();
        public Student[] _students;
        public Root[] _equations;
        private string[] _menu = {
            "T1.Вывод массива уравнений - Q",
            "T1.Cумма элементов массива, расположенных между первым и последним нулем - W",
            "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~",
            "T2.Вывод массива студентов - A",
            "T2.Вывод массива студентов хорошистов - S",
            "T2.Вывод массива студентов двоечников - D",
            "T2.Упорядочивание массива по фамилиям и инициалам - F",
            "T2.Перемешивание массива студентов - G",
            "T2.Упорядочивание массива по возрастанию среднего балла - H",
            "Выход - Esc",
        };

        #region Утилиты
        //вывод меню
        public void ShowMenu()
        {
            for (int i = 0; i < _menu.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.SetCursorPosition(7, i + 10);
                Console.WriteLine(_menu[i]);
                Console.ForegroundColor = ConsoleColor.White;

            }
        }
        public void EndOfTask()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
            Console.Clear();
        }
        public void StartOfTask(string str)
        {
            Console.Clear();
            Console.WriteLine(str);
            Console.ForegroundColor = ConsoleColor.Blue;
        }
        #endregion

        #region Task1
        //фабрика уравнений
        public Root Creator(int x)
        {
            switch (x)
            {
                case 1:
                    Square square = new Square(random.Next(0,10), random.Next(0,10), random.Next(0, 10));
                    return square;
                    break;
                case 2:
                    Linear linear = new Linear(random.Next(0, 10), random.Next(0, 10));
                    return linear;
                    break;
                default: goto case 1;
            }
        }


        //инициализация массива уравнений
        public void Task1Iniz()
        {
            _equations = new Root[]
            {
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3)),
                Creator(random.Next(1,3))
            };
            
        }
        //вывод в консоль уравнений
        public void Task1Show()
        {
            StartOfTask("");
            Array.ForEach(_equations, x => x.Show());
            EndOfTask();
        }
        //вывести статистику
        public void Task1ShowStat()
        {
            StartOfTask("");
            Console.WriteLine($"Всего уравнений {_equations.Length}");
            EndOfTask();
        }

        #endregion

        #region Task2
        //заполнение данными (сгенерированными) массива из десяти структур типа Student
        public void Task2Iniz()
        {
            _students = new Student[]
            {
                new Student("Андреев Д.С", "БД012"),
                new Student("Судиловский Р.С", "БД012"),
                new Student("Шаталов Д.Д", "БД012"),
                new Student("Нелина Е.Н", "БД012"),
                new Student("Марушкевич Ю.Д", "БД012"),
                new Student("Вотинцева А.Т", "БД011"),
                new Student("Шунтов Р.М", "БД011"),
                new Student("Булыгина Т.К", "БД011"),
                new Student("Гунев Е.С", "БД011"),
                new Student("Пушкин А.С", "БД011"),
            };

        }
        //вывод массива студентов 
        public void Task2Show()
        {
            Console.WriteLine("\t ________________________________________________________________________");
            Console.WriteLine("\t|           ФИО           |Группа |           Предмет и оценка           |");
            Console.WriteLine("\t|_________________________|_______|______________________________________|");
            Array.ForEach(_students, x => x.ShowTable());
            Console.WriteLine("\t|_________________________|_______|______________________________________|");
            EndOfTask();
        }
        //вывод массива студентов двоечников
        public void Task2ShowBadSt()
        {
            StartOfTask("\n\t\t\t   Вывод массива студентов двоечников");
            int n = _students.Length;
            bool flag = true;

            Console.WriteLine("\t ________________________________________________________________________");
            Console.WriteLine("\t|           ФИО           |Группа |           Предмет и оценка           |");
            Console.WriteLine("\t|_________________________|_______|______________________________________|");


            for (int i = 0; i < n; i++)
            {
                if (_students[i].isBad())
                {
                    _students[i].ShowTable();
                    flag = false;
                }
            }


            if(flag)
                Console.WriteLine("\t|                          Двоечников нет!                               |");
            Console.WriteLine("\t|________________________________________________________________________|");
            Console.WriteLine("\t|_________________________|_______|______________________________________|");
            EndOfTask();
        }
        //вывод массива студентов хорошистов
        public void Task2ShowGoodSt()
        {
            StartOfTask("\n\t\t\t   Вывод массива студентов хорошистов");

            int n = _students.Length;
            bool flag = true;

            Console.WriteLine("\t ________________________________________________________________________");
            Console.WriteLine("\t|           ФИО           |Группа |           Предмет и оценка           |");
            Console.WriteLine("\t|_________________________|_______|______________________________________|");


            for (int i = 0; i < n; i++)
            {
                if (_students[i].isGood())
                {
                    _students[i].ShowTable();
                    flag = false;
                }
            }


            if (flag)
                Console.WriteLine("\t|                             Хорошистов нет!                            |");
            Console.WriteLine("\t|________________________________________________________________________|");
            Console.WriteLine("\t|_________________________|_______|______________________________________|");

            EndOfTask();
        }
        //упорядочивание массива по возрастанию среднего балла
        public void Task2SortAv()
        {
            StartOfTask("\n\t\t  Упорядочивание массива по возрастанию среднего балла");
            Array.Sort(_students, (Student a, Student b) => a.AverageMark().CompareTo(b.AverageMark()));

            Task2Show();
        }
        //упорядочивание массива по фамилиям и инициалам
        public void Task2SortName()
        {
            StartOfTask("\n\t\t  Упорядочивание массива по фамилиям и инициалам");
            Array.Sort(_students, (Student a, Student b) => a.Name.CompareTo(b.Name));

            Task2Show();
        }
        //перемешивание массива студентов
        public void Task2Shuffle()
        {
            StartOfTask("\n\t\t\t  Перемешивание массива студентов");

            int n = _students.Length;

            for (int i = 0; i < n; i++)
            {
                int j = random.Next(i + 1);

                Student tmp = _students[j];
                _students[j] = _students[i];
                _students[i] = tmp;
            }
            
            Task2Show();
        }
        #endregion
    }
}
