﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Structures.Task1Classes
{
    //класс для линейных уравнений Linear
    class Linear : Root
    {
        //конструкторы
        public Linear():base(1,1)
        {

        }
        public Linear(int a, int b) :base(a,b)
        {

        }

        public override bool HasSolve() => _a != 0;

        public override void Show()
        {
            Console.Write( $"\t\t\t\t{_a}x + {_b} = 0       | x == ");
            Solve();
        }

        public override void Solve()
        {
            string str = HasSolve() ? $"{-_b / _a}" : "Нет решений";
            Console.WriteLine(str);
        }
    }
}
