﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Создать иерархию классов и интерфейс для решения линейных и квадратных уравнений. Линейное
//уравнение имеет вид: ax + b = 0, квадратное уравнение имеет вид ax2 + bx + c = 0


namespace Structures.Task1Classes
{
    //класс для квадратных уравнений Square
    class Square : Root
    {
        private int _c;

        public int C
        {
            get { return _c; }
            set { _c = value; }
        }

        //конструкторы
        public Square() : base(1, 1)
        {
            _c = 1;
        }
        public Square(int a, int b, int c):base(a,b)
        {
            _c = c;
        }

        public override void Show()
        {
            Console.Write($"\t\t\t\t{_a}x2 + {_b}x + {_c} = 0 | x == ");
            Solve();
        }

        public override void Solve()
        {
            string str = HasSolve() ? $"{_b * _b - 4 * _a * _c}" : "Нет решений";
            Console.WriteLine(str);
        }

        public override bool HasSolve() => _b * _b - 4 * _a * _c > 0 && _a > 0;
    }
}
