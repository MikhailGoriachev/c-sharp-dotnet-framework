﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structures.Task1Classes
{
    //Базовый абстрактный класс Root
    abstract class Root : ISolver
    {
        protected int _a;
        protected int _b;

        //конструкторы
        public Root()
        {
            _a = 1;
            _b = 1;
        }
        public Root(int a, int b)
        {
            _a = a;
            _b = b;
        }

        //свойства
        public int B
        {
            get { return _b; }
            set { _b = value; }
        }
        public int A
        {
            get { return _a; }
            set { _a = value; }
        }

        public abstract bool HasSolve();
        public abstract void Show();
        public abstract void Solve();
    }
}
