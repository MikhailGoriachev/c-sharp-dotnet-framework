﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Интерфейс ISolver должен содержать методы void Solve() для решения уравнения,
//void Show() для вывода решения в консоль, bool HasSolve() для определения наличия решения
//уравнения.

namespace Structures.Task1Classes
{
    //Интерфейс ISolver
    interface ISolver
    {
        //для решения уравнения
        void Solve();
        //для вывода решения в консоль
        void Show();
        //для определения наличия решения уравнения
        bool HasSolve();
    }
}
