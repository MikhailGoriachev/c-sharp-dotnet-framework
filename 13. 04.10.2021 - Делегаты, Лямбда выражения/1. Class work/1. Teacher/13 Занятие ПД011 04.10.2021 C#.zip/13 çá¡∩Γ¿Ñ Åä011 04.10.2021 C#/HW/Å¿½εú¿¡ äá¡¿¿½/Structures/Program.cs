﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;


namespace Structures
{
    class Program
    {
        static void Main(string[] args)
        {
            App app = new App();
            bool flag = true;
            app.Task1Iniz();
            app.Task2Iniz();

            try
            {
                while (flag)
                {
                    app.ShowMenu();
                    switch (Console.ReadKey().Key)
                    {
                        case ConsoleKey.Q:
                            app.Task1Show();
                            break;
                        case ConsoleKey.W:
                            app.Task1ShowStat();
                            break;
                        case ConsoleKey.A:
                            app.StartOfTask("\n\t\t\t\t  Массив студентов");
                            app.Task2Show();
                            break;
                        case ConsoleKey.S:
                            app.Task2ShowGoodSt();
                            break;
                        case ConsoleKey.D:
                            app.Task2ShowBadSt();
                            break;
                        case ConsoleKey.F:
                            app.Task2SortName();
                            break;
                        case ConsoleKey.G:
                            app.Task2Shuffle();
                            break;
                        case ConsoleKey.H:
                            app.Task2SortAv();
                            break;
                        case ConsoleKey.Escape:
                            flag = false;
                            break;
                        default:
                            continue;
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical);
            }
        }
    }
}
