﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Structures;

namespace Structures.Task2Classes
{

    //структура Student
    struct Student
    {
        static public Random random = new Random();

        //вложенная структура: название предмета, оценка (short))
        public struct Mark
        {
            private short _grade;
            private string _course;

            public Mark(short grade, string course)
            {
                _grade = grade;
                _course = course;
            }

            public short Grade
            {
                get { return _grade; }
                set
                {
                    _grade = value > 0 && value < 6 ? value :
                      throw new Exception($"Нет такой оценки {value}!");
                }
            }


            public string Course
            {
                get { return _course; }
                set
                {
                    _course = !string.IsNullOrWhiteSpace(value) ? value :
                      throw new Exception("Некорректно введены данные названия предмета!");
                }
            }

            public override string ToString() => $"{_course}: {_grade}";
        }


        private string _name;   //· фамилия и инициалы;
        private string _group;  //· название группы;
        private Mark[] _marks;  //· успеваемость(массив из пяти элементов типа Mark)

        //конструктор с параметрами
        public Student(string name, string group)
        {
            _name = name;
            _group = group;
            _marks = new Mark[]
                {
                    new Mark((short)random.Next(2,5),"C#"),
                    new Mark((short)random.Next(2,5),"JS"),
                    new Mark((short)random.Next(2,5),"UML"),
                    new Mark((short)random.Next(2,5),"MSQL"),
                    new Mark((short)random.Next(2,5),"Python")
                };
        }

        //свойства
        public Mark[] Marks
        {
            get { return _marks; }
            set { _marks = value ?? throw new Exception("Свойство Marks: пустой массив оценок!"); }
        }
        public string Group
        {
            get { return _group; }
            set
            {
                _group = !string.IsNullOrWhiteSpace(value) ? value :
                  throw new Exception($"Свойство Group: некорректное название группы!");
            }
        }
        public string Name
        {
            get { return _name; }
            set
            {
                _name = !string.IsNullOrWhiteSpace(value) ? value :
                  throw new Exception($"Свойство Name: некорректное ФИО студента!");
            }
        }


        //проверка, является ли студент двоечником
        public bool isBad()
        {
            int n = _marks.Length;
            bool key = false;
            for (int i = 0; i < n; i++)
            {
                if (_marks[i].Grade == 2)
                {
                    key = true;
                    break;
                }
            }
            return key;
        }
        //проверка, хорошо ли учится студент(только на оценки 4 и 5)
        public bool isGood()
        {
            bool key = true;
            int n = _marks.Length;

            for (int i = 0; i < n; i++)
            {
                if(_marks[i].Grade < 4)
                {
                    key = false;
                    break;
                }
            }

            return key;
        }

        //рассчет среднего балла студента
        public int AverageMark()
        {
            int temp = 0;
            int n = _marks.Length;

            for (int i = 0; i < n; i++)
                temp+=_marks[i].Grade;

            return temp;
        }


        //индексатор для массива оценок Mark
        public Mark this[int index]
        {
            get
            {
                if (index > _marks.Length || index < 0)
                    throw new Exception("Индексатор: индекс вышел за пределы массива!");
                else return _marks[index];
            }
            set
            {
                if (index > _marks.Length || index < 0)
                    throw new Exception("Индексатор: индекс вышел за пределы массива!");
                else _marks[index] = value;
            }
        }

        //вывод в консоль
        public void ShowTable()
        {
            Console.Write($"\t|{_name,20}     | {_group} | ");
            int n = _marks.Length;
            for (int i = 0; i < n; i++)
            {
                Console.Write($"{_marks[i]} ");
            }
            Console.WriteLine("|");
        }
    }
}
