﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Home_Task_04_10.Utilities;
using Home_Task_04_10.Models;

namespace Home_Task_04_10.Solutions
{
    public class Task1
    {
        
    }
}
