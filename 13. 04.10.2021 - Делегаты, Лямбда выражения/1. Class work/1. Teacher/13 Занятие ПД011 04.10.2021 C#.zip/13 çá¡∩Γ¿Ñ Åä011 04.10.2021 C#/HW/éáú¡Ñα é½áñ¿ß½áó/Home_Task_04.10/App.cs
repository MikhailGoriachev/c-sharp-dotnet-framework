﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using Home_Task_04_10.Utilities;
using Home_Task_04_10.Solutions;
namespace Home_Task_04_10
{
    partial class App
    {
        Task1 task1;
        Task2 task2;
        public App ()
        {
            task1 = new Task1();
            task2 = new Task2();
        }
        public void Menu()
        {
            #region Главное меню
            /*Console.ForegroundColor = Utils._SymbolsColor;
            Console.BackgroundColor = Utils._MainColor;*/
            Palette.MainColor.EstablishColor();
            string MainTitle = "Домашнее задание на 29.09";

            //Массивы пунктов меню. 
            MenuItem[] baseMenu = new[] {
                new MenuItem {key = " 1 ",Text = " - Задача 1: решение уравнений"},
                new MenuItem {key = " 2 ",Text = " - Задача 2: структура Student"},
                new MenuItem {key = "ESC",Text = " - выход из программы"}
            };

            while (true)
            {
                Console.Clear();
                Utils.ShowBarMessage(" ".PadRight(Console.WindowWidth/2-MainTitle.Length/2)+MainTitle);
                Console.CursorVisible = false;
                Utils.ShowMenu(3, 3, "Выберете задание", baseMenu);

                //Если задание сделано не до конца

                Console.ForegroundColor = Utils.colors.W;
                Console.BackgroundColor = Utils.colors.R;
                Console.SetCursorPosition(3, 14);
                Console.Write("Ps.Задание в разработке!");
                Palette.MainColor.EstablishColor();

                ConsoleKey key = Console.ReadKey().Key;

                try
                {
                    switch (key)
                    {
                        case ConsoleKey.D1:
                            {
                                Console.Clear();
                                Task1Menu();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.D2:
                            {
                                Console.Clear();
                                Task2Menu();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.Escape:
                            {
                                Console.Clear();
                                return;
                            }
                        default:
                            throw new Exception($"Клавиша {key} не поддерживается");
                    }

                }
                //Обрабатываем общее исключение
                catch (Exception ex)
                {
                    Console.Clear();
                    Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);

                    Console.ReadKey();
                }//catch
            }

            #endregion
        }
    }
}
