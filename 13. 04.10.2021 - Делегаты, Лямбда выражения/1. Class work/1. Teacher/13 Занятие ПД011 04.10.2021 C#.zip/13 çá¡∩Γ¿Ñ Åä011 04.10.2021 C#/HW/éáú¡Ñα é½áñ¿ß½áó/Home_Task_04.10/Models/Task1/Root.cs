﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Task_04_10.Models
{ 
    abstract class Root
    {
        //Неполное свойство
      public double X
        {
            get;
            set;
        }

    public double a
        {
            get;
            set;
        }
        
        public double b
        {
            get;
            set;
        }

        //Шапка таблицы
        static public string Header(int space)
        {
            string indent = " ".PadRight(space);


            string res = $"\n{indent}┌─────┬──────────────────────┬───────────────────┐" +
                         $"\n{indent}│  N  │     Уравнение        │ Результат решения │" +
                         $"\n{indent}│     │                      │ X. X1,X2          │" +
                         $"\n{indent}├─────┼──────────────────────┼───────────────────┤";

            return res;
        }

        //Разделительная строка
        public static string MiddleLine(int space)
        {
            return $"\n{(" ",space)}├─────┼──────────────────────┼───────────────────┤";
        }

        //Подвал таблицы
        public static string FooterEquations(int space,int squares,int linears)
        {
            string indent = new string (' ',space);

            
                                   //├─────┼──────────────────────┼───────────────────┤
            string res = $"\n{indent}├─────┴───────────┬──────────┴─────┬─────────────┤" +
                         $"\n{indent}│ Общее количество│   Количество   │ Количество  │" +
                         $"\n{indent}│ уравнений       │   квадтратных  │ линейных    │\n{indent}├─────────────────┼────────────────┼─────────────┤" +
                         $"\n{indent}|{squares+linears,17}|{squares,16}|{linears,13}|";
                                   //├─────────────────┼────────────────┼─────────────┤
            return res;
        } 
        public static string FooterSolutions(int space,int squares,int linears)
        {
            string indent = new string (' ',space);

            
                                   //├─────┼──────────────────────┼───────────────────┤
            string res = $"\n{indent}├─────┴───────────┬──────────┴─────┬─────────────┤" +
                         $"\n{indent}│ Общее количество│ Решения для    │ Решения для │" +
                         $"\n{indent}│ решений         │ квадтратных ур.│ линейных ур.│\n{indent}├─────────────────┼────────────────┼─────────────┤" +
                         $"\n{indent}|{squares+linears,17}|{squares,16}|{linears,13}|";
                                   //├─────────────────┼────────────────┼─────────────┤
            return res;
        }
    }
}
