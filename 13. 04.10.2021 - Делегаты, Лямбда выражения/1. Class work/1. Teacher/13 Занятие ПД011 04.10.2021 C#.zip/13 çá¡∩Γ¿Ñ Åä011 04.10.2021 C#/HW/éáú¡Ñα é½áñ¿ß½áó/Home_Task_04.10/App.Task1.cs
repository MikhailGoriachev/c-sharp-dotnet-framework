﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Home_Task_04_10.Utilities;

namespace Home_Task_04_10
{
    partial class App
    {
        //Меню задания 1
        void Task1Menu()
        {
            //Console.SetWindowSize(60, 50);
            //Массивы пунктов меню 
            MenuItem[] FirstTaskMenu = new[] {
                new MenuItem {key = " Q ",Text = " - Посчитать количество уравнений"},
                new MenuItem {key = " W ",Text = " - Посчитать количество решений "},
                new MenuItem {key = "ESC",Text = " - Выход"}
            };
            //App app = new App();
            try
            {

                while (true)
                {
                    Console.Clear();
                    Utils.ShowBarMessage($"Задание 1: ");
                    Console.CursorVisible = false;
                    Utils.ShowMenu(3, 3, "Выберете действие", FirstTaskMenu);
                    //Если задание сделано не до конца

                    Console.ForegroundColor = Utils.colors.W;
                    Console.BackgroundColor = Utils.colors.R;
                    Console.SetCursorPosition(3, 12);
                    Console.Write("Ps.Задание в разработке. Методы не реализованы!");
                    Palette.MainColor.EstablishColor();
                    ConsoleKey key = Console.ReadKey().Key;

                    

                    switch (key)
                    {
                        case ConsoleKey.Q:
                            {
                                Console.Clear();
                              
                                Utils.ShowFrameMessage("Метод в разработке!", "INFO_Tas1", 3, 5);
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.W:
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("Метод в разработке!", "INFO_Task1", 3, 5);
                                Console.ReadKey();
                                break;
                            }

                        case ConsoleKey.Escape:
                            {

                                return;
                            }
                        default:
                            throw new Exception($"Клавиша {key} не поддерживается");
                    }//Switch

                }//While

            }//Try
             //Catсh блок
            //Обрабатываем общее исключение
            catch (Exception ex)
            {
                Console.Clear();
                Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);
                //Console.Write($"{ ex.Message}\n {ex.StackTrace}");

            }//catch

        } //Task 1
    }
}
