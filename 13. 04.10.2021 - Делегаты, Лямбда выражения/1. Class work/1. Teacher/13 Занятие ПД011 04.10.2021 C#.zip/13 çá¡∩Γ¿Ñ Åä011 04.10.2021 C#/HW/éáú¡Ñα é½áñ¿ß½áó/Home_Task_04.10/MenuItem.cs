﻿using System;

namespace Home_Task_04_10
{
    
    // пункт меню
    public struct MenuItem 
    {
        //свойство в типе Conspole key
        public ConsoleKey HotKey 
        { get; set; }  // горячая клавиша пункта меню

        public string key
        { get; set; }
        public string Text 
        { get; set; }        // текст пункта меню
    } // class MenuItem
}