﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Home_Task_04_10.Utilities;
using Home_Task_04_10.Solutions;

namespace Home_Task_04_10
{
    partial class App
    {
        //Меню задания 2
        void Task2Menu()
        {
            //Массивы пунктов меню 
          #region Что должно быть в меню
          /*
           * заполнение данными (сгенерированными) массива из десяти структур типа Student
           
           * вывод на экран фамилий и названия групп для всех студентов, 
             * имеющих хотя бы одну оценку 2 (если таких студентов нет, вывести соответствующее сообщение)
           
           * вывод на экран фамилий и названий групп для всех студентов, имеющих оценки только 4 и 5 (если таких студентов нет, вывести соответствующее сообщение)
           
           * упорядочивание массива по возрастанию среднего балла
           
           * упорядочивание массива по фамилиям и инициалам
           
           * перемешивание массива студентов
          */
          #endregion
          MenuItem[] FirstTaskMenu = new[] {
              new MenuItem {key = " Q ",Text = " - Инициализировать массив структур student"},
              new MenuItem {key = " W ",Text = " - Вывести студентов с мин 1-й оценкой 2"},
              new MenuItem {key = " E ",Text = " - Вывести студентов с оценками 4 и 5"},
              new MenuItem {key = " R ",Text = " - Отсортировать массив по возрастанию среднего балла"},
              new MenuItem {key = " T ",Text = " - Отсортировать массив по фамилиям студентов"},
              new MenuItem {key = " Y ",Text = " - Перемешать массив студентов"},
              new MenuItem {key = "ESC",Text = " - Выход"}
          };
          
          try
          {
              while (true)
              {
                  Console.Clear();
                  //Полное заполнение строки вычисляется путём нахождения оставшегося пространства после строки до края
                  Utils.ShowBarMessage($"Задание 2:");
                  Console.CursorVisible = false;
                  Utils.ShowMenu(3, 3, "Выберете действие", FirstTaskMenu);
          
                  //Если задание сделано не до конца
          
                  Console.ForegroundColor = Utils.colors.W;
                  Console.BackgroundColor = Utils.colors.R;
                  Console.SetCursorPosition(3, 22);
                  Console.Write(" Ps.задание не выполнено! ");
                  Palette.MainColor.EstablishColor();
          
                  ConsoleKey key = Console.ReadKey().Key;
          
          
          
                  switch (key)
                  {
                      case ConsoleKey.Q:
                          {
                              Console.Clear();
                              Utils.ShowFrameMessage("Структура студентов в разработке!", "INFO_Task2", 3, 5);
                              Console.ReadKey();
                              break;
                          }
                      case ConsoleKey.W:
                          {
                              Console.Clear();
                              Utils.ShowFrameMessage("Вывод студентов с мин 1-й оценкой 2 в разработке!", "INFO_Task2", 3, 5);
                              Console.ReadKey();
                              break;
                          }

                        case ConsoleKey.E:
                          {
                              Console.Clear();
                              Utils.ShowFrameMessage("Вывод студентов с оценками 4 и 5 в разработке!", "INFO_Task2", 3, 5);
                              Console.ReadKey();
                              break;
                          }
                        
                        case ConsoleKey.R:
                          {
                              Console.Clear();
                              Utils.ShowFrameMessage("Сортировка массива по возрастанию среднего балла в разработке", "INFO_Task2", 3, 5);
                              Console.ReadKey();
                              break;
                          }
                        
                        case ConsoleKey.T:
                          {
                              Console.Clear();
                              Utils.ShowFrameMessage("Сортировка массива по фамилиям студентов в разработке!", "INFO_Task2", 3, 5);
                              Console.ReadKey();
                              break;
                          }
                        
                        case ConsoleKey.Y:
                          {
                              Console.Clear();
                              Utils.ShowFrameMessage("Перемешивание массива студентов в разработке!", "INFO_Task2", 3, 5);
                              Console.ReadKey();
                              break;
                          }
          
                      case ConsoleKey.Escape:
                          {
          
                              return;
                          }
                      default:
                          throw new Exception($"Клавиша {key} не поддерживается");
                  }
          
              }//While
          }//try
           //Catсh блок
          
          
          //Обрабатываем общее исключение
          catch (Exception ex)
          {
              Console.Clear();
              Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);
          }//catch
        }
  }
}

