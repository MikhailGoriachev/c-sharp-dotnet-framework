﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructuresInheritance.Tasks.Task1
{
    class Square: Root
    {
        public string Name = "Квадраное";
        public double A
        {
            get => _a;
            set => _a = value;
        }

        public double B
        {
            get => _b;
            set => _b = value;
        }

        private double _c ;

        public double C
        {
            get => _c; 
            set=> _c = value; 
        }

        public double discriminant() => Math.Pow(B, 2) - (4 * A * C);
        public (double x1, double x2) Result { get; private set; }
        public double root1() => (-B + Math.Sqrt(discriminant()) / 2 * A);
        public double root2() => (-B - Math.Sqrt(discriminant()) / 2 * A);
        


        public override void Solve()
        {
            if (!HasSolve()) throw new ArithmeticException(" Кортней нет");
            if (Math.Abs(discriminant()) < 0.0001)
            {
                double answer = -(B / 2 * A);
                Result = (answer, answer); 
            }
            Result = (root1(), root2()); 
            
        }

        

        public  override bool HasSolve()
        {
            if (discriminant() < 0) return false;
            return true; 
        }

        public override void Show()
        {
            Console.WriteLine($"Уравнение имеет корни {Result, 2:F}");
        }

    }
}
