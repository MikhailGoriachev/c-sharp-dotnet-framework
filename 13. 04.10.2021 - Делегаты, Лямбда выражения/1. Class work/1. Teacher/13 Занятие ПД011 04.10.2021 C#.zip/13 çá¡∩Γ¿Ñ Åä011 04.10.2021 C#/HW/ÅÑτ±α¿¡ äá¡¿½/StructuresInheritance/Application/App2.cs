﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StructuresInheritance.Tasks.Task2;

namespace StructuresInheritance.Application
{
    internal partial class App
    {

        public void Task2Point1()
        {
            Utils.ShowNavBarTask("Задание2. Массив данных студентов");

            int n = 10;
            task2.Fill(n);
            task2.ShowTable();

            Console.ReadKey();
        }

        public void Task2Point2()
        {
            Utils.ShowNavBarTask("Задание2. Массив данных студентов, имеющих оценку 2");

            int n = 10;
            task2.Fill(n);
            task2.ShowTableTwos();

            Console.ReadKey();
        }

        public void Task2Point3()
        {
            Utils.ShowNavBarTask("Задание2. Массив данных студентов, имеющих оценку только 4 и 5");


            int n = 10;
            task2.Fill(n);
            task2.ShowTable45();

            Console.ReadKey();
        }

        public void Task2Point4()
        {
            Utils.ShowNavBarTask("Задание2. Упорядочивание массива по возрастанию среднего балла");
            int n = 10;
            task2.Fill(n);
            task2.SortByGrade();
            task2.ShowTable();

            Console.ReadKey();
        }

        public void Task2Point5()
        {
            Utils.ShowNavBarTask(" Задание2. Упорядочивание массива по фамилиям и инициалам");

            int n = 10;
            task2.Fill(n);
            task2.SortByName();
            task2.ShowTable();

            Console.ReadKey();
        }

        public void Task2Point6()
        {
            Utils.ShowNavBarTask(" Задание2. Перемешивание массива студентов");

            Console.WriteLine("\n\nМассив до перемешивания");
            int n = 10;
            task2.Fill(n);
            task2.SortByName();
            task2.ShowTable();

            Console.WriteLine("\nМассив после перемешивания");

            task2.Shuffle();
            task2.ShowTable();

            Console.ReadKey();
        }
    }
}
