﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StructuresInheritance.Tasks.Task1;
using StructuresInheritance.Tasks.Task2;


namespace StructuresInheritance.Application
{
    internal partial class App
    {
        Task1 task1 = new Task1();
        Task2 task2 = new Task2();

    }
}
