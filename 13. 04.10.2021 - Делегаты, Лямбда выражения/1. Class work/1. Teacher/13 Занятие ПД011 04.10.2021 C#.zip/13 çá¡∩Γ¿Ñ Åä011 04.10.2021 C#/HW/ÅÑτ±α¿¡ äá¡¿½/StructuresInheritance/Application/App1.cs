﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StructuresInheritance.Tasks.Task1;

namespace StructuresInheritance.Application
{
    internal partial class App
    {
        public void Task1Point1()
        {
            Utils.ShowNavBarTask(" Задание 1.Общее количество уравнений");

            Console.WriteLine("\n\n");
            Console.WriteLine($" Общее количество уравнений (линейных, квадратных) равно:  {task1.CountEquations()}");

            Console.ReadKey();
        }

        public void Task1Point2()
        {
            Utils.ShowNavBarTask("Задание 1. Общее количество решений");

            Console.WriteLine("\n\n");
            Console.WriteLine($"Общее количество решений (линейных, квадратных) равно : {task1.CountResults()}");

            Console.ReadKey();
        }
    }
}
