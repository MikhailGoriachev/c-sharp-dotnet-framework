﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructuresInheritance.Tasks.Task1
{
    class Linear : Root
    {
        public string Name = "Линейное";
        public double A
        {
            get => _a;
            set => _a = value;
        }

        public double B
        {
            get => _b;
            set => _b = value;
        }

        public double result { get; private set;  }

        public override void  Solve() 
        {
             HasSolve();
             result =  B / A;
        }

        public override void  Show()
        {
            Console.WriteLine($" Уравнение имеет корень {result}");
        }

        public override bool HasSolve()
        {
            if (A == 0 && B == 0)
                return false;
            if (A == 0 && B != 0)
                return false;
            return true;
        }


    }
}
