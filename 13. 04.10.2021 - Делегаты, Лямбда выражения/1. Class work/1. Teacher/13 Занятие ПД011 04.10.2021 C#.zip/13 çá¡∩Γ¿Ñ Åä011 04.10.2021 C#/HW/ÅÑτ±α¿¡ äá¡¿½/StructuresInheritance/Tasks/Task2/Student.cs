﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructuresInheritance.Tasks.Task2
{
    struct Student
    {

        private string _fullName;

        public string FullName
        {
            get => _fullName; 
            set => _fullName = value; 
        }

        private string  _groupName;

        public string  GroupName
        {
            get => _groupName; 
            set => _groupName = value; 
        }

        private Mark[] _marks;

        // конструктор с параметрами
        public Student (string name, string group, Mark[] marks)
        {
            _fullName = name;
            _groupName = group;
            _marks = marks;
        }
        

        public struct Mark
        {
            public string Subject { get; set; }
            public short Grade { get; set; }

            public Mark (string subject, short grade)
            {
                Subject = subject;
                Grade = grade;
            }
        }

        // индексатор 
        public Mark this[int index]
        {
            get => _marks[index];
            set => _marks[index] = value;
        }

        public double AveageMark()
        {
            double result = 0;
            foreach(var item in _marks)
            {
                result += item.Grade;
            }

            return result/_marks.Length;
        }

        // упорядочивание студентов по средненему баллу
        public static int CompareByAverageGrade(Student s1, Student s2) => s1.AveageMark().CompareTo(s2.AveageMark());

        // упорядочивание студентов по фамилиям

        public static int CompareByName(Student s1, Student s2) => s1.FullName.CompareTo(s2.FullName);





    }
}
