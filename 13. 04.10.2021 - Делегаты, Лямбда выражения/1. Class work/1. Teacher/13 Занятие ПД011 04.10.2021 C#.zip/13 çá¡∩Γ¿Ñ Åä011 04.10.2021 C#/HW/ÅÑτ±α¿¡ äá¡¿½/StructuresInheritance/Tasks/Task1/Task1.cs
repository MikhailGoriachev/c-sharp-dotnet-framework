﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructuresInheritance.Tasks.Task1
{
    class Task1
    {
        ISolver[] array = new ISolver[]
        {
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),
            Root.Factory(),

        };

        public (int linear, int square) CountEquations()
        {
            int countLinear = 0;
            int countSquare = 0; 
            foreach(var item in array )
            {
                if (item is Linear) countLinear++;
                else countSquare++;
            }

            return (countLinear, countSquare); 
        }

        public (int linear, int square) CountResults()
        {
            int countLinear = 0;
            int countSquare = 0;
            foreach(var item in array)
            {
                if(item.HasSolve())
                {
                    if (item is Linear) countLinear++;
                    else countSquare++;
                }
            }
            return(countLinear, countSquare);


        }
    }
}
