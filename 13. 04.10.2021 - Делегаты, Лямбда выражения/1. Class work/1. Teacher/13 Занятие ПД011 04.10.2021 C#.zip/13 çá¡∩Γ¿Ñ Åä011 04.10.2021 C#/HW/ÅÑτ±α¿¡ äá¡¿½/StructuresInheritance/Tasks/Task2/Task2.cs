﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StructuresInheritance.Tasks.Task2;

namespace StructuresInheritance.Tasks.Task2
{
    class Task2
    {
        Student[] _students; 
        static Random rand = new Random();

        public void Fill(int size)
        {
            _students = new Student[size]; 
            for(int i =0; i<size; i++)
            {
                _students[i] = new Student(FullNames(), GroupName(), Marks()); 
            }


        }

        public string FullNames()
        {
            string[] names = {"Иванов В.И.", "Петров В.С.", "Сидоров К.У",
                "Давыдов С.И.", "Никонорова А.М.", "Параманов С.К.", "Федоров.М.К.",
                "Калиущенко В.С.", "Вещенко А.К.", "Михайлова М.К" };

            return names[rand.Next(names.Length - 1)];
        }

        public string GroupName()
        {
            string[] names = { "БД012", "ВК212", "ДВ768", "КА425",
                "МИ485", "СК634", "ШК657", "РО934", "ТИ827", "ФУ864" };

            
            return names[rand.Next(names.Length - 1)];
        }

        public Student.Mark[] Marks()
        {
            

            return new Student.Mark[5]
            {
               new Student.Mark("Химия",(short)Utils.GetRandomInt(1,5)),
               new Student.Mark("Биология",(short)Utils.GetRandomInt(1,5)),
               new Student.Mark("Литература",(short)Utils.GetRandomInt(1,5)),
               new Student.Mark("Геометрия",(short)Utils.GetRandomInt(1,5)),
               new Student.Mark("Алгебра",(short)Utils.GetRandomInt(1,5)),
            };
        }

        public void ShowTable()
        {
            Console.WriteLine("\n\n");

            Console.WriteLine($"\t\t ");
            Console.WriteLine("┌──────────────────┬────────────┬──────────────────┐");
            Console.WriteLine("│   Ф. И. О.       │  Группа    │   Средний бал    |");
            Console.WriteLine("├──────────────────┼────────────┼──────────────────┤");
            foreach(var item in _students)
            {
                Console.WriteLine($"| {item.FullName, -16} | {item.GroupName, 10} | {item.AveageMark(), 16 } |");
            }
            Console.WriteLine("└──────────────────┴────────────┴──────────────────┘");

        }

        public bool Mark2(Student name)
        {
            for (int i = 0; i < 5; i++)
            {
                if (name[i].Grade == 2) return true;

            }
            return false;

        }

        public bool Mark45(Student name)
        {
            for(int i = 0; i<5; i++)
            {
                if (name[i].Grade != 4 && name[i].Grade != 5) return false;
            }

            return true;
        }

        public void ShowTableTwos()
        {
            Console.WriteLine("\n\n");

            Console.WriteLine($"\t\t ");
            Console.WriteLine("┌──────────────────┬────────────┬──────────────────┐");
            Console.WriteLine("│   Ф. И. О.       │  Группа    │   Средний бал    |");
            Console.WriteLine("├──────────────────┼────────────┼──────────────────┤");
            foreach (var item in _students)
            {
                if(Mark2(item))
                    Console.WriteLine($"| {item.FullName,-16} | {item.GroupName,10} | {item.AveageMark(),16 } |");
            }

            Console.WriteLine("└──────────────────┴────────────┴──────────────────┘");
        }

        public void ShowTable45()
        {
            Console.WriteLine("\n\n");
            int counter = 0;
            Console.WriteLine($"\t\t ");
            Console.WriteLine("┌──────────────────┬────────────┬──────────────────┐");
            Console.WriteLine("│   Ф. И. О.       │  Группа    │   Средний бал    |");
            Console.WriteLine("├──────────────────┼────────────┼──────────────────┤");
            foreach (var item in _students)
            {
                if (Mark45(item))
                {
                    Console.WriteLine($"| {item.FullName,-16} | {item.GroupName,10} | {item.AveageMark(),16 } |");
                    counter++;
                }
            }
            Console.WriteLine("└──────────────────┴────────────┴──────────────────┘");
            if (counter == 0)
                Console.WriteLine("Таких студентов нет");
        }

        public void SortByGrade() => Array.Sort(_students, Student.CompareByAverageGrade);

        public void SortByName() => Array.Sort(_students, Student.CompareByName);

        // перемешивание 
        public  void Shuffle()
        {
            for (int i = 0; i < _students.Length; i++)
            {
                int j = rand.Next(_students.Length - 1);

                (_students[i], _students[j]) = (_students[j], _students[i]);
            }

        }
    }
}
