﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructuresInheritance.Tasks.Task1
{
    interface ISolver
    {
        void Solve();
        void Show();
        bool HasSolve();
    }
}
