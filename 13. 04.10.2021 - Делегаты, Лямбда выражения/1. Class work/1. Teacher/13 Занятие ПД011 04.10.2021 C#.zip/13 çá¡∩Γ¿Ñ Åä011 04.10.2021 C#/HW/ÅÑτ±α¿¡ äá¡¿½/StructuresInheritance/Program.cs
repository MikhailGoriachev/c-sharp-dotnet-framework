﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StructuresInheritance.Application;

namespace StructuresInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 04.09.2021. Структуры. Множественное наследование.";

            //меню приложения 
            MenuItem[] menu = new[]
            {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задание1. Общее количество уравнений (линейныйх и квадратных)"},
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задание1. Общее количество решений(линейных и квадратных)"},
                //-----------------------------------------------------------------------------------------//
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задание2. Массив данных студентов"},
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задание2. Массив данных студентов, имеющих оценку 2"},
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Задание2. Массив данных студентов, имеющих оценку только 4 и 5"},
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задание2. Упорядочивание массива по возрастанию среднего балла"},
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задание2. Упорядочивание массива по фамилиям и инициалам"},
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задание2. Перемешивание массива студентов"},
            };

            // экземпляр класса приложения
            App app = new App();

            while(true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - Абстрактные классы. Интерфейсы. Структуры");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с абстрактными классами и интерфесами", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key)
                    {
                        // пункты меню, относящиеся к Задаче 1
                        #region Задача 1
                        case ConsoleKey.Q:
                            app.Task1Point1();
                            break;
                        case ConsoleKey.W:
                            app.Task1Point2();
                            break;
                        #endregion

                        // пункты меню, относящиеся к Задаче 2
                        #region Задача2
                        case ConsoleKey.R:
                            app.Task2Point1();
                            break;
                        case ConsoleKey.T:
                            app.Task2Point2();
                            break;
                        case ConsoleKey.Y:
                            app.Task2Point3();
                            break;
                        case ConsoleKey.A:
                            app.Task2Point4();
                            break;
                        case ConsoleKey.S:
                            app.Task2Point5();
                            break;
                        case ConsoleKey.D:
                            app.Task2Point6();
                            break;

                        #endregion
                    }

                }
                catch(Exception ex)
                {
                    Console.Clear();
                    Console.WriteLine(ex);
                    Console.ReadKey();
                }

            }// while 

        }
    }
}
