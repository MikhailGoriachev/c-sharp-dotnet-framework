﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructuresInheritance.Tasks.Task1
{
    /* Базовый абстрактный класс Root*/
    abstract class Root : ISolver
    {
        public double _a;
        public double _b;

        public abstract bool HasSolve();
        public abstract void Show();
        public abstract void Solve();

        public static ISolver Factory()
        {
            int a = Utils.GetRandomInt(0, 2);
            if (a == 0) return new Linear() {A = Utils.GetRandom(-3, 5), B = Utils.GetRandom(-3, 5) };
            else return new Square() {A = Utils.GetRandom(-3, 5), B = Utils.GetRandom(-3, 5), C =Utils.GetRandom(-3, 5)} ;
        }
    }
}
