﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    // класс для квадратных уравнений 
    class Square : Root, ISolver {
        // коэффициент уравнения
        protected double c;
        public double C {
            get => c;
            set => c = value;
        } // C

        // первый корень
        public double X1 { get => x; } // X1

        // второй корень
        protected double x2;
        public double X2 { get => x2; } // X2

        // дискриминант
        public double D { get => (b*b) - (4 * a * c); } // D

        // метод для определения наличия решения уравнения
        public bool HasSolve() => D >= 0;

        public void Show() {
            Console.WriteLine($"{this};  ");
            Console.WriteLine(HasSolve() ?
                //                     два корня               один корень
                D > 1e-5 ?    $"x1 = {x:f3}; x2 = {x2:f3}" :  $"x = {x:f3}" 
                // корни отсутствуют
                : "Корней нет");
        } // Show

        public void Solve() {
            if (!HasSolve()) throw new Exception($"У уравнения {this} нет корней!");
            if (D < 1e-5) x = -b / 2 * a;
            else {
                x  = (-b - Math.Sqrt(D))/ (2 * a);
                x2 = (-b + Math.Sqrt(D))/ (2 * a);
            } // if
        } // Solve

        // вывод строки таблицы
        public override string ToTableRow(int row) {
            string str = $"│ { row,5} │ { this,-27} │";

            str += HasSolve() ?
                //              два корня                   один корень
                D > 1e-5 ? $" {x,8:f3} │ {x2,8:f3} │"    : $" {x,8:f3} │ {" ",8} │" 
                // корни отсутствуют
                : $" {"     Корней нет",-19} │";
            return str;
        } // ToTableRow

        public override string ToString()  {
            string s1 = b > 0 ? "+" : "-";
            string s2 = c > 0 ? "+" : "-";
            return $"{a:f2}x^2 {s1} {Math.Abs(b):f2}x {s2} {Math.Abs(c):f2} = 0";
        } // ToString

    } // Square
}
