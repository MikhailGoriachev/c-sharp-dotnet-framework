﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Models.Task2;

namespace Задание.Application
{
    /* 
    * Методы для решения задачи 2
    */
    internal partial class App {

        // Начальное формирование массива структур типа Student
        public void StudentsInitialize() {
            Utils.ShowNavBarTask("   Начальное формирование массива структур типа Student");
            _task2.Initialize();
            Console.WriteLine(_task2.Show("Данные сформированы:", 12));
        } // StudentsInitialize

        // Упорядочить массив по фамилиям и инициалам
        public void DemoOrderByName() {
            Utils.ShowNavBarTask("   Упорядочить массив по фамилиям и инициалам");
            _task2.OrderByName();
            Console.WriteLine(_task2.Show("Массив упорядочен по фамилиям и инициалам:", 12));
        } // DemoOrderByName

        // Вывод фамилий и названий групп для всех студентов, имеющих хотя бы одну оценку 2
        public void DemoSelectBadScore() {
            Utils.ShowNavBarTask("   Вывод фамилий и названий групп для всех студентов, имеющих хотя бы одну оценку 2");
            Student[] badScore = _task2.SelectWhereBadScore();
            if (badScore.Length != 0) Console.WriteLine(ArrayStudent.Show("Cтуденты, имеющие хотя бы одну оценку 2:", 12, badScore));
            else Utils.WriteXY(13, 4, "Cтуденты, имеющие хотя бы одну оценку 2 отсутствуют!", ConsoleColor.Yellow);
        } // DemoSelectBadScore

        // Вывод фамилий и названий групп для всех студентов, имеющих оценки только 4 и 5
        public void DemoSelectGoodScore() {
            Utils.ShowNavBarTask("   Вывод фамилий и названий групп для всех студентов, имеющих оценки только 4 и 5");
            Student[] doogScore = _task2.SelectWhereGoodScore();
            if (doogScore.Length != 0) Console.WriteLine(ArrayStudent.Show("Cтуденты, имеющие оценки только 4 и 5:", 12, doogScore));
            else Utils.WriteXY(13, 4, "Cтуденты, имеющие оценки только 4 и 5 отсутствуют!", ConsoleColor.Yellow);
        } // DemoSelectGoodScore

        // Упорядочить массив по возрастанию среднего балла
        public void DemoOrderByAverageScore() {
            Utils.ShowNavBarTask("   Упорядочить массив по возрастанию среднего балла");
            _task2.OrderByAverageScore();
            Console.WriteLine(_task2.Show("Массив упорядочен по возрастанию среднего балла:", 12));
        } // DemoOrderByName
        
        // Перемешивание массива студентов
        public void DemoShuffle() {
            Utils.ShowNavBarTask("   Перемешивание массива студентов");
            _task2.Shuffle();
            Console.WriteLine(_task2.Show("Массив студентов перемешан:", 12));
        } // DemoOrderByName
          // 
    } // App
}
