﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    abstract class Root {
        // коэффициенты уравнений
        protected double a;
        public double A {
            get => a;
            set => a = value;
        } // A

        protected double b;
        public double B {
            get => b;
            set => b = value;
        } // B

        // неизвестное
        protected double x;

        // Шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}┌───────┬─────────────────────────────┬──────────┬──────────┐\n" +
            $"{spaces}│ N п/п │          Уравнение          │    X1    │    X2    │\n" +
            $"{spaces}├───────┼─────────────────────────────┼──────────┼──────────┤\n";
        } // Header

        // Подвал таблицы, статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└───────┴─────────────────────────────┴──────────┴──────────┘\n";

        // вывод в табличном формате - разный для разных классов
        public abstract string ToTableRow(int row);

    } // Root
}
