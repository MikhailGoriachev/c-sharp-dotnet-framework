﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    class ArrayEquation {
        // уравнения
        private ISolver[] _equations;

        // количество уравнений в массиве по умолчанию
        private const int DefNumber = 20;

        // для статистики:
        private int nLinear;             // количество линейных уравнений
        private int nSquare;             // количество квадратных уравнений
        private int nDecisions;          // количество решений
        private int nDecisionsLinear;    // количество решений линейных уравнений
        private int nDecisionsSquare;    // количество решений квадратных уравнений

        public ArrayEquation() : this(new ISolver[DefNumber]) {
            Initialize();
        } // ArrayEquation

        ArrayEquation(ISolver[] equations) {
            _equations = equations;
        } // ArrayEquation

        public void Initialize(double lo = -10d, double hi = 10d) {
            nLinear = Utils.Random.Next(0, DefNumber);
            nSquare = DefNumber - nLinear;

            for (int i = 0; i < nLinear; i++) 
                _equations[i] = new Linear { A = Utils.GetRandom(lo, hi), B = Utils.GetRandom(lo, hi) };

            for (int i = nLinear; i < DefNumber; i++)
                _equations[i] = new Square { A = Utils.GetRandom(lo, hi), B = Utils.GetRandom(lo, hi), C = Utils.GetRandom(lo, hi) };

            Solve();
            Shuffle();
        } // Initialize

        public void Solve() {
            nDecisions = 0;
            nDecisionsLinear = 0;
            nDecisionsSquare = 0;

            for (int i = 0; i < DefNumber; i++) {
                if (_equations[i].HasSolve()) {
                    _equations[i].Solve();
                    nDecisions++;
                    if (i < nLinear) nDecisionsLinear++;
                    else nDecisionsSquare++;
                } // if
            } // for i
        } // Solve

        public void Shuffle() {
            for (int i = DefNumber - 1; i >= 1; i--) {
                int temp = Utils.Random.Next(i + 1);
                (_equations[i], _equations[temp]) = (_equations[temp], _equations[i]);
            } // for i
        } // Shuffle

        // Вывести данные в консоль
        public string Show(string caption, int indent) =>
            Show(caption, indent, _equations);

        public string ShowStatistics(string caption, int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}{caption}\n" +
            $"{spaces}Общее количество уравнений     : {DefNumber}\n" +
            $"{spaces}Kоличество квадратных уравнений: {nSquare}\n" +
            $"{spaces}Kоличество линейных уравнений  : {nLinear}\n\n" +
            $"{spaces}Общее количество решений               : {nDecisions}\n" +
            $"{spaces}Количество решений квадратных уравнений: {nDecisionsSquare}\n" +
            $"{spaces}Количество решений линейных уравнений  : {nDecisionsLinear}\n";
        } // ShowStatistics

        // Вывести данные массива  в консоль - для вывода 
        // массивов, полученных из отбора
        public static string Show(string caption, int indent, ISolver[] equations) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            StringBuilder sb = new StringBuilder($"\n\n{space}{caption}\n{Root.Header(indent)}");

            // вывод всех элементов массива объектов данных
            int row = 1;
            void OutItem(ISolver v) => sb.Append($"{space}{((Root)v).ToTableRow(row++)}\n");
            Array.ForEach(equations, OutItem);

            // вывод подвала таблицы
            return sb.Append($"{Root.Footer(indent)}\n").ToString();
        } // Show

    } // ArrayEquation
}
