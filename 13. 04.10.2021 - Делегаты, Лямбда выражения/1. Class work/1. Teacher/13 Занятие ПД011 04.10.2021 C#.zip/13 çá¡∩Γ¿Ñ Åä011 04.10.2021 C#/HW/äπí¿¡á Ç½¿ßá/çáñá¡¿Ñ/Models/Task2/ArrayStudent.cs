﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    class ArrayStudent {
        // студенты
        private Student[] _students;

        // количество студентов в массиве по умолчанию
        private const int NStudent = 10;

        public ArrayStudent() : this(new Student[NStudent]) {
            Initialize();
        } // ArrayStudent

        ArrayStudent(Student[] students) {
            _students = students;
        } // ArrayStudent

        public void Initialize() {
            // массив фамилий для получения данных заполнения массива студентов
            string[] surnames = new[] { "Семенов " , "Дунаев " , "Харламова ", "Олегова ", "Янковский ", "Абалкин ", "Абалкин ",
                                        "Романова ", "Воликов ", "Абалкин "  , "Жукова " , "Соколов "  , "Лебедев ", };
            // массив инициалов для получения данных заполнения массива студентов
            string[] initials = new[] { "A.", "Б.", "В.", "Г.", "Д.", "Е.", "Ж.", "З.", "И.", "К.", "Л.", "М.", "Н.", "О.", "П.", "Р.", "С.", "Т.",
                                        "У.", "Ф.", "Х.", "Ц.", "Ч.", "Ш.", "Э.", "Ю.", "Я."};
            // массив групп для получения данных заполнения массива студентов
            string[] groups = new[] { "ДБ014", "ПН012", "РК013", "ГВ019", "ОТ002" };

            for (int i = 0; i < _students.Length; i++)
                _students[i] = new Student(surnames[Utils.Random.Next(surnames.Length - 1)] +
                    initials[Utils.Random.Next(initials.Length - 1)] + initials[Utils.Random.Next(initials.Length - 1)],
                    groups[Utils.Random.Next(groups.Length - 1)]);
        } // Initialize

        // Вывести данные в консоль
        public string Show(string caption, int indent) =>
            Show(caption, indent, _students);

        // Вывести данные массива  в консоль - для вывода 
        // массивов, полученных из отбора
        public static string Show(string caption, int indent, Student[] students) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            StringBuilder sb = new StringBuilder($"\n\n{space}{caption}\n{Student.Header(indent)}");

            // вывод всех элементов массива объектов данных
            int row = 1;
            void OutItem(Student v) => sb.Append($"{space}{v.ToTableRow(row++)}\n");
            Array.ForEach(students, OutItem);

            // вывод подвала таблицы
            return sb.Append($"{Student.Footer(indent)}\n").ToString();
        } // Show
        public void Shuffle() {
            for (int i = _students.Length - 1; i >= 1; i--) {
                int temp = Utils.Random.Next(i + 1);
                (_students[i], _students[temp]) = (_students[temp], _students[i]);
            } // for i
        } // Shuffle

        // выбрать студентов у которых оценки только 4 и 5 
        public Student[] SelectWhereGoodScore() { 
            bool Match(Student s) => s.GoodScore;
            return Array.FindAll(_students, Match);
        } // SelectWhereGoodScore

        // выбрать студентов у которых хотя бы одна оценка 2 
        public Student[] SelectWhereBadScore() {
            bool Match(Student s) => s.BadScore;
            return Array.FindAll(_students, Match);
        } // SelectWhereBadScore

        // сортировка массива студентов по фамилиям и инициалам
        public void OrderByName() => Array.Sort(_students, Student.NameComparer);

        // сортировка массива студентов по возрастанию среднего балла
        public void OrderByAverageScore() => Array.Sort(_students, Student.AverageScoreComparer);
    }
}
