﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task2
{
    struct Student {
        private string _name;  // фамилия и инициалы
        private string _group; // название группы
        private Mark[] _marks; // успеваемость(массив из пяти элементов типа Mark– вложенная структура: название предмета, оценка (short))
                               
        private const int NMarks = 5; // количество элементов типа Mark
        public string Name {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Student: Некорректные фамилия и инициалы!"); _name = value; }
        } // Name

        public string Group {
            get => _group;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Student: Некорректное название группы!"); _group = value; }
        } // Group

        // Средний балл
        public double AverageScore {
            get {
                double sum = 0;
                foreach (Mark item in _marks)
                    sum += item.Score;
                return sum / _marks.Length;
            } // get
        } // AverageScore
        public Student(string name, string group): this() {
            Name = name;
            Group = group;
            Initialize();
        } // Student
        public void Initialize() {
            _marks = new Mark[NMarks] {
                new Mark("Химия", (short)Utils.Random.Next(2, 6)), 
                new Mark("Физика", (short)Utils.Random.Next(4, 6)), 
                new Mark("Русский язык", (short)Utils.Random.Next(4, 6)), 
                new Mark("Латынь", (short)Utils.Random.Next(2, 6)), 
                new Mark("Биология", (short)Utils.Random.Next(3, 6))
            };
        } // Initialize

        // true - оценки только 4 и 5 
        public bool GoodScore {
            get {
                foreach (Mark item in _marks)
                    if (item.Score <= 3) return false;
                return true;
            }
        } // GoodScore

        // true - хотя бы одна оценка 2 
        public bool BadScore {
            get {
                foreach (Mark item in _marks)
                    if (item.Score == 2) return true;
                return false;
            }
        } // BadScore

        // Индексатор. 
        public Mark this[int index] { 
            get {
                if (index < 0 || index >= NMarks)
                    throw new Exception("Student: Попытка обращения за пределы массива!");

                return _marks[index];
            } // Аксессор.

            set {
                if (index < 0 || index >= NMarks)
                    throw new Exception("Student: Попытка обращения за пределы массива!");

                _marks[index] = value;
            } // Мутатор
        }


        // Mark– вложенная структура: название предмета, оценка 
        public struct Mark {
            private string _subject;  // название предмета
            private short _score;       // оценка

            public Mark(string subject, short score): this() {
                Subject = subject;
                Score = score;
            } // Mark

            public string Subject {
                get => _subject;
                set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Mark: Некорректное название предмета!"); _subject = value; }
            } // Subject
            public short Score {
                get => _score;
                set { if (value < 1 || value > 5) throw new Exception("Mark: Некорректное значение оценки!"); _score = value; }
            } // Mark
        } // Mark

        // Шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}┌───────┬────────────────────────┬──────────┬──────────┐\n" +
            $"{spaces}│ N п/п │      Фамилия И.О.      │  Группа  │ Ср. балл │\n" +
            $"{spaces}├───────┼────────────────────────┼──────────┼──────────┤\n";
        } // Header

        // Подвал таблицы, статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└───────┴────────────────────────┴──────────┴──────────┘\n";

        // вывод в табличном формате - разный для разных классов
        public string ToTableRow(int row) =>
            $"│ {row,5} │ {_name,-22} │ {_group, -8} │ {AverageScore,8:f2} │";

        // Компаратор для сортировки по фамилиям и инициалам
        public static int NameComparer(Student s1, Student s2) =>
            s1.Name.CompareTo(s2.Name);

        // Компаратор для сортировки по возрастанию среднего балла
        public static int AverageScoreComparer(Student s1, Student s2) =>
            s1.AverageScore.CompareTo(s2.AverageScore);

    } // Student
}
