﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    // интерфейс для решения линейных и квадратных уравнений
    interface ISolver {
        // метод для решения уравнения
        void Solve();

        // метод для вывода решения в консоль
        void Show();

        // метод для определения наличия решения уравнения
        bool HasSolve();
    } // ISolver
}
