﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание.Models.Task1
{
    // класс для линейных уравнений 
    class Linear : Root, ISolver {

        public double X { get => x; } // X

        public bool HasSolve() => Math.Abs(a) > 1e-5;

        public void Show() {
            Console.Write($"{this};  ");
            Console.WriteLine(HasSolve() ? $"x = {x:f3}" : "Корней нет");
        } // Show

        public void Solve(){
            if (!HasSolve()) throw new Exception($"У уравнения {this} нет корней!");
            x = -b / a;
        } // Solve

        // вывод строки таблицы
        public override string ToTableRow(int row) {
            string str = $"│ { row,5} │ { this,-27} │";

            str += HasSolve()? $" {x,8:f3} │ {" ",8} │" : $" {"     Корней нет", -19} │";

            return str;
        } // ToTableRow
        public override string ToString() {
            string s = b > 0 ? "+" : "-";
            return $"{a:f2}x {s} {Math.Abs(b):f2} = 0";
        } // ToString
    } // Linear
}
