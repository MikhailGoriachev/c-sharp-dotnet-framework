﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction
using Задание.Application;

namespace Задание
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 04.10.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Создать массив из 20 уравнений" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Вывести уравнения и решения" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1. Вычислить и вывести статистику" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Начальное формирование массива структур типа Student" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Вывод фамилий и названий групп для всех студентов, имеющих хотя бы одну оценку 2" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2. Вывод фамилий и названий групп для всех студентов, имеющих оценки только 4 и 5 " },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2. Упорядочить массив по возрастанию среднего балла" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Задача 2. Упорядочить массив по фамилиям и инициалам" },
                new MenuItem { HotKey = ConsoleKey.H, Text = "Задача 2. Перемешивание массива студентов" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 04.10.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Создать массив из 20 уравнений
                        case ConsoleKey.Q:
                            app.EquationsInitialize();
                            break;

                        // Вывести уравнения и решения
                        case ConsoleKey.W:
                            app.EquationsShow();
                            break;

                        // Вычислить и вывести статистику
                        case ConsoleKey.E:
                            app.StatisticsShow();
                            break;

                        // ------------------------------------------------------------

                        // Начальное формирование массива структур типа Student
                        case ConsoleKey.A:
                            app.StudentsInitialize();
                            break;

                        // Вывод фамилий и названий групп для всех студентов, имеющих хотя бы одну оценку 2
                        case ConsoleKey.S:
                            app.DemoSelectBadScore();
                            break;

                        // Вывод фамилий и названий групп для всех студентов, имеющих оценки только 4 и 5
                        case ConsoleKey.D:
                            app.DemoSelectGoodScore();
                            break;

                        // Упорядочить массив по возрастанию среднего балла
                        case ConsoleKey.F:
                            app.DemoOrderByAverageScore();
                            break;

                        // Упорядочить массив по фамилиям и инициалам
                        case ConsoleKey.G:
                            app.DemoOrderByName();
                            break;

                        // Перемешивание массива студентов
                        case ConsoleKey.H:
                            app.DemoShuffle();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
