﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Models.Task1;

namespace Задание.Application
{
    /* 
    * Методы для решения задачи 1
    */
    internal partial class App {

        // Создать массив из 20 уравнений
        public void EquationsInitialize() {
            Utils.ShowNavBarTask("   Создать массив из 20 уравнений");

            _task1.Initialize();
            Console.WriteLine(_task1.Show("Данные сформированы:", 12));
        } // EquationsInitialize

        // Вывести уравнения и решения
        public void EquationsShow() {
            Utils.ShowNavBarTask("   Вывести уравнения и решения");
            Console.WriteLine(_task1.Show("Массив уравнений:", 12));
        } // EquationsShow


        // Вычислить и вывести статистику
        public void StatisticsShow() {
            Utils.ShowNavBarTask("   Вычислить и вывести статистику");
            Console.WriteLine(_task1.Show("Массив уравнений:", 12));
            Console.WriteLine(_task1.ShowStatistics("Статистика:", 12));
        } // StatisticsShow

    } // App
}
