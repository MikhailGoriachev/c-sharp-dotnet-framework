﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW12.Task1
{
	class Square : Root, ISolver
	{
		// Коэффициент c
		public double C { get; private set; }

		// Второй корень 
		public double X2 { get; private set; }

		// Дискриминант
		public double D => B * B - 4 * A * C;

		// Конструкторы
		public Square() : this(1, 2, 3) { }

		public Square(double a, double b, double c) : base(a, b)
		{ 
			C = c; 
		}

		// Фабричный метод генерации
		public static Square Generate() {
			double a;
			// Избегаем генерации первого коэффициента равного(близкого) нулю,
			// для осуществления условия квадратного уравнения
			do a = Utilities.GenerateDouble(minCoeffValue, maxCoeffValue);
			while (Math.Abs(a) < Math.E);
			
			return new Square
			{
				A = a,
				B = Utilities.GenerateDouble(minCoeffValue, maxCoeffValue),
				C = Utilities.GenerateDouble(minCoeffValue, maxCoeffValue)
			};
		}

		// Проверка на наличие решения
		public bool HasSolve() => !(D < 0);

		// Решение уравнения
		public void Solve()
		{
			if (!HasSolve())
				RootsCount = 0;
			else if (Math.Abs(D) < Math.E) { 
				RootsCount = 1;
				X = X2 = -(B / (2 * A));
			}
			else if(D > 0)
			{
				RootsCount = 2;
				X = (-B + Math.Sqrt(D)) / (2 * A);
				X2 = (-B - Math.Sqrt(D)) / (2 * A);
			}
		}

		// Строковое представление уравнения
		public override string ToString() => $"    Квадратное уравнение: {A,5:f2}*x^2 + {B,5:f2}*x + {C,5:f2} = 0";

		// Вывод информации о решении уравнения
		public void Show()
		{
			string str = "    ";

			Console.WriteLine(ToString());

			if (RootsCount == 0)
				str = str + "Решение: нет корней";
			else if (RootsCount == 1) { 
				str = str + $"Решение: x1 =  {X,5:f2}";
			}
			else str = str + $"Решение: x1 = {X,5:f2}, x2 = {X2,5:f2}";

			Console.WriteLine(str);
		}

	}
}
