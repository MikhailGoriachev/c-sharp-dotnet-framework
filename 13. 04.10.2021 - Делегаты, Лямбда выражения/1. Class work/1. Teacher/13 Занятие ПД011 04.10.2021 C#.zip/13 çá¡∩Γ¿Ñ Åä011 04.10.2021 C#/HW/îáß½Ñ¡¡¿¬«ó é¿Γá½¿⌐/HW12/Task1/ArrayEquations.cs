﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW12.Task1
{
	class ArrayEquations
	{
		// Количество уравнений по заданию
		private const int n = 20;

		// Массив уравнений
		Root[] _roots;

		// Количество квадратных уравнений
		private int SquareNumber { get; set; }
		
		// Количество линейных уравнений
		private int LinearNumber { get; set; }

		// Количество решений квадратных уравнений
		private int SquareSolutionsNumber { get; set; }

		// Количество решений линейных уравнений
		private int LinearSolutionsNumber { get; set; }


		// Конструкторы
		public ArrayEquations() : this(new Root[n])
		{
			Initialize();
		}

		public ArrayEquations(Root[] roots) => _roots = roots;

		// Инициализация
		public void Initialize()
		{
			for (int i = 0; i < n; i++)
			{
				if (Utilities.GenerateInt(1, 3) == 1)
					_roots[i] = Square.Generate();
				else _roots[i] = Linear.Generate();
			}
		}

		public void SolveEquations()
		{
			for (int i = 0; i < n; i++)
			{
				ISolver it = _roots[i] is Linear ? (Linear)_roots[i] : (Square)_roots[i];
				it.Solve();
			}
		}


		// Вывод массива уравнений c решениями
		public void ShowEquations(int indent)
		{
			SolveEquations();

			void Out(Root item)
			{
				ISolver it = item is Linear ? (Linear)item : (Square)item;
				it.Show();
				Console.WriteLine();
			}
			Array.ForEach(_roots, Out);
		}


		// Вывести статистику - общее количество каждого типа уравнений
		public void ShowNumbersOfEquations(int indent)
		{
			string spaces = " ".PadRight(indent);
			CountNumbersOfEquations();
			Console.WriteLine($"{spaces}Количество линейных уравнений: {LinearNumber}." +
				$" Количество квадратных уравнений: {SquareNumber}");
		}

		// Вывести статистику - общее количество решений каждого типа уравнений
		public void ShowNumbersOfEquationsSolutions(int indent)
		{
			string spaces = " ".PadRight(indent);
			CountLinearSolutions();
			CountSquareSolutions();
			Console.WriteLine($"{spaces}Количество решений линейных уравнений: {LinearSolutionsNumber}." +
			                  $" Количество решений квадратных уравнений: {SquareSolutionsNumber}");
		}

		// Посчитать общее количество уравнений
		private void CountNumbersOfEquations()
		{
			foreach (var item in _roots)
			{
				if (item is Linear)
					LinearNumber++;
				else if (item is Square)
					SquareNumber++;
			}
		}

		// Количество решений линейных уравнений
		private void CountLinearSolutions()
		{
			foreach (var item in _roots)
			{
				if (item is Linear)
				{
					ISolver it = (Linear)item;
					if (it.HasSolve()) LinearSolutionsNumber++;
				}
			}
		}

		// Количество решений квадратных уравнений
		private void CountSquareSolutions()
		{
			foreach (var item in _roots)
			{
				if (item is Square)
				{
					ISolver it = (Square)item;
					if (it.HasSolve()) SquareSolutionsNumber++;
				}
			}
		}
	}
}
