﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW12.Task2
{
	class Class
	{
		// Количество студентов по заданию
		private const int nStudents = 10;

		// Массив студентов
		private Student[] _students;


		public Class() : this(new Student[nStudents]) => Initialize();

		public Class(Student[] students)
		{
			_students = students;
		}

		public void Initialize()
		{
			_students = new Student[nStudents];
			for (int i = 0; i < _students.Length; i++)
			{
				Student gen;
				do
				{
					gen = Student.Generate();
				} while (Array.Find(_students, student => student.Name == gen.Name).Name != null);
				_students[i] = gen;
			}
		}

		public void Show(string title)
		{

			Console.WriteLine($"{Utilities.spaces}{title}\n");
			Console.Write(Student.Header(Utilities.indent));
			
			int row = 1;
			
			foreach (var stud in _students)
				Console.WriteLine(stud.ToTableRow(row, Utilities.indent));
			
			Console.Write(Student.Footer(Utilities.indent));
		}

		public Student[] SelectStudentsByRate2()
		{
			bool RangePredicate(Student st)
			{
				foreach (var subj in Student.Subjects)
					if (st[subj] == 2)
						return true;
				return false;
			}
			return Array.FindAll(_students, RangePredicate);
		}

		public Student[] SelectStudentsByRate4And5()
		{
			bool RangePredicate(Student st)
			{
				foreach (var subj in Student.Subjects)
					if (st[subj] < 4)
						return false;
				return true;
			}
			return Array.FindAll(_students, RangePredicate);
		}

		public void OrderByPerformance() => Array.Sort(_students, Student.AvgRateAscendComparer);
		public void OrderByName() => Array.Sort(_students, Student.AvgNameComparer);


		public void Shuffle()
		{
			int n = _students.Length;
			for (int i = 0; i < (n - 1); i++)
			{
				int r = i + Utilities._rand.Next(n - i);
				(_students[r], _students[i]) = (_students[i], _students[r]);
			}
		}
	}
}
