﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW12.Task1
{
	interface ISolver
	{
		void Solve();

		void Show();

		bool HasSolve();
	}
}
