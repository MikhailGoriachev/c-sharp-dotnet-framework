﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW12.Task2
{
	struct Student
	{
		public static readonly string[] Subjects = new string[] { "Алгебра", "Геометрия", "Русский язык", "Информатика", "Физкультура" };

		// Фамилия и инициалы;
		private string _name;
		public string Name
		{
			get => _name;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new ArgumentNullException("Не указана фамилия и инициалы");
				_name = value;
			}
		}

		// Название группы;
		private string _group;
		public string Group
		{
			get => _group;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new ArgumentNullException("Не указана фамилия и инициалы");
				_group = value;
			}
		}

		// Mark– вложенная структура
		internal struct Mark
		{
			// Название предмета
			private string _subject;

			public string Subject
			{
				get => _subject;
				set
				{
					if (string.IsNullOrWhiteSpace(value))
						throw new ArgumentNullException("Не указано название предмета");
					_subject = value;
				}
			}

			private short _rate;

			public short Rate
			{
				get => _rate;
				set
				{
					if(value < 0)
						throw new ArgumentNullException("Оценка не может быть отрицательной");
					_rate = value;
				}
			}
		}

		// Количество оценок предметов
		private const int nMarks = 5;

		// Успеваемость(массив из пяти элементов типа Mark)
		public Mark[] _performance;
		
		
		// Индексатор для массива оценок Mark – вложенная структура: название предмета, оценка (short)
		public short this[string subj]
		{
			get
			{
				bool findSubject(Mark mark) => mark.Subject == subj;
				var find = Array.Find(_performance, findSubject);
				if (find.Subject == null)
					throw new ArgumentOutOfRangeException(nameof(subj), "Указанное название предмета не найдено");
				else return find.Rate;
			}
			set
			{
				bool findSubject(Mark mark) => mark.Subject == subj;
				var find = Array.Find(_performance, findSubject);
				if (find.Subject == null)
					throw new ArgumentOutOfRangeException(nameof(subj), "Указанное название предмета не найдено");
				else find.Rate = value;
			}
		}

		// Средний балл
		public double AverageRate()
		{
			int sum = 0;
			foreach (var item in _performance)
				sum += item.Rate;
			return (double)sum / nMarks;
		}

		// Компаратор по возрастанию среднего бала
		public static int AvgRateAscendComparer(Student st1, Student st2) => 
			st1.AverageRate().CompareTo(st2.AverageRate());

		// Компаратор по возрастанию среднего бала
		public static int AvgNameComparer(Student st1, Student st2) =>
			st1.Name.CompareTo(st2.Name);

		// Фабричный метод генерации объекта
		public static Student Generate()
		{
			string[] groups = { "Группа 1", "Группа 2","Группа 3","Группа 4","Группа 5"};
			string[] names =
			{
				"Гущин Ф. А.",
				"Симонов Н.А.",
				"Молчанов А.А.",
				"Емельянов Ц.И.",
				"Беляков К.В.",
				"Доронин У.И.",
				"Несвитайло Д.П.",
				"Кондратьев М.Ю.",
				"Симонов Ч.В.",
				"Тягай С.В.",
				"Василенко В.Ю.",
				"Дзюба Д.Д.",
				"Константинов Д.П.",
				"Лукин А.В.",
				"Марков Й.В.",
				"Несвитайло Р.В.",
				"Титов П.Ф.",
				"Анисимов Е.В.",
				"Миклашевский Д.В.",
				"Зыков Э.Б.",
				"Комаров С.Л.",
				"Рогов Э.Э.",
				"Королёв О.В.",
				"Воронцов И.А.",
				"Аксёнов Х.Л.",
				"Легойда Р.М.",
				"Одинцов З.Б.",
				"Токар К.Б.",
				"Сысоев П.Б.",
				"Самсонов В.В."
			};

			string group = groups[Utilities.GenerateInt(0, groups.Length)];
			string name = names[Utilities.GenerateInt(0, names.Length)];

			Mark[] marks = new Mark[nMarks];

			// Генерация оценок с моделированием рассредотачиванием случайностей
			for (int i = 0; i < marks.Length; i++)
			{
				marks[i].Subject = Subjects[i];

				// 1 к 10 на генерацию 2 балла
				if (Utilities.GenerateInt(1, 10) == 1){
					marks[i].Rate = 2;
					continue;
				}
				// 1 к 8 на генерацию 3 балла
				if (Utilities.GenerateInt(1, 8) == 1)
				{
					marks[i].Rate = 3;
					continue;
				}
				// 1 к 3 на генерацию 4 балла
				if (Utilities.GenerateInt(1, 3) == 1)
				{
					marks[i].Rate = 4;
					continue;
				}
				// 1 к 2 на генерацию 5 баллов
				if (Utilities.GenerateInt(1, 2) == 1)
				{
					marks[i].Rate = 5;
					continue;
				}
				// Если все проверки провалились - случайный балл
				marks[i].Rate = (short)Utilities.GenerateInt(2, 5);
			}

			return new Student() {Name = name, Group = group, _performance = marks};
		}

		// Строковое представление
		public override string ToString() => $"Фамилия И.О: {Name}, группа: {Group}.";

		// Шапка таблицы
		public static string Header(int indent)
		{
			string spaces = " ".PadRight(indent);

			return $"{spaces}╔═════════════════════╦══════════╦══════════════╗\n" +
			       $"{spaces}║     Фамилия И.О     ║  Группа  ║ Средний балл ║\n" +
			       $"{spaces}╠═════════════════════╬══════════╬══════════════╣\n";
		}


		// В табличную строку
		public string ToTableRow(int n, int indent)
		{
			string spaces = " ".PadRight(indent);
			return $"{spaces}║ {Name,-19} ║ {Group,-8} ║ {AverageRate(),12:f1} ║";
		}

		// Подвал таблицы
		public static string Footer(int indent)
		{
			string spaces = " ".PadRight(indent);

			return $"{spaces}╚═════════════════════╩══════════╩══════════════╝\n";
		}

		// Подробная информация по студенту
		public string ShowFullStudentsInfo(int indent)
		{
			string spaces = " ".PadRight(indent);
			
			string str = spaces + ToString() + "\n";
			
			foreach (var mark in _performance)
				str = str + $"{spaces}Предмет: {mark.Subject, -15} Оценка: {mark.Rate}\n";
			
			return str;
		}

	}
}
