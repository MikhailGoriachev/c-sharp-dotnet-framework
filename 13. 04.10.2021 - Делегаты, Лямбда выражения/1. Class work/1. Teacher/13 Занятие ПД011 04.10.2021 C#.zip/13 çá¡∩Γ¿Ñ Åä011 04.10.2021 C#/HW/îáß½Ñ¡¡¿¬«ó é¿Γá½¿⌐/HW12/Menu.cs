﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

namespace HW12
{
	// Класс работы навигационного меню
	class Menu
	{
		// Статический класс набора цветов меню
		public static class Palette
		{
			public static Utilities.ColorSet OrdinaryColor { get; set; }
				= new Utilities.ColorSet() { Foreground = ConsoleColor.Green, Background = ConsoleColor.Black };

			public static Utilities.ColorSet HighlightedColor { get; set; }
				= new Utilities.ColorSet() { Foreground = ConsoleColor.Black, Background = ConsoleColor.Green };
		}

		// Класс пункта меню
		public class MenuItem
		{
			public Action Callback { get; set; }
			public string Text { get; set; }

			public MenuItem(string text, Action callback)
			{
				Text = text;
				Callback = callback;
			}


			public MenuItem(string text)
			{
				Text = text;
			}

		}

		// Стартовая позиция вывода меню
		private Point MenuPosition { get; set; }
		// Массив объектов пунктов меню
		private MenuItem[] Items { get; set; }
		// Заголовок меню
		private string Title { get; set; }

		private int _maxLength;                     // Максимальная длина пункта меню
		private int _current;                       // Номер текущего выделенного пункта меню
		private int _previous;                      // Номер прошлого выделенного пункта меню
		private int _nItems;                        // Количество пунктов меню
		private static bool returnedFromSubMenu;    // 

		// Конструктор создания меню
		public Menu(MenuItem[] items, Point menuPosition, string title)
		{
			Items = items;
			MenuPosition = menuPosition;
			_previous = 1;
			_current = 1;
			_nItems = Items.Length;
			_maxLength = Items.Max(x => x.Text.Length);
			Title = title;
		}


		// Цикл работы меню
		public void Run(bool isSubMenu = false)
		{
			// Первичный вывод меню
			Console.Clear();
			Console.SetCursorPosition(MenuPosition.X, MenuPosition.Y);
			Console.CursorVisible = false;
			ShowMenu();

			_current = _previous;
			ChangeSelection(_previous, _current);

			ConsoleKeyInfo key;
			do
			{
				// Ожидание нажатия клавиши
				while (true)
				{
					if (Console.KeyAvailable)
					{
						key = Console.ReadKey();
						break;
					}
				}

				switch (key.Key)
				{
					case ConsoleKey.UpArrow:

						_previous = _current;
						_current = _current > 1 ? --_current : _nItems;
						ChangeSelection(_previous, _current);
						break;

					case ConsoleKey.DownArrow:

						_previous = _current;
						_current = _current < _nItems ? ++_current : 1;
						ChangeSelection(_previous, _current);
						break;

					case ConsoleKey.Enter:

						if (_current == _nItems)
						{
							returnedFromSubMenu = isSubMenu;
							_current = 0;
							break;
						}
						Console.Clear();

						try
						{
							Items[_current - 1].Callback();
						}
						catch (Exception ex)
						{
							Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
						}

						if (returnedFromSubMenu)
							returnedFromSubMenu = false;
						else
							Console.ReadKey();


						Console.Clear();
						ShowMenu();
						ChangeSelection(_previous, _current);
						break;

					case ConsoleKey.Escape:
						_current = 0;
						returnedFromSubMenu = isSubMenu;
						break;
				}
			} while (_current != 0);
			Console.Clear();

		}

		// Вывод меню
		public void ShowMenu()
		{
			Utilities.ColorSet curColors = new Utilities.ColorSet(true);

			Palette.OrdinaryColor.SetToConsole();

			Console.SetCursorPosition(MenuPosition.X, MenuPosition.Y);

			Console.Write($"{Title}\n\n");

			foreach (var menuItem in Items)
			{
				Console.SetCursorPosition(MenuPosition.X, Console.CursorTop);
				Console.WriteLine($"{menuItem.Text.PadRight(_maxLength)}");
			}

			curColors.SetToConsole();
		}

		// Смена выделения пункта меню
		public void ChangeSelection(int prev, int cur)
		{
			Utilities.ColorSet curColors = new Utilities.ColorSet(true);

			Console.SetCursorPosition(MenuPosition.X, MenuPosition.Y + prev + 1);
			Palette.OrdinaryColor.SetToConsole();
			Console.Write($"{Items[prev - 1].Text.PadRight(_maxLength)}");

			Console.SetCursorPosition(MenuPosition.X, MenuPosition.Y + cur + 1);
			Palette.HighlightedColor.SetToConsole();
			Console.Write($"{Items[cur - 1].Text.PadRight(_maxLength)}");

			curColors.SetToConsole();
		}


	}
}
