﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW12.Task1
{
	class Linear : Root, ISolver
	{
		public Linear() : this(1, 2) {}

		public Linear(double a, double b) :base(a, b){}

		// Фабричный метод генерации
		public static Linear Generate() =>
			new Linear
			{
				A = Utilities.GenerateDouble(minCoeffValue, maxCoeffValue),
				B = Utilities.GenerateDouble(minCoeffValue, maxCoeffValue)
			};

		// Проверка на наличие решения
		public bool HasSolve() => !(Math.Abs(A) < Math.E && Math.Abs(B) > Math.E);

		// Решение уравнения
		public void Solve()
		{
			if (!HasSolve())
				RootsCount = 0;
			else if (Math.Abs(A) < Math.E && Math.Abs(B) < Math.E)
				RootsCount = -1;			
			else {
				RootsCount = 1;
				X = B / A;
			}
		}

		// Строковое представление уравнения
		public override string ToString() => $"    Линейное уравнение: {A,5:f2}*x+{B,5:f2}=0";
		

		// Вывод информации о решении уравнения
		public void Show()
		{
			string str = "    ";

			Console.WriteLine(ToString());

			if (RootsCount == 0)
				str = str + "Решение: нет корней";
			else if(RootsCount == -1)
				str = str + "Решение: бесконечно много корней";
			else str = str + $"Решение: x = {X,5:f2}";

			Console.WriteLine(str); 
		}
	}
}
