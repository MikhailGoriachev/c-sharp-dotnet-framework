﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW12.Task1;
using HW12.Task2;

namespace HW12
{
	internal partial class App
	{
		private int indent = 4;

		private Menu _mainMenu;
		private Menu _subMenu1;
		private Menu _subMenu2;

		private ArrayEquations _equations;
		private Class _class;
		public App() : this(new ArrayEquations(), new Class())
		{}

		public App(ArrayEquations equations, Class newClass)
		{
			_equations = equations;
			_class = newClass;
			InitMenu();
		}

		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem("Задание 1", MainMenuItem1),
					new Menu.MenuItem("Задание 2", MainMenuItem2),
					new Menu.MenuItem("Выход")
				}, new Point(5, 5),
				"Меню приложения");

			// Подменю - первое задание
			_subMenu1 = new Menu(new[]
				{
					new Menu.MenuItem("Вывод списка уравнений", Task1MenuItem1),
					new Menu.MenuItem("Статистика о количестве уравнений", Task1MenuItem2),
					new Menu.MenuItem("Статистика о количестве решений уравнений", Task1MenuItem3),
					new Menu.MenuItem("Назад")
				}, new Point(5, 5),
				"Задание 1");

			// Подменю - второе задание
			_subMenu2 = new Menu(new[]
				{
					new Menu.MenuItem("Заполнение данными массива из десяти структур типа Student", Task2MenuItem1),
					new Menu.MenuItem("Вывести фамилии и названия групп студентов, имеющих хотя бы одну оценку 2", Task2MenuItem2),
					new Menu.MenuItem("Вывести фамилии и названия групп студентов, имеющих только оценки 4 и 5", Task2MenuItem3),
					new Menu.MenuItem("Упорядочивание массива по возрастанию среднего балла", Task2MenuItem4),
					new Menu.MenuItem("Упорядочивание массива по фамилиям и инициалам", Task2MenuItem5),
					new Menu.MenuItem("Перемешивание массива студентов", Task2MenuItem6),
					new Menu.MenuItem("Назад")
				}, new Point(5, 5),
				"Задание 2");
			
		}
		
		public void Run() =>_mainMenu.Run();
		private void MainMenuItem1() => _subMenu1.Run(true);
		private void MainMenuItem2() => _subMenu2.Run(true);
		}
}
