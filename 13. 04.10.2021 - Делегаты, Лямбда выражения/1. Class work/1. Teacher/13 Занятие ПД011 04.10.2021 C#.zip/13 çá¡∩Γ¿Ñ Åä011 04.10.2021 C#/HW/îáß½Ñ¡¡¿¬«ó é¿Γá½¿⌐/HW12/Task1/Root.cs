﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW12.Task1
{
	// Базовый абстрактный класс уравнения

	/*
	 * Табличный вывод  не реализован, т.к. по ТЗ сказано "void Show() для вывода решения в консоль",
	 * который наследуется от интерфейса.
	 */
	abstract class Root
	{
		// Границы для генерации значений коэффициентов
		public static double minCoeffValue = -50;
		public static double maxCoeffValue = 50;

		// Коэффициент a
		public double A { get; protected set; }

		// Коэффициент b
		public double B { get; protected set; }

		// Переменная x
		public double X { get; protected set; }

		// Количество корней
		public int RootsCount { get; protected set; }

		// Базовый конструктор
		protected Root(double a, double b)
		{
			A = a;
			B = b;
		}

		// Строковое представление
		public override string ToString() => $"a:{A} b{B}: x:{X} ";
	}
}
