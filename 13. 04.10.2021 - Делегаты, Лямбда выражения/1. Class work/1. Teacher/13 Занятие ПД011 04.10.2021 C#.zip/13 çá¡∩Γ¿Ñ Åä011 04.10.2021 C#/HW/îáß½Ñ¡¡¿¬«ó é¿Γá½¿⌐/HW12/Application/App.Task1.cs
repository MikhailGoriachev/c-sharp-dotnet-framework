﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace HW12
{
	internal partial class App
	{
		private void Task1MenuItem1()
		{
			Utilities.ShowNavBar("    Вывод списка уравнений");
			
			Console.WriteLine("\n");
			_equations.ShowEquations(indent);
		}

		private void Task1MenuItem2()
		{
			Utilities.ShowNavBar("   Статистика о количестве уравнений");

			Console.WriteLine("\n");
			_equations.ShowNumbersOfEquations(indent);
		}

		private void Task1MenuItem3()
		{
			Utilities.ShowNavBar("    Статистика о количестве решений уравнений");

			Console.WriteLine("\n");
			_equations.ShowNumbersOfEquationsSolutions(indent);
		}
	}
}
