﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW12
{
	internal partial class App
	{
		private void Task2MenuItem1()
		{
			Utilities.ShowNavBar("    Заполнение данными массива из десяти структур типа Student");
			Utilities.NewLines(2);
			_class.Initialize();
			_class.Show("Список студентов:");
		}

		private void Task2MenuItem2()
		{
			Utilities.ShowNavBar("    Вывести фамилии и названия групп студентов, имеющих хотя бы одну оценку 2");
			Utilities.NewLines(2);

			var students = _class.SelectStudentsByRate2();
			if(students.Length == 0) Console.WriteLine($"{Utilities.spaces}Остутствуют студенты с данным критерием");
			else Array.ForEach(students, st => Console.WriteLine(st.ShowFullStudentsInfo(Utilities.indent)));
		}

		private void Task2MenuItem3()
		{
			Utilities.ShowNavBar("    Вывести фамилии и названия групп студентов, имеющих только оценки 4 и 5");
			Utilities.NewLines(2);

			var students = _class.SelectStudentsByRate4And5();

			if (students.Length == 0) Console.WriteLine($"{Utilities.spaces}Остутствуют студенты с данным критерием");
			else Array.ForEach(students, st => Console.WriteLine(st.ShowFullStudentsInfo(Utilities.indent)));
		}
		private void Task2MenuItem4()
		{
			Utilities.ShowNavBar("    Упорядочивание массива по возрастанию среднего балла");
			Utilities.NewLines(2);
			_class.OrderByPerformance();
			_class.Show("Список студентов, упорядоченный по возрастанию среднего балла:");

		}


		private void Task2MenuItem5()
		{
			Utilities.ShowNavBar("    Упорядочивание массива по фамилиям и инициалам");
			Utilities.NewLines(2);
			_class.OrderByName();
			_class.Show("Список студентов, упорядоченный по фамилиям и инициалам:");
		}


		private void Task2MenuItem6()
		{
			Utilities.ShowNavBar("    Перемешивание массива студентов");
			Utilities.NewLines(2);

			_class.Shuffle();
			_class.Show("Список студентов перемешан:");
		}
	}
}