﻿using InterfacesStructures.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesStructures.Application
{
    internal partial class App
    {
        // Формирование массива уравнений для решения
        public void GenerateEquations() {
            Utils.ShowNavBarTask("  Задача 1. Формирование массива уравнений для решения");

            _task1Controller.Initialize();
            _task1Controller.Show("\n\n\n\n\tМассив уравнений для решения");
        } // GenerateEquations

        // Вывод массива решаемых уравнений
        public void ShowEquations() {
            Utils.ShowNavBarTask("  Задача 1. Вывод массива решаемых уравнений");

            _task1Controller.Show("\n\n\n\n\tМассив уравнений для решения");
        } // ShowEquations

        // Решение массива уравнений, отчет по решениям
        public void SolveEquations() {
            Utils.ShowNavBarTask("  Задача 1. Решение массива уравнений, отчет по решениям");
            
            // решение уравнений из массива
            _task1Controller.Solve();

            // вывод решения массива уравнения
            _task1Controller.ShowSolve("\n\tМассив решенных уравнений, статистика решений");
        } // SolveEquations
    } // class App
}
