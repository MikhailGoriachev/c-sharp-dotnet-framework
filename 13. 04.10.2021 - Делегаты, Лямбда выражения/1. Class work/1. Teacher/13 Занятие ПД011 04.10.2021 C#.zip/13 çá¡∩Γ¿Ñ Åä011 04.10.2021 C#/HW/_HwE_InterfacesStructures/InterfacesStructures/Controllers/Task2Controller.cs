﻿using InterfacesStructures.Helpers;
using InterfacesStructures.Models.Task2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesStructures.Controllers
{
    // Массив студентов и его обработки
    internal class Task2Controller
    {
        // контейнер данных
        private Student[] _students;


        public Task2Controller():this(10) {}
        
        public Task2Controller(int n) {
            _students = new Student[n];
            Initialize();
        } // Task2Controller

        public Task2Controller(Student[] students) {
            _students = students;
        } // Task2Controller


        #region Задача 2 - работа со структурами
        // Решение задачи 2

        // Заполнение массива студентов
        public void Initialize() {
            for (int i = 0; i < _students.Length; i++) {
                _students[i] = Student.Generate();
            } // for i
        } // Initialize

        // вывод заголовка и массива студентов, выводим только фамилию
        // студента и название группы
        public static void Show(string title, Student[] students) {
            Console.WriteLine($"{title}");

            if (students.Length == 0) {
                Console.WriteLine("\n\tНет таких студентов\n\n\n");
                return;
            } // if

            // При выводе шапки таблицы заменим крайние правые символы-коннекторы на символы-терминаторы 
            Console.WriteLine(
                $"\t{Student.BriefTop.Substring(0, Student.BriefTop.Length - 1) + "┐"}\n\t" +
                $"{Student.BriefHead.Substring(0, Student.BriefHead.Length - 1) + "│"}\n\t" +
                $"{Student.BriefMiddle.Substring(0, Student.BriefMiddle.Length - 1) + "┤"}");
            
            // перебор массива студентов и вывод
            for (int i = 0; i < students.Length; ++i) {
                Console.WriteLine($"\t\t│ {i + 1,3} │{students[i].ToBriefTableRow()}");
            } // for i

            Console.WriteLine(
                $"\t{Student.BriefBottom.Substring(0, Student.BriefBottom.Length - 1) + "┘"}\n\n\n");
        } // Show

        // вывод заголовка и полной информации о каждом студенте
        public void DetailShow(string title) {
            Console.WriteLine($"{title}\n{Student.DetailTop}\n{Student.DetailHead}\n{Student.DetailMiddle}");

            // перебор массива студентов и вывод
            for (int i = 0; i < _students.Length; i++) {
                Console.WriteLine($"\t│ {i + 1,3} │{_students[i].ToDetailTableRow()}");
            } // for i

            Console.WriteLine($"{Student.DetailBottom}\n\n\n");
        } // DetailShow

        // вывод заголовка, краткой информации о каждом студенте и среднего балла
        public void AvgGradeShow(string title) {
            // формирование разделителей для таблицы
            string line1 = $"{Student.BriefTop}──────────┐";
            string line2 = $"{Student.BriefMiddle}──────────┤";
            string line3 = $"{Student.BriefBottom}──────────┘";

            Console.WriteLine($"{title}\n{line1}\n{Student.BriefHead} Ср. балл │\n{line2}");

            // перебор массива студентов и вывод
            for (int i = 0; i < _students.Length; i++) {
                double avg = _students[i].AvgGrade();  // вычисление среднего балла
                Console.WriteLine($"\t│ {i + 1,3} │{_students[i].ToBriefTableRow()} {avg,8:F2} │");
            } // for i

            Console.WriteLine($"{line3}\n\n");
        } // AvgGradeShow

        // выборка студентов, имеющих хотя бы одну оценку grade
        public Student[] SelectUnderperformingStudents(short grade) {
            // предикат поиска студента, у которого сработает предикат на заданную оценку
            bool HasGrade(Student student) => student.HasGrade(grade);

            return Array.FindAll(_students, HasGrade);
        } // SelectUnderperformingStudents

        // вывод на экран фамилий и названий групп для всех студентов, имеющих
        // оценки 4 и 5 (если таких студентов нет, вывести соответствующее
        // сообщение)
        public Student[] SelectSuccessfulStudents(int grade1, int grade2) {
            // предикат поиска студента, у которого сработает предикат на равенство
            // оценки значению grade1 или значению grade2 
            bool HasOnly(Student student) => student.HasOnly(grade1, grade2);

            return Array.FindAll(_students, HasOnly);
        } // SelectSuccessfulStudents

        // упорядочивание массива по возрастанию среднего балла
        public void OrderByAvgGrade() =>
            Array.Sort(_students, Student.AvgGradeComarer);

        // упорядочивание массива по фамилиям и инициалам
        public void OrderBySurname() =>
            Array.Sort(_students, Student.FullnameComparer);


        // перемешивание массива студентов по алгоритму "Тасование Фишера-Йетса"
        // https://vscode.ru/prog-lessons/kak-peremeshat-massiv-ili-spisok.html
        public void Shuffle() {
            // просматриваем массив с конца
            for (int i = _students.Length - 1; i >= 1; i--) {

                // определяем элемент, с которым меням элемент с индексами i
                int j = Utils.Random.Next(0, i + 1);  // фактически генерится 0, ..., i

                // меняем местами элементы массива при помощи кортежа
                (_students[i], _students[j]) = (_students[j], _students[i]);
            } // for i
        } // Shuffle
        #endregion        
    } // class Task2Controller
}
