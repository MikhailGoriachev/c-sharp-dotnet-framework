﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesStructures.Models.Task1
{
    // Класс для решения линейных уравнений
    internal class Linear: Root, ISolver
    {
        // реализация метода интерфейса - решение уравнения
        public void Solve() =>
            X1 = HasSolve() ? -B / A : double.NaN;

        // реализация метода интерфейса - вывод параметров
        // уравнения и результатов решения
        public void Show() {
            string tableRow =
                // $"│ Линейное      │ {A,8:f3} {B,8:f3}          │ " +
                $"{this}{(HasSolve() ? $"{X1, 8:f3}" : "   нет решения"),-20} │";
            Console.Write(tableRow);
        } // Show

        // реализация метода интерфейса - проверка
        // наличия корня уравнения
        public bool HasSolve() => !A.Equals(0d) && !B.Equals(0d);

        public override string ToString() => $"│ Линейное      │ {A,8:f3} {B,8:f3}          │ "; 
    } // class Linear
}
