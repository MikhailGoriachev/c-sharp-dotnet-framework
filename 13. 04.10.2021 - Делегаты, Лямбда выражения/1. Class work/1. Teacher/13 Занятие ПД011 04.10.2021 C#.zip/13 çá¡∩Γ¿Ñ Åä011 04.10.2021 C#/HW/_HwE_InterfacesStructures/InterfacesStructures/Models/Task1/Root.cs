﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesStructures.Models.Task1
{
    // Базовый абстрактный класс Root для иерархии классов решения уравнений
    internal abstract class Root
    {
        // коэффициенты уравнения A, B определены в базовом классе
        public double A { get; set; }
        public double B { get; set; }

        // один из корней определен в базовом классе
        protected double Root1;
        public double X1 {
            get => Root1;
            protected set => Root1 = value;
        } // X1
    } // class Root
}
