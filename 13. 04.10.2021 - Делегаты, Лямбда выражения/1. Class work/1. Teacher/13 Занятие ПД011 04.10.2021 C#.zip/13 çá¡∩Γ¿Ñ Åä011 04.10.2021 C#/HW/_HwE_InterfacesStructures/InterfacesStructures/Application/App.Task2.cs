﻿using InterfacesStructures.Controllers;
using InterfacesStructures.Helpers;
using InterfacesStructures.Models.Task2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesStructures.Application
{
    internal partial class App
    {

        // Формирование массива данных по студентам
        public void GenerateStudents() {
            Utils.ShowNavBarTask("  Задача 2. Формирование массива данных по студентам");

            _task2Controller.Initialize();
            _task2Controller.DetailShow("\n\n\tСформированные данные студентов для обработки:\n");
        } // GenerateStudents

        // Вывод массива данных по студентам
        public void ShowStudents() {
            Utils.ShowNavBarTask("  Задача 2. Вывод массива данных по студентам");

            _task2Controller.DetailShow("\n\n\tДанные студентов для обработки:\n");
        } // ShowStudents


        // Выборка неуспевающих студентов - имеющих хотя бы одну оценку 2
        public void SelectUnderperformingStudents() {
            Utils.ShowNavBarTask("  Задача 2. Выборка неуспевающих студентов - имеющих хотя бы одну оценку 2");

            // выборка неуспевающих студентов
            short grade = 2;
            Student[] underperformings = _task2Controller.SelectUnderperformingStudents(grade);

            // вывод массива неуспевающих студентов
            Task2Controller.Show($"\n\n\t\tСтуденты, имеющие хотя бы одну оценку {grade}:", underperformings);
        } // SelectUnderperformingStudents


        // Выборка успевающих студентов - имеющих оценки только 4 и 5
        public void SelectSuccessfullStudents() {
            Utils.ShowNavBarTask("  Задача 2. Выборка успевающих студентов - имеющих оценки только 4 и 5");

            // оценки для успевающих студентов, выборка успевающих студентов
            short grade1 = 4, grade2 = 5;
            Student[] succcessfuls = _task2Controller.SelectSuccessfulStudents(grade1, grade2);
            
            // вывод массива успевающих студентов
            Task2Controller.Show($"\n\n\tСтуденты, имеющие оценки только {grade1} или {grade2}:", succcessfuls);
        } // SelectUnsuccessfullStudents

        // Упорядочить массив данных о студентах по среднему баллу
        public void OdrerStudentsByAverageMark() {
            Utils.ShowNavBarTask("  Задача 2. Упорядочить массив данных о студентах по среднему баллу");

            _task2Controller.OrderByAvgGrade();
            _task2Controller.AvgGradeShow("\n\n\tДанные студентов, упорядоченные по среднему баллу.");
        } // OdrerStudentsByAverageMark


        // Упорядочить массив данных о студентах по алфавиту
        public void OdrerStudentsByFullname() {
            Utils.ShowNavBarTask("  Задача 2. Упорядочить массив данных о студентах по алфавиту");

            _task2Controller.OrderBySurname();
            _task2Controller.DetailShow("\n\n\tДанные студентов, упорядоченные по алфавиту.");
        } // OdrerStudentsByFullname


        // Перемешать массив данных о студентах
        public void ShuffleStudents() {
            Utils.ShowNavBarTask("  Задача 2. Перемешать массив данных о студентах");
            
            _task2Controller.Shuffle();
            _task2Controller.DetailShow("\n\n\tПеремешивание данных студентов выполнено.");
        } // ShuffleStudents

    } // class App
}
