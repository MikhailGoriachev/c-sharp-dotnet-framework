﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

using InterfacesStructures.Helpers;
using InterfacesStructures.Application;

/* 
 * Задача 1. 
 * Создать иерархию классов и интерфейс для решения линейных и квадратных 
 * уравнений. Линейное уравнение имеет вид: ax + b = 0, квадратное уравнение 
 * имеет вид ax^2 + bx + c = 0
 * Базовый абстрактный класс Root, класс для линейных уравнений Linear, класс 
 * для квадратных уравнений Square. Интерфейс ISolver должен содержать методы 
 * void Solve() для решения уравнения, void Show() для вывода решения в консоль, 
 * bool HasSolve() для определения наличия решения уравнения. 
 * Создать массив из 20 уравнений, типы и коэффициенты уравнений выбирать 
 * случайно. Решить уравнения в массиве, вывести уравнения и решения (или 
 * сообщение об отсутствии решения).
 * Вычислить и вывести следующую статистику:
 *     • общее количество уравнений
 *         o сколько из них квадратных
 *         o сколько из них линейных
 *     • общее количество решений
 *         o сколько из них для квадратных уравнений
 *         o сколько из них для линейных уравнений
 * 
 * Задача 2. 
 * Описать структуру Student, содержащую поля:
 *     • фамилия и инициалы;
 *     • название группы;
 *     • успеваемость (массив из пяти элементов типа Mark– вложенная структура:
 *       название предмета, оценка (short)) 
 *     • индексатор для массива оценок Mark – вложенная структура: название 
 *       предмета, оценка (short)
 * Написать программу, выполняющую обработку массива структур Student:
 *     • заполнение данными (сгенерированными) массива из десяти структур типа 
 *       Student
 *     • вывод на экран фамилий и названия групп для всех студентов, имеющих 
 *       хотя бы одну оценку 2 (если таких студентов нет, вывести 
 *       соответствующее сообщение)
 *     • вывод на экран фамилий и названий групп для всех студентов, имеющих 
 *       оценки только 4 и 5 (если таких студентов нет, вывести соответствующее
 *       сообщение)
 *     • упорядочивание массива по возрастанию среднего балла
 *     • упорядочивание массива по фамилиям и инициалам
 *     • перемешивание массива студентов
 * 
 */
namespace InterfacesStructures
{
    internal class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 04.10.2021 - Иерархия классов и интерфейсов, структуры в C#";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Формирование массива уравнений для решения"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Вывод массива решаемых уравнений"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Решение массива уравнений, отчет по решениям"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.A, Text = "Формирование массива данных по студентам"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Вывод массива данных по студентам"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Выборка неуспевающих студентов - имеющих хотя бы одну оценку 2"},
                new MenuItem {HotKey = ConsoleKey.F, Text = "Выборка успевающих студентов - имеющих оценки только 4 и 5"},
                new MenuItem {HotKey = ConsoleKey.G, Text = "Упорядочить массив данных о студентах по среднему баллу"},
                new MenuItem {HotKey = ConsoleKey.H, Text = "Упорядочить массив данных о студентах по алфавиту"},
                new MenuItem {HotKey = ConsoleKey.J, Text = "Перемешать массив данных о студентах"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - интерфейсы, наследование");
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации наследования и интерфейсов, структур в C#", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1

                        #region Задача 1

                        // Формирование массива уравнений для решениям
                        case ConsoleKey.Q:
                            app.GenerateEquations();
                            break;

                        // Вывод массива решаемых уравнений
                        case ConsoleKey.W:
                            app.ShowEquations();
                            break;

                        // Решение массива уравнений, отчет по решения
                        case ConsoleKey.E:
                            app.SolveEquations();
                            break;
                        #endregion

                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 2

                        #region Задача 2

                        // Формирование массива данных по студентам
                        case ConsoleKey.A:
                            app.GenerateStudents();
                            break;

                        // Вывод массива данных по студентам
                        case ConsoleKey.S:
                            app.ShowStudents();
                            break;

                        // Выборка неуспевающих студентов - имеющих хотя бы одну оценку 2
                        case ConsoleKey.D:
                            app.SelectUnderperformingStudents();
                            break;
                            
                        // Выборка успевающих студентов - имеющих оценки только 4 и 5
                        case ConsoleKey.F:
                            app.SelectSuccessfullStudents();
                            break;

                        // Упорядочить массив данных о студентах по среднему баллу
                        case ConsoleKey.G:
                            app.OdrerStudentsByAverageMark();
                            break;

                        // Упорядочить массив данных о студентах по алфавиту
                        case ConsoleKey.H:
                            app.OdrerStudentsByFullname();
                            break;

                        // Перемешать массив данных о студентах
                        case ConsoleKey.J:
                            app.ShuffleStudents();
                            break;

                        #endregion

                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    } // class Program
}
