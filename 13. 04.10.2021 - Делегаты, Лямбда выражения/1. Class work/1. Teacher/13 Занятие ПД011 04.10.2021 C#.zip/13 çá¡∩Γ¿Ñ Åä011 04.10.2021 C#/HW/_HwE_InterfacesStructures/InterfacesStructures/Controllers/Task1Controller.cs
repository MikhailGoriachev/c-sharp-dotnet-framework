﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InterfacesStructures.Helpers;
using InterfacesStructures.Models.Task1;

namespace InterfacesStructures.Controllers
{
    // Массив уравнений и обработки этого массива
    internal class Task1Controller
    {

        // полиморфный массив уравнений для решения
        private ISolver[] _equations;
        public ISolver[] Solvers {
            get { return _equations; }
            protected set { _equations = value; }
        } // Solver

        // признак - вызывался метод решения или еще нет
        private bool _solved;

        // количество уравнений по заданию
        private const int SolveNumber = 20;

        // в конструкторе по умолчанию заполняем массив данными
        public Task1Controller():this(new ISolver[SolveNumber]) {
            Initialize();
        } // Task1Controller

        public Task1Controller(ISolver[] equatoins) {
            _equations = equatoins;
            _solved = false;        // уравнения еще не решены
        } // Task1Controller


        // формирование массива уравнений для обработки
        public void Initialize() {
            // Заполнение массива уравнений
            for (int i = 0; i < _equations.Length; ++i) {
                // генерация линейного или квадратного уравнения - тип уравнения
                // выбирается случайно
                // тернарный оператор тут не применим :(
                if (Utils.Random.Next(0, 2) == 0)
                    _equations[i] = new Linear { A = Utils.GetRandom(-10d, 10d), B = Utils.GetRandom(-10d, 10d) };
                else
                    _equations[i] = new Square {
                        A = Utils.GetRandom(-10d, 10d),
                        B = Utils.GetRandom(-10d, 10d),
                        C = Utils.GetRandom(-10d, 10d)
                    };
                // if
            } // for i

            _solved = false;
        } // Initialize

        // Вывод массива уравнений
        public void Show(string title) {
            string header =  
                "\t┌───────┬───────────────┬────────────────────────────┐\n" +
                "\t│ N п/п │ Вид уравнения │     A        B        C    │\n" +
                "\t├───────┼───────────────┼────────────────────────────┤";

            string footer = 
                "\t└───────┴───────────────┴────────────────────────────┘";
            // шапка таблицы
            Console.WriteLine($"{title}\n{header}");

            // вывод коэффициентов уравнений
            int i = 1;
            void ShowItem(ISolver eq) => Console.WriteLine($"\t│ {i++,5} {eq}");
            Array.ForEach(_equations, ShowItem);

            // подвал таблицы
            Console.WriteLine($"{footer}\n\n\n");
        } // Show

        // Решение массива уравнений
        public void Solve() {
            // foreach (var equation in _equations) {
            //     equation.Solve();
            // } // foreach

            // в стиле C#
            void Solve(ISolver eq) => eq.Solve(); 
            Array.ForEach(_equations, Solve);

            // Array.ForEach(_equations, eq => eq.Solve());

            _solved = true;
        } // Solve

        // Вывод массива уравнений с решениями и статистикой
        public void ShowSolve(string title) {
            // Если уравнения еще не решались - выбрасывать исключение
            if (!_solved)
                throw new Exception("Массив уравнений еще не решался!\nВыполните пункт решения массива!");

            string header = 
                "\t┌───────┬───────────────┬────────────────────────────┬──────────────────────┐\n" +
                "\t│ N п/п │ Вид уравнения │     A        B        C    │     X1       X2      │\n" +
                "\t├───────┼───────────────┼────────────────────────────┼──────────────────────┤";
            string footer1 = 
                "\t├───────┴───────────────┴────────────────────────────┴──────────────────────┤";
            string footer2 = 
                "\t└───────────────────────────────────────────────────────────────────────────┘\n";
            // шапка таблицы
            Console.Write($"{title}\n{header}\n");

            // решение уравнений,вычисление статистики
            int i = 1;
            void ShowItem(ISolver eq) { 
                Console.Write($"\t│ {i++,5} ");  // неудобный код,
                eq.Show();                       // из-за ошибки проектирования интерфейса
                Console.WriteLine();
            } // ShowItem
            Array.ForEach(_equations, ShowItem);

            // вычисление статистики
            int linears = 0;       // количество линейных уравнений
            int solved = 0;        // количество решенных уравенений
            int solvedLinear = 0;  // количество решенных линейных уравнений
            int solvedSquare = 0;  // количество решенных квадратных уравнений
            (linears, solved, solvedLinear) = CalcStatistics();

            int squares = _equations.Length - linears;
            solvedSquare = solved - solvedLinear;

            Console.WriteLine(
                $"{footer1}\n" +
                $"\t│ \t  Всего уравнений : {_equations.Length,2}                 Всего решений   : {solved,2}         │\n" +
                $"\t│ \t        линейных  : {linears,2}                       линейных  : {solvedLinear,2}         │\n" +
                $"\t│ \t        квадратных: {squares,2}                       квадратных: {solvedSquare,2}         │\n" +
                $"{footer2}\n");
        } // ShowSolve


        // статистика по массиву уравнений, определить:
        // linears      - количество линейных уравнений,
        // solved       - количество уравнений имеющих решение
        // solvedLinear - количество линейных уравнений, имеющих решение
        private (int linears, int solved, int solvedLinear) CalcStatistics() {
            // Если уравнения еще не решались - выбрасывать исключение
            if (!_solved)
                throw new Exception("Массив уравнений еще не решался!\nВыполните пункт решения массива!");

            (int linears, int solved, int solvedLinear) stats = (0, 0, 0);

            // просмотр массива уравнений, сбор статистики
            foreach (var equation in _equations) {
                bool exp1 = equation is Linear;    // является ли уравнение линейным
                bool exp2 = equation.HasSolve();   // имеет ли уравнение решение

                if (exp1) stats.linears++;         // подчсчет линейных 
                if (exp2) stats.solved++;          // подсчет имеющих решение
                
                // подсчет линейных уравнений, имеющих решение
                if (exp1 && exp2) stats.solvedLinear++;   
            } // foreach

            return stats;
        } // CalcStatistics
    } // class Task1Controller
}
