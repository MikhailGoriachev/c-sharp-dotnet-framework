﻿using InterfacesStructures.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesStructures.Models.Task2
{
    internal struct Student
    {
        #region Вложенная структура - описание оценки по предмету

        // оценка по предмету
        public struct Mark {
            // название предмета
            private string _subject;
            public string Subject {
                get => _subject;
                set => _subject = value;
            } // Subject

            // оценка за предмет
            private short _grade;
            public short Grade {
                get => _grade;
                set => _grade = value;
            } // Grade

            // вывод оценки
            public override string ToString() =>
                $"{_subject,-20}: {_grade,3}";
        } // struct Mark
        #endregion

        #region Собственно описание студента
        // фамилия и инициалы;
        private string _fullname;
        public string Fllname {
            get => _fullname;
            set => _fullname = value;
        } // Fllname

        // название группы;
        private string _group;
        public string Group {
            get => _group;
            set => _group = value;
        } // Group

        // успеваемость (массив из пяти элементов типа Mark)
        private Mark[] _marks;

        // индексатор для массива оценок 
        public Mark this[int index] {
            get => _marks[index];
            set => _marks[index] = value;
        } // Mark

        // вывести в строку поля структуры, описывающей студента
        public override string ToString() {
            StringBuilder sbr = new StringBuilder($"Студент {_fullname}, группа {_group}, оценки:\n");

            // выводим оценки - по три оценки в строке
            int m = 3;
            for (int i = 0; i < _marks.Length; ++i) {
                sbr.Append(_marks[i]);
                if ((i + 1) % m == 0) sbr.Append("\n");
            } // for i
            if (_marks.Length % m != 0) sbr.Append("\n");

            // вернуть строковое представление сформированного StringBuilder
            return sbr.ToString();
        } // ToString

        // конструктор с параметрами
        public Student(string surnameNp, string group, Mark[] marks) {
            _fullname = surnameNp;
            _group = group;
            _marks = marks;
        } // Student

        // Вычисление среднего балла студента
        public double AvgGrade() {
            double sum = 0;
            foreach (var grade in _marks) {
                sum += grade.Grade;
            } // foreach

            return sum / _marks.Length;
        } // AvgGrade

        // генерация студента
        public static Student Generate() {
            string[] fullnames = {
                "Угаев Е.Г.", "Дорофеев С.Н.", "Четверик А.К.", "Смирнова А.А.", "Фролов Е.В.", "Терещенко Е.Ф.",
                "Радионенко К.Е.", "Орлов В.Ш.", "Кутепов Д.Н.", "Миронюк А.Е.", "Гуренко Е.П.", "Харченко А.В.",
                "Новикова Т.А.", "Иванченко С.А.", "Даниленко Е.В.", "Пащенко К.К.", "Михайлов Д.Н.", "Дмитриев Д.Ю."
            };

            string[] groups = {
                "СУ 1-35", "ППС 31-01", "ИСВ 33-03", "ПСД 2-23", "ИСД 3-17", "ЕКО 18П-86"
            };

            string[] subjects = {
                "IT Essential",  "C Starter", "ООП C++", "C# Essential",
                "Design UML", "Паттерны", "Теория БД",
                "Windows 10", "Illustrator", "Photoshop", "3D Max", "Maya 3D",
                "HTML/CSS", "JavaScript", "PHP", "ADO.NET", "ASP.NET"
            };

            // генерируем массив оценок для студента
            Mark[] marks = new Mark[5];
            for (int i = 0; i < marks.Length; i++) {
                marks[i].Grade = (short)Utils.Random.Next(2, 6);  // оценки от 2 до 5
                marks[i].Subject = subjects[Utils.Random.Next(0, subjects.Length)];
            } // for i

            // создать и вернуть объект - студента
            return new Student(
                fullnames[Utils.Random.Next(0, fullnames.Length)],
                groups[Utils.Random.Next(0, groups.Length)], 
                marks);
        } // Student
        #endregion

        // Для отрисовки таблицы отбражения кратких данных о студенте
        // и статистики о группе студентов
        public static string BriefTop =
            "\t┌─────┬─────────────────┬────────────┬";
        public static string BriefMiddle =
            "\t├─────┼─────────────────┼────────────┼";
        public static string BriefBottom =
            "\t└─────┴─────────────────┴────────────┴";

        public static string BriefHead =
            "\t│ п/п │ Фамилия И.О.    │ Группа     │";

        // вывод фамилии, инициалов и названия группы
        public string ToBriefTableRow() =>
            $" {_fullname,-15} │ {_group,-10} │";

        // Заголовок таблицы подробной информации о студенте
        public static string DetailTop =
            "\t┌─────┬─────────────────┬────────────┬──────────────────────────────────────────────────────────────────────────┐";
        public static string DetailHead =
            "\t│ п/п │ Фамилия И.О.    │ Группа     │                             Предметы и оценки                            │";

        public static string DetailMiddle =
            "\t├─────┼─────────────────┼────────────┼──────────────┬──────────────┬──────────────┬──────────────┬──────────────┤";

        public static string DetailBottom =
            "\t└─────┴─────────────────┴────────────┴──────────────┴──────────────┴──────────────┴──────────────┴──────────────┘";

        // вывод фамилии, инициалов, названия группы и
        // оценок по предметам
        // в первую строку выводим фамилию, инициалы, названия группы и предметов
        // во вторую строку выводим оценки по предметам
        public string ToDetailTableRow() {
            StringBuilder sbr = new StringBuilder(ToBriefTableRow());

            // формирование названий предметов в той же линии, что 
            // фамилия и группа студента
            foreach (var mark in _marks) {
                sbr.Append($" {mark.Subject,-12} │");
            } // foreach mark

            // переход ко второй строке и начальный отступ до оценок
            sbr.Append($"\n\t│{" ",5}│{" ",17}│{" ",12}│");

            // формирование строки оценок
            foreach (var mark in _marks) {
                sbr.Append($" {mark.Grade,5}{" ",7} │");
            } // foreach mark

            return sbr.ToString();
        } // ToDetailTableRow

        // возвращает true если оценки студента имеют значение
        // только grade1 или grade2
        public bool HasOnly(int grade1, int grade2) {
            // предикат для проверки наличия оценки1 или оценки2
            bool IsGrade1OrGrade2(Mark mark) => mark.Grade == grade1 || mark.Grade == grade2;

            return Array.TrueForAll(_marks, IsGrade1OrGrade2);
        } // HasOnly

        // Возвращает true, если студент имеет оценку grade
        public bool HasGrade(int grade) {
            // предикат для проверки равенства оценки заданному значению
            bool IsGrade(Mark mark) => mark.Grade == grade;

            return Array.FindIndex(_marks, IsGrade) >= 0;
        } // HasGrade

        // компаратор для сортировки по фамилиям и инициалам
        public static int FullnameComparer(Student st1, Student st2) =>
            st1.Fllname.CompareTo(st2.Fllname);

        // компаратор для сортировки по среднему баллу
        public static int AvgGradeComarer(Student st1, Student st2) =>
            st1.AvgGrade().CompareTo(st2.AvgGrade());

    } // struct Student
}
