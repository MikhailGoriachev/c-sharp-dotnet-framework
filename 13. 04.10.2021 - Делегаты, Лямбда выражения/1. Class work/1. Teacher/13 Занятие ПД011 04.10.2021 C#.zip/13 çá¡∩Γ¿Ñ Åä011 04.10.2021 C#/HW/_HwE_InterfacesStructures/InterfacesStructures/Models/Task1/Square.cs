﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesStructures.Models.Task1
{
    // Класс для решения квадратных уравнений Square
    internal class Square: Root, ISolver
    {
        // коэффициент C
        protected double CoefC;
        public double C {
            get => CoefC;
            set => CoefC = value;
        } // C

        // второй корень уравнения
        protected double Root2;
        public double X2 {
            get => Root2;
            protected set => Root2 = value;
        } // X2 

        // реализация метода интерфейса - решение уравнения
        public void Solve() {
            if (!HasSolve()) return;

            // вспомогательные расчеты - дискриминант и
            // знаменатель выражения
            double d = Math.Sqrt(B * B - 4d * A * C);
            double a2 = 2d * A;

            if (d.Equals(0d)) {
                X1 = X2 = -B / a2;
            } else {
                X1 = (-B + d) / a2;
                X2 = (-B - d) / a2;
            } // if

        } // Solve

        // реализация метода интерфейса - вывод уравнения и его решения
        public void Show() {
            string tableRow = 
                // $"│ Квадратное    │ {A,8:f3} {B,8:f3} {C,8:f3} │ " +
                $"{this}{(HasSolve() ? $"{X1,8:f3} {X2,8:f3}" : "нет решения"),-20} │";
            Console.Write(tableRow);
        } // Show

        // проверка наличия корней уравнения - нулевой или положительный
        // дискриминант и коэффициент A не равен нулю
        public bool HasSolve() => B * B - 4d * A * C >= 0 && !A.Equals(0);

        public override string ToString() => $"│ Квадратное    │ {A,8:f3} {B,8:f3} {C,8:f3} │ ";
    } // class Square
}
