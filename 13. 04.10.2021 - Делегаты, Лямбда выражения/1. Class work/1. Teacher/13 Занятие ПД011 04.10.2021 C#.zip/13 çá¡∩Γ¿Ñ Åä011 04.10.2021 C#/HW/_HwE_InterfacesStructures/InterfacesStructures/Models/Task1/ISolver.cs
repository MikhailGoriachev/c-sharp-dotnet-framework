﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesStructures.Models.Task1
{
    // Интерфейс ISolver  методы для решения уравнений 
    internal interface ISolver
    {
        // решение уравнения
        void Solve();

        // вывод решения в консоль
        void Show();

        // проверка наличия решения уравнения
        bool HasSolve();
    } // ISolver
}
