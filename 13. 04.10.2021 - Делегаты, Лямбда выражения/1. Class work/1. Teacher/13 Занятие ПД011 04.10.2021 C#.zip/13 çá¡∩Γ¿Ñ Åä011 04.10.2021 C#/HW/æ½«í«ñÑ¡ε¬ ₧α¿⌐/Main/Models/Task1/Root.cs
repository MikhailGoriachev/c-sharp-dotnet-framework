﻿using Main.Utilities;
using Main.Utilities.TableFormatter;


namespace Main.Models.Task1
{


	public abstract class Root : ISolver
	{
		public double A { get; set; }
		public double B { get; set; }


		public abstract void Solve();
		public abstract void Show();
		public abstract bool HasSolve();


		public static ISolver MakeRandomRoot(double min, double max) =>
			General.Rand.Next(0, 2) switch
			{
				0 => new Linear
					{ A = General.Rand.RealNextDouble(min, max), B = General.Rand.RealNextDouble(min, max) },
				1 => new Square
				{
					A = General.Rand.RealNextDouble(min, max), B = General.Rand.RealNextDouble(min, max),
					C = General.Rand.RealNextDouble(min, max)
				},
			};
	}


}
