﻿using System;
using System.Threading;
using Main.Controllers;
using Main.Models.Task2;
using Main.Utilities.TableFormatter;


namespace Main
{


	internal class Program
	{
		public static void Main(string[] args)
		{
			App app = new App();
			
			app.Run();
		}
	}


}
