﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;


namespace Main.Utilities.TableFormatter
{


	public sealed class TablePrinter<T>
	{
		private static readonly Type RequiredAttribute = typeof(TableDataAttribute);
		private readonly Dictionary<PropertyInfo, TableDataAttribute> _dataForTable;


		public TablePrinter()
		{
			var genericType = typeof(T);

			_dataForTable =
				genericType
				   .GetProperties(BindingFlags.Public | BindingFlags.Instance)
				   .Where(p => p.IsDefined(RequiredAttribute))
				   .Select(p => new
					{
						Prop = p, Attr = p.GetCustomAttribute<TableDataAttribute>()
					})
				   .ToDictionary(arg => arg.Prop, arg => arg.Attr);

			if (_dataForTable.Count == 0)
				throw new ArgumentException(
					$"Обобщенный тип({genericType}) должен иметь хотя бы один атрибут {RequiredAttribute}");

			Header = MakeHeader();
			Footer = MakeFooter();
		}


		public string[] Header { get; }
		public string Footer { get; }

		
		public string ConvertObjectToTableRow(T target) =>
			CreateLine((sb, pair) =>
			{
				string formattedMember = string.Format
					(pair.Value.ValuesFormat, pair.Key.GetValue(target));

				sb.Append($"{formattedMember} │ ");
			}, "│ ").ToString();


		public List<(T, string)> ConvertObjectsToTableRow(IEnumerable<T> targets) =>
			targets.Select(target => (target, ConvertObjectToTableRow(target))).ToList();


		private string[] MakeHeader()
		{
			var topLine = MakeTopLineOfHeader();
			var columnNamesLine = MakeColumnNamesLineOfHeader();
			var bottomLine = MakeBottomLineOfHeader();

			return new[]
			{
				topLine.ToString(), columnNamesLine.ToString(), bottomLine.ToString()
			};
		}


		private StringBuilder MakeTopLineOfHeader() => CreateLineOfChars(new TableChars('┌', '┬', '┐'));


		private StringBuilder MakeColumnNamesLineOfHeader() =>
			CreateLine((sb, pair) =>
			{
				string centeredColumnName =
					pair.Value.ColumnName.Center(pair.Value.WidthOfValueOutput);

				sb.Append($"{centeredColumnName} │ ");
			}, "│ ");


		private StringBuilder MakeBottomLineOfHeader() => CreateLineOfChars(new TableChars('├', '┼', '┤'));


		private string MakeFooter() => CreateLineOfChars(new TableChars('└', '┴', '┘')).ToString();


		private StringBuilder CreateLine(Action<StringBuilder, KeyValuePair<PropertyInfo, TableDataAttribute>> forEach,
										 string atStart = "", string atEnd = "")
		{
			var builder = new StringBuilder();
			builder.Append(atStart);

			foreach (var data in _dataForTable)
				forEach.Invoke(builder, data);

			builder.ReplaceLast(atEnd);
			return builder;
		}


		private StringBuilder CreateLineOfChars(TableChars chars) =>
			CreateLine((sb, pair) =>
			{
				sb.Append(chars.Filler, pair.Value.WidthOfColumnName);
				sb.Append(chars.Separator);
			}, $"{chars.AtStart}", $"{chars.AtEnd}");
	}


}
