﻿using System;
using System.Collections.Generic;
using System.Linq;
using Main.Models;
using Main.Models.Task1;
using Main.Utilities.TableFormatter;


namespace Main.Controllers
{


	public sealed class Task1Controller
	{
		private ISolver[] _equations;


		public void Generate(int size, double min, double max)
		{
			_equations = new ISolver[size];

			for (int i = 0; i < _equations.Length; i++)
				_equations[i] = Root.MakeRandomRoot(min, max);
		}


		public void Show()
		{
			foreach (var equation in _equations)
			{
				try
				{
					equation.Show();
				}
				catch (ArithmeticException)
				{
					Console.WriteLine("Для данного уравнения нет решения\n");
					continue;
				}
			
				Console.WriteLine();
			}
		}


		public (int linears, int squares) CountEquations()
		{
			(int linears, int squares) counts = (0, 0);

			foreach (var equation in _equations) 
				counts = CountEquation(equation, counts);

			return counts;
		}


		private static (int, int) CountEquation(ISolver equation, (int, int) counts) => equation switch
		{
			Linear _ => (counts.Item1 + 1, counts.Item2),
			Square _ => (counts.Item1, counts.Item2 + 1)
		};


		public (int linears, int squares) CountSolvableEquations()
		{
			(int linears, int squares) counts = (0, 0);

			foreach (var equation in _equations) 
				if (equation.HasSolve())
					counts = CountEquation(equation, counts);

			return counts;
		}
	}


}
