﻿using System;
using Main.Controllers;
using Main.Utilities;
using Main.Utilities.Menu;


namespace Main.Views
{


	public sealed class Task1View : MenuWrapper
	{
		private readonly Task1Controller _controller = new Task1Controller();


		public Task1View() => Menu = new Menu("Задача 1. Решение линейных и квадратных уравнений", new[]
		{
			new MenuItem("Генерация массива уравнений", Fill),
			new MenuItem("Вывод уравнений", Show),
			new MenuItem("Посчитать количество уравнений", CountEquations),
			new MenuItem("Посчитать количество решаемых уравнений", CountSolvableEquations)
		});


		private void Fill()
		{
			int size = General.Rand.Next(18, 25);
			double min = General.Rand.RealNextDouble(-5, 5);
			double max = General.Rand.RealNextDouble(min);

			_controller.Generate(size, min, max);

			Show();
		}


		private void Show() => _controller.Show();


		private void CountEquations()
		{
			Show();

			var (linears, squares) = _controller.CountEquations();

			Console.WriteLine("\n\nКоличество уравнений:");
			Console.WriteLine($"\tЛинейных - {linears}");
			Console.WriteLine($"\tКвадратных - {squares}");
		}


		private void CountSolvableEquations()
		{
			Show();

			var (linears, squares) = _controller.CountSolvableEquations();

			Console.WriteLine("\n\nКоличество решаемых уравнений:");
			Console.WriteLine($"\tЛинейных - {linears}");
			Console.WriteLine($"\tКвадратных - {squares}");
		}
	}


}
