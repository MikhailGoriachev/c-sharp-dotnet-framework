﻿using System;
using Main.Utilities;


namespace Main.Models.Task1
{


	public sealed class Square : Root
	{
		public double C { get; set; }


		public (double x1, double x2) Result { get; private set; }


		private double Discriminant() => B * B - 4 * A * C;
		
		
		private double CalculateRoot(bool isPlusInvertedToMinus) =>
			isPlusInvertedToMinus
				? (-B - Math.Sqrt(Discriminant())) / (2 * A)
				: (-B + Math.Sqrt(Discriminant())) / (2 * A);


		public override void Solve()
		{
			if (!HasSolve())
				throw new ArithmeticException(
					$"Невозможно посчитать квадратное уравнение из A - {A:F}, B - {B:F}, C - {C:F}");

			double d = Discriminant();

			if (Math.Abs(d) < 0.001)
			{
				double temp = -(B / (2 * A));
				Result = (temp, temp);
			}

			Result = (CalculateRoot(true), CalculateRoot(false));
		}


		public override void Show()
		{
			Solve();

			$"Квадратное уравнение: x1 = {Result.x1,-12:F} x2 = {Result.x1,-12:F}"
			   .ColoredLine(Palette.AccentDedicated);
			Console.WriteLine($"Параметры: A - {A,-12:F} B - {B,-12:F} C - {C,-12:F}");
		}

		
		public override bool HasSolve() => !(Discriminant() < 0);
	}


}
