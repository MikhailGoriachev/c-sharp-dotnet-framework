﻿using System;
using System.Drawing;
using Main.Models.Task2;
using Main.Utilities;
using Main.Utilities.TableFormatter;


namespace Main.Controllers
{


	public sealed class Task2Controller
	{
		private readonly TableFormatter<Student> _table = new TableFormatter<Student>();
		private Student[] _students;


#region Fill


		public void Fill(int size)
		{
			_students = new Student[size];

			for (int i = 0; i < _students.Length; i++)
				_students[i] = NextStudent();
		}


		public static Student NextStudent() => new Student($"{NextFirstName()} {NextLastName()}",
			NextGroupName(), NextMarks());


		private static string NextFirstName()
		{
			string[] firstNames =
			{
				"Johnnie", "Jayson", "Moira", "Dorsey", "Katherine",
				"Gabriel", "Audrey", "Lovie", "Ingrid", "Thor",
				"Efren", "Berry", "Jamison", "Svetlana", "Judy"
			};

			return firstNames[General.Rand.Next(firstNames.Length - 1)];
		}


		private static string NextLastName()
		{
			string[] lastNames =
			{
				"Bashirian", "Bartell", "Nolan", "O'Keefe", "Bins",
				"Carter", "Heller", "Murray", "Rodriguez", "Wisoky",
				"Veum", "Conn", "Bogan", "McClure", "Turner"
			};

			return lastNames[General.Rand.Next(lastNames.Length - 1)];
		}


		private static string NextGroupName()
		{
			string[] groupNames =
			{
				"autem", "amet", "eveniet", "dolorem", "distinctio"
			};

			return groupNames[General.Rand.Next(groupNames.Length - 1)];
		}


		private static Student.Mark[] NextMarks() => new[]
		{
			new Student.Mark("Chemistry", NextGrade()),
			new Student.Mark("Physics", NextGrade()),
			new Student.Mark("Biology", NextGrade()),
			new Student.Mark("Literature", NextGrade()),
			new Student.Mark("Craft", NextGrade())
		};


		private static short NextGrade() => (short)General.Rand.Next(
			Student.Mark.GradeRanges.min, Student.Mark.GradeRanges.max + 1);


#endregion


		public void Show()
		{
			_table.Options.Update();

			_table.Show(_students);
		}


		public void Show(Student[] students)
		{
			_table.Options.Update();

			_table.Show(students);
		}


		private Student[] Select(Predicate<Student> match) => Array.FindAll(_students, match);


		public Student[] SelectNonAchievers()
		{
			bool IsMarksContainsGradeD(Student student)
			{
				for (int i = 0; i < student.MarksLength; i++)
					if (student[i].Grade == 2)
						return true;

				return false;
			}

			return Select(IsMarksContainsGradeD);
		}


		public Student[] SelectAchievers()
		{
			bool IsMarksContainsGradeAOrB(Student student)
			{
				for (int i = 0; i < student.MarksLength; i++)
					if (student[i].Grade != 4 && student[i].Grade != 5)
						return false;

				return true;
			}

			return Select(IsMarksContainsGradeAOrB);
		}


		private void Sort(Comparison<Student> comparer) => Array.Sort(_students, comparer);


		public void OrderByAverageGradeAscending()
		{
			int CompareByAverageGradeAscending(Student lhs, Student rhs) =>
				lhs.AverageGrade.CompareTo(rhs.AverageGrade);
			
			Sort(CompareByAverageGradeAscending);
		}
		
		
		public void OrderByFullNameAscending()
		{
			int CompareByFullNameAscending(Student lhs, Student rhs) =>
				lhs.FullName.CompareTo(rhs.FullName);
			
			Sort(CompareByFullNameAscending);
		}


		public void Shuffle()
		{
			for (int i = 0; i < _students.Length; i++)
			{
				int lhs = General.Rand.Next(_students.Length - 1);
				int rhs = General.Rand.Next(_students.Length - 1);

				(_students[lhs], _students[rhs]) = (_students[rhs], _students[lhs]);
			}
		}
	}


}
