﻿using System;
using Main.Utilities;


namespace Main.Models.Task1
{


	public sealed class Linear : Root
	{
		public double Result { get; private set; }


		public override void Solve() =>
			Result = HasSolve()
						 ? B / A
						 : throw new ArithmeticException(
							   $"Невозможно посчитать линейное уравнение из A - {A:F}, B - {B:F}");
		
		
		public override void Show()
		{
			Solve();

			$"Линейное уравнение: {Result, -12:F}"
			   .ColoredLine(Palette.TertiaryDedicated);
			Console.WriteLine($"Параметры: A - {A, -12:F} B - {B, -12:F}");
		}

		
		public override bool HasSolve() => A != 0;
	}


}
