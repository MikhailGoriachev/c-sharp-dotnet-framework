﻿using Main.Utilities.Guards;
using Main.Utilities.TableFormatter;


namespace Main.Models.Task2
{


	public readonly struct Student
	{
		private readonly Mark[] _marks;


		public Student(string fullName, string groupName, Mark[] marks)
		{
			Guard.Against.AnyOf(marks.Length, 5, nameof(marks));

			FullName = fullName;
			GroupName = groupName;
			_marks = marks;
		}


		[TableData("Ф.И.О", "{0, -30}")]
		public string FullName { get; }

		[TableData("Группа", "{0, -20}")]
		public string GroupName { get; }

		[TableData("Средний балл", "{0, -14}")]
		public double AverageGrade
		{
			get
			{
				short sum = 0;
				foreach (var mark in _marks)
					sum += mark.Grade;
				return (double)sum / _marks.Length;
			}
		}

		
		public int MarksLength => 5;

		public Mark this[int index]
		{
			get => _marks[index];
			set => _marks[index] = value;
		}


		public readonly struct Mark
		{
			public static readonly (short min, short max) GradeRanges = (2, 5);


			public Mark(string subject, short grade)
			{
				Subject = subject;
				Grade = grade;
			}


			public string Subject { get; }
			public short Grade { get; }
		}
	}


}
