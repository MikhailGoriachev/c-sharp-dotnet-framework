﻿using Main.Utilities.Menu;
using Main.Views;


namespace Main
{


	public sealed class App : MenuWrapper
	{
		private readonly Task1View _task1 = new Task1View();
		private readonly Task2View _task2 = new Task2View();


		public App() =>
			Menu = new Menu("Главное меню приложения", new[]
			{
				new MenuItem("Задача 1. Решение линейных и квадратных уравнений", _task1.Run)
					{ IsSimpleInvoke = true },
				new MenuItem("Задача 2. Обработка класса Student", _task2.Run)
					{ IsSimpleInvoke = true },
			});
	}


}
