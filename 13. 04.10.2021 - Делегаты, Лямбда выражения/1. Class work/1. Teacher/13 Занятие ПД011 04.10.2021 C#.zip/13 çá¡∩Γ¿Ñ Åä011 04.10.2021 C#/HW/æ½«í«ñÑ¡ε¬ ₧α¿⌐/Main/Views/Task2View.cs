﻿using System;
using Main.Controllers;
using Main.Models.Task2;
using Main.Utilities;
using Main.Utilities.Menu;


namespace Main.Views
{


	public sealed class Task2View : MenuWrapper
	{
		private readonly Task2Controller _controller = new Task2Controller();


		public Task2View() => Menu = new Menu("Задача 2. Обработка класса Student", new[]
		{
			new MenuItem("Генерация массива", Fill),
			new MenuItem("Вывод массива на экран", Show),
			new MenuItem("Выбрать студентов с хотя бы одной оценкой 2", SelectNonAchievers),
			new MenuItem("Выбрать студентов с ценками только 4 и 5", SelectAchievers),
			new MenuItem("Упорядочивание по возрастанию среднего балла", OrderByAverageGradeAscending),
			new MenuItem("Упорядочивание по фамилиям и инициалам", OrderByFullNameAscending),
			new MenuItem("Перемешивание", Shuffle),
		});


		private void Fill()
		{
			_controller.Fill(General.Rand.Next(20, 32));
			
			_controller.Show();
		}


		private void Show() => _controller.Show();


		private void SelectNonAchievers()
		{
			var nonAchievers = _controller.SelectNonAchievers();

			if (nonAchievers.Length == 0)
			{
				Console.WriteLine("Нет студентов с такой оценкой");
				return;
			}
			
			Console.WriteLine("Студенты с хотя бы одной оценкой 2:");
			_controller.Show(nonAchievers);
		}
		
		
		private void SelectAchievers()
		{
			var achievers = _controller.SelectAchievers();

			if (achievers.Length == 0)
			{
				Console.WriteLine("Нет студентов с такой оценкой");
				return;
			}
			
			Console.WriteLine("Студенты с оценками 4 и 5:");
			_controller.Show(achievers);
		}

		
		private void OrderByAverageGradeAscending()
		{
			_controller.OrderByAverageGradeAscending();

			Console.WriteLine("Студенты упорядочены по возрастанию среднего балла:");
			_controller.Show();
		}
		

		private void OrderByFullNameAscending()
		{
			_controller.OrderByFullNameAscending();

			Console.WriteLine("Студенты упорядочены по фамилиям и инициалам:");
			_controller.Show();
		}


		private void Shuffle()
		{
			_controller.Shuffle();

			Console.WriteLine("Массив студентов перемешан:");
			_controller.Show();
		}
	}


}
