﻿namespace Main.Models.Task1
{


	public interface ISolver
	{
		void Solve();

		void Show();

		bool HasSolve();
	}


}
