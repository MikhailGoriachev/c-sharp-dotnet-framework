﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

using HomeWork07._10._21.Models;
using HomeWork07._10._21.Application;

namespace HomeWork07._10._21
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.Title = "Домашние задание на 07.10.21";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Демонстрация для типа Int"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Демонстрация для типа Double"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Демонстрация для типа Person"},               
               
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();


            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("Обобщенные классы");
                    Utils.ShowMenu(12, 5, "Меню ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key)
                    {
                        // ------------------------------------------------------------
                      
                        case ConsoleKey.Q:
                            app.DemoInt();
                            break;


                        case ConsoleKey.W:

                            app.DemoDouble();

                            break;

                        
                        case ConsoleKey.E:
                            app.DemoPerson();
                            break;
                                              


                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while



        }
    }
}
