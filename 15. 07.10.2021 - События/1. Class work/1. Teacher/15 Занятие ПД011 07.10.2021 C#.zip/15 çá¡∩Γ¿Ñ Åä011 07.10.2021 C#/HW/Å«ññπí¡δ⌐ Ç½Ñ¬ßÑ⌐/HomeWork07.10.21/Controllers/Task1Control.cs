﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork07._10._21.Models;

namespace HomeWork07._10._21.Controllers
{
    class Task1Control
    {


        // задание 1 
        private ArraySaver<int> _intSave;
        public ArraySaver<int> IntSave
        {
            get { return _intSave; }
            private set { _intSave = value; }
        }

        private ArraySaver<double> _doubleSave;
        public ArraySaver<double> DoubleSave
        {
            get { return _doubleSave; }
            private set { _doubleSave = value; }
        }

        private ArraySaver<Person> _personSave;
        public ArraySaver<Person> PersonSave
        {
            get { return _personSave; }
            private set { _personSave = value; }
        }

       
        public Task1Control()
        {
            _intSave = new ArraySaver<int>();
            _doubleSave = new ArraySaver<double>();
            _personSave = new ArraySaver<Person>();

        }

        public void DemoInt()
        {
            _intSave.Initialize(-10, 10, Utils.GetRandom);
            _intSave.Show("Массив целых чисел");
            Console.WriteLine($"Количество максимальных элементов {_intSave.CountMaxElem()}") ;
            _intSave.Sort();
            _intSave.Show("Массив отсортирован");
        }



        public void DemoDouble()
        {
            _doubleSave.Initialize(-10d, 10d, Utils.GetRandom);
            _doubleSave.Show("Массив вещественных чисел");
            Console.WriteLine($"Количество максимальных элементов {_doubleSave.CountMaxElem()}");
            _doubleSave.Sort();
            _doubleSave.Show("Массив отсортирован");




        }


        public void DemoPerson()
        {
            _personSave.Initialize(Person.Generate);
            _personSave.Show("Массив персон");
            Console.WriteLine($"Количество максимальных элементов {_personSave.CountMaxElem()}");
            _personSave.Sort();
            _personSave.Show("Массив отсортирован");




        }








    }
}
