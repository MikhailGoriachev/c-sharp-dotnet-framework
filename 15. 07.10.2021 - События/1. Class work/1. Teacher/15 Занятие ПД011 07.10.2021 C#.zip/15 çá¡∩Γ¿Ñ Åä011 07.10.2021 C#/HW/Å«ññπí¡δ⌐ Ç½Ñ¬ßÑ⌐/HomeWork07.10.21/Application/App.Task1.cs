﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork07._10._21.Application
{
    internal partial class App
    {

        public void DemoInt()
        {

            _task1.DemoInt();



        }

        public void DemoDouble()
        {

            _task1.DemoDouble();



        }

        public void DemoPerson()
        {

            _task1.DemoPerson();



        }


    }
}
