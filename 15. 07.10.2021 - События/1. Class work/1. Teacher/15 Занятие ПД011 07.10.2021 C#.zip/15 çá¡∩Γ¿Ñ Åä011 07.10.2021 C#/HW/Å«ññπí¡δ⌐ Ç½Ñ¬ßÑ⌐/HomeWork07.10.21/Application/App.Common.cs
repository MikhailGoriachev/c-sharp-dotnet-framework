﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork07._10._21.Models;
using HomeWork07._10._21.Controllers;

namespace HomeWork07._10._21.Application
{
    internal partial class App
    {
        // массив уровнений
        private Task1Control _task1;

       

        // ансамбль конструкторов
        public App() : this(new Task1Control())
        {
            //_task2.Initialize();

        } // App

        public App(Task1Control task1)
        {
            _task1 = task1;
            
        } // App

    }
}
