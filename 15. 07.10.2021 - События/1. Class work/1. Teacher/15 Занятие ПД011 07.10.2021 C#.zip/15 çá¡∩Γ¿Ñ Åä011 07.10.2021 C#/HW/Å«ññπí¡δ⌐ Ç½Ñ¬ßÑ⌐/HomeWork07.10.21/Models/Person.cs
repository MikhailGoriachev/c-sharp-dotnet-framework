﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork07._10._21.Models
{
    public class Person : IComparable<Person> , IComparer<Person>
    {
        // имя
        private string _name;
        public string Name
        {
            get { return _name; }
            set { if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Person: ошибка именни");
                 _name = value; }
        }

        //возраст
        private int _age;
        public int Age
        {
            get { return _age; }
            set { if(value<=0)
                    throw new Exception("Person: ошибка возраста");
                _age = value; }
        }

        // зарплата
        private double _salary;
        public double Salary
        {
            get { return _salary; }
            set { if (value <= 0)
                    throw new Exception("Person: ошибка зарплаты");
                _salary = value; }
        }


        //public static int sAge = 20;
        public Person() {
            Name = "Неизвестно";
            Age = 20;
            Salary = 100d;
            
        }

        public Person(string name, int age, double salary)
        {
            Name = name;
            Age = age;
            Salary = salary;

        }

        public Person(Person p)
        {
            Name = p.Name;
            Age = p.Age;
            Salary = p.Salary;

        }

        public override string ToString()
        {
            return $"{Name}, возраст {Age}, оклад {Salary}";
        } // ToString

        public int CompareTo(Person obj)
        {
            return this.Salary > obj.Salary ? -1 : obj.Salary > this.Salary ? 1 : 0;
        }

        public int Compare(Person x, Person y)
        {
            return x.Age > y.Age ? -1 : y.Age > x.Age ? 1 : 0;
        }




        static string[] names = new string[]{

            "Данилова Е.Р.",
            "Дроздова Т.И.",
            "Жукова З.Д.  ",
            "Зубкова А.Д. ",
            "Лосев Д.М.   ",
            "Медведев С.Г.",
            "Миронов Ю.А. ",
            "Пономарев Д.В.",
            "Устинов П.А.",
            "Хомякова А.А."
        };

        public static Person Generate() {

            return new Person
            {

                Name = names[Utils.GetRandom(0, names.Length)],
                Age = Utils.GetRandom(20, 50),
                Salary = Utils.GetRandom(20000d, 50000d)
            };    
        
        
        }


    }
}
