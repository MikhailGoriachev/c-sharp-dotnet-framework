﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace HW14.Models
{
	class GenericArray<T> where T : IComparable<T>
	{
		private const int nElements = 10;

        private T[] _data; //контейнер


        public GenericArray():this(nElements)
        {}

        public GenericArray(int n)
        {
	        _data = new T[n];

	        // Заполнение массива значениями по умолчанию для типа T
	        for (int i = 0; i < _data.Length; i++) _data[i] = default;
        }

        public int Length => _data.Length;

		// Начальная инициализация массива (заполнение в методе случайными значениями)
		public void Initialize(Func<T> generate)
        {
	        for (int i = 0; i < Length; i++)
		        _data[i] = generate();
        }

		public bool Empty() => Length == 0;


		// Вывод массива в консоль
		public void Show(string title) =>
			Console.Write($"{title}\n{Utilities.spaces}{this}");

		// Вывод массива в строку
		public override string ToString()
        {
	        StringBuilder sb = new StringBuilder();
	        
	        int nl = _data[0] is Person ? 1 : 10;

	        string Out(T x) =>
		        typeof(T) == typeof(double) ? $"{x,8:f2}" : typeof(T) == typeof(int ) ? $"{x,5}" : $"{x}";

			for (int i = 0; i < Length; i++)
	        {
		        sb.Append($" {Out(_data[i])} ");
		        if ((i + 1) % nl == 0) sb.Append($"\n{ Utilities.spaces}");
	        } 
	        if (_data.Length % nl != 0) sb.Append("\n");
	        return sb.ToString();
        }

		public void ShowMaxColored(string title, Utilities.ColorSet color)
		{
			int nl = _data[0] is Person ? 1 : 10;

			string Out(T x) =>
				typeof(T) == typeof(double) ? $"{x,8:f2}" : typeof(T) == typeof(int) ? $"{x,5}" : $"{x}";

			T max = FindMax();

			Console.Write($"{title}\n{Utilities.spaces}");

			for (int i = 0; i < Length; i++)
			{
				Utilities.ColorSet.SetToConsole(_data[i].Equals(max) ? color : Utilities.Palette.Ordinary);
				Console.Write($" {Out(_data[i])} ");
				Utilities.Palette.Ordinary.SetToConsole();
				if ((i + 1) % nl == 0) Console.Write($"\n{ Utilities.spaces}");
			}
			if (_data.Length % nl != 0) Console.Write("\n");
		}

		

		// Определение максимального элемента массива
		public T FindMax()
        {
	        T max = _data[0];
	        Array.ForEach(_data, x =>
	        {
		        if (x.CompareTo(max) > 0) max = x;
	        });
	        return max;
        }

        // Определение количества максимальных элементов массива
        public int FindMaxValuesCount()
        {
	        T max = FindMax();
	        return Array.FindAll(_data, x => x.Equals(max)).Length;
        }



        // Упорядочение массива 
        public void Sort() =>
			Array.Sort(_data, (x1, x2) => x2.CompareTo(x1));
		
	}
}
