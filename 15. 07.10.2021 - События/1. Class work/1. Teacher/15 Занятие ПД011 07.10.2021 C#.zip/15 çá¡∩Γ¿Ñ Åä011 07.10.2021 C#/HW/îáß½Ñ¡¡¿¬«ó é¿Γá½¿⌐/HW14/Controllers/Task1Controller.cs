﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW14.Models;

namespace HW14.Controllers
{
	class Task1Controller
	{
		private GenericArray<int> _intArray;
		private GenericArray<double> _doubleArray;
		private GenericArray<Person> _personArray;

		
		public void InitIntArray()
		{
			_intArray = new GenericArray<int>();
			_intArray.Initialize(() => Utilities.GenerateInt(0,10));
			_intArray.Show($"{Utilities.spaces}Массив:");
		}

		public void ShowIntArray()
		{
			if (_intArray is null || _intArray.Empty())
			{
				Console.WriteLine($"\n\n{Utilities.spaces}Нет данных");
				return;
			}
			_intArray.Show($"{Utilities.spaces}Массив:");
		} 

		public void MaxValuesIntCount()
		{
			if (_intArray is null || _intArray.Empty())
			{
				Console.WriteLine($"\n\n{Utilities.spaces}Нет данных");
				return;
			}

			_intArray.ShowMaxColored($"{Utilities.spaces}Массив:", Utilities.Palette.HighLight);
			Console.WriteLine($"\n{Utilities.spaces}Количество элементов, равных максимальному значению:" +
			                  $" {_intArray.FindMaxValuesCount()}");
		}

		public void OrderIntDesc()
		{
			if (_intArray is null || _intArray.Empty())
			{
				Console.WriteLine($"\n\n{Utilities.spaces}Нет данных");
				return;
			}

			_intArray.Sort();
			_intArray.Show($"{Utilities.spaces}Массив упорядочен по уменьшению:");

		}


		//--------------

		public void InitDoubleArray()
		{
			_doubleArray = new GenericArray<double>();
			_doubleArray.Initialize(() => Utilities.GenerateDouble(0d, 10d));
			_doubleArray.Show($"{Utilities.spaces}Массив:");
		}

		public void ShowDoubleArray()
		{
			if (_doubleArray is null || _doubleArray.Empty())
			{
				Console.WriteLine($"\n\n{Utilities.spaces}Нет данных");
				return;
			}

			_doubleArray.Show($"{Utilities.spaces}Массив:");

		}

		public void MaxValuesDoubleCount()
		{
			if (_doubleArray is null || _doubleArray.Empty())
			{
				Console.WriteLine($"\n\n{Utilities.spaces}Нет данных");
				return;
			}

			_doubleArray.ShowMaxColored($"{Utilities.spaces}Массив:", Utilities.Palette.HighLight);

			Console.WriteLine($"\n{Utilities.spaces}Количество элементов, равных максимальному значению:" +
			                  $" {_doubleArray.FindMaxValuesCount()}");
		}

		public void OrderDoubleDesc()
		{
			if (_doubleArray is null || _doubleArray.Empty())
			{
				Console.WriteLine($"\n\n{Utilities.spaces}Нет данных");
				return;
			}

			_doubleArray.Sort();
			_doubleArray.Show($"{Utilities.spaces}Массив упорядочен по уменьшению:");

		}

		//--------------

		public void InitPersonArray()
		{
			_personArray = new GenericArray<Person>();
			_personArray.Initialize(() => Person.Generate());
			_personArray.Show($"{Utilities.spaces}Массив:");
		}

		public void ShowPersonArray()
		{
			if (_personArray is null || _personArray.Empty())
			{
				Console.WriteLine($"\n\n{Utilities.spaces}Нет данных");
				return;
			}

			_personArray.Show($"{Utilities.spaces}Массив:");
		}


		public void MaxValuesPersonCount()
		{
			if (_personArray is null || _personArray.Empty())
			{
				Console.WriteLine($"\n\n{Utilities.spaces}Нет данных");
				return;
			}


			_personArray.ShowMaxColored($"{Utilities.spaces}Массив:", Utilities.Palette.HighLight);
			Console.WriteLine($"\n{Utilities.spaces}Количество элементов, равных максимальному значению зарплаты:" +
			                  $" {_personArray.FindMaxValuesCount()}");
		}

		public void OrderPersonDesc()
		{
			if (_personArray is null || _personArray.Empty())
			{
				Console.WriteLine($"\n\n{Utilities.spaces}Нет данных");
				return;
			}

			_personArray.Sort();
			_personArray.Show($"{Utilities.spaces}Массив по уменьшению возраста:");

		}
	}
}
