﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW14
{
	public static class Utilities
	{
		public const int indent = 4;

		public static string spaces = " ".PadRight(indent);

		public static Random _rand = new Random();
		public static void ShowNavBar(string promt, int nIndentLines = 0, int leftIndents = indent)
		{
			// сохранить цвета консоли
			ColorSet curColors = new ColorSet(true);

			string header = new string(' ', Console.WindowWidth);

			Palette.Hint.SetToConsole();
			Console.SetCursorPosition(0, 0);
			Console.Write(header);

			// Выводим текст в верхнюю строку
			WriteXY(indent, 0, promt, ConsoleColor.Black);

			// восстановить цвета консоли
			curColors.SetToConsole();

			NewLines(nIndentLines);
		}

		public static void NewLines(int n)
		{
			for (int i = 0; i < n; i++)
			{
				Console.WriteLine();
			}
		}

		// Вспомогательный метод для вывода в заданных координатах окна консоли текста
		// заданным цветом
		public static void WriteXY(int x, int y, string s, ConsoleColor color)
		{
			// сохранить текущий цвет консоли и установить заданный
			ConsoleColor oldColor = Console.ForegroundColor;
			Console.ForegroundColor = color;

			Console.SetCursorPosition(x, y);
			Console.WriteLine(s);

			// восстановить цвет консоли
			Console.ForegroundColor = oldColor;
		}

		public static void WriteColored(string str, ColorSet colors)
		{
			ColorSet curColors = new ColorSet(true);
			colors.SetToConsole();
			Console.Write(str);
			curColors.SetToConsole();
		}


		public static double GenerateDouble(double from, double to) => from + _rand.NextDouble() * (to - from);
		public static int GenerateInt(int from, int to) => _rand.Next(from, to);


		public class ColorSet
		{
			public ConsoleColor Foreground { get; set; }
			public ConsoleColor Background { get; set; }

			public ColorSet(bool currentConsole = false)
			{
				if (currentConsole)
				{
					Foreground = Console.ForegroundColor;
					Background = Console.BackgroundColor;
				}
			}

			public void SetToConsole()
			{
				Console.ForegroundColor = Foreground;
				Console.BackgroundColor = Background;
			}

			public static void SetToConsole(ColorSet colors)
			{
				Console.ForegroundColor = colors.Foreground;
				Console.BackgroundColor = colors.Background;
			}

		}

		public static class Palette
		{
			public static ColorSet Ordinary = new ColorSet()
			{ Foreground = ConsoleColor.Green, Background = ConsoleColor.Black };

			public static ColorSet Hint = new ColorSet()
			{ Foreground = ConsoleColor.Black, Background = ConsoleColor.Gray };

			public static ColorSet Notice = new ColorSet()
			{ Foreground = ConsoleColor.DarkCyan, Background = ConsoleColor.Black };

			public static ColorSet Context = new ColorSet()
			{ Foreground = ConsoleColor.Yellow, Background = ConsoleColor.Black };

			public static ColorSet TableRow = new ColorSet()
			{ Foreground = ConsoleColor.Black, Background = ConsoleColor.Green };

			public static ColorSet HighLight = new ColorSet()
				{ Foreground = ConsoleColor.Black, Background = ConsoleColor.Green };
		}
	}
}
