﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace HW14
{
	internal partial class App
	{
		private void Task1MenuItem1()
		{
			Utilities.ShowNavBar("Инициализация массива", 2);
			_task.InitIntArray();
		}

		private void Task1MenuItem2()
		{
			Utilities.ShowNavBar("Вывод массива в консоль", 2);
			_task.ShowIntArray();
		}

		private void Task1MenuItem3()
		{
			Utilities.ShowNavBar("Определение количества максимальных элементов массива", 2);
			_task.MaxValuesIntCount();

		}

		private void Task1MenuItem4()
		{
			Utilities.ShowNavBar("Упорядочение массива", 2);

			_task.OrderIntDesc();
		}


		//-----------

		private void Task1MenuItem5()
		{
			Utilities.ShowNavBar("Инициализация массива", 2);
			_task.InitDoubleArray();
		}

		private void Task1MenuItem6()
		{
			Utilities.ShowNavBar("Вывод массива в консоль", 2);
			_task.ShowDoubleArray();
		}

		private void Task1MenuItem7()
		{
			Utilities.ShowNavBar("Определение количества максимальных элементов массива", 2);
			_task.MaxValuesDoubleCount();

		}

		private void Task1MenuItem8()
		{
			Utilities.ShowNavBar("Упорядочение массива", 2);

			_task.OrderDoubleDesc();
		}

		//-----------

		private void Task1MenuItem9()
		{
			Utilities.ShowNavBar("Инициализация массива", 2);
			_task.InitPersonArray();
		}

		private void Task1MenuItem10()
		{
			Utilities.ShowNavBar("Вывод массива в консоль", 2);
			_task.ShowPersonArray();
		}

		private void Task1MenuItem11()
		{
			Utilities.ShowNavBar("Определение количества максимальных элементов массива", 2);
			_task.MaxValuesPersonCount();

		}

		private void Task1MenuItem12()
		{
			Utilities.ShowNavBar("Упорядочение массива", 2);

			_task.OrderPersonDesc();
		}

	}
}
