﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW14.Models
{
	class Person : IComparable<Person>
	{
		public string Name { get; set; }
		public int Age { get; set; }
		public double Salary { get; set; }

		public override string ToString() => $"Имя: {Name, -20} Возраст: {Age, 3} Зарплата: {Salary, 6}";
		public int CompareTo(Person other) => Age.CompareTo(other.Age);

		public static Person Generate()
		{
			string[] names =
			{
				"Кошелева Агата",
				"Карпова Полина",
				"Корнеева Елизавета",
				"Семенова Кира",
				"Калмыкова Ирина",
				"Соболева Фатима",
				"Круглов Максим",
				"Колесова Аглая",
				"Жукова Есения",
				"Зеленина Вероника",
				"Корнилова Мария",
				"Кузнецова Анастасия",
				"Калинина Дарья",
				"Одинцова Милана",
				"Прохорова Милана",
				"Алексеева Мирослава",
				"Нефедова Ульяна",
				"Карпов Данила",
				"Захарова Александра",
				"Богданов Сергей"
			};

			return new Person
			{
				Name = names[Utilities.GenerateInt(0, names.Length - 1)],
				Age = Utilities.GenerateInt(18, 60),
				Salary = Utilities.GenerateInt(5000, 50000)
			};

		}
	}
}
