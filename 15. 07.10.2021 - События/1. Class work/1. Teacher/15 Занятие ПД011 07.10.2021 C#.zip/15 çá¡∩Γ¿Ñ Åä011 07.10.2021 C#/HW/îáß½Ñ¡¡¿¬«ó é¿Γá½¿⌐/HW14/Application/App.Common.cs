﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW14.Controllers;

namespace HW14
{
	internal partial class App
	{
		private Menu _mainMenu;
		private Menu _subMenu1;
		private Menu _subMenu2;
		private Menu _subMenu3;

		private Task1Controller _task;
		public App() : this(new Task1Controller())
		{}

		public App(Task1Controller task)
		{
			_task = task;
			InitMenu();
		}

		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem("Массив Int", MainMenuItem1),
					new Menu.MenuItem("Массив Double", MainMenuItem2),
					new Menu.MenuItem("Массив Person", MainMenuItem3),
					new Menu.MenuItem("Выход")
				}, new Point(5, 5),
				"Меню приложения");

			// Подменю 1
			_subMenu1 = new Menu(new[]
				{
					new Menu.MenuItem("Инициализация массива", Task1MenuItem1),
					new Menu.MenuItem("Вывод массива в консоль", Task1MenuItem2),
					new Menu.MenuItem("Определение количества максимальных элементов массива", Task1MenuItem3),
					new Menu.MenuItem("Упорядочение массива", Task1MenuItem4),
					new Menu.MenuItem("Назад")
				}, new Point(5, 5),
				"Работа массива Int");

			// Подменю 2
			_subMenu2 = new Menu(new[]
				{
					new Menu.MenuItem("Инициализация массива", Task1MenuItem5),
					new Menu.MenuItem("Вывод массива в консоль", Task1MenuItem6),
					new Menu.MenuItem("Определение количества максимальных элементов массива", Task1MenuItem7),
					new Menu.MenuItem("Упорядочение массива", Task1MenuItem8),
					new Menu.MenuItem("Назад")
				}, new Point(5, 5),
				"Работа массива Double");

			// Подменю 3
			_subMenu3 = new Menu(new[]
				{
					new Menu.MenuItem("Инициализация массива", Task1MenuItem9),
					new Menu.MenuItem("Вывод массива в консоль", Task1MenuItem10),
					new Menu.MenuItem("Определение количества максимальных элементов массива", Task1MenuItem11),
					new Menu.MenuItem("Упорядочение массива", Task1MenuItem12),
					new Menu.MenuItem("Назад")
				}, new Point(5, 5),
				"Работа массива Person");

		}

		public void Run() => _mainMenu.Run();
		private void MainMenuItem1() => _subMenu1.Run(true);
		private void MainMenuItem2() => _subMenu2.Run(true);
		private void MainMenuItem3() => _subMenu3.Run(true);
	}
}
