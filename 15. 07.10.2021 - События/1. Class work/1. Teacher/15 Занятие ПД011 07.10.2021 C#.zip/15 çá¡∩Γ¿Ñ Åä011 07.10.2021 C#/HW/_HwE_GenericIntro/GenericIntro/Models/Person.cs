﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GenericIntro.Helpers;

namespace GenericIntro.Models
{
    // класс, хранящий данные о работниках - источник данных
    // для обобщенного массива Vector
    // по заданию реализует компаратор для сравнения по свойству Salary  
    internal class Person : IComparable<Person>
    {
        // Имя работника
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException("Person: пустое имя недопустимо");
                _name = value;
            } // set
        } // Name

        // Возраст работника, полных лет
        private int _age;
        public int Age {
            get => _age;
            set {
                if (value <= 0)
                    throw new ArgumentException("Person: недопустимое значение возраста");
                
                _age = value;
            } // set
        } // Age

        // Оклад работника, руб.
        private double _salary;
        public double Salary {
            get => _salary;
            set {
                if (value <= 0)
                    throw new ArgumentException("Person: недопустимое значение оклада");

                _salary = value;
            } // set
        } // Salary

        public Person() : this("Иванова Б.А.", 32, 34_000) { }
        public Person(string name, int age, double salary) {
            Name = name;
            Age = age;
            Salary = salary;
        } // Person

        // вывод шапки таблицы
        // Шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}┌───────┬────────────────────────┬──────────────┬───────────────┐\n" +
            $"{spaces}│ N п/п │ Полное имя сотрудника  │ Возраст, лет │  Оклад, руб.  │\n" +
            $"{spaces}├───────┼────────────────────────┼──────────────┼───────────────┤\n";
        } // Header

        // Подвал таблицы, статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└───────┴────────────────────────┴──────────────┴───────────────┘\n";

        // строковое представление класса используем для вывода в формате строки таблицы
        public override string ToString() => $"│ {_name,-22} │ {_age,12:f0} │ {_salary,13:n2} │";

        public string ToTableRow(int row, int indent) =>
            $"{" ".PadRight(indent)}│ {row, 5} │ {_name,-22} │ {_age,12:f0} │ {_salary,13:n2} │";

        // компаратор по свойству salary - для ускорения доступа обращаемся
        // напрямую к опорному полю свойства
        public int CompareTo(Person p) => _salary.CompareTo(p._salary);

        // переопределение метода сравнени для подсчета количества элементов,
        // со значением, равным заданному (максимальный оклад)
        public override bool Equals(object obj) => ((Person)obj).Salary == Salary;

        // генерация объекта класса Person
        public static Person Generate() {
            string[] fullNames = {
                "Васильев А.Н.",    "Швайко О.А.",    "Дёмина Д.П.",  "Лысюк А.В.",  
                "Якубовская Ю.В.",  "Пачкория Г.В.",  "Аникеев В.О.", "Мироненко Н.Я.",
                "Решетникова Н.А.", "Свиридова Т.Л.", "Репеко Д.А.",  "Лысенко Б.П.", 
            };
            return new Person { 
                Name   = fullNames[Utils.GetRandom(0, fullNames.Length-1)],
                Age    = Utils.GetRandom(19, 56),
                Salary = Utils.GetRandom(12, 56) * 1_000
            };
        } // Generate
    } // class Person
}