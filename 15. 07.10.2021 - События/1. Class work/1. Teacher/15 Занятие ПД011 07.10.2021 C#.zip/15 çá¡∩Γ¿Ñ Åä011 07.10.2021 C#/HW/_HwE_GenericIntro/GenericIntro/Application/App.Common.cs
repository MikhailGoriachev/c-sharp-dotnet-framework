﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GenericIntro.Helpers;
using GenericIntro.Models;


namespace GenericIntro.Application
{
    // Общая часть приложения, создание объектов для выполнения задания
    internal partial class App
    {
        // объекты для обработки
        private Vector<int> _integers;
        private Vector<double> _doubles;
        private Vector<Person> _persons;

        // ансамбль конструктлоров
        public App() :
            this(new Vector<int>(), new Vector<double>(), new Vector<Person>(12)) {
            Initialize();
        } // App

        public App(Vector<int> integers, Vector<double> doubles, Vector<Person> persons) {
            _integers = integers;
            _doubles = doubles;
            _persons = persons;
        } // App

        // формирование исходных данных - частичный метод
        partial void Initialize();
    } // class App
}
