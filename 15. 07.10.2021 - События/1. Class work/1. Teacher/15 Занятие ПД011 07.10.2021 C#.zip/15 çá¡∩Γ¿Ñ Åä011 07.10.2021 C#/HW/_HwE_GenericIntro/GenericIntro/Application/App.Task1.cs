﻿
using System;

using GenericIntro.Helpers;
using GenericIntro.Models;

namespace GenericIntro.Application
{
    /*
     * Методы для решения задачи 1 
     */
    internal partial class App
    {
        // генерация данных
        partial void Initialize() {
            _integers.Initialize(-10, 10, Utils.GetRandom);
            _doubles.Initialize(-10, 10, Utils.GetRandom);
            _persons.Initialize(Person.Generate);    
        } // Initialize
        
        // генерация и вывод массивов для обработки
        public void GenerateAndShow() {
            Utils.ShowNavBarTask("  Генерация и вывод массивов для обработки");

            // собственно формирование данных
            Initialize();

            // вывод сформированных массивов 
            Show("\n\n\tМассивы данных для обработки сформированы:");
        } // GenerateAndShow

        
        // Вывод массивов для обработки
        public void ShowData() {
            Utils.ShowNavBarTask("  Вывод массивов для обработки");

            Show("\n\n\tДанные для обработки по заданию:");
        } // ShowData

        
        // Перемешать массивы данных для обработки
        public void ShuffleData() {
            Utils.ShowNavBarTask("  Перемешать массивы данных для обработки");

            // перемешивание массивов по заданию
            _integers.Shuffle();
            _doubles.Shuffle();
            _persons.Shuffle();

            // вывод массивов после перемешивания
            Show("\n\n\tМассивы данных перемешаны, готовы к продолжению обработки:");
        } // ShuffleData


        // Определить количество максимальных элементов в массивах
        public void GetNumberMaximums() {
            Utils.ShowNavBarTask("  Определить количество максимальных элементов в массивах");

            // обработка массива типа int
            int intMax = _integers.Max();
            int counters = _integers.CounterIf(intMax);

            // вывод массива типа int
            int i = 1, m = 10;
            _integers.Show($"\n\n\tВ массиве целых чисел максимальное: {intMax}, " +
                $"количество максимальных: {counters}\n\t", "\n", (item) => {
                    if (item == intMax) {
                        (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);
                    } // if
                    Console.Write($"{item,8}  ");
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Write(" ");
                    if (i++ % m == 0) Console.Write("\n\t");
                } // lambda
            );

            // обработка массива типа double
            double dblMax = _doubles.Max();
            counters = _doubles.CounterIf(dblMax);

            // вывод результатов
            i = 1;
            _doubles.Show($"\n\tВ массиве вещественных чисел максимальное: {dblMax:f3}, " +
                $"количество максимальных: {counters}\n\t", "\n", (item) => {
                    if (item.Equals(dblMax)) {
                        (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);
                    } // if
                    Console.Write($"{item, 8:f3}  ");
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Write(" ");
                    if (i++ % m == 0) Console.Write("\n\t");
                } // lambda
            );

            // обработка массива типа Person
            Person personMax = _persons.Max();
            counters = _persons.CounterIf(personMax);  // подсчет с использованием Equals

            // вывод результатов
            i = 1;
            _persons.Show($"\n\tВ массиве персон для обработки максимальный оклад: {personMax.Salary}," +
                $" количество персон с таким окладом: {counters}\n" +
                $"{Person.Header(12)}", Person.Footer(12),
                item => {
                    Console.Write(" ".PadRight(11));
                    if (item.Equals(personMax)) {
                        (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);
                    } // if
                    Console.WriteLine($"{item.ToTableRow(i++, 0)}");
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                });
        } // GetNumberMaximums


        // Сортировка массивов по заданию
        public void SortData() {
            Utils.ShowNavBarTask("  Сортировка массивов по заданию");

            // сортировка массивов - реализация паттерна Посетитель
            _integers.OrderBy((a, b) => a.CompareTo(b));
            _doubles.OrderBy((a, b) => a.CompareTo(b));
            _persons.OrderBy((a, b) => b.Age.CompareTo(a.Age));
            
            // вывод отсортировнных массивов
            Show("\n\n\tМассивы упорядочены по заданию, персоны - по убыванию возраста:");
        } // SortData


        // собственно вывод массивов в консоль
        private void Show(string title) {
            Console.WriteLine(title);

            // вывод масива типа int
            int i = 1, m = 10;
            _integers.Show("\tМассив целых чисел:\n\t", "\n", (item) => {
                Console.Write($"{item, 8}");
                if (i++ % m == 0) Console.Write("\n\t");
            });

            // вывод масива типа double
            i = 1;
            _doubles.Show("\tМассив вещественных чисел:\n\t", "\n", (item) => {
                Console.Write($"{item, 8:f3}");
                if (i++ % m == 0) Console.Write("\n\t");
            });

            // вывод массива объектов типа Person
            i = 1;
            _persons.Show($"\tСписок персон для обработки:\n{Person.Header(12)}", Person.Footer(12),
                item => Console.WriteLine($"{item.ToTableRow(i++, 12)}"));
        } // Show
    } // class App
}
