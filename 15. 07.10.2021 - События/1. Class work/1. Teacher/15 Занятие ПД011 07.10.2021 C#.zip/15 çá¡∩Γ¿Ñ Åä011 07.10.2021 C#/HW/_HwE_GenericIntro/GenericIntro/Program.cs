﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

using GenericIntro.Helpers;
using GenericIntro.Application;

/* 
 * Задача 1. 
 * Разработать обобщенный класс для хранения одномерного массива. Класс должен 
 * иметь следующий функционал:
 *     • начальная инициализация массива (заполнение в методе случайными 
 *       значениями)
 *     • вывод массива в консоль
 *     • определение количества максимальных элементов массива
 *     • упорядочение массива 
 * Проверить работу приложения на типах данных 
 *     • int (массив упорядочивать по убыванию значений)
 *     • double (массив упорядочивать по убыванию значений)
 *     • Person (Name: string, Age: int, Salary: double, для Person – максимальный 
 *       по значению свойства Salary, упорядочение по убыванию свойства Age
 * 
 */
namespace GenericIntro
{
    internal class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 06.10.2021 - Делегаты и лямбда-выражения в C#";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Генерация и вывод массивов для обработки"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Вывод массивов для обработки"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Перемешать массивы данных для обработки"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Определить количество максимальных элементов в массивах"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "Сортировка массивов по заданию"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - обобщенные типы, лямбда-выражения");
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации обобщенных типов, делегатов и лямбда-выражений в C#", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1

                        // Генерация и вывод массивов для обработки
                        case ConsoleKey.Q:
                            app.GenerateAndShow();
                            break;

                        // Вывод массивов для обработки
                        case ConsoleKey.W:
                            app.ShowData();
                            break;

                        // Перемешать массивы данных для обработки
                        case ConsoleKey.E:
                            app.ShuffleData();
                            break;

                        // Определить количество максимальных элементов в массивах
                        case ConsoleKey.R:
                            app.GetNumberMaximums();
                            break;

                        // Сортировка массивов по заданию
                        case ConsoleKey.T:
                            app.SortData();
                            break;

                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    } // class Program
}
