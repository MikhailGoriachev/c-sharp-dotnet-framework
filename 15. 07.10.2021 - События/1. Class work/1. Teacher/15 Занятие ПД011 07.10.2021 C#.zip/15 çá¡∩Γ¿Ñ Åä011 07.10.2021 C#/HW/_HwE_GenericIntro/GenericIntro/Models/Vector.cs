﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GenericIntro.Models;
using GenericIntro.Helpers;

namespace GenericIntro.Models
{
    // Обобщенный класс для хранения одномерного массива.
    // Класс имеет следующий функционал:
    //     • начальная инициализация массива (заполнение в методе случайными 
    //       значениями)
    //     • вывод массива в консоль
    //     • определение количества максимальных элементов массива
    //     • упорядочение массива 
    internal class Vector<T> where T: IComparable<T>
    {
        // контейнер данных
        public T[] Data { get; set; }
        
        // размер массива по умолчанию
        private const int Number = 23; 

        // Конструкторы класса
        public Vector() : this(new T[Number]) { } // Vector
        public Vector(int n) : this(new T[n]) { } // Vector

        public Vector(T[] data) {
            Data = data;
        } // Vector


        // Инициализация массива данными - использовать стандартный делегат
        // Func<in T, in T, return T> - ему соответсвтвуют методы с сигнатурой T func(T a, T b)
        // т.е. double GetRandom(double lo, double hi) подойдет
        public void Initialize(T lo, T hi, Func<T, T, T> generator) {
            for (int i = 0; i < Data.Length; i++) {
                 Data[i] = generator(lo, hi);
            } // for i
        } // Initialize


        // перегруженный вариант инициализатора - для ссылочного типа
        // Func<T> - ему соответствуют методы с сигнатурой T func()
        // т.е. Person Generate() подойдет
        public void Initialize(Func<T> generator) {
            for (int i = 0; i < Data.Length; i++) {
                Data[i] = generator();
            } // for i
        } // Initializer


        // Вывод массива в консоль: заголовок, данные, подвал
        // Action<T> - делегат для сигнатуры void f(T p)         !! outItem !! Visitor - паттерн Посетитель
        public void Show(string header, string footer, Action<T> outItem) {
            Console.Write(header);       // заголовок (в том числе шапка таблицы)
            Array.ForEach(Data, outItem);    // собственно элементы массива
            Console.WriteLine(footer);       // вывод подвала (не обязательно)
        } // Show


        // Поиск максимального элемента в массиве
        public T Max() {
            T max = Data[0];

            // поиск максимального элемента в массиве
            Array.ForEach(Data, item => { 
                if (max.CompareTo(item) < 0) {   // max < item
                    max = item;
                } // if
            });

            // вернуть индекс максимального элемента массива
            return max;
        } // IndexMax
        

        // Подсчет количества элементов, для которых срабатывает предикат, сравнивающий
        // элемент массива с заданным значением
        public int CounterIf(T value) {
            int counter = 0;    // замыкание в делегате!!  closure 
            Array.ForEach(Data, item => counter += item.Equals(value) ? 1 : 0);
            return counter;
        } // CounterIf

        // Сортировка массива - вызываем для конкретного типа из клиентского кода
        public void OrderBy(Comparison<T> comparison) => Array.Sort(Data, comparison);


        // перемешивание массива по алгоритму "Тасование Фишера-Йетса"
        // https://vscode.ru/prog-lessons/kak-peremeshat-massiv-ili-spisok.html
        public void Shuffle() {
            // просматриваем массив с конца
            for (int i = Data.Length - 1; i >= 1; i--) {
                // определяем элемент, с которым меняем элемент с индексами i
                int j = Utils.GetRandom(0, i);  

                // меняем местами элементы массива при помощи кортежа
                (Data[i], Data[j]) = (Data[j], Data[i]);
            } // for i
        } // Shuffle 
    } // class Vector
}
