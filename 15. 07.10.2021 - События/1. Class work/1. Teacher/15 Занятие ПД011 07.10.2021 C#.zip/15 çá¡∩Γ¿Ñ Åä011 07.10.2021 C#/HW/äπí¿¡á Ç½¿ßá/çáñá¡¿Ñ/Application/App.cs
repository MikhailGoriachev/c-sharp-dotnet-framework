﻿using System;
using Задание.Models;
using Задание.Helpers;

namespace Задание.Application
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        Vector<int>    _intArr;
        Vector<double> _doubleArr;
        Vector<Person> _personArr;

        // конструктор по умолчанию
        public App() : this(new Vector<int>(), new Vector<double>(), new Vector<Person>()) { }

        // конструктор с внедрением зависимостей
        public App(Vector<int> intArr, Vector<double> doubleArr, Vector<Person> personArr) {
            _intArr    = intArr;
            _doubleArr = doubleArr;
            _personArr = personArr;
        } // App

        // Обработка массива типа int
        public void Part1() {
            Utils.ShowNavBarTask("    Обработка массива типа int");
            Processing(_intArr, -10, 10);
        } // Part1

        // Обработка массива типа double
        public void Part2() { 
            Utils.ShowNavBarTask("    Обработка массива типа double");
            Processing(_doubleArr, -10d, 10d);
        } // Part2

        // Обработка массива типа Person
        public void Part3() {
            Utils.ShowNavBarTask("    Обработка массива типа Person");
            Processing(_personArr, new Person(), new Person());
        } // Part3

        // Обработка по заданию 
        public void Processing<T>(Vector<T> arr, T lo, T hi) {
            arr.Fill(lo, hi);
            T max = arr.Max();

            BiPredicate<T> biPredicate = delegate (T x, T y) {
                if (max is Person) return Person.CompareSalary(x, y) == 0;
                return arr.Compare(x, y) == 0; 
            };

            arr.Show("Массив заполнен:", 8, biPredicate, max);
            Console.WriteLine($"\n{"", 8}Количество максимальных элементов массива: {arr.CounterIf(biPredicate, max)}");

            arr.SortDescend();
            arr.Show("Массив отсортирован:", 8);

        } // Processing

    } // class App
}