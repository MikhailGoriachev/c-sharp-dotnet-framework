﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Helpers;

namespace Задание.Models
{
    internal class Person {
        private string _name;           // фамилия и инициалы 
        private int _age;               // возраст
        private double _salary;         // оклад

        public string Name {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Person: Некорректное значение фамилии и инициалов!"); _name = value; }
        } // Name

        public int Age {
            get => _age;
            set { if (value <= 0) throw new Exception("Person: Некорректное значение возраста!"); _age = value; }
        } // Age

        public double Salary {
            get => _salary;
            set { if (value <= 0d) throw new Exception("Person: Некорректное значение оклада!"); _salary = value; }
        } // Salary


        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"│ {_name, -18} │ {_age, 5}   │ {_salary, 11:f2} │";

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌────────────────────┬─────────┬─────────────┐\n" +
                $"{spaces}│    Фамилия И.О.    │ Возраст │ Оклад, руб. │\n" +
                $"{spaces}├────────────────────┼─────────┼─────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└────────────────────┴─────────┴─────────────┘";

        // сравниваем два объекта по окладу
        static public int CompareSalary(object x, object y) =>
            ((Person)x).Salary.CompareTo(((Person)y).Salary);

        // сравниваем два объекта по возрасту
        static public int CompareAge(object x, object y) =>
            ((Person)x).Age.CompareTo(((Person)y).Age);

        // Фабричный метод для создания персоны из случайных данных
        public static Person Generate() {
            // массив фамилий для создания персоны
            string[] surnames = new[] { "Семенов " , "Дунаев " , "Харламова ", "Олегова ", "Янковский ", "Абалкин ", "Абалкин ",
                                        "Романова ", "Воликов ", "Абалкин "  , "Жукова " , "Соколов "  , "Лебедев ", };
            // массив инициалов для создания персоны
            string[] initials = new[] { "A.", "Б.", "В.", "Г.", "Д.", "Е.", "Ж.", "З.", "И.", "К.", "Л.", "М.", "Н.", "О.", "П.", "Р.", "С.", "Т.",
                                        "У.", "Ф.", "Х.", "Ц.", "Ч.", "Ш.", "Э.", "Ю.", "Я."};
            return new Person {
                _name = surnames[Utils.Random.Next(surnames.Length)] + initials[Utils.Random.Next(initials.Length)] + initials[Utils.Random.Next(initials.Length)],
                _age  = Utils.Random.Next(15, 68),
                _salary = Utils.GetRandom(1_000d, 100_000d),
            };
        } // Generate

        public override string ToString() {
            return $"{ToTableRow()}";
        } // ToString

    }
}
