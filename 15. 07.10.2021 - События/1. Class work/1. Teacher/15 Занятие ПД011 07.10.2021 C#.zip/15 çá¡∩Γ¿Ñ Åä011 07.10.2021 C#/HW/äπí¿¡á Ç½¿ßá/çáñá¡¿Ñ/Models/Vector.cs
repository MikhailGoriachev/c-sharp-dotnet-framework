﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Helpers;

namespace Задание.Models
{
    // делегаты предикатов обработки
    internal delegate bool BiPredicate<T>(T item, T value);  // для сравнения с некоторым значением 
    internal class Vector<T>
    {
        private T[] _data; //контейнер

        public Vector() : this(10) { }
        public Vector(int n) {
            _data = new T[n];

            // Заполнение массива значениями по умолчанию для типа T
            for (int i = 0; i < _data.Length; i++) _data[i] = default;
        } // Vector

        // Вывод массива
        public void Show(string caption, int indent, BiPredicate<T> biPredicate, T value, ConsoleColor color = ConsoleColor.Yellow) {
            string space = " ".PadRight(indent);

            Console.WriteLine($"\n\n{space}{caption}");

            if (_data[0] is Person)
                Console.Write($"{Person.Header(indent)}");
            else Console.Write($"{space}");

            for (int i = 0; i < _data.Length; i++) {
                Utils.SetColor(biPredicate(_data[i], value) ?
                      color
                    : Console.ForegroundColor, Console.BackgroundColor);

                if (_data[i] is Person)
                    Console.Write($"{space}{_data[i]}\n");
                else
                    Console.Write($"{_data[i], 8:0.###}");

                Utils.RestoreColor();
                
                if ((i + 1) % 10 == 0 && !(_data[0] is Person)) Console.Write($"\n{space}");
            } // for i

            if (_data[0] is Person)
                Console.Write($"{Person.Footer(indent)}");
        } // Show

        public void Show(string caption, int indent)
        {
            string space = " ".PadRight(indent);

            Console.WriteLine($"\n\n{space}{caption}");

            if (_data[0] is Person)
                Console.Write($"{Person.Header(indent)}");
            else Console.Write($"{space}");

            for (int i = 0; i < _data.Length; i++) {

                if (_data[i] is Person)
                    Console.Write($"{space}{_data[i]}\n");
                else
                    Console.Write($"{_data[i],8:0.###}");

                if ((i + 1) % 10 == 0 && !(_data[0] is Person)) Console.Write($"\n{space}");
            } // for i

            if (_data[0] is Person)
                Console.Write($"{Person.Footer(indent)}");
        } // Show

        // Подсчет количества элементов, для которых срабатывает предикат, сравнивающий
        // элемент массива с заданным значением
        public int CounterIf(BiPredicate<T> predicate, T value) =>
            Array.FindAll(_data, item => predicate(item, value)).Length;

        public int Length => _data.Length;

        // Заполнение массива случайными величинами
        public void Fill(T low, T high) {
            for (int i = 0; i < _data.Length; i++)
                _data[i] = Utils.GetRand(low, high);
        } // Fill

        // Поиск максимального элементa массива
        public T Max() {
            T max = _data[0];
            for (int i = 1; i < _data.Length; i++) {
                if (_data[i] is Person && Person.CompareSalary(_data[i], max) > 0) max = _data[i];
                else if (Compare(_data[i], max) > 0) max = _data[i];
            } // for i
            return max;
        } // Max

        public void SortDescend() =>
            Array.Sort(_data, (a, b) => Compare(b, a));

        public int Compare(object x, object y) {
            if (_data[0] is Person) return Person.CompareAge(x, y);
            else if(_data[0] is double) return (double)x - (double)y == 0 ? 0 : (double)x - (double)y < 0? -1: 1;
            else  return (int)x - (int)y;
        } // Compare
    } // Vector
}
