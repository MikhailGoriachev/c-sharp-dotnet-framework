﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Generics.Task;

namespace Generics.Application
{
    class App
    {
        Task1 task1 = new Task1();
        Vector<int> v1 = new Vector<int>();
        Vector<double> v2 = new Vector<double>();
        Vector<Person> v3 = new Vector<Person>();



        public void Task1Point1()
        {
            Utils.ShowNavBarTask("Начальная инициализация массива вывод в консоль ");

            v1.Fill(10, ()=>Utils.GetRandomInt(-5, 5));
            v2.Fill(10, () => Utils.GetRandom(-5, 5));
            v3.Fill(10,Person.Factory);

            Console.WriteLine("\n\n");
            Console.WriteLine($"Массив закрытый типом int: {v1.ToString()}");
            Console.WriteLine($"Массив закрытый типом double : {v2.ToString()}");
            Console.WriteLine($"Массив закрытый типом Person: {v3.ToString()}");


            Console.ReadKey();
        }

        public void Task1Point2()
        {
            Utils.ShowNavBarTask("Нахождение количества максимальных элементов массива");

            Console.WriteLine($"Максимальное количество элементов для int: {v1.NumberOfMaxElem()}");
            Console.WriteLine($"Максимальное количество элементов для double {v2.NumberOfMaxElem()}");
            Console.WriteLine($"Максимальное количество элементов для Person : {v3.NumberOfMaxElem()}");




            Console.ReadKey();
        }
        
        public void Task1Point3()
        {
            Utils.ShowNavBarTask("Упорядочивание массива");

            


            Console.ReadKey();
        }
    }
}
