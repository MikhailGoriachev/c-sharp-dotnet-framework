﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics.Task
{
    class Vector<T> where T: IComparable<T> // CompareTo
    {
        public delegate T Factory();

        private T[] _data; // контейнер 

        

        public void Fill(int n, Factory filler)
        {
            _data = new T[n];

            for(int i =0; i<_data.Length; i++) 
            {
                _data[i] = filler.Invoke();
            }
        }

        //вывод массива в строку 
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            for(int i  =0; i< _data.Length; i++)
            {
                sb.Append($"{_data[i],10:0.##}");
                if ((i + 1) % 8 == 0) sb.Append("\n");
            }// for 

            if (_data.Length % 8 != 0) sb.Append("\n");
            return sb.ToString();
        }

        public T MaxElem()
        {
            T max = _data[0];

            for(int i =1; i<_data.Length; i++)
            {
                if(_data[i].CompareTo(max)==1)
                {
                    max = _data[i];
                }
            }

            return max;
        }

        public int NumberOfMaxElem()
        {
            int counter = 0;
            T t = MaxElem();

            for (int i =0; i<_data.Length; i++)
            {
                if (_data[i].CompareTo(t) == 0)
                {
                    counter++;
                } 
            }
            return counter;
        }

        // компаратор по убыванию
        public int Comparator(T a1, T a2) => a2.CompareTo(a1); 
    }
}
