﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Generics.Application;

namespace Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 07.09.2021 . Обобщения";

            //  меню приложения 
            MenuItem[] menu = new[]
            {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задание 1 Начальная инициализация массива вывод в консоль  "},
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задание 1.Нахождение количества максимальных элементов массива "},
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задание 1.Упорядочивание массива "},
            };

            App app = new App();

            while(true)
            {
                try
                {
                    //настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП С# - Делегаты. Лямбда выражения");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с делегатами", menu);

                    // получения кода клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = " Нажмите выделенныую цветом клавишу для выбора ".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch(key)
                    {
                        case ConsoleKey.Q:
                            app.Task1Point1();
                            break;

                        case ConsoleKey.W:
                            app.Task1Point2();
                            break;

                        case ConsoleKey.E:
                            app.Task1Point3();
                            break;

                       

                    }// switch

                }
                catch(Exception ex)
                {
                    Console.WriteLine("\n");
                    Console.WriteLine(ex);
                    Console.ReadKey(); 
                }
            }// while

        }
    }
}
