﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics.Task
{
    class Task1
    {
        Person[] people;

        static Random rand = new Random();

        public void Fill(int size)
        {
            people = new Person[size]; 

            for(int i =0; i<size; i++)
            {
                people[i] = new Person(FullNames(), Ages(), Salaries());
            }
        }

        

        public string FullNames()
        {
            string[] names = {"Иванов В.И.", "Петров В.С.", "Сидоров К.У",
                "Давыдов С.И.", "Никонорова А.М.", "Параманов С.К.", "Федоров.М.К.",
                "Калиущенко В.С.", "Вещенко А.К.", "Михайлова М.К" };

            return names[rand.Next(names.Length - 1)];
        }

        public int Ages()
        {
            int[] ages = { 34, 56, 78, 45, 54, 65, 32, 76, 51 };

            return ages[rand.Next(ages.Length - 1)];
        }

        public double Salaries()
        {
            double[] salaries = { 12345, 30000, 40000, 23000, 43000, 21000, 32000, 560000 };

            return salaries[rand.Next(salaries.Length - 1)]; 
        }


    }
}
