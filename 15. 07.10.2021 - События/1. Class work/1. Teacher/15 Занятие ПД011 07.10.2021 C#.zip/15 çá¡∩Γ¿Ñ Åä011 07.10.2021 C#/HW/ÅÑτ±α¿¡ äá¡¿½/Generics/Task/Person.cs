﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics.Task
{
    class Person:IComparable<Person>
    {
        public string Name { get; set; }

        

        public int Age { get; set; }

        private double _salary;

        public double Salary
        {
            get => _salary; 
            set => _salary = value; 
        }

        public Person(string name, int age, double salary)
        {
            Name = name;
            Age = age;
            Salary = salary;
        }


        public int CompareTo(Person other) =>Salary.CompareTo(other.Salary);

        public override string ToString() => $"\n Имя : {Name, 15}, Возраст : {Age, 7}, Зарплата: {Salary, 10} \n";

        public static Person Factory()
        {
            string[] names = {"Иванов В.И.", "Петров В.С.", "Сидоров К.У",
                "Давыдов С.И.", "Никонорова А.М.", "Параманов С.К.", "Федоров.М.К.",
                "Калиущенко В.С.", "Вещенко А.К.", "Михайлова М.К" };

            return new Person(names[Utils.GetRandomInt(0, names.Length - 1)], Utils.GetRandomInt(18, 65), Utils.GetRandom(12000, 50000)); 
        }    
             
        
    }
}
