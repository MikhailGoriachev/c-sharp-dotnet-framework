﻿using Main.Utilities.Menu;
using Main.Views;


namespace Main
{


	public sealed class App : MenuWrapper
	{
		private readonly IntVectorView _intVector = new IntVectorView();
		private readonly DoubleVectorView _doubleVector = new DoubleVectorView();
		private readonly PersonVectorView _personVector = new PersonVectorView();


		public App() => Menu = new Menu("Главное меню приложения", new[]
		{
			new MenuItem("Массив типа int", _intVector.Run)
				{ IsSimpleInvoke = true },
			new MenuItem("Массив типа double", _doubleVector.Run)
				{ IsSimpleInvoke = true },
			new MenuItem("Массив типа person", _personVector.Run)
				{ IsSimpleInvoke = true },
		});
	}


}
