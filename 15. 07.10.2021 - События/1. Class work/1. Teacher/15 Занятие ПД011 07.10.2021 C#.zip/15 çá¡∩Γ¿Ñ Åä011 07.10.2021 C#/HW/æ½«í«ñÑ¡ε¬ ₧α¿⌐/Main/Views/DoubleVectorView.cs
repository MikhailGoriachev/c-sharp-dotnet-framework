﻿using System;
using Main.Models;
using Main.Utilities;
using Main.Utilities.Menu;
using Palette = Main.Utilities.Palette;


namespace Main.Views
{


	public sealed class DoubleVectorView : MenuWrapper
	{
		private Vector<double> _vector;
		private readonly int _numbersPerRow = 6;
		private readonly (int min, int max) _sizeRanges = (15, 30);
		private readonly (double min, double max) _randomRanges = (-2, 2);
		private readonly double _epsForMaximum = 0.001;


		public DoubleVectorView() => Menu = new Menu("Массив типа double", new[]
		{
			new MenuItem("Заполнение массива", Fill),
			new MenuItem("Вывод массива", Show),
			new MenuItem("Определение количества максимальных элементов массива", CountMaximums),
			new MenuItem("Упорядочивание по убыванию значений", OrderByValueDescending),
		});


		private void Fill()
		{
			_vector = new Vector<double>(General.Rand.Next(_sizeRanges.min, _sizeRanges.max));
			_vector.Fill(() => General.Rand.RealNextDouble(_randomRanges.min, _randomRanges.max));

			Show();
		}


		private void Show() => Show(null);


		private void Show(Action<double> color)
		{
			_vector.Show((index, value) =>
			{
				color?.Invoke(value);
				
				Console.Write($" {value:F} ".Center(16));
				
				Palette.Default.AsCurrent();
				
				if ((index + 1) % _numbersPerRow == 0)
					Console.WriteLine();
			});
		}


		private void CountMaximums()
		{
			var (max, count) = _vector.CountMaximums();

			Console.WriteLine($"Максимальное значение: {max:F}");
			Console.WriteLine($"Количество максимальных элементов: {count}\n\n");

			Show(i =>
			{
				if (Math.Abs(i - max) < _epsForMaximum)
					Palette.Accent.AsCurrent();
			});
		}


		private void OrderByValueDescending()
		{
			_vector.Sort((lhs, rhs) => rhs.CompareTo(lhs));
			
			Show();
		}
	}


}
