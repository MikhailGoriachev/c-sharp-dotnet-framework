﻿using System;
using Main.Utilities.Guards;


namespace Main.Models
{


	public sealed class Vector<T>
		where T : IComparable<T>
	{
		private readonly T[] _array;


		public Vector(int size) => _array = new T[size];


		public Vector(T[] array) => _array = array;


		public void Fill(Func<T> factory)
		{
			Guard.Against.Null(factory, nameof(factory));

			for (int i = 0; i < _array.Length; i++)
				_array[i] = factory.Invoke();
		}


		public void Show(Action<int, T> show)
		{
			Guard.Against.Null(show, nameof(show));

			for (int i = 0; i < _array.Length; i++)
				show.Invoke(i, _array[i]);
		}


		public (T max, int count) CountMaximums()
		{
			T max = FindMax();
			int counter = 0;

			foreach (T comparable in _array)
				if (max.CompareTo(comparable) == 0)
					counter++;

			return (max, counter);
		}


		private T FindMax()
		{
			T max = _array[0];

			for (int i = 1; i < _array.Length; i++)
				if (_array[i].CompareTo(max) == 1)
					max = _array[i];

			return max;
		}


		public void Sort(Comparison<T> match) => Array.Sort(_array, match);
	}


}
