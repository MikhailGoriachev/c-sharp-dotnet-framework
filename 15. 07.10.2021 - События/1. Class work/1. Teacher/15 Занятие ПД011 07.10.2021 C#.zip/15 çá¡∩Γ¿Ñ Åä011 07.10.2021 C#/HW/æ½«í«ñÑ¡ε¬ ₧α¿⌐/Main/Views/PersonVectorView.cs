﻿using System;
using Main.Models;
using Main.Utilities;
using Main.Utilities.Menu;
using Palette = Main.Utilities.Palette;


namespace Main.Views
{


	public sealed class PersonVectorView : MenuWrapper
	{
		private Vector<Person> _vector;
		private readonly int _numbersPerRow = 6;
		private readonly (int min, int max) _sizeRanges = (15, 30);
		private readonly double _epsForSalary = 0.001;


		public PersonVectorView() => Menu = new Menu("Массив типа Person", new[]
		{
			new MenuItem("Заполнение массива", Fill),
			new MenuItem("Вывод массива", Show),
			new MenuItem("Определение максимальных персон по окладу", CountMaximums),
			new MenuItem("Упорядочивание по убыванию возраста", OrderByAgeDescending),
		});


		private void Fill()
		{
			_vector = new Vector<Person>(General.Rand.Next(_sizeRanges.min, _sizeRanges.max));
			_vector.Fill(Person.Create);

			Show();
		}

		
		private void Show() => Show(null);
		

		private void Show(Action<Person> color)
		{
			_vector.Show((index, value) =>
			{
				color?.Invoke(value);
				
				Console.WriteLine($"{value}");
				
				Palette.Default.AsCurrent();
			});
		}


		private void CountMaximums()
		{
			var (max, count) = _vector.CountMaximums();

			Console.WriteLine($"Максимальное значение: {max}");
			Console.WriteLine($"Количество максимальных элементов: {count}\n\n");

			Show(person =>
			{
				if (Math.Abs(person.Salary - max.Salary) < _epsForSalary)
					Palette.Accent.AsCurrent();
			});
		}


		private void OrderByAgeDescending()
		{
			_vector.Sort((lhs, rhs) => rhs?.Age.CompareTo(lhs?.Age) ?? 0);

			Show();
		}
	}


}
