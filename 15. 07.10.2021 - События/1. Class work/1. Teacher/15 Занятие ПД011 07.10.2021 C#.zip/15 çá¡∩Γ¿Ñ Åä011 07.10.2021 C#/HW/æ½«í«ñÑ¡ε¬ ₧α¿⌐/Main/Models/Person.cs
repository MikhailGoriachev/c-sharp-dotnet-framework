﻿using System;
using Main.Utilities;
using Main.Utilities.Guards;


namespace Main.Models
{


	public sealed class Person : IComparable<Person>
	{
		private int _age;
		private double _salary;


		public string Name { get; set; }

		public int Age
		{
			get => _age;
			set => _age = Guard.Against.Negative(value, nameof(value));
		}
		
		public double Salary
		{
			get => _salary;
			set => _salary = Guard.Against.Negative(value, nameof(value));
		}


		public override string ToString() => $"Name: {Name, -32} Age: {_age, -12} Salary: {_salary, -14:F}";


		public int CompareTo(Person other) => _salary.CompareTo(other?._salary);


		public static Person Create()
		{
			string[] names =
			{
				"Johnnie", "Jayson", "Moira", "Dorsey", "Katherine",
				"Gabriel", "Audrey", "Lovie", "Ingrid", "Thor",
				"Efren", "Berry", "Jamison", "Svetlana", "Judy"
			};

			return new Person
			{
				Name = names[General.Rand.Next(names.Length - 1)],
				Age = General.Rand.Next(20, 40),
				Salary = General.Rand.RealNextDouble(2000, 20000)
			};
		}
	}


}
