﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W14C_
{/// <summary>
/// Проверить работу приложения на типах данных 
///•	int (массив упорядочивать по убыванию значений)
///•	double (массив упорядочивать по убыванию значений)
///•	Person(Name: string, Age: int, Salary: double)    
///   для Person - максимальный по значению свойства Salary,
///   упорядочение по убыванию свойства Age
/// </summary>
    internal class App
    {
        public App() { }


        public void Proc1()
        {
            Processing<int> intArr = new Processing<int>();
            Utils.ShowNavBarTask("   Начальная инициализация и вывод массива в консоль");

            intArr.Fill(-10, 20);
            intArr.Show("\n\n Массив заполнен случайными значениями\n\n");
            
            intArr.FindMax(out var intMax);
            Console.WriteLine($"\n Максимальный элемент : {intMax}");

            intArr.SortDescend();
            intArr.Show("\n\n Массив упорядочен по убыванию значений\n\n");

        }// Proc1

        public void Proc2()
        {
            Processing<double> dblArr = new Processing<double>();
            Utils.ShowNavBarTask("   Начальная инициализация и вывод массива в консоль");

            dblArr.Fill(-5.5, 10.8);
            dblArr.Show("\n\n Массив заполнен случайными значениями\n\n");

            dblArr.FindMax(out var dblMax);
            Console.WriteLine($"\n Максимальный элемент : {dblMax :n2}");

            dblArr.SortDescend();
            dblArr.Show("\n\n Массив упорядочен по убыванию значений\n\n");

        }// Proc2

        public void Proc3()
        {
            Utils.ShowNavBarTask("   Формирование объектов класса Person");
            //Processing<Persona> p = new Processing<Persona>();

            Person<string, int, double> obj = new Person<string, int, double>  ("Василий", 50, 80d) ;
            Person<string, int, double> obj1 = new Person<string, int, double>  ("Иван", 22, 65d) ;
            Person<string, int, double> obj2 = new Person<string, int, double>  ("Виктор", 29, 67d) ;
            Person<string, int, double> obj3 = new Person<string, int, double>  ("Артём", 45, 94d) ;
            Person<string, int, double> obj4 = new Person<string, int, double>  ("Марина",15, 45d) ;

            Console.WriteLine($"\n\n Объекты:\n\n {obj}\n {obj1}\n {obj2}\n {obj3}\n {obj4}\n");

        }


    }// class App
}
