﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Разработать обобщенный класс для хранения одномерного массива.
/// Класс должен иметь следующий функционал:
///•	начальная инициализация массива (заполнение в методе случайными значениями)
///•	вывод массива в консоль
///•	определение количества максимальных элементов массива
///•	упорядочение массива 
/// </summary>
namespace H_W14C_
{
    internal class Processing<T> where T : IComparable<T>
    {
        // контейнер для хранения данных обобщенного типа
        private T[] _arr;
        

        public Processing() : this((8)) { }

        // конструктор
        public Processing(int n)
        {
            _arr = new T[n];

            // Заполнение массива значениями по умолчанию для типа T
            for (int i = 0; i < _arr.Length; i++)
                _arr[i] = default;

        }// Processing

        public int Length => _arr.Length;


        // заполнение массива случайными величинами
        public void Fill(T low , T high)
        {
            for (int i = 0; i < _arr.Length; i++)
            {
                _arr[i] = Utils.GetRand(low, high);
            } // for i

        } // Fill

        // вывод массива
        public void Show(string title) => Console.Write($"{title}{this}");

        // вывод массива в строку
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < _arr.Length; i++)
            {
                // использование оператора typeof(тип)
                sb.Append($"{_arr[i],10:0.##}");
                if ((i + 1) % 8 == 0) sb.Append("\n");
            } // for i
            if (_arr.Length % 8 != 0) sb.Append("\n");
            return sb.ToString();
        } // ToString


        // поиск и возврат максимального элемента массива
        public void FindMax(out T max)
        {
            max = _arr[0];
            for (int i = 1; i < _arr.Length; i++)
            {
                if (_arr[i].CompareTo(max) > 0) max = _arr[i];
            } // for i
        } // FindMax

        public void SortAscend() =>
             Array.Sort(_arr, (a, b) => a.CompareTo(b));

        public void SortDescend() =>
             Array.Sort(_arr, (a, b) => b.CompareTo(a));

    }// class Processing
}
