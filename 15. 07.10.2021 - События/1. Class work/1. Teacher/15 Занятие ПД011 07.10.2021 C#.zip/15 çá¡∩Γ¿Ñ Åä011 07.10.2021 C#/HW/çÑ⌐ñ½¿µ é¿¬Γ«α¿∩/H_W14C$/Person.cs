﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W14C_
{
    // класс Рerson для задания
    internal class Person<T, K, B> 
    {
        private T _name;
        private K _age;
        private B _salary;

        public Person() : this(default(T), default(K), default(B)) { }
        public Person(T v1, K v2, B v3)
        {
            _name = v1;
            _age = v2;
            _salary = v3;
        }

        public T Name { get => _name; set => _name = value; }

        public K Age { get => _age; set => _age = value; }

        public B Salary { get => _salary; set => _salary = value; }

        public override string ToString() => $" | Имя : { Name, -10} | Возраст:{Age, 8}лет | Зарплата: {Salary, 8:n2}рубл | ";

    }// class Person
}
