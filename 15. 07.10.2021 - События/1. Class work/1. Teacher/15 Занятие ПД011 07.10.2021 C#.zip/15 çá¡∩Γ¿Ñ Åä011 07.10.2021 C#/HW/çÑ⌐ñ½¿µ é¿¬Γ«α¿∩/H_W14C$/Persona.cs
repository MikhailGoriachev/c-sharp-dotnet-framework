﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W14C_
{
    class Persona
    {
        private string _name;
        private int _age;
        private double _salary;

        public string Name { get => _name; set => _name = value; }

        public int Age { get => _age; set => _age = value; }

        public double Salary { get => _salary; set => _salary = value; }

        public override string ToString() => $" | имя { Name,-15} | возраст{Age,8} | зарплата {Salary,8:n2} | ";

    }
}
