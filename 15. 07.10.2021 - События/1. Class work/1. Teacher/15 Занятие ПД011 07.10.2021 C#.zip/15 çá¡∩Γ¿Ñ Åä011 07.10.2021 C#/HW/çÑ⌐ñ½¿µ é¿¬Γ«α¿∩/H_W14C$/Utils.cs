﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W14C_
{
    class Utils
    {

        // объект для получения случайных чисел
        public static readonly Random Random = new Random(Environment.TickCount);

        // Получение случайного числа
        // краткая форма записи метода - это не лямбда выражение
        public static int GetRand(int lo, int hi) => Random.Next(lo, hi + 1);
        public static double GetRand(double lo, double hi) => lo + (hi - lo) * Random.NextDouble();
        public static char GetRand(char min = (char)0, char max = (char)255) =>
            (char)Random.Next(min, max + 1);


        // Наглядная демонстрация, почему не стоит формировать обобщенный метод
        // для генерации случайных чисел )))
        public static T GetRand<T>(T low, T high)
        {
            if (typeof(T) == typeof(double))
            {
                return (T)(object)GetRand((double)(object)low, (double)(object)high);
            } // if

            if (typeof(T) == typeof(int))
            {
                return (T)(object)GetRand((int)(object)low, (int)(object)high);
            } // if

            return (T)(object)GetRand((char)(object)low, (char)(object)high);
        } // GetRand

        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line)
        {
            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;
            ConsoleColor oldFgColor = Console.ForegroundColor;

            // при выводе немного используем методы класса string :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Magenta);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
            Console.ForegroundColor = oldFgColor;
        } // ShowNavBarTask


        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // Вывод меню приложения
        public static void ShowMenu(int x, int y, string title, MenuItem[] menu)
        {
            WriteXY(x, y, title, ConsoleColor.White);
            int offsetY = 2;

            foreach (var menuItem in menu)
            {
                WriteXY(x, y + offsetY, menuItem.HotKey.ToString(), ConsoleColor.Red);
                WriteXY(x + 3, y + offsetY++, menuItem.Text, ConsoleColor.White);
            } // foreach menuItem
        } // ShowMenu

    }
}
