﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Work.Models.Task2
{
    // Класс Аргументы события Childhood
    internal class ChildhoodEventArgs : EventArgs
    {
        #region Свойства 

        // новый возраст 
        public int Age { get; set; }

        #endregion
    }
}
