﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Work.Models.Task1
{
    // Класс Аргументы события StateChange
    internal class StateChangeEventArgs
    {
        // значение состояния питания
        public bool Active { get; set; }
    }
}
