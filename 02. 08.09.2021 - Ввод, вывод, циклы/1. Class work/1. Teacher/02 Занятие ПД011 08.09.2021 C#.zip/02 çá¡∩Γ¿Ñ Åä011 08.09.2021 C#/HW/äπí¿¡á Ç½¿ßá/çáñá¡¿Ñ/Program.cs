﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Задание{
    class Program{
        static void Main(string[] args){

            Console.Title = "Задание на 08.09.2021";
            Console.SetWindowSize(80, 35);

            Console.CursorVisible = false;

            string str  = "  |\\_/|   ****************************  (\\_/) "; // для вычисления координат центра консоли

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();

            // Вывод ASCII-картинки в верхней левой части консоли
            Console.WriteLine(str);
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ");
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\") ");
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   * "          );
            Console.WriteLine("  / O \\   ****************************"          );

            Thread.Sleep(3000);

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Clear();

            // Вывод ASCII-картинки по центру консоли
            Console.SetCursorPosition((Console.WindowWidth - str.Length) / 2, Console.WindowHeight / 2 - 2);
            Console.WriteLine(str);
            Console.SetCursorPosition((Console.WindowWidth - str.Length) / 2, Console.WindowHeight / 2 - 1);
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ");
            Console.SetCursorPosition((Console.WindowWidth - str.Length) / 2, Console.WindowHeight / 2);
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\") ");
            Console.SetCursorPosition((Console.WindowWidth - str.Length) / 2, Console.WindowHeight / 2 + 1);
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   * ");
            Console.SetCursorPosition((Console.WindowWidth - str.Length) / 2, Console.WindowHeight / 2 + 2);
            Console.WriteLine("  / O \\   ****************************");

            Thread.Sleep(3000);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.Clear();

            // Вывод ASCII-картинки в нижней правой части консоли
            Console.SetCursorPosition(Console.WindowWidth - str.Length, Console.WindowHeight - 5);
            Console.WriteLine(str);
            Console.SetCursorPosition(Console.WindowWidth - str.Length, Console.WindowHeight - 4);
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ");
            Console.SetCursorPosition(Console.WindowWidth - str.Length, Console.WindowHeight - 3);
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\") ");
            Console.SetCursorPosition(Console.WindowWidth - str.Length, Console.WindowHeight - 2);
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   * ");
            Console.SetCursorPosition(Console.WindowWidth - str.Length, Console.WindowHeight - 1);
            Console.WriteLine("  / O \\   ****************************");

            Console.ForegroundColor = ConsoleColor.DarkGray;

            Console.CursorVisible = true;


        } // Main
    } // class Program
}
