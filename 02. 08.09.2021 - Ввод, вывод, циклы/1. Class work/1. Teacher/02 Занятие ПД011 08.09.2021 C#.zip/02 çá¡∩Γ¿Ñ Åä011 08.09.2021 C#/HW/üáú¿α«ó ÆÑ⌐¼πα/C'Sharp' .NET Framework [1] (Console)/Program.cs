﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;



namespace C_Sharp_.NET_Framework__1___Console_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Домашнаяя работа по C# №1";

            Console.SetWindowSize(80,35);
            
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            
            Console.Clear();


            int left = 2;
            int top = 0;

            
            Console.SetCursorPosition(left--, top++);
            Console.WriteLine("|\\_/|   ****************************  (\\_/)");
            Console.SetCursorPosition(left--, top++);
            Console.WriteLine("/ @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ");
            Console.SetCursorPosition(left++, top++);
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\") ");
            Console.SetCursorPosition(left++, top++);
            Console.WriteLine("'>>x<<'  *   (pprinz@example.com)   * ");
            Console.SetCursorPosition(left, top++);
            Console.WriteLine("/ O \\   ****************************");

            Thread.Sleep(3000);
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.BackgroundColor = ConsoleColor.Yellow;
            
            left = 16;
            top = 14;

            Console.SetCursorPosition(left, top++);
            Console.WriteLine("  |\\_/|   ****************************  (\\_/)   ");
            Console.SetCursorPosition(left, top++);
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=)  ");
            Console.SetCursorPosition(left, top++);
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\")  ");
            Console.SetCursorPosition(left, top++);
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   *          ");
            Console.SetCursorPosition(left, top++);
            Console.WriteLine("  / O \\   ****************************          ");

            Thread.Sleep(3000);
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.BackgroundColor = ConsoleColor.DarkGray;

            left = 32;
            top = 29;

            Console.SetCursorPosition(left, top++);
            Console.WriteLine("  |\\_/|   ****************************  (\\_/)   ");
            Console.SetCursorPosition(left, top++);
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=)  ");
            Console.SetCursorPosition(left, top++);
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\")  ");
            Console.SetCursorPosition(left, top++);
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   *          ");
            Console.SetCursorPosition(left, top++);
            Console.WriteLine("  / O \\   ****************************          ");

            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor  = default;
            Console.BackgroundColor = ConsoleColor.White;


        }
    }
}
