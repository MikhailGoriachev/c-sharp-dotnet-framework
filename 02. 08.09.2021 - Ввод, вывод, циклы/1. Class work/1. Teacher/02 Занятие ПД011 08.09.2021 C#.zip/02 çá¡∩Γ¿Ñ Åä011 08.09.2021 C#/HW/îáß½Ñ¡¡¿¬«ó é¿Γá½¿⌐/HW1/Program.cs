﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HW1
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.SetWindowSize(80, 35);

			Console.CursorVisible = false;

			Console.ForegroundColor = ConsoleColor.Yellow;
			Console.BackgroundColor = ConsoleColor.Black;

			Console.WriteLine("  |\\_/|   ****************************  (\\_/)   ");
			Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=)  ");
			Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\")  ");
			Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   * 		   ");
			Console.WriteLine("  / O \\   ****************************		   ");

			Thread.Sleep(3000);

			Console.ForegroundColor = ConsoleColor.Black;
			Console.BackgroundColor = ConsoleColor.White;

			Console.Clear();

			const int LINE_LENGTH = 48, N_LINES = 5;
			int xPos = Console.WindowWidth / 2 - LINE_LENGTH / 2;
			int yPos = Console.WindowHeight / 2;

			Console.SetCursorPosition(xPos, yPos - 2);
			Console.WriteLine("  |\\_/|   ****************************  (\\_/)   ");
			Console.SetCursorPosition(xPos, yPos - 1);
			Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=)  ");
			Console.SetCursorPosition(xPos, yPos);
			Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\")  ");
			Console.SetCursorPosition(xPos, yPos + 1);
			Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   * 		   ");
			Console.SetCursorPosition(xPos, yPos + 2);
			Console.WriteLine("  / O \\   ****************************		   ");

			Thread.Sleep(3000);

			Console.ForegroundColor = ConsoleColor.Green;
			Console.BackgroundColor = ConsoleColor.DarkMagenta;

			Console.Clear();

			xPos = Console.WindowWidth - LINE_LENGTH;
			yPos = Console.WindowHeight - N_LINES;

			Console.SetCursorPosition(xPos, yPos);
			Console.WriteLine("  |\\_/|   ****************************  (\\_/)   ");
			Console.SetCursorPosition(xPos, yPos + 1);
			Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=)  ");
			Console.SetCursorPosition(xPos, yPos + 2);
			Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\")  ");
			Console.SetCursorPosition(xPos, yPos + 3);
			Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   * 		   ");
			Console.SetCursorPosition(xPos, yPos + 4);
			Console.WriteLine("  / O \\   ****************************		   ");



		}
	}
}
