﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HW_APP
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.SetWindowSize(80, 35);
            string line1 = "|\\_/|   ****************************  (\\_/)";
            string line2 = "/ @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ";
            string line3 = "( > o < ) *       Poppy Prinz        * (\")_(\")  ";
            string line4 = "'>>x<<'  *   (pprinz@example.com)   * ";
            string line5 = " / O \\   ****************************";

            Console.Write($"{line1}\n{line2}\n{line3}\n{line4}\n{line5}");
           
            Thread.Sleep(3000);
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.SetCursorPosition((Console.WindowWidth - line1.Length) / 2, Console.WindowHeight / 2 - 1) ;
            Console.Write($"{line1}\n\t\t{line2}\n\t\t{line3}\n\t\t{line4}\n\t\t{line5}");

            Thread.Sleep(3000);
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.SetCursorPosition(Console.WindowWidth - line1.Length, 0);
            Console.Write($"{line1}\n\t\t\t\t  {line2}\n\t\t\t\t {line3}\n\t\t\t\t   {line4}\n\t\t\t\t     {line5}");

            Console.ReadKey();
            Console.ForegroundColor = oldColor;




        }

    }
}
