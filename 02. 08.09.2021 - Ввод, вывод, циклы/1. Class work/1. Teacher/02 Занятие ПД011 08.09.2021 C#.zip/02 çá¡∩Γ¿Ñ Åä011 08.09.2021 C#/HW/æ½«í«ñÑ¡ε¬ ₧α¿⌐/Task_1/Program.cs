﻿using System;
using System.Threading;


namespace Main
{
	class Program
	{
		static void Main(string[] args)
		{
			const string first   = "  |\\_/|   ****************************  (\\_/)\n";
			const string second  = " / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=)\n";
			const string third   = "( > o < ) *       Poppy Prinz        * (\")_(\")\n";
			const string fourth  = " '>>x<<'  *   (pprinz@example.com)   *\n";
			const string fifth   = "  / O \\   ****************************\n";
			const int    timeout = 3000;

			Console.SetWindowSize(80, 35);
			Console.SetBufferSize(80, 35);

			Console.WriteLine($"\n\n{first}{second}{third}{fourth}{fifth}\n\n\n");
			
			string indents = "\t\t";
			Thread.Sleep(timeout);
			Console.ForegroundColor = ConsoleColor.Yellow;
			Console.Write($"{indents}{first} {indents}{second} {indents}{third} {indents}{third} {indents}{fifth}\n\n\n\n");
			
			indents = "\t\t\t\t";
			Thread.Sleep(timeout);
			Console.ForegroundColor = ConsoleColor.Magenta;
			Console.WriteLine("{0}{1} {0}{2} {0}{3} {0}{4} {0}{5}\n\n\n",
							  indents, first, second, third,
							  fourth, fifth);

			Console.ReadKey();
		}
	}
}
