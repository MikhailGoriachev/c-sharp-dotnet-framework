﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.SetWindowSize(80, 35);


            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("  |\\_/|   ****************************  (\\_/) " +
                             "\n / @ @ \\  *                          * (='.'=)" +
                             "\n( > o < ) *      Hallo C# world!     * (\")_(\")" +
                             "\n '>>x<<'  *                          *        " +
                             "\n  / O \\   ****************************        ");


            Thread.Sleep(3_000);


            Console.SetCursorPosition(0, 15);
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("\n\t\t  |\\_/|   ****************************  (\\_/) " +
                             "\n\t\t / @ @ \\  *                          * (='.'=)" +
                             "\n\t\t( > o < ) *      Hallo C# world!     * (\")_(\")" +
                             "\n\t\t '>>x<<'  *                          *        " +
                             "\n\t\t  / O \\   ****************************        ");



            Thread.Sleep(3_000);



            Console.SetCursorPosition(0, 28);
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n\t\t\t\t    |\\_/|   ****************************  (\\_/) " +
                              "\n\t\t\t\t   / @ @ \\  *                          * (='.'=)" +
                              "\n\t\t\t\t  ( > o < ) *      Hallo C# world!     * (\")_(\")" +
                              "\n\t\t\t\t   '>>x<<'  *                          *        " +
                              "\n\t\t\t\t    / O \\   ****************************        ");

            Console.ReadKey();

        }
    }
}
