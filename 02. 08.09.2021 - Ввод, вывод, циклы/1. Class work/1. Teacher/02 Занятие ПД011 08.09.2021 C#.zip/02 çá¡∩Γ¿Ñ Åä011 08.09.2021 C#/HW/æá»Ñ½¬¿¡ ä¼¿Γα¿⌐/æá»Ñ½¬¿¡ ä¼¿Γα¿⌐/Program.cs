﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Сапелкин_Дмитрий
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.Title = "Домашнее Задание";


			string msg = @"  |\_/|   ****************************   (\_/) " + "\r\n";
			string msg1 = @" / @ @ \  * ""Purrrfectly pleasant""   * (= '.' =) " + "\r\n";
			string msg2 = @"( > o < ) *       Poppy Prinz        *  ("")_("") " + "\r\n";
			string msg3 = @" '>>x<<'  *   (pprinz@example.com)   * " + "\r\n";
			string msg4 = @"  / O \   **************************** " + "\r\n";



		


			// Задать размер окна консоли, цвет символа и фона
			Console.SetWindowSize(80, 35);
			Console.ForegroundColor = ConsoleColor.Green;
			Console.BackgroundColor = ConsoleColor.Black;
			Console.Clear();

			



			// позиционирование в окне

			//Сверху слева
			Console.Write(msg);
			Console.Write(msg1);
			Console.Write(msg2);
			Console.Write(msg3);
			Console.Write(msg4);
			Thread.Sleep(1500);
			Console.Clear();


			//По центру
			Console.ForegroundColor = ConsoleColor.White;
			Console.SetCursorPosition(20, 17);
			Console.Write(msg);
			Console.SetCursorPosition(20, 18);
			Console.Write(msg1);
			Console.SetCursorPosition(20, 19);
			Console.Write(msg2);
			Console.SetCursorPosition(20, 20);
			Console.Write(msg3);
			Console.SetCursorPosition(20, 21);
			Console.Write(msg4);
			Thread.Sleep(1500);
			Console.Clear();

			//Снизу справа
			Console.ForegroundColor = ConsoleColor.Yellow;
			Console.SetCursorPosition(33, 31);
			Console.Write(msg);
			Console.SetCursorPosition(33, 32);
			Console.Write(msg1);
			Console.SetCursorPosition(33, 33);
			Console.Write(msg2);
			Console.SetCursorPosition(33, 34);
			Console.Write(msg3);
			Console.SetCursorPosition(33, 35);
			Console.Write(msg4);
			Thread.Sleep(1500);
			Console.Clear();




			Console.Write("Нажмите любую клавишу для продолжения");
			Console.ReadKey();
		}
	}
}
