﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HW_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //установка размера окна консоли
            Console.SetWindowSize(80, 35);
            //изменение цвета символов
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            //сам вывод
            Console.WriteLine("  |\\_/|   ****************************  (\\_/)   ");
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ");
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\")  ");
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   *            ");
            Console.WriteLine("  / O \\   ****************************           ");
            //пауза 
            Thread.Sleep(3_000);
            //очистка консоли
            Console.Clear();

            //изменение позиции курсора
            Console.SetCursorPosition(16, 12);
            //изменение цвета символов
            Console.ForegroundColor = ConsoleColor.DarkRed;
            //сам вывод
            Console.WriteLine("  |\\_/|   ****************************  (\\_/)   ");
            Console.SetCursorPosition(16, 13);
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ");
            Console.SetCursorPosition(16, 14);
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\")  ");
            Console.SetCursorPosition(16, 15);
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   *            ");
            Console.SetCursorPosition(16, 16);
            Console.WriteLine("  / O \\   ****************************           ");
            //пауза 
            Thread.Sleep(3_000);
            //очистка консоли
            Console.Clear();

            Console.SetCursorPosition(Console.WindowWidth - 48, Console.WindowHeight - 5);
            //изменение цвета символов
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("  |\\_/|   ****************************  (\\_/)   ");
            Console.SetCursorPosition(Console.WindowWidth - 48, Console.WindowHeight - 4);
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ");
            Console.SetCursorPosition(Console.WindowWidth - 48, Console.WindowHeight - 3);
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\")  ");
            Console.SetCursorPosition(Console.WindowWidth - 48, Console.WindowHeight - 2);
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   *            ");
            Console.SetCursorPosition(Console.WindowWidth - 48, Console.WindowHeight - 1);
            Console.WriteLine("  / O \\   ****************************           ");
            //пауза 
            Thread.Sleep(3_000);
            //очистка консоли
            Console.Clear();

        }
    }
}
