﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = " |\\_/|    **************************   (\\_/)\n";
            string b = " / @ @ \\   *  \"Purrrfectly pleasant\"*  (='.'=)\n";
            string c = "( > o < )  *       Poppy Prinz      *  (\")_(\")\n";
            string d = " '>>x<<'   *   (pprinz@example.com) *   \n";
            string e = "  / O \\    **************************\n";

            Console.SetWindowSize(80, 35);
            Console.BackgroundColor=ConsoleColor.Blue;
            Console.Clear();
            Console.SetCursorPosition(9, 5);
            Console.ForegroundColor = ConsoleColor.White;
            Thread.Sleep(3000);

            Console.WriteLine($"{a}, \t{b}, \t{c}, \t{d}, \t{e}");

            Console.SetCursorPosition(17, 15);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Thread.Sleep(3000);

            Console.WriteLine($"{a}, \t\t{b}, \t\t{c}, \t\t{d}, \t\t{e}");

            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.DarkRed;

            Console.WriteLine("\n\n\n");
            Thread.Sleep(3000);
            Console.WriteLine($"\t\t\t {a}, \t\t\t{b}, \t\t\t{c}, \t\t\t{d}, \t\t\t{e}"); 

        }
    }
}
