﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace H_W1C_
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.SetWindowSize(80, 35);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.Black;

            // объектный тип string
            string msg = "\n\n\t\t\tHello, C#!\n\n\n";


            Console.Write(msg);

            Thread.Sleep(1_000);

            Console.WriteLine("\n\n\t     |\\_ /|   ****************************   (\\_ /)");
            Console.WriteLine("\t    / @ @ \\   *  \"Purrrfectly pleasant\"  *  (='.'=)");

            Thread.Sleep(3_000);

            Console.WriteLine("\t   ( > o < )  *        Poppy Prinz       *  (\")_(\")");

            Thread.Sleep(3_000);

            Console.WriteLine("\t    '>>x<<'   *  (pprinz@example.com)    *");
            Console.WriteLine("\t     / O \\    ****************************");

          
            Console.SetCursorPosition(0, Console.WindowHeight - 1);
        }
    }
}
