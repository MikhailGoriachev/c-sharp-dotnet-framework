﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;         // Для Thread.Sleep()

/*
 * Задание по C#.
 * Разработайте консольное приложение .Net Framework для решения следующей
 * задачи. Код решения разместите в статическом методе Main() класса Program.
 * Используйте возможности консоли по работе с цветом, позиционирование
 * курсора.
 * Установите размер окна консоли 80 символов на 35 строк. Выведите
 * ASCII-картинку, приведенную ниже (и в файле ascii_art.txt) в верхней левой
 * части консоли, по центру консоли, в нижней правой части консоли.
 * Не применяйте вычислений, циклов, методов – в этом задании просто хард-код
 * 😊 вспомните первые задания базового семестра 😊
 * Перед вторым и третьим выводом сделайте паузу в 3 секунды, для каждого
 * рисунка изменяйте цвет символов (можно и цвет фона).
 * 
 *   |\_/|   ****************************  (\_/) 
 *  / @ @ \  *  "Purrrfectly pleasant"  * (='.'=) 
 * ( > o < ) *       Poppy Prinz        * (")_(") 
 *  '>>x<<'  *   (pprinz@example.com)   * 
 *   / O \   ****************************
 * 
 */
namespace ConsoleOutput
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 08.09.2021 - простой вывод в консоль";

            // Установить размер окна консоли 80 символов на 35 строк
            Console.WindowWidth = 80;
            Console.WindowHeight = 35;
            
            // Исходная цветовая палитра консоли
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();

            // Вывести ASCII-art в левый верхний угол
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(0, 0); Console.Write("                                                      ");
            Console.SetCursorPosition(0, 1); Console.Write("      |\\_/|   ****************************  (\\_/)     "); 
            Console.SetCursorPosition(0, 2); Console.Write("     / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=)    ");
            Console.SetCursorPosition(0, 3); Console.Write("    ( > o < ) *       Poppy Prinz        * (\")_(\")    ");
            Console.SetCursorPosition(0, 4); Console.Write("     '>>x<<'  *   (pprinz@example.com)   *            ");
            Console.SetCursorPosition(0, 5); Console.Write("      / O \\   ****************************            ");
            Console.SetCursorPosition(0, 6); Console.Write("                                                      ");

            // Пауза в 3 с перед выводом второй картинки
            Thread.Sleep(3_000);

            // Вывести ASCII-art по центру окна консоли
            // т.к. известно, что размер окна консоли - 35 строк, нумерация строк начинается с 0,
            // количество выводимых строк - 5 (из файла ascii_art.txt), и еще 2 строки для полей,
            // то верхняя строка картинки для вывода по центру -> (35 - 7 - 2)/2 ~~ 15
            // Ширина самой широкой строки картинки - 47 символов (из файла ascii_art.txt) --> отсюда 
            // определяем позицию в строке для вывода в центре окна консоли, напоминаю, что
            // ширина окна консоли - известна, и равна 80 символам, а ширина полей равна 8,
            // тогда (80 - 47 - 8) / 2 = 25 / 2  = 12
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.SetCursorPosition(12, 15); Console.Write("                                                      ");
            Console.SetCursorPosition(12, 16); Console.Write("      |\\_/|   ****************************  (\\_/)     "); 
            Console.SetCursorPosition(12, 17); Console.Write("     / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=)    ");
            Console.SetCursorPosition(12, 18); Console.Write("    ( > o < ) *       Poppy Prinz        * (\")_(\")    ");
            Console.SetCursorPosition(12, 19); Console.Write("     '>>x<<'  *   (pprinz@example.com)   *            ");
            Console.SetCursorPosition(12, 20); Console.Write("      / O \\   ****************************            ");
            Console.SetCursorPosition(12, 21); Console.Write("                                                      ");

            // Пауза в 3 с перед выводом третьей картинки
            Thread.Sleep(3_000);

            // Вывести ASCII-art в правом нижнем углу окна консоли
            // т.к. известно, что размер окна консоли - 35 строк, а нумерация строк начинается с 0,
            // нижняя строка картинки должна быть в строке 34 -> начинаем ввод номеров с последней
            // строки, и поднимаемся при вводе кода вверх, уменьшая номера строк
            // Ширина самой широкой строки картинки - 47 символов (из файла ascii_art.txt) и еще 8
            // символов для полей --> отсюда 
            // определяем позицию в строке для вывода в правом углу окна консоли, напоминаю, что
            // ширина окна консоли - известна, и равна 80 символам: 80 - (47 + 8) = 25
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(26, 28); Console.Write("                                                      ");
            Console.SetCursorPosition(26, 29); Console.Write("      |\\_/|   ****************************  (\\_/)     "); 
            Console.SetCursorPosition(26, 30); Console.Write("     / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=)    ");
            Console.SetCursorPosition(26, 31); Console.Write("    ( > o < ) *       Poppy Prinz        * (\")_(\")    ");
            Console.SetCursorPosition(26, 32); Console.Write("     '>>x<<'  *   (pprinz@example.com)   *            ");
            Console.SetCursorPosition(26, 33); Console.Write("      / O \\   ****************************            ");
            Console.SetCursorPosition(26, 34); Console.Write("                                                      ");
            
            // курсор в левый нижний угол консоли, восстановим цвет символов,
            // ожидаем нажатия любой клавиши
            Console.SetCursorPosition(0, Console.WindowHeight-1);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ReadKey(false);
            Console.Clear();
        } // Main
    } // class Program
}
