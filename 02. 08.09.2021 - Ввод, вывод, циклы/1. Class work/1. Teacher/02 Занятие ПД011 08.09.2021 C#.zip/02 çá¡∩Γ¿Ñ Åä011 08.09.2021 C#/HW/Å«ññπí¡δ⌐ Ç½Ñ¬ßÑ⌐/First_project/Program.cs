﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace First_project
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Первое приложение C#";
            Console.SetWindowSize(80, 35);

            string s1, s2, s3, s4, s5;

            s1 = "    |\\_/|   ****************************  (\\_/)    ";
            s2 = "   / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=)   ";
            s3 = "  ( > o < ) *       Poppy Prinz        * (\")_(\")   ";
            s4 = "   '>>x<<'  *   (pprinz@example.com)   *           ";
            s5 = "    / O \\   ****************************           ";

            ConsoleColor foreColor = Console.ForegroundColor;
            ConsoleColor backColor = Console.BackgroundColor;

            Console.ForegroundColor = ConsoleColor.Red;
            Console.BackgroundColor = ConsoleColor.DarkBlue;

            Console.WriteLine(s1);
            Console.WriteLine(s2);
            Console.WriteLine(s3);
            Console.WriteLine(s4);
            Console.WriteLine(s5);

            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.DarkCyan;

            Thread.Sleep(1_000);

            Console.SetCursorPosition((Console.WindowWidth - s1.Length) / 2, Console.WindowHeight / 2-2);
            Console.WriteLine(s1);
            Console.SetCursorPosition((Console.WindowWidth - s2.Length) / 2, Console.WindowHeight / 2-1);
            Console.WriteLine(s2);
            Console.SetCursorPosition((Console.WindowWidth - s2.Length) / 2, Console.WindowHeight / 2 );
            Console.WriteLine(s3);
            Console.SetCursorPosition((Console.WindowWidth - s2.Length) / 2, Console.WindowHeight / 2 +1);
            Console.WriteLine(s4);
            Console.SetCursorPosition((Console.WindowWidth - s2.Length) / 2, Console.WindowHeight / 2+2 );
            Console.WriteLine(s5);

            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Cyan;

            Thread.Sleep(1_000);


            Console.SetCursorPosition((Console.WindowWidth - s1.Length) ,Console.WindowHeight - 5);
            Console.WriteLine(s1);
            Console.SetCursorPosition((Console.WindowWidth - s2.Length) ,Console.WindowHeight - 4);
            Console.WriteLine(s2);
            Console.SetCursorPosition((Console.WindowWidth - s2.Length) ,Console.WindowHeight - 3);
            Console.WriteLine(s3);
            Console.SetCursorPosition((Console.WindowWidth - s2.Length) ,Console.WindowHeight - 2);
            Console.WriteLine(s4);
            Console.SetCursorPosition((Console.WindowWidth - s2.Length) ,Console.WindowHeight - 1);
            Console.WriteLine(s5);

            Console.ForegroundColor = foreColor;
            Console.BackgroundColor = backColor;
        }
    }
}
