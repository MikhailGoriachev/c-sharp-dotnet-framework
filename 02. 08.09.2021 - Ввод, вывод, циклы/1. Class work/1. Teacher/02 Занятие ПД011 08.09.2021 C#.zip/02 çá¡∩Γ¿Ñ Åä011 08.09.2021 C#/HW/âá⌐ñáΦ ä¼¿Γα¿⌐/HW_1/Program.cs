﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HW_1{
    class Program    {
        static void Main(string[] args)        {
            Console.Title = "HW";
            Console.SetWindowSize(80, 35);
            Console.SetCursorPosition(0, 0);
            Console.WriteLine("  |\\_/|   ****************************  (\\_/) ");
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ");
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\") ");
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   * ");
            Console.WriteLine("  / O \\   ****************************\n");

            // Thread.Sleep(3_000);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.SetCursorPosition(15, 15);
            Console.WriteLine("  |\\_/|   ****************************  (\\_/) ");
            Console.SetCursorPosition(15, 16);
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ");
            Console.SetCursorPosition(15, 17);
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\") ");
            Console.SetCursorPosition(15, 18);
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   * ");
            Console.SetCursorPosition(15, 19);
            Console.WriteLine("  / O \\   ****************************\n");

            // Thread.Sleep(3_000);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.SetCursorPosition(33, 29);
            Console.WriteLine("  |\\_/|   ****************************  (\\_/) ");
            Console.SetCursorPosition(33, 30);
            Console.WriteLine(" / @ @ \\  *  \"Purrrfectly pleasant\"  * (='.'=) ");
            Console.SetCursorPosition(33, 31);
            Console.WriteLine("( > o < ) *       Poppy Prinz        * (\")_(\") ");
            Console.SetCursorPosition(33, 32);
            Console.WriteLine(" '>>x<<'  *   (pprinz@example.com)   * ");
            Console.SetCursorPosition(33, 33);
            Console.WriteLine("  / O \\   ****************************\n");
        }
    }
}
