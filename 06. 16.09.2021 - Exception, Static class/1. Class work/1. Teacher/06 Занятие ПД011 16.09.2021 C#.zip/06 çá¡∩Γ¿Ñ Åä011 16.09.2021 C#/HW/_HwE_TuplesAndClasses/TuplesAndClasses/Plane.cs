﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuplesAndClasses
{
    /* 
     * Класс Самолет со следующими полными свойствами:
     * 	   › производитель и тип самолета (это одно свойство, например: Ил-76, 
     * 	     Boeing 747, …)
     * 	   › количество пассажирских мест (целое число)
     * 	   › расход горючего за час полета (вещественное число)
     * 	   › количество двигателей (целое число)
     * 	   › название авиакомпании – владельца
     * Компараторы для сортировки:
     * 	   › по свойству производитель и тип (!!! это одно свойство !!!)
     * 	   › по убыванию количества двигателей
     *     › по возрастанию расхода горючего за час полета
     * Методы для вывода данных в строку, в табличном формате    
     */
    public class Plane
    {
        // производитель и тип самолета
        private string _manufacturerAndType;
        public string BrandAndType {
            get => _manufacturerAndType;
            set => _manufacturerAndType = string.IsNullOrWhiteSpace(value)?"Noname X-1":value;
        } // BrandAndType


        // количество пассажирских мест
        private int _paxCapacity;
        public int PaxCapacity {
            get => _paxCapacity;
            set => _paxCapacity = value < 0?0:value;
        } // PaxCapacity


        // расход горючего за час полета
        private double _fuelConsumption;
        public double FuelConsumption {
            get => _fuelConsumption;
            set => _fuelConsumption = value <= 0?1:value;
        } // FuelConsumption


        // количество двигателей
        private int _engines;
        public int Engines {
            get => _engines;
            set => _engines = value <= 0?1:value;
        } // Engines

        // название авиакомпании – владельца
        private string _owner;
        public string Owner {
            get => _owner;
            set => _owner = string.IsNullOrWhiteSpace(value)?"Bee":value;
        } // Owner


        // Компаратор для сортировки по свойству производитель
        // и тип самолета (!!! это одно свойство !!!)
        public static int BrandAndTypeComparer(Plane p1, Plane p2) =>
            p1._manufacturerAndType.CompareTo(p2.BrandAndType);


        // Компаратор для сортировки по убыванию количества двигателей
        public static int EnginesDescendComparer(Plane p1, Plane p2) => 
            p2._engines.CompareTo(p1._engines);


        // Компаратор для сортировки по возрастанию расхода горючего
        // за час полета
        public static int FuelConsumptionComparator(Plane p1, Plane p2) =>
            p1._fuelConsumption.CompareTo(p2._fuelConsumption);


        // формирование строкового представления объекта 
        public override string ToString() =>
            $"{_manufacturerAndType}, пассажиров {_paxCapacity}; двигаталей {_engines}; " +
            $"расход горючего {_fuelConsumption:f2} кг/ч; компания-владелец: {_owner}";


        // формирование строки таблицы для представления объекта 
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber, 3} │ {_manufacturerAndType, -18} │ {_paxCapacity, 8}    " +
            $"│ {_engines, 6}     │ {_fuelConsumption, 13:f2} │ {_owner, -16} │";

        // статический метод для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬────────────────────┬─────────────┬────────────┬───────────────┬──────────────────┐\n" +
                $"{spaces}│  №  │ Производитель      │ Пассажиро-  │ Количество │ Расход горюч. │ Компания         │\n" +
                $"{spaces}│ п/п │     и тип самолета │ вместимость │ двигателей │ за час, кг/ч  │         владелец │\n" +
                $"{spaces}├─────┼────────────────────┼─────────────┼────────────┼───────────────┼──────────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴────────────────────┴─────────────┴────────────┴───────────────┴──────────────────┘";
    } // class Plane
}
