﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuplesAndClasses
{
    // класс, представляющий координату точки
    public class Coord
    {
        public double X { get; set; }
        public double Y { get; set; }

        // переопределение строкового представления
        public override string ToString() => $"({X, 7:f3}; {Y, 7:f3})";
    } // class Coord
}
