﻿using System;

namespace TuplesAndClasses
{
    
    // Объекты и методы для обработки по заданию
    public class App {
        private Airport _airport;   // объект для аэропорта

        // в конструкторе по умолчанию будем создатавать объект
        // с полями по умолчанию
        public App() : this(new Airport()) { } // App

        // конструктор с внедрением зависимостей/ dependency injection
        public App(Airport airport) {
            _airport = airport;
        } // App

        // Методы для обработок по заданию
        // ---------------------------------------------------------------

        // Решение задачи Proc3
        // С помощью метода tuplesDemo.Mean(x, y) найти среднее арифметическое  
        // и среднее геометрическое для трех пар случайных чисел из диапазона 
        // значений [0, 10]
        public void Proc3(int n = 3, double lo = 0, double hi = 10) {
            Utils.ShowNavBarTask("  Решение задачи Proc3");

            Console.WriteLine("\n\n\n\n\t    Задача Proc3. С использование кортежей\n" +
              "\t    ┌─────┬────────────────┬────────────────┬────────────────┬────────────────┐\n" +
              "\t    │  №  │    Число 1     │    Число 2     │     Среднее    │    Среднее     │\n" +
              "\t    │ п/п │                │                │ арифметическое │ геометрическое │\n" +
              "\t    ├─────┼────────────────┼────────────────┼────────────────┼────────────────┤");

            for (int i = 1; i <= n; i++) {
                // кортеж - для компактной инициализации
                (double x, double y) = (Utils.GetRandom(lo, hi), Utils.GetRandom(lo, hi));

                // принимаем кортеж из метода Mean в переменные
                (double aMean, double gMean) = TuplesDemo.Mean(x, y);
                Console.WriteLine($"\t    │ {i, 3} │ {x, 14:f3} │ {y, 14:f3} │ {aMean, 14:f3} │ {gMean, 14:f3} │");
            } // for i

            Console.WriteLine("\t    └─────┴────────────────┴────────────────┴────────────────┴────────────────┘");

        } // Proc3

        // Решение задачи Proc5
        // С помощью метода TuplesDemo.RectPS() найти периметры и площади 
        // трех прямоугольников с данными противоположными вершинами.
        public void Proc5(int n = 3, double lo = -10, double hi = 10) {
            Utils.ShowNavBarTask("  Решение задачи Proc5");

            Console.WriteLine("\n\n\n\n\t    Задача Proc5. Использование кортежей классов\n" +
                "\t    ┌─────┬────────────────────┬────────────────────┬────────────────┬────────────────┐\n" +
                "\t    │  №  │     Вершина 1      │     Вершина 2      │    Периметр    │    Площадь     │\n" +
                "\t    │ п/п │   прямоугольника   │   прямоугольника   │ прямоугольника │ прямоугольника │\n" +
                "\t    ├─────┼────────────────────┼────────────────────┼────────────────┼────────────────┤"
            );


            for (int i = 1; i <= n; i++) {
                // получить координаты вершин прямоугольника
                Coord p1 = new Coord { X = Utils.GetRandom(lo, hi), Y = Utils.GetRandom(lo, hi) };
                Coord p2 = new Coord { X = Utils.GetRandom(lo, hi), Y = Utils.GetRandom(lo, hi) };

                // кортеж из метода помещаем в переменные p (периметр), a (площадь)
                (double p, double a) = TuplesDemo.RectPS(p1, p2); 
                Console.WriteLine($"\t    │ {i,3} │ {p1,16} │ {p2,16} │ {p,14:f3} │ {a,14:f3} │");
            } // for i

            Console.WriteLine("\t    └─────┴────────────────────┴────────────────────┴────────────────┴────────────────┘");
        } // Proc5



        // ---------------------------------------------------------------

        // Формирование объекта аэропорта
        public void AirportInitialize() {
            Utils.ShowNavBarTask("  Формирование объекта аэропорта");
            
            _airport.Initialize();
            _airport.Show("Данные аэропорта сформированы", 12);
        } // AirportInitialize

        

        // Вывод данных аэропорта в табличном формате
        public void ShowAirport() {
            Utils.ShowNavBarTask("  Вывод данных аэропорта в табличном формате");

            _airport.Show("Данные аэропорта для обработки", 12);
        } // ShowConoids
        
        
        
        // Вывод самолетов с максимальным количеством пассажиров
        public void ShowMostCapacities() {
            Utils.ShowNavBarTask("  Вывод самолетов с максимальным количеством пассажиров");
            
            Plane[] theMostCapacities = _airport.SelectMostCapacity();
            _airport.Show("Отобраны самые вместительные самолеты", 12, theMostCapacities);
        } // ShowMostCapacities


        // Сортировка самолетов по производителю и типу
        public void DemoOrderByBrandAndType() {
            Utils.ShowNavBarTask("  Сортировка самолетов по производителю и типу");
            
            _airport.OrderByBrandAndType();
            _airport.Show("Коллекция самолетов, упорядоченная по производителю и типу", 12);
        } // DemoOrderByBrandAndType

        // Сортировка самолетов по убыванию количества двигателей
        public void DemoOrderByEnginesDesc() {
            Utils.ShowNavBarTask("  Сортировка самолетов по убыванию количества двигателей");
            
            _airport.OrderByEnginesDesc();
            _airport.Show("Коллекция самолетов, упорядоченная по убыванию количества двигателей", 12);
        } // DemoOrderByWeightDesc

        // Сортировка самолетов по возрастанию расхода горючего за час полета
        public void DemoOrderByFuelConsumption() {
            Utils.ShowNavBarTask("  Сортировка самолетов по возрастанию расхода горючего за час полета");
            
            _airport.OrderByFuelConsumption();
            _airport.Show("Коллекция самолетов, упорядоченная по возрастанию расхода горючего за час полета", 12);
        } // DemoOrderByHeight
        
    } // class App
}