﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuplesAndClasses
{
    // класс для хранения и обработки массива самолетов 
    public class Airport
    {
        // название аэропорта
        private string _title;
        public string Title {
            get { return _title; }
            set { _title = string.IsNullOrWhiteSpace(value)?"Донецк":value; }
        } // Title

        // самолеты аэропорта, делаем невозможным изменение
        // коллекции при помощи сеттера
        private Plane[] _planes;
        public Plane[] planes
        {
            get => _planes;
            private set => _planes = value;
        } // Planes


        // конструкторы для класса 
        public Airport():this("Новый Свет", new Plane[12]) {
            Initialize();
        } // Airport

        public Airport(string title, Plane[] planes) {
            _title = title;
            _planes = planes;
        } // Airport



        // методы для обработки по заданию

        // заполнение массива самолетов начальными значениями
        public void Initialize()
        {
            // массив для поллучения данных заполнения массива самолетов, размер этого массива
            Plane[] seeds = new [] {
                new Plane {BrandAndType = "Ту-154Б3",          PaxCapacity = 121, FuelConsumption =  818.9, Engines = 3, Owner = "S7 Airlines" },
                new Plane {BrandAndType = "Ил-96-400",         PaxCapacity = 380, FuelConsumption = 1432.2, Engines = 4, Owner = "Победа" },
                new Plane {BrandAndType = "Sukhoi SSJ-100-90", PaxCapacity =  95, FuelConsumption =  456.1, Engines = 2, Owner = "Qatar Airlines" },
                new Plane {BrandAndType = "Як42Д-М2",          PaxCapacity = 100, FuelConsumption = 1100.0, Engines = 3, Owner = "Райн-аваиа" },
                new Plane {BrandAndType = "Boeing B-747-800",  PaxCapacity = 546, FuelConsumption = 1277.2, Engines = 4, Owner = "Аэрофлот" },
                new Plane {BrandAndType = "Airbus A380-700",   PaxCapacity = 652, FuelConsumption = 1231.1, Engines = 4, Owner = "Fly Dubai" }
            };                                                 
            int lenSeeds = seeds.Length;

            // заполнение массива самолетов аэропорта начальными данными
            for (int i = 0; i < _planes.Length; i++) {
                _planes[i] = seeds[Utils.Random.Next(0, lenSeeds)];
            } // for i
        } // Initialize


        // возвращает максимальное количество пассажиров в массиве самолетов 
        public int MaxPaxCapacity() {
            int max = _planes[0].PaxCapacity;
            for (int i = 1; i < _planes.Length; i++) {
                int t = _planes[i].PaxCapacity;
                if (t > max) max = t;
            } // for i

            return max;
        } // MaxPaxCapacity

        // выборка самолетов с максимальным количеством пассажирских мест
        public Plane[] SelectMostCapacity() {
            
            // получить максимальное количество пассажиров
            int maxPaxCapacity = MaxPaxCapacity();

            // предикат для поиска самолетов с максимальной пассажировместимости
            bool IsMaxPaxCapacity(Plane plane) => plane.PaxCapacity == maxPaxCapacity;
            
            // собственно выборка самолетов с максимальной пассажировместимости
            return Array.FindAll(_planes, IsMaxPaxCapacity);
        } // SelectMostCapacity

        // сортировка массива самолетов по свойству производитель и тип (!!! это одно свойство !!!)
        public void OrderByBrandAndType() => Array.Sort(_planes, Plane.BrandAndTypeComparer);

        // сортировка массива самолетов по убыванию количества двигателей
        public void OrderByEnginesDesc() => Array.Sort(_planes, Plane.EnginesDescendComparer);

        // сортировка массива самолетов по возрастанию расхода горючего за час полета
        public void OrderByFuelConsumption() => Array.Sort(_planes, Plane.FuelConsumptionComparator);


        // Вывести данные аэропорта в консоль
        public void Show(string caption, int indent) {
            // вывод заголовка таблицы данных самолетов аэропорта
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Plane.Header(indent)}");

            // вывод всех элементов массива самолетов
            int row = 1;
            void OutItem(Plane p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(_planes, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Plane.Footer(indent));
        } // Show


        // Вывести массив отобранных самолетов в консоль.
        public void Show(string caption, int indent, Plane[] planes) {
            // вывод заголовка таблицы самолетов
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Plane.Header(indent)}");

            // вывод всех элементов массива самолетов
            int row = 1;
            void OutItem(Plane p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(planes, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Plane.Footer(indent));
        } // Show
    } // class Airport
}
