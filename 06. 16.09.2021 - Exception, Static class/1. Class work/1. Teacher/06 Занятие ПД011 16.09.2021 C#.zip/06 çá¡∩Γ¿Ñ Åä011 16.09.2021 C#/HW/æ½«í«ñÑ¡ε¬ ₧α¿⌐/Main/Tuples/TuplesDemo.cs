﻿using System;


namespace Main.Tuples
{
	public static class TuplesDemo
	{
		public static (double aMean, double gMean) Mean(double x, double y) =>
			(aMean: (x + y) / 2, gMean: Math.Sqrt(x * y));


		public static (double area, double perimeter) RectPs(
			(double x1, double y1) firstPoint, (double x2, double y2) secondPoint)
		{
			double a = Math.Abs(secondPoint.x2 - firstPoint.x1);
			double b = Math.Abs(secondPoint.y2 - firstPoint.y1);

			return (area: a * b, perimeter: a + a + b + b);
		}
	}
}
