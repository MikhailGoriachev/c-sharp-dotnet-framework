﻿using System;
using Main.Utilities;


namespace Main.Tuples
{
	public class TuplesMenu : MenuWrapper
	{
		public TuplesMenu() => Menu = new Menu("Главное меню приложения", new[]
		{
			new Menu.MenuItem
				("Proc3. Описать метод Mean(x, y), вычисляющую среднее арифметическое", Proc3Demo),
			new Menu.MenuItem
				("Proc5. Описать метод RectPs(x1, y1, x2, y2), вычисляющую среднее геометрическое", Proc5Demo)
		});


		public int    Size     => General.Rand.Next(10, 18);
		public double Generate => General.Rand.RealNextDouble(0, 10);


		private (double x, double y)[] MakeArrayOfPoints()
		{
			var returned = new (double x, double y)[Size];

			for (int i = 0; i < returned.Length; i++)
				returned[i] = (Generate, Generate);

			return returned;
		}


		/// Описать метод Mean(x, y), вычисляющую среднее арифметическое a_mean=(x+y)/2 и
		/// среднее геометрическое g_mean=√(x∙y), двух положительных вещественных чисел x и y.
		/// Возвращать a_mean, g_mean из метода в кортеже. С помощью этого метода найти среднее
		/// арифметическое и среднее геометрическое для трех пар случайных чисел из диапазона значений [0, 10].
		private void Proc3Demo()
		{
			var points = MakeArrayOfPoints();

			void PointAsTable((double x, double y) point)
			{
				(double aMean, double gMean) = TuplesDemo.Mean(point.x, point.y);

				Console.WriteLine($"│ {point.x,-13:N3} │ {point.y,-13:N3} │ {aMean,-17:N6} │ {gMean,-17:N6} │");
			}

			Console.WriteLine("┌───────────────┬───────────────┬───────────────────┬───────────────────┐");
			Console.WriteLine("│       X       │       Y       │      A Mean       │      G Mean       │");
			Console.WriteLine("├───────────────┼───────────────┼───────────────────┼───────────────────┤");
			Array.ForEach(points, PointAsTable);
			Console.WriteLine("└───────────────┴───────────────┴───────────────────┴───────────────────┘");
		}


		private (double x, double y)[,] MakeMatrixOfPoints()
		{
			var returned = new (double x, double y)[2, Size];

			for (int i = 0; i < returned.GetLength(0); i++)
				for (int j = 0; j < returned.GetLength(1); j++)
					returned[i, j] = (Generate, Generate);

			return returned;
		}


		/// Описать метод RectPS(x1, y1, x2, y2), вычисляющую периметр и площадь прямоугольника
		/// со сторонами, параллельными осям координат, по координатам (x1, y1), (x2, y2) его
		/// противоположных вершин (стороны вычисляются как a = Math.Abs(x2 - x1), b = Math.Abs(y2 – y1)).
		/// Метод возвращает кортеж с периметром и площадью. С помощью этого метода найти периметры и
		/// площади трех прямоугольников с данными противоположными вершинами.
		private void Proc5Demo()
		{
			var points = MakeMatrixOfPoints();

			Console.WriteLine("┌─────────────┬─────────────┬─────────────┬─────────────┬───────────────────┬───────────────────┐");
			Console.WriteLine("│      X1     │      Y1     │      X2     │      Y2     │       Area        │     Perimiter     │");
			Console.WriteLine("├─────────────┼─────────────┼─────────────┼─────────────┼───────────────────┼───────────────────┤");
			for (int i = 0; i < points.GetLength(1); i++)
			{
				(double x1, double y1)          = points[0, i];
				(double x2, double y2)          = points[1, i];
				(double area, double perimeter) = TuplesDemo.RectPs((x1, y1), (x2, y2));

				Console.WriteLine($"│ {x1,-11:N3} │ {y1,-11:N3} │ {x2,-11:N3} │ {y2,-11:N3} │ {area,-17:N6} │ {perimeter,-17:N6} │");
			}

			Console.WriteLine("└─────────────┴─────────────┴─────────────┴─────────────┴───────────────────┴───────────────────┘");
		}
	}
}
