﻿using System.Drawing;
using Main.Planes;
using Main.Tuples;
using Main.Utilities;


namespace Main
{
	public class App : MenuWrapper
	{
		private readonly TuplesMenu _tuplesMenu = new TuplesMenu();
		private readonly PlanesMenu _planesMenu = new PlanesMenu();


		public App() => Menu = new Menu("Главное меню приложения", new[]
		{
			new Menu.MenuItem("Задача 1. Обработка кортежей", _tuplesMenu.Run)
				{ IsSimpleInvoke = true },
			new Menu.MenuItem("Задача 2. Обработка самолетов", _planesMenu.Run)
				{ IsSimpleInvoke = true }
		}) {CursorPosition = new Point(20, 7)};
	}
}
