﻿using Main.Utilities;


namespace Main.Planes
{
	public class PlanesMenu : MenuWrapper
	{
		private readonly PlaneArray _planes = new PlaneArray();


		public PlanesMenu() => Menu = new Menu("Главное меню приложения", new[]
		{
			new Menu.MenuItem("Заполнить массив самолетов", Fill),
			new Menu.MenuItem("Вывести массив самолетов", Show),
			new Menu.MenuItem("Вывести массив самолетов с дополнительной информацией", ShowAdvanced),
			new Menu.MenuItem("Упорядочивание по производителю и типу", OrderByMakerAndTypeDescending),
			new Menu.MenuItem("Упорядочивание по убыванию количества двигателей", OrderByEnginesCountDescending),
			new Menu.MenuItem("Упорядочивание по возрастанию расхода горючего за час полета",
							  OrderByFuelByHourAscending)
		});


		/// Заполнить массив самолетов
		private void Fill()
		{
			_planes.Planes = new[]
			{
				new Plane
				{
					AirlineCompany = "Littel, Anderson and Towne", MakerAndType = "Cessna-140",
					EnginesCount   = 2, PassengersSeats                         = 100, FuelByHour = 5000
				},
				new Plane
				{
					AirlineCompany = "Moore, Abshire and Simonis", MakerAndType = "An-12",
					EnginesCount   = 6, PassengersSeats                         = 500, FuelByHour = 50000
				},
				new Plane
				{
					AirlineCompany = "Abernathy Group", MakerAndType = "Bf-110",
					EnginesCount   = 2, PassengersSeats              = 130, FuelByHour = 6000
				},
				new Plane
				{
					AirlineCompany = "Murray, Lubowitz and Johnston", MakerAndType = "Bf-109",
					EnginesCount   = 2, PassengersSeats                            = 125, FuelByHour = 3000
				},
				new Plane
				{
					AirlineCompany = "Cremin, Schaefer and Reilly", MakerAndType = "L-39",
					EnginesCount   = 2, PassengersSeats                          = 200, FuelByHour = 10000
				},
				new Plane
				{
					AirlineCompany = "Reinger-Heller", MakerAndType = "Beechcraft Baron",
					EnginesCount   = 2, PassengersSeats             = 400, FuelByHour = 7000
				},
				new Plane
				{
					AirlineCompany = "Anderson LLC", MakerAndType = "T-38",
					EnginesCount   = 2, PassengersSeats           = 400, FuelByHour = 8500
				},
				new Plane
				{
					AirlineCompany = "Wuckert-Ullrich", MakerAndType = "Mi-17",
					EnginesCount   = 4, PassengersSeats              = 230, FuelByHour = 40000
				},
				new Plane
				{
					AirlineCompany = "Wilkinson, Waters and Shields", MakerAndType = "Dassault Mirage F1",
					EnginesCount   = 6, PassengersSeats                            = 500, FuelByHour = 60000
				},
				new Plane
				{
					AirlineCompany = "Herman-Champlin", MakerAndType = "Il-76",
					EnginesCount   = 4, PassengersSeats              = 345, FuelByHour = 24000
				},
				new Plane
				{
					AirlineCompany = "Lind-Hamill", MakerAndType = "Airbus 319",
					EnginesCount   = 4, PassengersSeats          = 270, FuelByHour = 14000
				},
				new Plane
				{
					AirlineCompany = "Langosh-Carter", MakerAndType = "Tu-95",
					EnginesCount   = 4, PassengersSeats             = 130, FuelByHour = 12700
				}
			};

			Show();
		}


		private void Show() => _planes?.ShowTable();


		private void ShowAdvanced() => _planes?.ShowAdvancedTable();


		/// Упорядочивание по производителю и типу
		private void OrderByMakerAndTypeDescending()
		{
			_planes?.OrderByMakerAndTypeDescending();

			_planes?.ShowTable();
		}


		/// Упорядочивание по убыванию количества двигателей
		private void OrderByEnginesCountDescending()
		{
			_planes?.OrderByEnginesCountDescending();

			_planes?.ShowTable();
		}


		/// Упорядочивание по возрастанию расхода горючего за час полета
		private void OrderByFuelByHourAscending()
		{
			_planes?.OrderByFuelByHourAscending();

			_planes?.ShowTable();
		}
	}
}
