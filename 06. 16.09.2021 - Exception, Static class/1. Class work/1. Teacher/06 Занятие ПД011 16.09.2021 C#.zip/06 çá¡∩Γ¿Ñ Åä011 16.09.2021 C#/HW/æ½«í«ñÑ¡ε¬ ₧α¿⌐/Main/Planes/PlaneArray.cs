﻿using System;
using Main.Utilities;


namespace Main.Planes
{
	public class PlaneArray
	{
		public Plane[] Planes { private get; set; }


		public void ShowTable()
		{
			if (Planes == null) return;

			Plane.ShowHeader();

			foreach (Plane plane in Planes)
				plane.ShowTableRow();

			Plane.ShowFooter();
		}


		public int MaxSeats()
		{
			if (Planes == null) return -1;

			int returned = int.MinValue;

			foreach (Plane plane in Planes)
				if (plane.PassengersSeats > returned)
					returned = plane.PassengersSeats;

			return returned;
		}


		public void ShowAdvancedTable()
		{
			if (Planes == null) return;

			int maxSeats = MaxSeats();

			Plane.ShowHeader();

			foreach (Plane plane in Planes)
			{
				if (plane.PassengersSeats == maxSeats)
					Palette.AccentDedicated.AsCurrent();

				plane.ShowTableRow();

				Palette.Default.AsCurrent();
			}

			Plane.ShowFooter();

			Console.WriteLine($"Максимальное количество пассажирский мест: {maxSeats}");
		}


		public void OrderByMakerAndTypeDescending() =>
			Array.Sort(Planes ?? Array.Empty<Plane>(), Plane.CompareByMakerAndTypeDescending);


		public void OrderByEnginesCountDescending() =>
			Array.Sort(Planes ?? Array.Empty<Plane>(), Plane.CompareByEnginesCountDescending);


		public void OrderByFuelByHourAscending() =>
			Array.Sort(Planes ?? Array.Empty<Plane>(), Plane.CompareByFuelByHourAscending);
	}
}
