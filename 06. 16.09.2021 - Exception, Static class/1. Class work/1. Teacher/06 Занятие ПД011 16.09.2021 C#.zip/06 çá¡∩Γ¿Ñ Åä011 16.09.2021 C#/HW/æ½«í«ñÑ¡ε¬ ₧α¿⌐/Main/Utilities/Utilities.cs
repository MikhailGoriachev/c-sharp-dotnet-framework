﻿using System;


namespace Main.Utilities
{
	internal static class Extensions
	{
		public static void ColoredLine(this string message, Color color)
		{
			message.Colored(color);
			Console.WriteLine();
		}


		public static void Colored(this string message, Color color)
		{
			Color old = Color.Instantiate();

			color.AsCurrent();

			Console.Write(message);

			old.AsCurrent();
		}


		public static int Center(this string message, int towardLength) => (towardLength - (message?.Length ?? 0)) / 2;


		public static void Output(this Exception e)
		{
			if (e == null)
				return;

			Console.Clear();

			Console.SetCursorPosition(0, Console.WindowHeight / 3);
			e.ToString().Colored(Palette.Wrong);
			Console.ReadKey(true);

			Console.Clear();
		}


		public static double RealNextDouble(this Random rand, double min, double max) =>
			(rand?.NextDouble() ?? throw new ArgumentNullException(nameof(rand))) * (max - min) + min;
	}


	internal static class General
	{
		public static Random Rand { get; } = new Random();


		public static void Pause()
		{
			Console.Write("Нажмите любую клавишу для продолжения...");
			Console.ReadKey(true);
		}


		public static void CursorToBottomAndPause()
		{
			CursorToBottom();
			Pause();
		}


		public static void CursorToBottom() => Console.SetCursorPosition(0, Console.WindowHeight - 1);


		public static void CursorAndPause(int left, int top)
		{
			Console.SetCursorPosition(left, top);
			Pause();
		}
	}


	internal static class Palette
	{
		public static ConsoleColor DefaultForeground          => ConsoleColor.Black;
		public static ConsoleColor DefaultBackground          => ConsoleColor.DarkGray;
		public static ConsoleColor DefaultBackgroundDedicated => ConsoleColor.Gray;


		public static Color Default => new Color
			{ Foreground = DefaultForeground, Background = DefaultBackground };
		public static Color Info => new Color
			{ Foreground = ConsoleColor.Cyan, Background = DefaultBackground };
		public static Color Wrong => new Color
			{ Foreground = ConsoleColor.DarkRed, Background = DefaultBackground };


		public static Color Accent => new Color
			{ Foreground = ConsoleColor.Green, Background = DefaultBackground };
		public static Color AccentDedicated => new Color
			{ Foreground = ConsoleColor.Green, Background = DefaultBackgroundDedicated };


		public static Color Secondary => new Color
			{ Foreground = ConsoleColor.Magenta, Background = DefaultBackground };
		public static Color SecondaryDedicated => new Color
			{ Foreground = ConsoleColor.Magenta, Background = DefaultBackgroundDedicated };


		public static Color Tertiary => new Color
			{ Foreground = ConsoleColor.Yellow, Background = DefaultBackground };
		public static Color TertiaryDedicated => new Color
			{ Foreground = ConsoleColor.DarkYellow, Background = DefaultBackgroundDedicated };
	}


	/// Обертка для цветов консоли
	internal struct Color
	{
		public ConsoleColor Foreground { get; set; }
		public ConsoleColor Background { get; set; }


		public void AsCurrent()
		{
			Console.ForegroundColor = Foreground;
			Console.BackgroundColor = Background;
		}


		public static Color Instantiate() => new Color
			{ Foreground = Console.ForegroundColor, Background = Console.BackgroundColor };
	}
}
