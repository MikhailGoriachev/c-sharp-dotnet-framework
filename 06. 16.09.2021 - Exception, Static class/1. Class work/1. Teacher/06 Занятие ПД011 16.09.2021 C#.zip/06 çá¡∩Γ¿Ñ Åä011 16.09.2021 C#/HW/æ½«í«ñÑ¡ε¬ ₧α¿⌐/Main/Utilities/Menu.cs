﻿using System;
using System.Drawing;
using System.Linq;


namespace Main.Utilities
{
	public sealed class Menu
	{
		public Menu(string title, MenuItem[] items)
		{
			if (items == null)
				throw new ArgumentNullException(nameof(items));
			if (items.Length < 1)
				throw new ArgumentOutOfRangeException(nameof(items), "Размер должен быть >= 1");

			Title          = title ?? throw new ArgumentNullException(nameof(title));
			Items          = items;
			CurrentItem    = 0;
			CursorLength   = Items.Max(item => item.Text.Length);
			CursorPosition = new Point(Console.WindowWidth / CursorLength + 10, 8);
		}


		private string     Title          { get; }
		public  string     DivideLine     { get; set; } = null;
		public  Point      CursorPosition { get; set; }
		private MenuItem[] Items          { get; }
		private int        CurrentItem    { get; set; }
		private int        CursorLength   { get; }


		private void Show()
		{
			Console.CursorVisible = false;

			Console.SetCursorPosition(CursorPosition.X, CursorPosition.Y);
			Title.ColoredLine(Palette.Title);
			Console.WriteLine();

			for (int i = 0; i < Items.Length; i++)
			{
				Console.SetCursorPosition(CursorPosition.X, Console.CursorTop + 1);

				string.Intern($"      {Items[i].Text.PadRight(CursorLength)}     ")
					  .Colored(i == CurrentItem ? Palette.Current : Palette.Normal);

				if (!Items[i].IsDivide)
					continue;

				Console.SetCursorPosition(CursorPosition.X, Console.CursorTop + 1);
				Console.WriteLine(DivideLine);
			}
		}


		private bool Navigate()
		{
			switch (Console.ReadKey(true).Key)
			{
				case ConsoleKey.UpArrow:
					CurrentItem--;
					if (CurrentItem < 0)
						CurrentItem = Items.Length - 1;
					break;
				case ConsoleKey.DownArrow:
					CurrentItem++;
					if (CurrentItem >= Items.Length)
						CurrentItem = 0;
					break;
				case ConsoleKey.Enter:
					Items[CurrentItem].InvokeItem();
					break;
				case ConsoleKey.Escape:
					return true;
			}

			return false;
		}


		public void Run()
		{
			Palette.Normal.AsCurrent();
			Console.Clear();

			while (true)
			{
				Show();

				try
				{
					if (Navigate())
					{
						Console.Clear();
						return;
					}
				}
				catch (Exception e)
				{
					e.Output();
				}
			}
		}


		public sealed class MenuItem
		{
			public MenuItem(string text, Action callback)
			{
				Text     = text ?? throw new ArgumentNullException(nameof(text));
				Callback = callback ?? throw new ArgumentNullException(nameof(callback));
			}


			public  string Text           { get; }
			private Action Callback       { get; }
			public  bool   IsDivide       { get; set; } = false;
			public  bool   IsSimpleInvoke { get; set; } = false;


			public void InvokeItem()
			{
				if (IsSimpleInvoke)
				{
					Callback.Invoke();
					return;
				}

				Console.Clear();
				Console.SetCursorPosition(0, 0);

				object space = ' ';
				$"{space,10} {Text} {space,10}".ColoredLine(Palette.Navbar);
				Console.WriteLine("\n\n");

				Callback.Invoke();

				if (Console.CursorTop >= Console.WindowHeight)
					Main.Utilities.General.CursorAndPause(0, Console.CursorTop + 5);
				else
					Main.Utilities.General.CursorToBottomAndPause();
				Console.Clear();
			}
		}


		private static class Palette
		{
			public static Color Title => Main.Utilities.Palette.Info;

			public static Color Normal => Main.Utilities.Palette.Default;

			public static Color Current => Main.Utilities.Palette.AccentDedicated;

			public static Color Navbar => Main.Utilities.Palette.TertiaryDedicated;
		}
	}


	public abstract class MenuWrapper
	{
		protected Menu Menu { get; set; }


		public void Run()
		{
			try
			{
				Menu?.Run();
			}
			catch (Exception e)
			{
				e.Output();
			}
		}
	}
}
