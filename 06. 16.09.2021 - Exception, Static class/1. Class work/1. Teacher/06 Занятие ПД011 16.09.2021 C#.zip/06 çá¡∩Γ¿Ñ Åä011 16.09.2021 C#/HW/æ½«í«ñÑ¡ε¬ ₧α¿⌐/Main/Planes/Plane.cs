﻿using System;


namespace Main.Planes
{
	public class Plane
	{
		private int    _enginesCount;
		private double _fuelByHour;
		private int    _passengersSeats;

		public string MakerAndType   { get; set; }
		public string AirlineCompany { get; set; }

		public int    PassengersSeats { get => _passengersSeats; set => _passengersSeats = value < 0 ? 0 : value; }
		public double FuelByHour      { get => _fuelByHour;      set => _fuelByHour = value < 0 ? 0 : value; }
		public int    EnginesCount    { get => _enginesCount;    set => _enginesCount = value < 0 ? 0 : value; }


#region Таблица


		public static void ShowHeader()
		{
			Console.WriteLine("┌───────────────────────────┬──────────────────────────────────┬──────────┬──────────────┬────────────┐");
			Console.WriteLine("│    Производитель и тип    │           Авиакомпания           │  Кол-во  │    Расход    │   Кол-во   │");
			Console.WriteLine("│                           │                                  │   мест   │   горючего   │ двигателей │");
			Console.WriteLine("├───────────────────────────┼──────────────────────────────────┼──────────┼──────────────┼────────────┤");
		}


		public void ShowTableRow() =>
			Console.WriteLine($"│ {MakerAndType,-25} │ {AirlineCompany,-32} │ {PassengersSeats,-8} │ {FuelByHour,-12:F2} │ {EnginesCount,-10} │");


		public static void ShowFooter() =>
			Console.WriteLine("└───────────────────────────┴──────────────────────────────────┴──────────┴──────────────┴────────────┘");


#endregion


#region Компараторы


		public static int CompareByMakerAndTypeDescending(Plane lhs, Plane rhs) =>
			(lhs.MakerAndType ?? string.Empty).CompareTo(rhs.MakerAndType);


		public static int CompareByEnginesCountDescending(Plane lhs, Plane rhs) =>
			rhs.EnginesCount.CompareTo(lhs.EnginesCount);


		public static int CompareByFuelByHourAscending(Plane lhs, Plane rhs) =>
			lhs.FuelByHour.CompareTo(rhs.FuelByHour);


#endregion
	}
}
