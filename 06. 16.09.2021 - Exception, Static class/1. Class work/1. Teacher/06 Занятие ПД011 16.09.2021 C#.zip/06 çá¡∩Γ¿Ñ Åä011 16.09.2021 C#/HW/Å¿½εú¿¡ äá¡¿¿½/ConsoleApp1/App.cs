﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class App
    {
        //массив самолетов
        private static Plane[] planes ={
                new Plane { Name = "Airbus-A310", Seats = 280, Engine = 8, Rate = 4.4, Airline = ""},
                new Plane { Name = "Ил-62", Seats = 186, Engine = 4, Rate = 3.2, Airline = ""},
                new Plane { Name = "ТУ-204", Seats = 200, Engine = 8, Rate = 4.2, Airline = ""},
                new Plane { Name = "ИЛ-96", Seats = 190, Engine = 8, Rate = 5.5, Airline = ""},
                new Plane { Name = "Boeing-777", Seats = 250, Engine = 8, Rate = 4.3, Airline = ""},
                new Plane { Name = "Катран", Seats = 2, Engine = 2, Rate = 3.5, Airline = ""},
                new Plane { Name = "Boeing-767", Seats = 177, Engine = 8, Rate = 3.9, Airline = ""},
                new Plane { Name = "Airbus A320", Seats = 280, Engine = 6, Rate = 4d, Airline = ""},
                new Plane { Name = "Airbus-A380", Seats = 215, Engine = 8, Rate = 3.8, Airline = ""},
                new Plane { Name = "Boeing-747", Seats = 210, Engine = 10, Rate = 4.1, Airline = ""}
            };
        //массив пунктов меню
        private static string[] menu =
            {
                "Вывод массива самолетов - S",
                "Поиск самолетов с наибольшим количесвтом мест - F",
                "Сортировка по имени - N",
                "Сортировка по двигателям - E",
                "Cортировка по расходу топлива - R",
                "Выход - Esc"
            };
        //вывод пунктов меню
        static public void ShowMenu()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.SetCursorPosition(5, 5);
            Console.Write(menu[0]);
            Console.SetCursorPosition(5, 6);
            Console.Write(menu[1]);
            Console.SetCursorPosition(5, 7);
            Console.Write(menu[2]);
            Console.SetCursorPosition(5, 8);
            Console.Write(menu[3]);
            Console.SetCursorPosition(5, 9);
            Console.WriteLine(menu[4]);
            Console.SetCursorPosition(5, 10);
            Console.WriteLine(menu[5]);
            Console.CursorVisible = false;
            Console.ForegroundColor = ConsoleColor.White;
        }
        //вывод массива самолетов в консоль
        static public void ShowPlanes()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(40, 1);
            Console.Write("Вывод самолетов\n");
            Array.ForEach(planes, Console.WriteLine);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
            Console.Clear();
        }
        //определить самолет/самолеты с максимальным количеством пассажирских мест
        static public void ShowMaxSeatsPlanes()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(25, 1);
            Console.Write("Вывод самолетов с максимальным количеством сидений\n");
            //самолеты с максимальным количеством сидений
            Array.ForEach(Plane.FindMaxSeats(planes), Console.WriteLine);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
            Console.Clear();
        }
        //вывод массива самолетов отсортированных по расходу топлива
        static public void ShowPlanesSortByRate()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(25, 1);
            Console.Write("Сортировка по возрастанию расхода горючего за час полета\n");
            //сортировка по возрастанию расхода горючего за час полета
            Array.Sort(planes, (Plane x1, Plane x2) => (x1.Rate.CompareTo(x2.Rate)));
            Array.ForEach(planes, Console.WriteLine);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
            Console.Clear();
        }
        //вывод массива самолетов отсортированных по количеству двигателей
        static public void ShowPlanesSortByEngine()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(25, 1);
            Console.Write("Сортировка по количеству двигателей\n");
            //сортировка по количеству двигателей
            Array.Sort(planes, (Plane x1, Plane x2) => (x2.Engine.CompareTo(x1.Engine)));
            Array.ForEach(planes, Console.WriteLine);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
            Console.Clear();
        }
        //вывод массива самолетов отсортированных по названию самолетов
        static public void ShowPlanesSortByName()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(25, 1);
            Console.Write("Сортировка по свойству производитель и тип\n");
            //сортировка по свойству производитель и тип
            Array.Sort(planes, (Plane x1, Plane x2) => (x1.Name.CompareTo(x2.Name)));
            Array.ForEach(planes, Console.WriteLine);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
            Console.Clear();
        }
    }
}
