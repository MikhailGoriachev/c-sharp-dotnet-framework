﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Plane
    {
        //производитель и тип самолета
        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = (!string.IsNullOrWhiteSpace(value))? value : "Самолет"; }
        }

        //количество пассажирских мест
        private int _seats;
        public int Seats
        {
            get { return _seats; }
            set { _seats = value > 0 ? value : 1; }
        }

        //расход горючего за час полета
        private double _rate;
        public double Rate
        {
            get { return _rate; }
            set { _rate = value > 0 ? value : 1; }
        }

        //количество двигателей
        private int _engine;
        public int Engine
        {
            get { return _engine; }
            set { _engine = value > 0 ? value : 1; }
        }

        //название авиакомпании – владельца
        private string _airline;
        public string Airline
        {
            get { return _airline; }
            set { _airline = (!string.IsNullOrWhiteSpace(value)) ? value : "Turkish Аirlines"; }
        }


        //поиск самолетов с максимальным количеством сидений
        public static Plane[] FindMaxSeats(Plane[] planes)
        {

            int max = planes[0].Seats;
            //поиск максимального количесвта сидений
            for (int i = 1; i < planes.Length; i++)
                if (planes[i].Seats > max) max = planes[i].Seats;
            //поиск самолетов с максимальным количеством сидений
            return Array.FindAll(planes, item => item.Seats == max);
        }
        
        //представление объекта класса Plane в строчном формате
        public override string ToString()
        {
            return $" Авиакомпания: {_airline,15}| Самолет: {_name,11}| Сидения: {_seats,3}| Расход: {_rate, 4:f2}| Двигатели: {_engine,2}";
        }
    }
}
