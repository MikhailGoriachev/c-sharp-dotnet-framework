﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool work = true;

            while (work)
            {
                App.ShowMenu();

                switch (Console.ReadKey().Key)
                {
                    case ConsoleKey.S:
                        App.ShowPlanes();
                        break;

                    case ConsoleKey.F:
                        App.ShowMaxSeatsPlanes();
                        break;

                    case ConsoleKey.R:
                        App.ShowPlanesSortByRate();
                        break;

                    case ConsoleKey.N:
                        App.ShowPlanesSortByName();
                        break;

                    case ConsoleKey.E:
                        App.ShowPlanesSortByEngine();
                        break;

                    case ConsoleKey.Escape:
                        work = false;
                        break;
                }
            }
        }
    }
}
