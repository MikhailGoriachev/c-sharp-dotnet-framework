﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class TuplesDemo
    {
        private static Random _random = new Random();
        private static double RandomDbl(double lo, double hi)
        {
            return lo + (hi - lo) * _random.NextDouble();
        }
        
        
        public static void Proc3()
        {
            //количество поисков значений по условию
            int n = 3;

            Console.ForegroundColor = ConsoleColor.Blue;

            Console.Write("\t\t ____________________________________________________________________\n");

            for (int i = 0; i < n; i++)
            {
                var couple = (RandomDbl(0, 10), RandomDbl(0, 10));

                var result = Mean(couple);
                
                Console.Write($"\t\t| Цикл {i+1}/{n} | Входные данные: {couple.Item1:f2} {couple.Item2:f2} | a_mean: {result.a_mean, 4:f2} | g_mean: {result.g_mean, 4:f2} |\n" );
                Console.Write("\t\t|__________|___________________________|______________|______________|\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
        }

        public static void Proc5()
        {
            //количество поисков значений по условию
            int n = 3;

            Console.ForegroundColor = ConsoleColor.Blue;

            Console.Write("\t ___________________________________________________________________________________\n");

            for (int i = 0; i < n; i++)
            {
                var four = (RandomDbl(0, 10), RandomDbl(0, 10), RandomDbl(0, 10), RandomDbl(0, 10));

                var result = RectPS(four);
                Console.Write($"\t| Цикл {i + 1}/{n} | Входные данные: {four.Item1,4:f2} {four.Item2,4:f2} {four.Item3,4:f2} {four.Item4,4:f2} | Периметр: {result.p, 5:f2} | Площадь: {result.s,5:f2} |\n");
                Console.Write("\t|__________|_____________________________________|_________________|________________|\n");

            }

            Console.ForegroundColor = ConsoleColor.White;

        }

        private static (double a_mean, double g_mean) Mean((double x, double y) couple)
        {
            return (a_mean: (couple.x + couple.y) / 2, g_mean: Math.Sqrt(couple.x * couple.y));
        }

        private static (double p, double s) RectPS((double x1, double y1, double x2, double y2)four)
        {
            double a = Math.Abs(four.x2 - four.x1), b = Math.Abs(four.y2 - four.y1);
            return (p: (a+b)*2, s: a*b);
        }

    }
}
