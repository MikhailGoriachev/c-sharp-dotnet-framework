﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    public class ArrayPlane {
        public string Title { get; set; }
        public Plane[] Planes { get; set; }

        public bool Empty => Planes.Length == 0;

        public void Initialize()
        {
            Title = $"Данные о самолётах на {DateTime.Now:d}";
            Planes = new[] {
                new Plane {Brand = "Aerospatiale", PassSeats = 800, Fuel = 7200d, Engines = 8, AirlineName = "Air Onix"},
                new Plane {Brand = "Aerospace"   , PassSeats = 300, Fuel = 5400d, Engines = 4, AirlineName = "Air Onix"},
                new Plane {Brand = "Boeing"      , PassSeats = 450, Fuel = 4300d, Engines = 8, AirlineName = "Air Onix"},
                new Plane {Brand = "Havilland"   , PassSeats = 150, Fuel = 6200d, Engines = 4, AirlineName = "Air Onix"},
                new Plane {Brand = "Embraer"     , PassSeats = 670, Fuel = 8500d, Engines = 4, AirlineName = "Air Onix"},
                new Plane {Brand = "Fokker"      , PassSeats = 800, Fuel = 3430d, Engines = 8, AirlineName = "Air Onix"},
                new Plane {Brand = "Cessna"      , PassSeats = 600, Fuel = 5830d, Engines = 8, AirlineName = "Air Onix"},
                new Plane {Brand = "Lancair"     , PassSeats = 640, Fuel = 6500d, Engines = 8, AirlineName = "Air Onix"},
                new Plane {Brand = "Vickers"     , PassSeats = 250, Fuel = 2550d, Engines = 4, AirlineName = "Air Onix"},
                new Plane {Brand = "Saab"        , PassSeats =  60, Fuel = 6780d, Engines = 2, AirlineName = "Air Onix"}
            };
        } // Initialize

        // Возвращает максимальное количество пассажирских мест
        int MaxPassSeats()
        {
            int maxPassSeats = Planes[0].PassSeats;
            for (int i = 1; i < Planes.Length; i++)
            {
                int passSeats = Planes[i].PassSeats;
                if (passSeats > maxPassSeats)
                    maxPassSeats = passSeats;
            } // for i

            return maxPassSeats;
        } // MaxPassSeats

        // Вывести массив самолётов в консоль
        public void Show(string caption, int indent)
        {
            // вывод заголовка таблицы самолётов
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Plane.Header(indent)}");

            // вывод всех элементов массива самолётов
            int row = 1;
            void OutItem(Plane p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(Planes, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Plane.Footer(indent));
        } // Show

        public void ShowMaxPassSeats(string caption, int indent)
        {
            // вывод заголовка таблицы самолётов
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Plane.Header(indent)}");

            // вывод всех элементов массива самолётов
            // вывод строк таблицы
            int max = MaxPassSeats();

            int row = 1;
            foreach (var plane in Planes)
            {
                Console.Write(" ".PadRight(indent));

                // выделение цветом строки таблицы с самолётом с максимальным количеством пассажирских мест
                if (max == plane.PassSeats) {
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.BackgroundColor = ConsoleColor.Gray;
                } // if

                // вывод строки таблицы 
                Console.WriteLine(plane.ToTableRow(row++));

                // восстановление цвета консоли
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.DarkGray;
            } // foreach

            // вывод подвала таблицы
            Console.WriteLine(Plane.Footer(indent));
        } // ShowMaxPassSeats

        // Упорядочить массив самолётов по свойству производитель и тип 
        public void OrderByBrand() => Array.Sort(Planes, Plane.BrandComparer);

        // Упорядочить массив самолётов по убыванию количества двигателей
        public void OrderByEngines() => Array.Sort(Planes, Plane.EnginesComparer);

        // Упорядочить массив самолётов по возрастанию расхода горючего за час полета
        public void OrderByFuel() => Array.Sort(Planes, Plane.FuelComparer);

    } // ArrayPlane
}
