﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    public class Plane
    {
        // производитель и тип самолета 
        private string _brand = "";
        public string Brand
        {
            get => _brand;
            set => _brand = string.IsNullOrWhiteSpace(value) ? _brand : value;
        } // Brand

        // количество пассажирских мест
        private int _passSeats;
        public int PassSeats
        {
            get => _passSeats;
            set => _passSeats = value >= 0 ? value : _passSeats;
        } // PassSeats

        // расход горючего за час полета
        private double _fuel;
        public double Fuel
        {
            get => _fuel;
            set => _fuel = value >= 0 ? value : _fuel;
        } // Fuel

        // количество двигателей
        private int _engines;
        public int Engines
        {
            get => _engines;
            set => _engines = value >= 0 ? value : _engines;
        } // Engines

        // название авиакомпании – владельца
        private string _airlineName = "";
        public string AirlineName
        {
            get => _airlineName;
            set => _airlineName = string.IsNullOrWhiteSpace(value) ? _airlineName : value;
        } // AirlineName

        // представление объекта в виде строки таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_brand,-14} │ {_passSeats,13}     " +
            $"│ {_fuel, 14:f2}  │ {_engines, 10} │ {_airlineName,-16} │";

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬────────────────┬───────────────────┬─────────────────┬────────────┬──────────────────┐\n" +
                $"{spaces}│  №  │ Производитель, │       Кол-во      │ Расход горючего │   Кол-во   │ Название         │\n" +
                $"{spaces}│ п/п │ тип самолета   │ пассажирских мест │   за час полета │ двигателей │     авиакомпании │\n" +
                $"{spaces}├─────┼────────────────┼───────────────────┼─────────────────┼────────────┼──────────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴────────────────┴───────────────────┴─────────────────┴────────────┴──────────────────┘";

        // Компаратор для сортировки по свойству производитель и тип 
        public static int BrandComparer(Plane p1, Plane p2) =>
            p1._brand.CompareTo(p2._brand);

        // Компаратор для сортировки по убыванию количества двигателей
        public static int EnginesComparer(Plane p1, Plane p2) =>
            p2._engines.CompareTo(p1._engines);


        // Компаратор для сортировки по возрастанию расхода горючего за час полета
        public static int FuelComparer(Plane p1, Plane p2) =>
            p1._fuel.CompareTo(p2._fuel);
    } // Plane
}
