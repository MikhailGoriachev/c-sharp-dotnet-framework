﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    public static class TuplesDemo{

        public static (double a_mean, double g_mean) Mean(double x, double y){
            return (a_mean: (x + y) / 2, g_mean: Math.Sqrt(x * y));
        } // Mean

        public static (double P, double S) RectPS(double x1, double x2, double y1, double y2){
            double a = Math.Abs(x2 - x1);
            double b = Math.Abs(y2 - y1);
            return (P: (a + b) * 2, S: a * b);
        } // RectPS

    } // TuplesDemo
}
