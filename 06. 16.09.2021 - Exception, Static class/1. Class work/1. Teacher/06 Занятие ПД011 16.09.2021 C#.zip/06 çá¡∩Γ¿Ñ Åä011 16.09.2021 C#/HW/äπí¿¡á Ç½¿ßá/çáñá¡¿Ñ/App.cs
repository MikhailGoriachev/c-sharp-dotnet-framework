﻿using System;

namespace Задание
{
    
    // Объекты и методы для обработки по заданию
    public class App {

        private ArrayPlane _planes;  // объект для конусов

        // в конструкторе по умолчанию будем заполнять коллекции
        public App() : this(new ArrayPlane())
        {
            _planes.Initialize();
        } // App

        // конструктор с внедрением зависимостей/ dependency injection
        public App(ArrayPlane planes) {
            _planes = planes;
        } // App


        // ---------------------------------------------------------------

        // Найти ср. арифметическое и ср. геометрическое для трех пар случайных чисел
        public void Proc3() {
            Utils.ShowNavBarTask("    Найти ср. арифметическое и ср. геометрическое для трех пар случайных чисел");
            const double LO = 0d, HI = 10d; 
            const int N = 3; // кол-во пар случайных чисел

            (double x, double y)[] arr = new (double, double)[N];

            // генерация случайных чисел
            for (int i = 0; i < N; i++) arr[i] = (Utils.GetRandom(LO, HI), Utils.GetRandom(LO, HI));

            Console.WriteLine("\n    Cр. арифметическое и ср. геометрическое для трех пар случайных чисел:");
            Console.WriteLine("\t┌─────┬───────┬───────┬────────────────────┬────────────────────┐");
            Console.WriteLine("\t│  №  │   X   │   Y   │ Cр. арифметическое │ Cр. геометрическое │");
            Console.WriteLine("\t├─────┼───────┼───────┼────────────────────┼────────────────────┤");

            for (int i = 0; i < N; i++) {
                // вычисляем ср. арифметическое и ср. геометрическое
                var result = TuplesDemo.Mean(arr[i].x, arr[i].y);
                // вывод результата
                Console.WriteLine($"\t│ {i + 1, 3} │ {arr[i].x, 5:f2} │ {arr[i].y,5:f2} │ {result.a_mean, 18:f2} │ {result.g_mean,18:f2} │");
            } // for i
            Console.WriteLine("\t└─────┴───────┴───────┴────────────────────┴────────────────────┘");

        } // Proc3



        // Найти периметры и площади трех прямоугольников с данными противоположными вершинами
        public void Proc5(){
            Utils.ShowNavBarTask("    Найти периметры и площади трех прямоугольников с данными противоположными вершинами");

            const double LO = -10d, HI = 10d;
            const int N = 3; // кол-во прямоугольников

            (double x1, double x2, double y1, double y2)[] arr = new (double, double, double, double)[N];

            // генерация координат противоположных вершин прямоугольников
            for (int i = 0; i < N; i++) arr[i] = (Utils.GetRandom(LO, HI), Utils.GetRandom(LO, HI), Utils.GetRandom(LO, HI), Utils.GetRandom(LO, HI));

            Console.WriteLine("\n    Периметры и площади трех прямоугольников с данными противоположными вершинами:");
            Console.WriteLine("\t    ┌─────┬───────┬───────┬───────┬───────┬─────────┬─────────┐");
            Console.WriteLine("\t    │  №  │   X1  │   X1  │   Y1  │   Y2  │    P    │    S    │");
            Console.WriteLine("\t    ├─────┼───────┼───────┼───────┼───────┼─────────┼─────────┤");


            for (int i = 0; i < N; i++) {
                // вычисляем периметр и площадь
                var result = TuplesDemo.RectPS(arr[i].x1, arr[i].x2, arr[i].y1, arr[i].y2);
                // вывод результата
                Console.WriteLine($"\t    │ {i + 1,3} │ {arr[i].x1,5:f2} │ {arr[i].x2,5:f2} │ {arr[i].y1,5:f2} │ {arr[i].y2,5:f2} │ {result.P,7:f2} │ {result.S,7:f2} │");
            } // for i

            Console.WriteLine("\t    └─────┴───────┴───────┴───────┴───────┴─────────┴─────────┘");

        } // Proc5

        // ---------------------------------------------------------------

        // Формирование коллекции персон
        public void PlanesInitialize()
        {
            Utils.ShowNavBarTask("  Формирование коллекции самолётов");

            _planes.Initialize();
            _planes.Show("Данные сформированы", 8);
        } // PlanesInitialize

        // Определить самолет/самолеты с максимальным количеством пассажирских мест
        public void ShowPlanesMaxPassSeats(){
            Utils.ShowNavBarTask("  Определить самолет/самолеты с максимальным количеством пассажирских мест");

            _planes.ShowMaxPassSeats("Cамолет/самолеты с максимальным кол-вом пассажирских мест выделены цветом", 8);
        } // ShowPlanesMaxPassSeats

        // Сортировка коллекции по свойству производитель и тип
        public void DemoOrderByBrand()
        {
            Utils.ShowNavBarTask("  Сортировка коллекции по свойству производитель и тип");

            _planes.OrderByBrand();
            _planes.Show("Сортировка коллекции по свойству производитель и тип", 8);
        } // DemoOrderByBrand

        // Сортировка коллекции по убыванию количества двигателей
        public void DemoOrderByEngines()
        {
            Utils.ShowNavBarTask("  Сортировка коллекции по убыванию количества двигателей");

            _planes.OrderByEngines();
            _planes.Show("Сортировка коллекции по убыванию количества двигателей", 8);
        } // DemoOrderByEngines

        // Сортировка коллекции по возрастанию расхода горючего за час полета
        public void DemoOrderByFuel() {
            Utils.ShowNavBarTask("  Сортировка коллекции по возрастанию расхода горючего за час полета");

            _planes.OrderByFuel();
            _planes.Show("Сортировка коллекции по возрастанию расхода горючего за час полета", 8);
        } // DemoOrderByFuel

    } // class App
}