﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 16.09.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Найти ср. арифметическое и ср. геометрическое для трех пар случайных чисел" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Найти периметры и площади трех прямоугольников с данными противоположными вершинами" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 2. Формирование коллекции самолётов" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 2. Определить самолет/самолеты с максимальным количеством пассажирских мест" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 2. Сортировка коллекции по свойству производитель и тип" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Сортировка коллекции по убыванию количества двигателей" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Сортировка коллекции по возрастанию расхода горючего за час полета" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true)
            {
                // настройка цветового оформления
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.Clear();
                Console.CursorVisible = false;

                Utils.ShowNavBarTask("  ");
                Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                Console.Clear();

                switch (key)
                {
                    // Найти ср. арифметическое и ср. геометрическое для трех пар случайных чисел
                    case ConsoleKey.Q:
                        app.Proc3();
                        break;

                    // Найти периметры и площади трех прямоугольников с данными противоположными вершинами
                    case ConsoleKey.W:
                        app.Proc5();
                        break;

                    // ------------------------------------------------------------

                    // Формирование коллекции самолётов
                    case ConsoleKey.E:
                        app.PlanesInitialize();
                        break;

                    // Определить самолет/самолеты с максимальным количеством пассажирских мест
                    case ConsoleKey.R:
                        app.ShowPlanesMaxPassSeats();
                        break;

                    // Сортировка коллекции по свойству производитель и тип
                    case ConsoleKey.T:
                        app.DemoOrderByBrand();
                        break;


                    // Сортировка коллекции по убыванию количества двигателей
                    case ConsoleKey.A:
                        app.DemoOrderByEngines();
                        break;

                    // Сортировка коллекции по возрастанию расхода горючего за час полета
                    case ConsoleKey.S:
                        app.DemoOrderByFuel();
                        break;

                    // выход из приложения назначен на клавишу F10 или кавишу Z
                    case ConsoleKey.F10:
                    case ConsoleKey.Z:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                        Console.CursorVisible = true;
                        return;

                    default:
                        continue;
                } // switch

                // Ожидать нажатия любой клавиши по окончании работы пункта меню
                Console.CursorVisible = true;
                Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                Console.ReadKey(true);
            } // while
        } // Main
    }
}
