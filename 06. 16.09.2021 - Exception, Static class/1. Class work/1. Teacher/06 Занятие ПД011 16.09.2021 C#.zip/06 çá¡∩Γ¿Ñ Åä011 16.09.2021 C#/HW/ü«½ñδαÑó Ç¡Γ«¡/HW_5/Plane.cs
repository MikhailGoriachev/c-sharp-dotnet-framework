﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Plane
    {
        //тип самолета
        private string _model;
        public string Model {
            get => _model;
            set => _model = value;
        }

        //количество мест
        private int _seats;
        public int Seats
        {
            get => _seats;
            set => _seats = value >= 0 ? value : 0;
        }


        //расход топлива
        private double _FuelConsumtion;
        public double FuelConsumstion
        {
            get => _FuelConsumtion;
            set => _FuelConsumtion = value >= 0 ? value :0;
        }

        //количество двигателей
        private int _engines;
        public int Engines
        {
            get => _engines;
            set => _engines = value >= 0 ? value : 0;
        }

        private string _nameCompany;
        public string NameCompany
        {
            get => _nameCompany;
            set => _nameCompany = value;
        }


        // строковое представление полей объекта
        public override string ToString() =>
            $"{_model}: {_seats}; мест {_FuelConsumtion:n2} кг/ч;{_engines} двигателей; Авиакомпания: {_nameCompany}";

       

        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_model,-18} │ {_seats,5}    " +
            $"│ {_FuelConsumtion,4}  │ {_engines,6} │ {_nameCompany,-16} │";

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬────────────────────┬──────────┬───────┬────────┬──────────────────┐\n" +
                $"{spaces}│  №  │ Тип   и            │  Кол-во  │Расход │ Кол-во │ Название         │\n" +
                $"{spaces}│ п/п │      производитель │   мест   │  кг/ч │ двиг-ей│ авиакомании      │\n" +
                $"{spaces}├─────┼────────────────────┼──────────┼───────┼────────┼──────────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴────────────────────┴──────────┴───────┴────────┴──────────────────┘";


        // Компараторы для сортировки по заданию
        // Компаратор для сортировки по типу
        public static int NameComparer(Plane p1, Plane p2) =>
            String.Compare(p1._model, p2._model, StringComparison.Ordinal);

        //по убыванию двигателей
        public static int EngineComparer(Plane p1, Plane p2) =>
            p2._engines.CompareTo(p1._engines);

        //по возрастанию расхода горючего за час полета
        public static int FuelComparer(Plane p1, Plane p2) =>
            p1._FuelConsumtion.CompareTo(p2._FuelConsumtion);

       
    }
}
