﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public static class Tuple
    {

        
       
        public static void TupleDemo1()
        {
            Utils.ShowNavBarTask(" Задача 1. Разработайте методы в статическом классе TuplesDemo, закодируйте решение задач");
            Console.WriteLine(@"

            Proc3. Описать метод Mean(x, y), вычисляющую среднее арифметическое  и среднее геометрическое , 
            двух положительных                                                                
            вещественных чисел x и y. Возвращать a_mean, g_mean из метода в кортеже. 
            С помощью этого метода найти среднее 
            арифметическое и среднее геометрическое для трех пар случайных чисел из диапазона значений [0, 10]                     ");


            
            Utils.WriteXY(0, 12, "Решение:\n", ConsoleColor.White);
             for (int i = 0; i < 3; i++)
             {
                 (double, double) tuple = (GetValues());
                 (double, double) tupleresult = (Mean(tuple));
                 Console.Write($"Среднее арифметическое чисел {tuple.Item1,2:n2} и {tuple.Item2,2:n2} ==> {tupleresult.Item1,2:n2} и Среднее геометрическое " +
                 $"===> {tupleresult.Item2,2:n2}\n\n");
             }

            Console.ReadKey();
            Console.Clear();
        }

        public static void TupleDemo2()
        {
            Utils.ShowNavBarTask(" Задача 1. Разработайте методы в статическом классе TuplesDemo, закодируйте решение задач");
            Console.WriteLine(@"
            Описать метод RectPS(x1, y1, x2, y2), вычисляющую периметр и площадь прямоугольника со сторонами, 
            параллельными осям координат, по координатам (x1, y1), (x2, y2) его противоположных вершин 
            (стороны вычисляются как a = Math.Abs(x2 - x1), b = Math.Abs(y2 – y1)).
            Метод возвращает кортеж с периметром и площадью. 
            С помощью этого метода найти периметры и площади трех прямоугольников с данными противоположными вершинами.");
           
            (double, double, double, double) tuple = (2, 3, 4, 6);
            (double, double) tupleres = (RectPS(tuple));

           
            ShowRect(1,tuple);
            Console.Write($"Площадь прямоугольника[1] S ={tupleres.Item2,2:n2} и Периметр P={tupleres.Item1,2:n2}");
            tuple = (3, 4, 6, 8);
            
            tupleres = (RectPS(tuple));
            ShowRect(2,tuple);
            Console.Write($"Площадь прямоугольника[2] S ={tupleres.Item2,2:n2} и Периметр P ={tupleres.Item1,2:n2}");
            tuple = (2, 4, 4, 8);
            tupleres = (RectPS(tuple));
            ShowRect(3,tuple);
            Console.Write($"Площадь прямоугольника[3] S = {tupleres.Item2,2:n2} и Периметр  P ={tupleres.Item1,2:n2}");

            Console.ReadKey();
            Console.Clear();
        }

        #region Методы задачи 1

        static Random random = new Random();
   private static (double x ,double y) Mean((double _x,double _y) tuple)
    {
       
 
        double a_mean = 0; //переменная для хранения ср.арефм
        double g_mean = 0; // переменная для хренения ср.геом
 
        a_mean = (tuple._x + tuple._y)/ 2;
 
        //формула для среднего геометрического https://math-prosto.ru/ru/pages/geometric_mean/how_to_find_geometric-mean/
        g_mean = Math.Sqrt((tuple._x * tuple._y));
 
        return (a_mean,g_mean);
    }
 
 
    // возврат набора значений из метода при помощи кортежа
    private static (double, double) GetValues()
    {
 
        var result = (random.Next(0, 11)+random.NextDouble(), random.Next(0, 11)+random.NextDouble());
        return result;
    } // GetValues
        #endregion

        #region Методы задачи 2
        private static (double p,double s) RectPS((double _x1,double _y1,double _x2,double _y2) tuple){

            double P = 0;
            double S = 0;
           
            P = 2 * (Math.Abs(tuple._x2 - tuple._x1) + Math.Abs(tuple._y2 - tuple._y1));
            S = Math.Abs(tuple._x2 - tuple._x1) * Math.Abs(tuple._y2 - tuple._y1);

            return (P, S);
        }

        //нахождение сторон

        private static(double a,double b) SideCalc((double x1,double y1,double x2,double y2) tuple)
        {
            double a = Math.Abs(tuple.x2 - tuple.x1);
            double b = Math.Abs(tuple.y2 - tuple.y1);

            return (a, b);
        }

        //вывод треуголника
        private static void ShowRect(int n,(double x1,double y1,double x2,double y2) tuple)
        {
            (double ,double) sideTup =SideCalc(tuple);
            Console.Write
        ($@"

          Прямоугольник #{n}
        ┌──────────────────────┐
        │                      │ {sideTup.Item2,1:n2}                  
        │                      │
        │                      │
        └──────────────────────┘
             {sideTup.Item1,1:n2}

        ");
        }
        #endregion
    }
}
