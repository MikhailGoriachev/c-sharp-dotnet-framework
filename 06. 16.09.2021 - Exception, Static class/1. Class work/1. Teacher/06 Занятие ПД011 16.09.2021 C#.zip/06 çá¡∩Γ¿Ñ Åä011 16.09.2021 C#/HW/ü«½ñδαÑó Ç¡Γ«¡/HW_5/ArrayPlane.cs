﻿using System;


namespace Classes
{
    public class ArrayPlane
    {
        public string Title { get; set; }
        public Plane[] planes { get; set; }

        public bool Empty => planes.Length == 0;

        public void Init()
        {
            Title = $"Данные о самолетах на {DateTime.Now:d}";
            planes = new[]
            {
                new Plane{Model ="Туполев Ту-134",Seats = 80,FuelConsumstion = 8296.00,Engines = 2,NameCompany = "Селяков" },
                new Plane{Model ="Ильюшин ИЛ-62",Seats = 138,FuelConsumstion = 6600.00,Engines = 4,NameCompany = "Ильюшин" },
                new Plane{Model ="Аэробус A310",Seats = 183,FuelConsumstion = 4400.00,Engines = 2,NameCompany = "Airbus" },
                new Plane{Model ="Аэробус A330",Seats = 440,FuelConsumstion = 6308.00,Engines = 2,NameCompany = "Airbus" },
                new Plane{Model ="Боинг-737",Seats = 114,FuelConsumstion = 2600.00,Engines = 2,NameCompany = "Boeing" },
                new Plane{Model ="Боинг-777 ",Seats = 235,FuelConsumstion = 6900.00,Engines = 3,NameCompany = "Boeing" },
                new Plane{Model ="Иркут МС-21",Seats = 165,FuelConsumstion = 8296.00,Engines = 4,NameCompany = "Иркут" },
                new Plane{Model ="Иркут МС-50",Seats = 110,FuelConsumstion = 9200.00,Engines = 6,NameCompany = "Иркут" },
                new Plane{Model ="Туполев Ту-154",Seats = 100,FuelConsumstion = 5200.00,Engines = 2,NameCompany = "Селяков" },
                new Plane{Model ="Аэробус А300",Seats = 250,FuelConsumstion = 6700.00,Engines = 4,NameCompany = "Airbus" }

            };
        }//Init

        // Возвращает максимальное количесвто мест в массиве самолето
        int MaxSeats()
        {
            int maxSeat = planes[0].Seats;
            for (int i = 1; i < planes.Length; i++)
            {
                int seat = planes[i].Seats;
                if (seat > maxSeat)
                    maxSeat = seat;
            } // for i

            return maxSeat;
        } // MaxSeats


        // Отбор cамолетов с максимальным количество пассажирских мест
        public Plane[] FindMaxSeat()
        {
            // найти максимальный рост в массиве персон
            int maxSeat = MaxSeats();

            // предикат для отбора персон с максимальным ростом
            bool MaxHeightPredicate(Plane p) => p.Seats == maxSeat;

            // отбор персон с максимальным ростом
            Plane[] selected = Array.FindAll(planes, MaxHeightPredicate);

            return selected;
        } // FindMaxSeat

        // Вывести массив самолетов в консоль
        public void Show(string caption, int indent)
        {
            // вывод заголовка таблицы персон
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Plane.Header(indent)}");

            // вывод всех элементов массива персон
            int row = 1;
            void OutItem(Plane p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(planes, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Plane.Footer(indent));
        } // Show

        // Вывести массив отобранных cамолетов в консоль.
        public void Show(string caption, int indent, Plane[] planes)
        {
            // вывод заголовка таблицы 
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Plane.Header(indent)}");

            // вывод всех элементов массива 
            int row = 1;
            void OutItem(Plane p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(planes, OutItem);

            // вывод подвала таблицы
            Console.WriteLine(Plane.Footer(indent));
        } // Show


        // Упорядочить массив  по типу
        public void OrderByType() => Array.Sort(planes, Plane.NameComparer);

        // Упорядочить массив  по убыванию количества двигателей
        public void OrderByEngineDesc() => Array.Sort(planes, Plane.EngineComparer);

        // Упорядочить массив  по увеличению расхода горючего
        public void OrderByFuel() => Array.Sort(planes, Plane.FuelComparer);
    }

}
