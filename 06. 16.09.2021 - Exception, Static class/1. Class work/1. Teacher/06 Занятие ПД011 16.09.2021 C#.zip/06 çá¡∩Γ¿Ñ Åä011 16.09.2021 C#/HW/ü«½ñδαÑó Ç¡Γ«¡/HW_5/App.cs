﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class App
    {
        private ArrayPlane planes; //обьект для самолетов

        // в конструкторе по умолчанию будем заполнять коллекции
        public App() : this( new ArrayPlane())
        {
            
            planes.Init();
        } // App

        // конструктор с внедрением зависимостей/ dependency injection
        public App(ArrayPlane plane)
        {
            
            planes = plane;
        } // App


        // Формирование коллекции самолетов
        public void PlaneInitialize()
        {
            

            planes.Init();
            planes.Show("Данные сформированы",10);
        }

        // Вывод в таблицу с самым большим количеством мест
        public void ShowMaxSeats()
        {
            

            Plane[] maxSeats = planes.FindMaxSeat();
            planes.Show("Отобраны cамолеты с самым большим количество мест", 10, maxSeats);
        }

        // Сортировка по типу
        public void DemoOrderByType()
        {
            

            planes.OrderByType();
            planes.Show("Коллекция cамолетов ,упорядоченная по типу", 10);
        } 
         
        // Сортировка по двигателям(по убыванию)
        public void DemoOrderByEngine()
        {
            

            planes.OrderByEngineDesc();
            planes.Show("Коллекция cамолетов ,упорядоченная по двигателям(по убыванию)", 10);
        }  // Сортировка по двигателям(по убыванию)
        public void DemoOrderByFuel()
        {
            

            planes.OrderByFuel();
            planes.Show("Коллекция cамолетов ,упорядоченная по расходу", 10);
        } 


        public  void DemoPlanes()
        {
            Utils.ShowNavBarTask("Задача 2. Разработайте класс Самолет со следующими полными свойствами:");
            Console.WriteLine(@"
        Задача 2. Разработайте класс Самолет со следующими полными свойствами:
            1	производитель и тип самолета (это одно свойство, например: Ил-76, Boeing 747, …)
            2	количество пассажирских мест (целое число)
            3	расход горючего за час полета (вещественное число)
            4	количество двигателей (целое число)
            5	название авиакомпании – владельца
         В массиве самолетов (не менее 10 элементов) определить самолет/самолеты с максимальным количеством пассажирских мест, упорядочить массив:
            #   по свойству производитель и тип (!!! это одно свойство !!!)
            #   по убыванию количества двигателей
            #   по возрастанию расхода горючего за час полета                                                                                     ");





            PlaneInitialize();
            Console.BackgroundColor = ConsoleColor.White;
            Utils.WriteXY(4, 40,"Нажмите Enter для вывода таблицы самолетов с максимальным количесвтом мест", ConsoleColor.Black);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ReadKey();
          
            ShowMaxSeats();
            Console.BackgroundColor = ConsoleColor.White;
            Utils.WriteXY(4, 55, "Нажмите Enter для вывода таблицы самолетов упордоченной по типу", ConsoleColor.Black);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ReadKey();

            DemoOrderByType();
            Console.BackgroundColor = ConsoleColor.White;
            Utils.WriteXY(4, 80, "Нажмите Enter для вывода таблицы самолетов упордоченной по количеству двигателей(по убыванию)", ConsoleColor.Black);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ReadKey();

            DemoOrderByEngine();
            Console.BackgroundColor = ConsoleColor.White;
            Utils.WriteXY(4, 105, "Нажмите Enter для вывода таблицы самолетов упордоченной по расходу топилва", ConsoleColor.Black);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ReadKey();

            DemoOrderByFuel();

            Console.ReadKey();
            Console.Clear();
        }

        
    }
}
