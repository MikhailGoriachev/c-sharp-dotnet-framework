﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public static class Utils
    {
        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line)
        {
            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;
            ConsoleColor oldFgColor = Console.ForegroundColor;

            // при выводе немного используем методы класса strring :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.White;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
            Console.ForegroundColor = oldFgColor;
        } // ShowNavBarTask


        public static void ShowMenuBar()
        {
            // сохранить цвет фона
            ConsoleColor oldBkColor = Console.BackgroundColor;

            string[] hotKeys = { "F5", "F6", "F7", "F10" };
            string[] descs = { "Задача 1", "Задача 1.1", "Задача 2", "Выход" };

            // при выводе немного используем методы класса strring :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.White;
            WriteXY(0, 0, " ".PadRight(Console.WindowWidth), Console.ForegroundColor);

            // Выводим текст с функциональными клавишами в верхнюю строку
            for (int i = 0, x = 2; i < hotKeys.Length; i++)
            {
                WriteXY(x, 0, hotKeys[i], ConsoleColor.Red);

                // позиция вывода описания - к позиции аваод хот-кея добавить
                // длину строки-хоткея и учесть пробел
                int descPos = x + hotKeys[i].Length + 1;
                WriteXY(descPos, 0, descs[i], ConsoleColor.Black);

                // вычисление следующей позиции вывода:
                // к позиции вывода описания добавить ее длину и промежуток до следующего вывода
                x = descPos + descs[i].Length + 3;
            } // for i

            // восстановить цвет фона
            Console.BackgroundColor = oldBkColor;
            
        } // ShowNavBar


    }
}