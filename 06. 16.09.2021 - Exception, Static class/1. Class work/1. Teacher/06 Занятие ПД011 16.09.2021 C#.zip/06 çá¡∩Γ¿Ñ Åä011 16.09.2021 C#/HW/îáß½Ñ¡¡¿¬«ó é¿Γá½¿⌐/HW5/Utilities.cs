﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW5
{
	public static class Utilities
	{
		private static Random _rand = new Random();
		public static void ShowNavBar(string promt)
		{
			// сохранить цвет фона
			ConsoleColor oldBkColor = Console.BackgroundColor;

			string header = new string(' ', Console.WindowWidth);

			Console.BackgroundColor = ConsoleColor.Gray;
			Console.SetCursorPosition(0, 0);
			Console.Write(header);

			// Выводим текст в верхнюю строку
			WriteXY(2, 0, promt, ConsoleColor.Black);

			// восстановить цвет фона
			Console.BackgroundColor = oldBkColor;
		}

		// Вспомогательный метод для вывода в заданных координатах окна консоли текста
		// заданным цветом
		public static void WriteXY(int x, int y, string s, ConsoleColor color)
		{
			// сохранить текущий цвет консоли и установить заданный
			ConsoleColor oldColor = Console.ForegroundColor;
			Console.ForegroundColor = color;

			Console.SetCursorPosition(x, y);
			Console.WriteLine(s);

			// восстановить цвет консоли
			Console.ForegroundColor = oldColor;
		}

		public static double GenerateDouble(double from, double to) => from + _rand.NextDouble() * (to - from);
		public static int GenerateInt(int from, int to) => _rand.Next(from, to);
	}
}
