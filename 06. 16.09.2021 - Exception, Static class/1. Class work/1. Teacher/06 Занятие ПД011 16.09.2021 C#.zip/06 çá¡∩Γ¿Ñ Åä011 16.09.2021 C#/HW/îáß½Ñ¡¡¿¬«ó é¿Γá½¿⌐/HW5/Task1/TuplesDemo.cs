﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW5.Task1
{
	// Статический класс, содержащий методы решения Задачи 1
	// на демонстрацию работы с кортежами
	public static class TuplesDemo
	{
		private static double _from = 0; // задание нижнего порога генерации значений
		private static double _to = 10;  // задание верхнего порога генерации значений
		private static int _n = 3;		 // количество генераций

		// Метод вычисления ср.арифметического и ср.геометрического значений двух положительных вещественных чисел
		private static (double, double) Mean(double x, double y)
		{
			var a_mean = (x + y) / 2;
			var g_mean = Math.Sqrt(x * y);
			return (a_mean, g_mean);
		}

		// Метод, вычисляющий периметр и площадь прямоугольника со сторонами, параллельными осям координат
		private static (double, double) RectPS(double x1, double y1, double x2, double y2)
		{
			var perim = (Math.Abs(x2 - x1) + Math.Abs(y2 - y1)) * 2;
			var square = Math.Abs(x2 - x1) * Math.Abs(y2 - y1);

			return (perim, square);
		}

		// Реализация решения задачи Proc3
		public static void Proc3()
		{
			for (int i = 1; i <= _n; i++)
			{
				var x = Utilities.GenerateDouble(_from, _to);
				var y = Utilities.GenerateDouble(_from, _to);
				var tuple = Mean(x, y);
				Console.WriteLine($"    {i}. x = {x, 4:f2}, y = {y, 4:f2}, a_mean = {tuple.Item1, 4:f2}, g_mean = {tuple.Item2, 4:f2}");
			}
		}

		// Реализация решения задачи Proc5
		public static void Proc5()
		{
			for (int i = 1; i <= _n; i++)
			{
				var x1 = Utilities.GenerateDouble(_from, _to);
				var x2 = Utilities.GenerateDouble(_from, _to);
				var y1 = Utilities.GenerateDouble(_from, _to);
				var y2 = Utilities.GenerateDouble(_from, _to);

				var tuple = RectPS(x1, y1, x2, y2);

				Console.WriteLine($"    {i}. x1 = {x1,4:f2}, y1 = {y1,4:f2}, x2 = {x2,4:f2}, y2 = {y2,4:f2}, " +
				                  $"P = {tuple.Item1,4:f2}, S = {tuple.Item2,4:f2}");
			}
		}

		// Вывод условия задачи Proc3
		public static void Proc3TaskText()
		{
			Console.WriteLine(
$@"    Описать метод Mean(x, y), вычисляющий среднее арифметическое и среднее геометрическое 
    двух положительных вещественных чисел x и y. Возвращать a_mean, g_mean из метода в кортеже.
    С помощью этого метода найти среднее арифметическое и среднее геометрическое для трех пар
    случайных чисел из диапазона значений [0, 10].");
		}


		// Вывод условия задачи Proc5
		public static void Proc5TaskText()
		{
			Console.WriteLine(
				$@"    Описать метод RectPS(x1, y1, x2, y2), вычисляющий периметр и площадь прямоугольника со сторонами,
    параллельными осям координат, по координатам (x1, y1), (x2, y2) его противоположных вершин
    (стороны вычисляются как a = Math.Abs(x2 - x1), b = Math.Abs(y2 – y1)). Метод возвращает кортеж 
    с периметром и площадью. С помощью этого метода найти периметры и площади трех прямоугольников
    с данными противоположными вершинами.");
		}

	}
}
