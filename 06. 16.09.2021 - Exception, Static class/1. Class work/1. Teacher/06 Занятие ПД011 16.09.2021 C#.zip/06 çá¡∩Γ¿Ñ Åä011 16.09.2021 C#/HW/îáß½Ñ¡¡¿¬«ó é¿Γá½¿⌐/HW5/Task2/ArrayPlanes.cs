﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW5.Task2
{
	/// <summary>
	/// Класс для работы с массивом объектов класса Plane
	/// </summary>
	public class ArrayPlanes
	{
		// Массив самолётов
		public Plane[] Planes { get; set; }

		// Инициализация массива
		public void Initialize()
		{
			Planes = new[] {
				new Plane {TypeBrand = "Airbus A220", Paxes = 130, Consumption = 2600, Engines = 2, Owner = "Авиакомпания 1" },
				new Plane {TypeBrand = "Боинг-747", Paxes = 610, Consumption = 14500, Engines = 4, Owner = "Авиакомпания 2" },
				new Plane {TypeBrand = "Bombardier CRJ", Paxes = 50, Consumption = 1260, Engines = 2, Owner = "Авиакомпания 3" },
				new Plane {TypeBrand = "Embraer ERJ", Paxes = 112, Consumption = 840, Engines = 2, Owner = "Авиакомпания 4" },
				new Plane {TypeBrand = "ATR 42/72", Paxes = 74, Consumption = 960, Engines = 2, Owner = "Авиакомпания 5" },
				new Plane {TypeBrand = "Saab", Paxes = 50, Consumption = 820, Engines = 2, Owner = "Авиакомпания 6" },
				new Plane {TypeBrand = "Антонов Ан-148", Paxes = 80, Consumption = 1550, Engines = 2, Owner = "Авиакомпания 7" },
				new Plane {TypeBrand = "Туполев Ту-204", Paxes = 166, Consumption = 3250, Engines = 2, Owner = "Авиакомпания 8" },
				new Plane {TypeBrand = "BAe Avro RJ", Paxes = 100, Consumption = 2600, Engines = 4, Owner = "Авиакомпания 9" },
				new Plane {TypeBrand = "Боинг-777", Paxes = 500, Consumption = 6900, Engines = 2, Owner = "Авиакомпания 10" },
			};
		}

		// Поиск значения максимального кол-ва пассажирских мест
		private int MaxPaxes()
		{
			int maxPaxes = Planes[0].Paxes;
			for (int i = 1; i < Planes.Length; i++)
			{
				int paxes = Planes[i].Paxes;
				if (paxes > maxPaxes) maxPaxes = paxes;
			}

			return maxPaxes;
		}

		// Отбор самолетов с максимальным количеством пассажирских мест
		public Plane[] FindMaxPaxes()
		{
			int maxPaxes = MaxPaxes();

			bool MaxPaxesPredicate(Plane p) => p.Paxes == maxPaxes;

			Plane[] found = Array.FindAll(Planes, MaxPaxesPredicate);

			return found;
		}


		// Вывести массив самолётов в консоль
		public void Show(string caption, int indent)
		{
			// вывод заголовка таблицы персон
			string space = " ".PadRight(indent);
			Console.Write($"\n\n\n\n{space}{caption}\n" +
			              $"{Plane.Header(indent)}");

			// вывод всех элементов массива самолётова
			int row = 1;
			void OutItem(Plane p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
			Array.ForEach(Planes, OutItem);

			// вывод подвала таблицы
			Console.WriteLine(Plane.Footer(indent));
		} 

		// Вывести массив отобранных самолётов в консоль.
		public void Show(string caption, int indent, Plane[] planes)
		{
			// вывод заголовка таблицы самолётов
			string space = " ".PadRight(indent);
			Console.Write($"\n\n\n\n{space}{caption}\n" +
			              $"{Plane.Header(indent)}");

			// вывод всех элементов массива самолётов
			int row = 1;
			void OutItem(Plane p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
			Array.ForEach(planes, OutItem);

			// вывод подвала таблицы
			Console.WriteLine(Plane.Footer(indent));
		}

		// Упорядочить массив самолётов по свойству производитель и тип
		public void OrderByType() => Array.Sort(Planes, Plane.TypeComparer);

		// Упорядочить массив самолётов по убыванию количества двигателей
		public void OrderByEnginesDesc() => Array.Sort(Planes, Plane.EnginesDescComparer);

		// Упорядочить массив самолётов по возрастанию расхода горючего за час полета
		public void OrderByConsumption() => Array.Sort(Planes, Plane.ConsumptionComparer);

	}
}
