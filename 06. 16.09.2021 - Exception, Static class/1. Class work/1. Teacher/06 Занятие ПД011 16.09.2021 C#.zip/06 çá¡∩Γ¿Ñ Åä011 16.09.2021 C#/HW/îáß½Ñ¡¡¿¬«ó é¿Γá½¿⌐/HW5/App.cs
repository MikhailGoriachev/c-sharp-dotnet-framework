﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW5.Task1;
using HW5.Task2;

namespace HW5
{
	// Класс, обеспечивающий работу приложения
	class App
	{
		// Массив самолётов
		private ArrayPlanes _planes;

		
		// Конструктор по-умолчанию
		public App()
		{
			_planes = new ArrayPlanes();
			_planes.Initialize();
		}



		// Метод запуска работы меню приложения
		public void Run()
		{
			Console.ForegroundColor = ConsoleColor.Green;
			Console.BackgroundColor = ConsoleColor.Black;

			Menu menu = new Menu(new[]
				{
					new Menu.MenuItem() {Text = "Решение задачи Proc3", Callback = MenuItem1},
					new Menu.MenuItem() {Text = "Решение задачи Proc5", Callback = MenuItem2},
					new Menu.MenuItem() {Text = "Вывод в самолётов с максимальным количеством пассажирских мест", Callback = MenuItem3},
					new Menu.MenuItem() {Text = "Упорядочить массив по производителю и типу", Callback = MenuItem4},
					new Menu.MenuItem() {Text = "Упорядочить массив по убыванию количества двигателей", Callback = MenuItem5},
					new Menu.MenuItem() {Text = "Упорядочить массив по возрастанию расхода горючего", Callback = MenuItem6},
					new Menu.MenuItem() {Text = "Выход"}
				}, new Point(5, 5),
				"Меню приложения");

			menu.Run();
		}

		// Решение задачи Proc3
		private void MenuItem1()
		{
			Utilities.ShowNavBar("    Решение задачи Proc3");
			
			TuplesDemo.Proc3TaskText();

			Console.WriteLine("\n\n    Решения по сгенерированым данным:\n\n");
			
			TuplesDemo.Proc3();

		}

		// Решение задачи Proc5
		private void MenuItem2()
		{
			Utilities.ShowNavBar("    Решение задачи Proc5");

			TuplesDemo.Proc5TaskText();

			Console.WriteLine("\n\n    Решения по сгенерированым данным:\n\n");

			TuplesDemo.Proc5();
		}



		// Вывод самолётов с максимальным количеством пассажирских мест 
		private void MenuItem3()
		{
			Utilities.ShowNavBar("    Вывод в самолётов с максимальным количеством пассажирских мест");

			Plane[] maxPaxesPlanes = _planes.FindMaxPaxes();

			_planes.Show("Cамолёты с максимальным количеством пассажирских мест", 12, maxPaxesPlanes);

		}

		// Упорядочить массив самолётов по производителю и типу
		private void MenuItem4()
		{
			Utilities.ShowNavBar("    Упорядочить массив по производителю и типу");

			_planes.OrderByType();
			_planes.Show("Коллекция самолётов, упорядоченных по производителю и типу", 12);
		}

		// Упорядочить массив самолётов по убыванию количества двигателей
		private void MenuItem5()
		{
			Utilities.ShowNavBar("    Упорядочить массив по убыванию количества двигателей");

			_planes.OrderByEnginesDesc();
			_planes.Show("Коллекция самолётов, упорядоченных по убыванию количества двигателей", 12);
		}

		// Упорядочить массив самолётов по возрастанию расхода горючего
		private void MenuItem6()
		{
			Utilities.ShowNavBar("    Упорядочить массив по возрастанию расхода горючего");

			_planes.OrderByConsumption();
			_planes.Show("Коллекция самолётов, упорядоченных по возрастанию расхода горючего", 12);
		}
	}
}
