﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace HW5.Task2
{
	// Класс, описывающий самолёт
	public class Plane
	{
		// Производитель и тип самолёта
		public string TypeBrand { get; set; }
		// Кол-во пассажирских мест
		public int Paxes { get; set; }
		// Расход горючего за час полёта
		public double Consumption { get; set; }
		// Кол-во двигателей
		public int Engines { get; set; }
		// Название авиакомпании – владельца
		public string Owner { get; set; }

		public override string ToString()
		{
			return $"Производитель и тип: {TypeBrand}, пассажирских мест: {Paxes}, Расход топлива: {Consumption}," +
			       $" кол-во двигателей: {Engines}, авиакомпания владелец: {Owner}";
		}

		// представление объекта в виде строки таблицы
		public string ToTableRow(int rowNumber) =>
			$"│ {rowNumber,3} │ {TypeBrand,-17} │ {Paxes,12} " +
			$"│ {Consumption,10:f1}  │ {Engines,10} │ {Owner,-21} │";

        // статическое свойство для вывода шапки таблицы
		public static string Header(int indent)
		{
			string spaces = " ".PadRight(indent);
			string str =
				$"{spaces}┌─────┬───────────────────┬──────────────┬─────────────┬────────────┬───────────────────────┐\n" +
				$"{spaces}│  №  │  Производитель и  │ Пассажирских │ Расход за   │   Кол-во   │ Авиакомпания-владелец │\n" +
				$"{spaces}│ п/п │    тип самолёта   │      мест    │ час полёта  │ двигателей │       проживания      │\n" +
				$"{spaces}├─────┼───────────────────┼──────────────┼─────────────┼────────────┼───────────────────────┤\n";
			return str;
		}

		// статический метод для вывода подвала таблицы
		public static string Footer(int indent) =>
			$"{" ".PadRight(indent)}└─────┴───────────────────┴──────────────┴─────────────┴────────────┴───────────────────────┘";


		// Компараторы для сортировки по заданию
		// Компаратор для сортировки по производителю и типу
		public static int TypeComparer(Plane p1, Plane p2) =>
			p1.TypeBrand.CompareTo(p2.TypeBrand);


		// Компаратор для сортировки по убыванию количества двигателей
		public static int EnginesDescComparer(Plane p1, Plane p2) =>
			p2.Engines.CompareTo(p1.Engines);

		// Компаратор для сортировки по возрастанию расхода горючего за час полета
		public static int ConsumptionComparer(Plane p1, Plane p2) =>
			p1.Consumption.CompareTo(p2.Consumption);

	}
}
