﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork16._09._21
{
    public class Airplane
    {
        // производитель и тип самолета
        private string _brandAndType;
        public string BrandAndType
        {
            get { return _brandAndType; }
            set { if (!string.IsNullOrWhiteSpace(value)) _brandAndType = value; }
        }

        // количество пассажирских мест 
        private int _passSeats;
        public int PassSeats
        {
            get { return _passSeats; }
            set { if(value>0)_passSeats = value; }
        }

        // расход горючего за час полета 
        private double _fuelUsage;
        public double FuelUsage
        {
            get { return _fuelUsage; }
            set { if(value>0)_fuelUsage = value; }
        }

        // количество двигателей 
        private int _enginesCount;
        public int EnginesCount
        {
            get { return _enginesCount; }
            set { if (value > 0) _enginesCount = value; }
        }

        // название авиакомпании – владельца
        private string _nameCompany;
        public string NameCompany
        {
            get { return _nameCompany; }
            set { if (!string.IsNullOrWhiteSpace(value)) _nameCompany = value; }
        }


        // Компараторы для сортировки по заданию
        // Компаратор для сортировки по свойству производитель и тип 
        public static int BrandAndTypeComparer(Airplane p1, Airplane p2) =>
            p1._brandAndType.CompareTo(p2._brandAndType);

        // Компаратор для сортировки по убыванию количества двигателей
        public static int EnginesCountComparer(Airplane p1, Airplane p2) =>
            p2._enginesCount.CompareTo(p1._enginesCount);

        // Компаратор для сортировки по возрастанию расхода горючего за час полета
        public static int FuelUsageComparer(Airplane p1, Airplane p2) =>
            p1._fuelUsage.CompareTo(p2._fuelUsage);


        // статическое свойство для вывода шапки таблицы
        public static string Header()
        {
            
            string str =  $"┌────────────────────┬────────────────┬─────────────────┬─────────────┬──────────────────┐\n" +
                          $"│ Производитель      │Количество пасс.│ Расход горючего │ Количество  │ Название         │\n" +
                          $"│     и тип самолета │      мест      │  за час полета  │  двигателей │     авиакомпании │\n" +
                          $"├────────────────────┼────────────────┼─────────────────┼─────────────┼──────────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"└────────────────────┴────────────────┴─────────────────┴─────────────┴──────────────────┘";

        // представление объекта в виде строки таблицы
        public string ToTableRow()
        {
            return $"│ {_brandAndType,18} │ {_passSeats,14} │ {_fuelUsage,15:f2} " +
                   $"│ {_enginesCount,11} │ {_nameCompany,16:f2} │";
        }

    }
}
