﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork16._09._21
{
    public static class TuplesDemo
    {

        // метод вычисляющую среднее арифметическое и среднее геометрическое двух положительных вещественных чисел
        public static (double a_mean, double g_mean) Mean ((double x, double y) tuple) {

            double a_mean = (tuple.x + tuple.y) / 2d;
            double g_mean = Math.Sqrt(tuple.x * tuple.y);

            return (a_mean, g_mean);
        }


        // метод вычисляющую периметр и площадь прямоугольника со сторонами, параллельными осям координат, по координатам его противоположных вершин
        public static (int P, int S) RectPS((int x1, int y1, int x2, int y2)tuple)
        {
            int a = Math.Abs(tuple.x2 - tuple.x1);
            int b = Math.Abs(tuple.y2 - tuple.y1);

            int P = 2 * (a + b);
            int S = a * b;

            return (P, S);
        }




    }

}
