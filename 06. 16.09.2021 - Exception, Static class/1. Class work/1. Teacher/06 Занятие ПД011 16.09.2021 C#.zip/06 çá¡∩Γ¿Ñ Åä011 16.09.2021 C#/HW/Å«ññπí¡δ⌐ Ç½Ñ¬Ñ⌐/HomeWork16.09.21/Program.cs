﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork16._09._21
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Домашние задание на 16.09.21";


           // простейшее меню приложения
           MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.D1, Text = "Демонстрация метода Mean" },
                new MenuItem { HotKey = ConsoleKey.D2, Text = "Демонстрация метода RectPS" },
                new MenuItem { HotKey = ConsoleKey.D3, Text = "Демонстрация работы класса самолет" },
                
               };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true)
            {
                // настройка цветового оформления
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.Clear();
                Console.CursorVisible = false;

                Utils.ShowNavBarTask("  Введение в ООП C# - классы, свойства, массивы объектов");
                Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                Console.Clear();

                switch (key)
                {
                    // Формирование коллекции конусов
                    case ConsoleKey.D1:
                        App.DemoMean();
                        break;

                    // Вывод коллекции конусов в табличном формате
                    case ConsoleKey.D2:
                        App.DemoRectPS();
                        break;

                    // Вывод коллекции конусов с итогами и цветовым выделением
                    case ConsoleKey.D3:
                        app.DemoTask2();
                        break;


                    // выход из приложения назначен на клавишу F10 или кавишу Z
                    case ConsoleKey.F10:
                    case ConsoleKey.Z:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                        Console.CursorVisible = true;
                        return;

                    default:
                        continue;
                } // switch

                // Ожидать нажатия любой клавиши по окончании работы пункта меню
                Console.CursorVisible = true;
                Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                Console.ReadKey(true);
            } // while
        }
    }
}
