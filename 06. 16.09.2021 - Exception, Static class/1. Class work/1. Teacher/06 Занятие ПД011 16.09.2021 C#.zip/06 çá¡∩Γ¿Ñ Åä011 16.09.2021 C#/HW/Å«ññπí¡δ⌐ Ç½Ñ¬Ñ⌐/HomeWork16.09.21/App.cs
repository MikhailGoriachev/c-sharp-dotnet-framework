﻿using System;

namespace HomeWork16._09._21
{
    public class App
    {
        private ArrayAirplanes _planes;  // объект для конусов
        

        // в конструкторе по умолчанию будем заполнять коллекции
        public App() : this(new ArrayAirplanes())
        {
            _planes.Initialize();
            
        } // App

        // конструктор с внедрением зависимостей/ dependency injection
        public App(ArrayAirplanes planes)
        {
            _planes = planes;
            
        } // App


        public static void DemoMean() {

            int countIter = 3;

            for (int i = 0; i < countIter; i++)
            {
                var tuple1 = (Utils.GetRandom(0d, 10d), Utils.GetRandom(0d, 10d));


                Console.WriteLine($"\nВывоз функции Mean для кортежа {tuple1 ,5:f3}, итерация {i+1}");

                var tupResult = TuplesDemo.Mean(tuple1);

                Console.WriteLine($"Резульатат:\n" +
                                  $"\tCреднее арифметическое a_mean : {tupResult.Item1,5:f3}\n" +
                                  $"\tCреднее геометрическое g_mean : {tupResult.Item2,5:f3}\n");
            }// for     
            
        }// DemoMean()


        public static void DemoRectPS()
        {

            int countIter = 3;

            for (int i = 0; i < countIter; i++)
            {
                var tuple1 = (Utils.GetRandom(10,20), (Utils.GetRandom(5, 10)+2), Utils.GetRandom(3,9), (Utils.GetRandom(6,13)+6));


                Console.WriteLine($"\nВывоз функции RectPS для кортежа {tuple1,5}, итерация {i + 1}");

                var tupResult = TuplesDemo.RectPS(tuple1);

                Console.WriteLine($"Резульатат:\n" +
                                  $"\tПериметр прямоугольника  : {tupResult.Item1,5:f3}\n" +
                                  $"\tПлощадь  прямоугольника  : {tupResult.Item2,5:f3}\n");
            }// for     

        }// DemoMean()


        public void DemoTask2() {

            Console.WriteLine($"\n\tДемонстрация задачи 2");

            // инициализация и вывод на экран
            if (_planes.Empty) _planes.Initialize();
            _planes.Show();

            // поиск и вывод самолетов с максимальным количеством пассажиров
            Console.WriteLine($"\n\tПоиск и вывод самолетов с максимальным количеством пассажиров");
            Airplane[] maxPassPlanes = _planes.FindMaxPassSeats();
            Console.Write($"{Airplane.Header()}");
            foreach (Airplane item in maxPassPlanes)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Airplane.Footer());

            _planes.SortByBrandAndType();
            _planes.SortByEnginesCount();
            _planes.SortByFuelUsage();



        }



    }
}
