﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork16._09._21
{
    public class ArrayAirplanes
    {
        private Airplane[] _airplanes;

        public Airplane[] Airplanes
        {
            get { return _airplanes; }
            set { _airplanes = value; }
        }

        

        public bool Empty => Airplanes.Length == 0;


        public void Initialize()
        {

            Airplanes = new[] {
                new Airplane {BrandAndType = "SSJ-100-95LR",     PassSeats = 100, FuelUsage = 2296d, EnginesCount =  4, NameCompany = "DNR AirLine"},
                new Airplane {BrandAndType = "МС-21-300UL",     PassSeats = 200, FuelUsage = 2265d, EnginesCount =  6, NameCompany = "LNR AirLine"},
                new Airplane {BrandAndType = "Boeing 777-300ER",     PassSeats = 365, FuelUsage = 7800d, EnginesCount =  8, NameCompany = "DNR AirLine"},
                new Airplane {BrandAndType = "Ил-76Т",     PassSeats = 0, FuelUsage = 8262d, EnginesCount =  4, NameCompany = "LNR AirLine"},
                new Airplane {BrandAndType = "Бе-200ЧС",     PassSeats = 0, FuelUsage = 1540d, EnginesCount =  3, NameCompany = "DNR AirLine"},
                new Airplane {BrandAndType = "ATR-72-600",     PassSeats = 74, FuelUsage = 580d, EnginesCount =  4, NameCompany = "LNR AirLine"},
                new Airplane {BrandAndType = "Ил-96-300",     PassSeats = 300, FuelUsage = 7800d, EnginesCount =  5, NameCompany = "DNR AirLine"},
                new Airplane {BrandAndType = "Fokker-100",     PassSeats = 107, FuelUsage = 2150d, EnginesCount =  6, NameCompany = "LNR AirLine"},
                new Airplane {BrandAndType = "Falcon 7X",     PassSeats = 19, FuelUsage = 318d, EnginesCount =  2, NameCompany = "DNR AirLine"},
                new Airplane {BrandAndType = "L-410UVP",     PassSeats = 19, FuelUsage = 247d, EnginesCount =  2, NameCompany = "LNR AirLine"},
                new Airplane {BrandAndType = "Ту-150",     PassSeats = 150, FuelUsage = 2500d, EnginesCount =  4, NameCompany = "DNR AirLine"},
                new Airplane {BrandAndType = "Як-20",     PassSeats = 30, FuelUsage = 1200d, EnginesCount =  3, NameCompany = "LNR AirLine"}          
                
            };
        } // Initialize

        // Возвращает максимальное количество пассажирских мест
        int MaxPass()
        {
            int maxPass = Airplanes[0].PassSeats;
            for (int i = 1; i < Airplanes.Length; i++)
            {
                int pass = Airplanes[i].PassSeats;
                if (pass > maxPass)
                    maxPass = pass;
            } // for i

            return maxPass;
        } // MaxHeight



        // Отбор самолетов с максимальным количеством пассажирских мест
        public Airplane[] FindMaxPassSeats()
        {
            
            int maxPass = MaxPass();
            
            bool MaxHeightPredicate(Airplane p) => p.PassSeats == maxPass;
            
            Airplane[] selected = Array.FindAll(Airplanes, MaxHeightPredicate);

            return selected;
        } // FindMaxHeight


        public void Show()
        {
            // вывод заголовка таблицы 
            
            Console.Write($"{Airplane.Header()}");

            // вывод всех элементов массива 

            foreach (Airplane item in Airplanes)
            {
                Console.WriteLine(item.ToTableRow());
            }           

            // вывод подвала таблицы
            Console.WriteLine(Airplane.Footer());
        } // Show


        public void SortByBrandAndType() {

            Console.WriteLine($"\nСортировка самолетов по свойству производитель и тип");

            Array.Sort(Airplanes, Airplane.BrandAndTypeComparer);
            Show();

        }


        public void SortByEnginesCount()
        {

            Console.WriteLine($"\nСортировка самолетов по убыванию количества двигателей");

            Array.Sort(Airplanes, Airplane.EnginesCountComparer);
            Show();

        }


        public void SortByFuelUsage()
        {

            Console.WriteLine($"\nСортировка самолетов по возрастанию расхода горючего за час полета");

            Array.Sort(Airplanes, Airplane.FuelUsageComparer);
            Show();

        }
    }
}
