﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__5___Tuples_
{
    public class Plane
    {
        // Производитель и тип самолета
        private string _manufactureType = "Airbus A310";   
        public string ManufactureType{
            get => _manufactureType;
            set => _manufactureType = string.IsNullOrWhiteSpace(value) ? _manufactureType : value;
        } // ManufactureType

        // Количество пассажиров
        private int _couPas = 4;
        public int CouPas
        {
            get => _couPas;
            set => _couPas = (value <= 0) ? _couPas : value;
        } // CouPas

        // Расход горючего за час полета
        private double _consumPerHour = 32.5;
        public double ConsumPerHour
        {
            get => _consumPerHour;
            set => _consumPerHour = (value <= 0d) ? _consumPerHour : value;
        } // ConsumptionPerHour

        // Количество двигателей
        private int _couEngine = 4;
        public int CouEngine
        {
            get => _couEngine;
            set => _couEngine = (value <= 0)? _couEngine : value;
        } // CouEngines

        // Название авиакомпании - владельца
        private string _nameAirlineOwner;
        public string NameAirlaneOwner
        {
            get => _nameAirlineOwner;
            set => _nameAirlineOwner = string.IsNullOrWhiteSpace(value) ? _nameAirlineOwner : value;
        } // NameAirlaneOwner


        public override string ToString() =>
            $" Тип сомолета {_manufactureType };\n Количество пассажирских мест {_couPas};\n Расход горючего за час полета{_consumPerHour};" +
            $"\n Количество двигателей {_couEngine};\n Название авиакомпании {_nameAirlineOwner}";

        // представление объекта в виде строки таблицы
        public string ToTableRow(int rowNumber) =>
            $"│ {rowNumber,3} │ {_manufactureType,-22} │ {_couPas,6}    " +
            $"│ {_consumPerHour,14:f2}  │ {_couEngine,10} │ {_nameAirlineOwner,-16} │";

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬────────────────────────┬───────────┬─────────────────┬────────────┬──────────────────┐\n" +
                $"{spaces}│  №  │   Производитель и      │  Кол-во   │ Расход горючего │   Кол-во   │   Название       │\n" +
                $"{spaces}│ п/п │      тип самолета      │ пас. мест │ за час полета   │ двигателей │     авиакомпание │\n" +
                $"{spaces}├─────┼────────────────────────┼───────────┼─────────────────┼────────────┼──────────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}┴─────┴────────────────────────┴───────────┴─────────────────┴────────────┴──────────────────┴";

        // Компаратор для сортировки по производителю и типу самолета
        public static int ManufactureTypeComparer(Plane plane1, Plane plane2) =>
            plane1._manufactureType.CompareTo(plane2._manufactureType);

        // Компаратор для сортировки по убыванию количества двигателей
        public static int CouEngineComparer(Plane plane1, Plane plane2) =>
            plane2._couEngine.CompareTo(plane1._couEngine);

        // Компаратор для сортировки по возростанию расхода горючего за час
        public static int ConsumPerHourComparer(Plane plane1, Plane plane2) =>
          plane1._consumPerHour.CompareTo(plane2._consumPerHour);



    }// Plane


}
