﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__5___Tuples_
{
    public class Airlane
    {
        public string Title { get; set; }
        public Plane[] Planes { get; set; }

        public void Initialize()
        {
            Title = $"Самолеты стоящие в ангарах аэропорта; дата: {DateTime.Now:f}";
            
            // Массив названий самолетов
            string[] type = { "Airbus-A310", "Airbus-A319","AirbusA320 ", "ТУ-154", "ИЛ-96",
                "ТУ-204", "Boeing-757", "Boeing-747","Mitsubishi SpaceJet","CR929" };

            string[] name =  { "Аврора", "ИрАэро","iFly", "Комиавиатранс", "Нордавиа",
                "NordStar", "Победа", "Red Wings","РусЛайн","Royal Flight" };

            const int n = 12;

            // * Возможно неверно |!спросить!| *
            Planes = new Plane[n];
;           for (int i = 0; i < n; i++){
                // переменные добавлены для читабельности в момент инициализации
                string tempType = type[Utils.Random.Next(0, 9)];
                int couPas = Utils.GetRandom(490, 500);
                double consumPerHour = Utils.GetRandom(10d, 700d);
                int couEngine = Utils.GetRandom(0, 8);
                string tempName = name[Utils.Random.Next(0, 9)];
                
                Planes [i]= new Plane { ManufactureType = tempType, CouPas = couPas, ConsumPerHour = consumPerHour, CouEngine = couEngine, NameAirlaneOwner = tempName };

            }// for

        } // Initialize

        public int MaxCouPas(){
            int maxCouPas = Planes[0].CouPas;
            for (int i = 1; i < Planes.Length; i++){
                if (maxCouPas < Planes[i].CouPas)
                    maxCouPas = Planes[i].CouPas;
            } // for
            return maxCouPas;
        } // MaxCouPas

        public Plane[] FindMaxCouPas(){
     
            int maxCouPas = MaxCouPas();
   
            bool ISMaxCouPas(Plane p) => p.CouPas == maxCouPas;
        
            Plane[] selected = Array.FindAll(Planes, ISMaxCouPas);

            return selected;


        }// FindMaxCouPas


        // Вывести массив персон в консоль
        public void Show(string caption, int indent)
        {
            // вывод заголовка таблицы персон
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n" +
                              $"{Plane.Header(indent)}");
           
            int maxCouPas = MaxCouPas();
            // вывод всех элементов массива персон
            int row = 1;
            // void OutItem(Plane p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");

            // Сохранение цвета фона 
            ConsoleColor oldFgColor = Console.ForegroundColor;
            ConsoleColor oldBgColor = Console.BackgroundColor;

            void OutItem(Plane p) {
                //  В задание не сказано как именно отображать самолеты с максимальным кол-во пассажиров 
                //  поэтому я добавил отдельный show, а также добавил выделение в основном выводе то есть в этом методе.
                if (p.CouPas == maxCouPas)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                } else { 
                Console.ForegroundColor = oldFgColor;
                Console.BackgroundColor = oldBgColor;
                } // if else 

            Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            };
            
            Array.ForEach(Planes, OutItem);


            // Необходимо на случай если последний элемент имеет максимальное количество пассажирских мест
            Console.ForegroundColor = oldFgColor;
            Console.BackgroundColor = oldBgColor;
            // вывод подвала таблицы
            Console.WriteLine(Plane.Footer(indent));

        } // Show

        // Вывести массив отобранных персон в консоль.
        public void Show(string caption, int indent, Plane[] persons)
        {
            // Сохранение цвета фона 
            ConsoleColor oldFgColor = Console.ForegroundColor;
            ConsoleColor oldBgColor = Console.BackgroundColor;


            // вывод заголовка таблицы персон
            string space = " ".PadRight(indent);
            Console.Write($"\n\n\n\n{space}{caption}\n{space}{Title}\n");
            // Установка нового цвета
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.Write($"{Plane.Header(indent)}");



            // вывод всех элементов массива персон
            int row = 1;
            void OutItem(Plane p) => Console.WriteLine($"{space}{p.ToTableRow(row++)}");
            Array.ForEach(persons, OutItem);


            // вывод подвала таблицы
            Console.WriteLine(Plane.Footer(indent));

            Console.ForegroundColor = oldFgColor;
            Console.BackgroundColor = oldBgColor;
        } // Show

        // Упорядочить массив самолетов по свойству производитель и тип
        public void OrderByManufactureType() => Array.Sort(Planes, Plane.ManufactureTypeComparer);

        // Упорядочить массив самолетов по убыванию количества двигателей
        public void OrderByCouEngine() => Array.Sort(Planes, Plane.CouEngineComparer);

        // Упорядочить массив самолетов по возрастанию расхода горючего за час полета
        public void OrderByConsumPerHour() => Array.Sort(Planes, Plane.ConsumPerHourComparer);

 


    }
}
