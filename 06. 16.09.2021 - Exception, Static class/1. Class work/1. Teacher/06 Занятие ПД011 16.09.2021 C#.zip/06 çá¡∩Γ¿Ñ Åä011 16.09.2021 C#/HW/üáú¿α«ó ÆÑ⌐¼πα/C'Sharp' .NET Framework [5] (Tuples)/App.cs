﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__5___Tuples_
{
    public class App
    {
        private Airlane _airlane;

        // Конструктор по умолчанию
        public App() : this(new Airlane() )
        {
            _airlane.Initialize();
        } // App

        // Конструктор с парамметрами
        public App(Airlane airlane )
        {
            _airlane = airlane;
  
        } // App

        #region DemoMean (1.1 задания Среднее арифметическое/геометрическое)

        // Демонстрация нахождения среднего арифметического/геометрического
        public void DemoMean()
        {
            ConsoleColor colorF = Console.ForegroundColor;
            ConsoleColor colorB = Console.BackgroundColor;


            const int n = 3;

            // Отступы при выводе данных в таблицу:
            // a) Данные (x,y)
            const int weightXY = 7;
            // b) Среднее арифметическое && геометрическое
            const int weightA_G_Mean = 11;

            // Начальные координаты для вывода ( метода WriteXY )
            int x = 31;
            int y = 8;

            Utils.WriteXY(x, y++, "+───────────────────────────────────────────────────────+", ConsoleColor.Cyan, ConsoleColor.DarkGray);
            Utils.WriteXY(x, y++, "|                   Данные Вычислений                   |", ConsoleColor.Cyan, ConsoleColor.DarkGray);
            Utils.WriteXY(x, y++, "+───────────────────────────────────────────────────────+", ConsoleColor.Cyan, ConsoleColor.DarkGray);
            Utils.WriteXY(x, y++, "|     x     |     y     |    Ср.ариф.   |    Ср.геом.   |", ConsoleColor.Cyan, ConsoleColor.DarkGray);
            Utils.WriteXY(x, y++, "+───────────────────────────────────────────────────────+", ConsoleColor.Cyan, ConsoleColor.DarkGray);
            for (int i = 0; i < n; i++)
            {
                var tuples_data = (x: Utils.GetRandom(0d, 10d), y: Utils.GetRandom(0d, 10d));
                // Вызов демонстрируемого метода
                var result = TuplesDemo.Mean(tuples_data);

                Utils.WriteXY(x, y++, $"|  {tuples_data.x,weightXY:f3}  |  {tuples_data.y,weightXY:f3}  |  {result.a_mean,weightA_G_Mean:f3}  |  {result.g_mean,weightA_G_Mean:f3}  |", ConsoleColor.Black, ConsoleColor.Yellow);


            }// for
            Utils.WriteXY(x, y++, "+───────────────────────────────────────────────────────+", ConsoleColor.Cyan, ConsoleColor.DarkGray);



        } // DemoMean
        #endregion

        #region DemoRectPS (1.2 задание на нахождение площади и периметра прямоугольника)
        // Демонстрация нахождения периметра и площади прямоугольника
        public void DemoRectPS(){
            
            ConsoleColor colorF = Console.ForegroundColor;
            ConsoleColor colorB = Console.BackgroundColor;
            
            
            const int n = 3;
           
            // Отступы при выводе данных прямоугольника в таблицу:
            // a) Сторон (a,b)
            const int weightAB = 7;
            // b) Периметр, площадь
            const int weightAreaPerim = 11;
            
            // Начальные координаты для вывода ( метода WriteXY )
            int x = 31;
            int y = 8;

            Utils.WriteXY(x,y++,"+───────────────────────────────────────────────────────+",ConsoleColor.Black,ConsoleColor.Yellow);
            Utils.WriteXY(x,y++,"|                 Данные Прямоугольника                 |",ConsoleColor.Black,ConsoleColor.Yellow);
            Utils.WriteXY(x,y++,"+───────────────────────────────────────────────────────+",ConsoleColor.Black,ConsoleColor.Yellow);
            Utils.WriteXY(x,y++,"|     a     |     b     |    Периметр   |    Площадь    |",ConsoleColor.Black,ConsoleColor.Yellow);
            Utils.WriteXY(x,y++,"+───────────────────────────────────────────────────────+",ConsoleColor.Black,ConsoleColor.Yellow);
            for (int i = 0; i < n; i++){
                var tuples = (x1: Utils.GetRandom(-10d, 10d), y1: Utils.GetRandom(-10d, 10d), x2: Utils.GetRandom(-10d, 10d), y2: Utils.GetRandom(-10d, 10d));
                // Вызов демонстрируемого метода
                var result = TuplesDemo.RectPS(tuples.x1, tuples.y1, tuples.x2, tuples.y2);

                Utils.WriteXY(x, y++, $"|  {result.a,weightAB:f3}  |  {result.b,weightAB:f3}  |  {result.perimeter,weightAreaPerim:f3}  |  {result.area,weightAreaPerim:f3}  |", ConsoleColor.Cyan, ConsoleColor.DarkGray);
                

            }// for
            Utils.WriteXY(x, y++, "+───────────────────────────────────────────────────────+",ConsoleColor.Black, ConsoleColor.Yellow);

        } // DemoRectPS
        #endregion

        #region Различные методы (2.0 Методы выполняющие решение ряда задач для класса "самолет" (Plane))
        // Генерация данных самолетов
        public void DemoAirlineInitialize(){
            Utils.ShowNavBarTask("  Формирование коллекции самолетов");

            _airlane.Initialize();
            _airlane.Show("Данные сформированы",12);

      
        } // DemoAirlineInitialize

        // Вывод данных о самолетах
        public void DemoShow()
        {
            Utils.ShowNavBarTask("  Вывод данных");

 
            _airlane.Show("Данные о самолетах", 12);


        } // DemoAirlineInitialize

        // Вывод в таблицу самолетов с максимальным количеством пассажирских мест
        public void DemoShowMaxCouPas()
        {
            Utils.ShowNavBarTask("   Вывод в таблицу самолетов с максимальным количеством пассажирских мест");

            Plane[] youngestPersons = _airlane.FindMaxCouPas();
            _airlane.Show("Отобраны вместительные самолеты", 12, youngestPersons);
        } // ShowYoungests

        // Сортировка по типу и производителю самолета
        public void DemoOrderByManufactureType()
        {
            Utils.ShowNavBarTask("  Сортировка по типу и производителю самолета");

            _airlane.OrderByManufactureType();
            _airlane.Show("Список самолетов отсортирован по типу и производителю", 12);

        } // DemoOrderByManufactureType

        // Сортировка по убыванию количества двигателей
        public void DemoOrderByCouEngine()
        {
            Utils.ShowNavBarTask("  Сортировка по убыванию количества двигателей");

            _airlane. OrderByCouEngine();
            _airlane.Show("Список самолетов отсортирован по убыванию количества двигателей", 12);

        } // DemoOrderByCouEngine

        // Сортировка по возростанию расхода горючего за час полета
        public void DemoOrderByConsumPerHour()
        {
            Utils.ShowNavBarTask("  Сортировка по возрастанию расхода горючего за час полета");

            _airlane. OrderByConsumPerHour();
            _airlane.Show("Список самолетов отсортирован по возрастанию расхода горючего за час полета", 12);

        } // DemoOrderByConsumPerHour
        #endregion


    } // App
}