﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__5___Tuples_
{
    public static class TuplesDemo
    {

        // Методы выполнены для практики, нечитабельны

        // Нахождение средне арифметического и средне геометрического (по заданию: 2 положительных вещественных чисел)
        public static (double a_mean, double g_mean) Mean((double x, double y) tuple)
        // Возврат:  средне арифметическое            средне геометрическое
            => (a_mean: (tuple.x + tuple.y) / 2, g_mean: Math.Sqrt(tuple.x * tuple.y));
        // Mean

        // метод возвращает больше параметров чем указано в задании, я решил дополнить кортеж полученными сторонами
        public static (double a,double b,double perimeter, double area)RectPS(double x1,double y1, double x2, double y2) {
            var rectangle = (a: Math.Abs(x2 - x1), b: Math.Abs(y2 - y1));

        // Возврат:   сторона а      сторона b                  периметр                                 площадь
            return (a:rectangle.a, b:rectangle.b, perimetr: (rectangle.a + rectangle.b) * 2, area: rectangle.a * rectangle.b);    
        } // RectPS


    }// class TuplesDemo


}