﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__5___Tuples_
{
    class Program
    {
        static void Main(string[] args)
        {
     
            App app = new App();
            while (true)
            {
                int y = 4;
                int x = 17;
                int choi;
                bool flu = true;
                do
                {
                    y = 4;
                    if (!flu) Console.Clear();
                    Utils.WriteXY(x, y++, "<|-------------------------------------------|>", ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|                    MENU                  |>",ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|   №   >|<           Задания              |>",ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|----------------------------------- ------|>", ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|   1   >|<          Пара чисел            |>",ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|   2   >|<         Прямоугольник          |>",ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.DarkRed,ConsoleColor./*Black*/DarkGray);
                    Utils.WriteXY(x, y++,  "<|xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx|>",ConsoleColor.DarkRed, ConsoleColor./*Black*/DarkGray);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.DarkRed, ConsoleColor./*Black*/DarkGray);
                    Utils.WriteXY(x, y++,  "<|   3   >|<   Генерация дынных самолетов   |>",ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|   4   >|<         Вывод данных           |>",ConsoleColor.Black, ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|   5   >|<      Вывод по критерию         |>", ConsoleColor.Black, ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|   6   >|<  Сортировка по производителю   |>",ConsoleColor.Black, ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|   7   >|< Сортировка по кол-во двигателей|>", ConsoleColor.Black, ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|   8   >|< Сортировка по расходу топлива  |>", ConsoleColor.Black, ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.Black, ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|   0   >|<             EXIT               |>",ConsoleColor.Black,ConsoleColor.White);
                    Utils.WriteXY(x, y++,  "<|------------------------------------------|>", ConsoleColor.Black,ConsoleColor.White);

                    Console.CursorVisible = false;

                    Console.Write("\n\n\t    Введите пункт: ");

                    choi = 0;
                    flu = int.TryParse(Console.ReadLine(), out choi);

                } while (!flu);
                Console.Clear();
                Console.CursorVisible = true;
                
                switch (choi)
                {
                    case 1: app.DemoMean(); break;
                    case 2: app.DemoRectPS(); break;
                    case 3: app.DemoAirlineInitialize(); break;
                    case 4: app.DemoShow(); break;
                    case 5: app.DemoShowMaxCouPas(); break;
                    case 6: app.DemoOrderByManufactureType(); break;
                    case 7: app.DemoOrderByCouEngine(); break;
                    case 8: app.DemoOrderByConsumPerHour(); break;
       
 
                    case 0: Console.Write("\n\n\tДо свидания\n"); break;
                }

                Console.ReadKey(false);
                Console.Clear();
            }// while
            Console.ReadKey(false);
        } // main



    }
}
