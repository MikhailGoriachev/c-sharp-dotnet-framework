﻿using System;

namespace Tuples {

    // Объекты и методы для обработки по заданию
    public class App {

        Random rand = new Random();
        Plane[] planes;


        // Методы для обработок по заданию


        // Задача Proc3
        public void Proc3() {
            Utils.ShowNavBarTask("  Задача Proc3");

            ShowTask1();

            //генерируем кортежи случайных чисел 
            double rand1 = Utils.GetRandom(0, 10);
            double rand2 = Utils.GetRandom(0, 10);
            double rand3 = Utils.GetRandom(0, 10);
            double rand4 = Utils.GetRandom(0, 10);
            double rand5 = Utils.GetRandom(0, 10);
            double rand6 = Utils.GetRandom(0, 10);

            (double, double) tuple1 = (rand1, rand2);
            (double, double) tuple2 = (rand3, rand4);
            (double, double) tuple3 = (rand5, rand6);

            // поиск среднего арифметического и геометрического

            (double, double) mean_tuple1 = TuplesDemo.Mean(tuple1.Item1, tuple1.Item2);
            (double, double) mean_tuple2 = TuplesDemo.Mean(tuple2.Item1, tuple2.Item2);
            (double, double) mean_tuple3 = TuplesDemo.Mean(tuple3.Item1, tuple3.Item2);

            Console.WriteLine("\n\n");

            Console.WriteLine("┌─────────────┬─────────────┬─────────────┬─────────────────┬");
            Console.WriteLine("│    Число 1  │   Число 2   │   A Mean    │     G Mean      │");
            Console.WriteLine("├─────────────┼─────────────┼─────────────┼─────────────────┼");
            Console.WriteLine($"|{tuple1.Item1,12:n2},| {tuple1.Item2,11:n2},|{mean_tuple1.Item1,11:n2}, |{mean_tuple1.Item2,17:n2}|");
            Console.WriteLine($"|{tuple2.Item1,12:n2},| {tuple2.Item2,11:n2},|{mean_tuple2.Item1,11:n2}, |{mean_tuple2.Item2,17:n2}|");
            Console.WriteLine($"|{tuple3.Item1,12:n2},| {tuple3.Item2,11:n2},|{mean_tuple3.Item1,11:n2}, |{mean_tuple3.Item2,17:n2}|");
            Console.WriteLine("└─────────────┴─────────────┴─────────────┴─────────────────┘");


        } // Proc3

        // Решение задачи Proc5
        public void Proc5() {
            Utils.ShowNavBarTask(" Задача Proc5");

            ShowTask2();

            // генерировать случайные числа 
            (double x, double y)[] coords = new (double x, double y)[6];
            for (int i = 0; i < coords.Length; i++) {
                coords[i].x = Utils.GetRandom(-10, 10);
                coords[i].y = Utils.GetRandom(-10, 10);
            }


            Console.WriteLine("\n\n");

            Console.WriteLine(
                "┌─────────────┬─────────────┬─────────────┬─────────────────┬────────────────┬─────────────┬\n"+
                "│      x1     │     x2      │     y1      │     y2          │       Area     │  Perimetr   │\n"+
                "├─────────────┼─────────────┼─────────────┼─────────────────┼────────────────┼─────────────┼");


            // поиск площадей и периметров прямоугольника
            for (int i = 0; i < coords.Length; i+=2) {
                (double a, double p) rect1 = TuplesDemo.RectPS(coords[i].x, coords[i].y, coords[i+1].x, coords[i+1].y);
                Console.WriteLine($"| {coords[i].x,11:n2} | {coords[i].y,11:n2} | {coords[i+1].x,11:n2} | {coords[i+1].y,15:n2} | {rect1.a,14:n2} | {rect1.p,11:n2} | ");
            }
            Console.WriteLine("└─────────────┴─────────────┴─────────────┴─────────────────┴────────────────┴─────────────┘");
        } // Proc5

        // Создание массива самолетов
        public void PlaneInitialise() {
            Utils.ShowNavBarTask("  Создание массива самолета");

            planes = new Plane[]{
                new Plane { Type = "Boeing 747", Pax = 345, Consumption = 200.5, Engines = 2, Airline = "AirFrance" },
                new Plane { Type = "A380", Pax = 250, Consumption = 350.1, Engines = 3, Airline = "KLM" },
                new Plane { Type = "ERJ", Pax = 134, Consumption = 450.2, Engines = 2, Airline = "Luftgansa" },
                new Plane { Type = "ATR", Pax = 234, Consumption = 534.6, Engines = 3, Airline = "Quatar Airlines" },
                new Plane { Type = "Dash-8", Pax = 156, Consumption = 854.9, Engines = 2, Airline = "Air New Zealand" },
                new Plane { Type = "SAAB", Pax = 123, Consumption = 245.4, Engines = 1, Airline = "Singapore Airlines" },
                new Plane { Type = "Cessna", Pax = 180, Consumption = 390.3, Engines = 2, Airline = "Qantas" },
                new Plane { Type = "Beechcraft", Pax = 115, Consumption = 523.9, Engines = 1, Airline = "Emirates" },
                new Plane { Type = "Ту-124", Pax = 290, Consumption = 578.3, Engines = 2, Airline = "Cathy Pacific" },
                new Plane { Type = "Emraer 175", Pax = 15, Consumption = 734.2, Engines = 2, Airline = "Virgin Atlantic" },

                };

            ShowTable();




        } // PlaneInitialise

        // Определить самолет с максимальным количеством мест
        public void MaxPassengers() {
            Utils.ShowNavBarTask("  Определить самолет с максимальным количеством мест");

            int maxpax = Plane.MaxPax(planes);
            ShowMaxPax(maxpax);


        } // 

        // Сортировка  по производителю и типу
        public void SortType() {
            Utils.ShowNavBarTask("  Упорядочить массив по свойству производителя и тип");

            Array.Sort(planes, Plane.ComparatorType);

            ShowTable(); 

        } // SortType

        

        // Сортировка по убыванию количества двигателей
        public void SortEngines() {
            Utils.ShowNavBarTask("  Упорядочить по убыванию количества двигателей");

            Array.Sort(planes, Plane.ComparatorEngine);

            ShowTable();


        } // SortEngines

        // Сортировка по возрастанию расхода горючего
        public void SortConsumption() {
            Utils.ShowNavBarTask("  Упорядочить по возрастанию расхода горючего");

            Array.Sort(planes, Plane.ComparatorConsumption);

            ShowTable();


        } // SortConsumption

        

        private static void ShowTask1()
        {
            string text = @" Proc3. Описать метод Mean(x, y), вычисляющую среднее арифметическое 
              a_mean=(x+y)/2 и среднее геометрическое g_mean=√(x∙y), двух положительных вещественных чисел 
              x и y. Возвращать a_mean, g_mean из метода в кортеже. С помощью этого метода найти среднее 
              арифметическое и среднее геометрическое для трех пар случайных чисел из диапазона значений [0, 10].";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        }

        private static void ShowTask2()
        {
            string text = @" Proc5. Описать метод RectPS(x1, y1, x2, y2), вычисляющую периметр 
             и площадь прямоугольника со сторонами, параллельными осям координат, по координатам 
             (x1, y1), (x2, y2) его противоположных вершин 
             (стороны вычисляются как a = Math.Abs(x2 - x1), b = Math.Abs(y2 – y1)). 
             Метод возвращает кортеж с периметром и площадью. С помощью этого метода найти периметры 
             и площади трех прямоугольников с данными противоположными вершинами.";
            Utils.WriteXY(0, 2, text, ConsoleColor.Gray);
        }

        private void ShowTable()
        {
            Console.WriteLine("\n\n");

            Console.WriteLine("┌─────────────┬─────────────┬────────────────┬──────────────────┬─────────────────────┬");
            Console.WriteLine("│      Тип    │     Pax     │  Расход топлива│   Кол.двигателей │    Авивкомпания     │");
            Console.WriteLine("├─────────────┼─────────────┼────────────────┼──────────────────┼─────────────────────┼");
            foreach(var item in planes)
            {
                Console.WriteLine(item.ToString());
            }
            Console.WriteLine("└─────────────┴─────────────┴────────────────┴──────────────────┴─────────────────────┴");
        }

        private void ShowMaxPax(int maxpax)
        {
            Console.WriteLine("\n\n");

            Console.WriteLine("┌─────────────┬─────────────┬────────────────┬──────────────────┬─────────────────────┬");
            Console.WriteLine("│      Тип    │     Pax     │  Расход топлива│   Кол.двигателей │    Авивкомпания     │");
            Console.WriteLine("├─────────────┼─────────────┼────────────────┼──────────────────┼─────────────────────┼");
            foreach (var item in planes)
            {
                if(item.Pax == maxpax)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    
                }
                Console.WriteLine(item.ToString());
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            Console.WriteLine("└─────────────┴─────────────┴────────────────┴──────────────────┴─────────────────────┴");

        }

       
        

        
        
    } // class App
}