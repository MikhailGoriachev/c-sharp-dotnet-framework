﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuples
{
    class Plane
    {
        private string _type;

        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }

        private int _pax;

        public int Pax
        {
            get { return _pax; }
            set { _pax = value; }
        }

        private double _consumption;

        public double Consumption
        {
            get => _consumption;
            set => _consumption = value <= 0 ? 1 : value;
        }

        private int _engines;

        public int Engines

        {
            get { return _engines; }
            set { _engines = value; }
        }

        private string _airline;

        public string Airline   // x.Airline = "+-+";
        {
            get { return _airline; }
            set => _airline = string.IsNullOrWhiteSpace(value)?"Airlines":value;
        }

        public override string ToString() => $"│ {Type, 11} │ {Pax, 11} │ {Consumption, 14} │ {Engines, 16} │ {Airline, 19} │ ";

        public static int MaxPax(Plane[] planes )
        {
            int maxpax = planes[0].Pax;
            foreach(var item in planes)
            {
                if(item.Pax > maxpax)
                {
                    maxpax = item.Pax;
                }
            }
            return maxpax;
        }

        // компаратор по типу самолета 
        public static int ComparatorType(Plane x, Plane y) => x.Type.CompareTo(y.Type);

        //компаратор по убыванию количества двигателей
        public static int ComparatorEngine(Plane x, Plane y) => y.Engines.CompareTo(x.Engines);

        //компаратор по возрастанию расходов горючего
        public static int ComparatorConsumption(Plane x, Plane y) => x.Consumption.CompareTo(y.Consumption);





    }
}
