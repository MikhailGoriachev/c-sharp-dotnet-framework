﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuples
{
    static class TuplesDemo
    {
        public static (double a, double g) Mean(double x, double y)
        {
            double a_mean = (x + y) / 2;
            double g_mean = Math.Sqrt(x * y);


            return (a_mean, g_mean);
        }

        public static (double a, double b) RectPS(double x1, double x2, double y1, double y2)
        {
            double a = Math.Abs(x2 - x1);
            double b = Math.Abs(y2 - y1);

            double area = a * b;
            double perimetr = 2 * (a + b);

            return (area, perimetr);
        }
    }
}
