﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Задача 1. Разработайте методы в статическом классе TuplesDemo, закодируйте решение задач 
 * 
	Proc3. Описать метод Mean(x, y), вычисляющую среднее арифметическое a_mean=(x+y)/2 и среднее 
    геометрическое g_mean=√(x∙y), двух положительных вещественных чисел x и y. Возвращать a_mean, g_mean 
    из метода в кортеже. С помощью этого метода найти среднее арифметическое и среднее геометрическое 
    для трех пар случайных чисел из диапазона значений [0, 10].

	Proc5. Описать метод RectPS(x1, y1, x2, y2), вычисляющую периметр и площадь прямоугольника со 
    сторонами, параллельными осям координат, по координатам (x1, y1), (x2, y2) его противоположных вершин 
    (стороны вычисляются как a = Math.Abs(x2 - x1), b = Math.Abs(y2 – y1)). Метод возвращает кортеж 
    с периметром и площадью. С помощью этого метода найти периметры и площади трех прямоугольников с 
    данными противоположными вершинами.

   Задача 2. Разработайте класс Самолет со следующими полными свойствами:

	производитель и тип самолета (это одно свойство, например: Ил-76, Boeing 747, …)
	количество пассажирских мест (целое число)
	расход горючего за час полета (вещественное число)
	количество двигателей (целое число)
	название авиакомпании – владельца
В массиве самолетов (не менее 10 элементов) определить самолет/самолеты с максимальным количеством пассажирских мест, упорядочить массив:
	по свойству производитель и тип (!!! это одно свойство !!!)
	по убыванию количества двигателей
	по возрастанию расхода горючего за час полета
Дополнительно
Запись занятия можно скачать по этой ссылке. Материалы занятия – в этом же архиве. 

 */



namespace Tuples
{
    class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 16.09.2021 - введение в ООП на C#: кортежи";
            
            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Proc3" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Proc5" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 2. Создать массив самолетов " },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 2. Определить самолет с максимальным количеством мест" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 2. Упорядочить массив по свойству производителя и тип" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Упорядочить по убыванию количества двигателей" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Упорядочить по возрастанию расхода горючего" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };
            
            // Создание экземпляра класса приложения
            App app = new App();
            
            // главный цикл приложения
            while (true) {
                // настройка цветового оформления
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.Clear();
                Console.CursorVisible = false;
                
                Utils.ShowNavBarTask("  Введение в ООП C# - работа с кортежами");
                Utils.ShowMenu(12, 5, "Меню приложения для работы с кортежами", menu);
                
                // получить код нажатой клавиши, не отображать символ клавиши
                ConsoleKey key = Console.ReadKey(true).Key;
                Console.Clear();
                
                switch (key) {
                    // Задача Proc3
                    case ConsoleKey.Q:
                        app.Proc3();
                        break;

                    // Proc5
                    case ConsoleKey.W:
                        app.Proc5();
                        break;

                    // Создание массивов самолетов
                    case ConsoleKey.E:
                        app.PlaneInitialise();
                        break;

                    // Поиск самолета с максимальным количеством пассажиров
                    case ConsoleKey.R:
                        app.MaxPassengers();
                        break;
                    
                    // Сортировка по типу самолета
                    case ConsoleKey.T:
                        app.SortType();
                        break;
                    
                    
                    // Сортировка по количеству двигателей
                    case ConsoleKey.A:
                        app.SortEngines();
                        break;
                    
                    // Сортировка по потреблению топлива
                    case ConsoleKey.S:
                        app.SortConsumption();
                        break;
                   
                    
                    // выход из приложения назначен на клавишу F10 или кавишу Z
                    case ConsoleKey.F10:
                    case ConsoleKey.Z:
                        Console.ResetColor();   // сброс цветового сочетания к исходному
                        Console.Clear();
                        Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                        Console.CursorVisible = true;
                        return;
                    
                    default:
                        continue;
                } // switch
                
                // Ожидать нажатия любой клавиши по окончании работы пункта меню
                Console.CursorVisible = true;
                Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                Console.ReadKey(true);
            } // while
        } // Main
    } // class Program
}
